The name of this directory stands for **et cetera**, not for
**exceptionally terrifying configurations**! It is not meant
to be an overlay over the linux `/etc` directory, instead its just
a random collection of configs and scripts that are useful for iptsd.
