<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="el">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="72"/>
        <source>installation</source>
        <translation>Εγκατάσταση</translation>
    </message>
    <message>
        <location filename="../show.qml" line="73"/>
        <source>After creating your chosen disk setup in the first 10 % the full copying of the ISO will take the longest of this install phase and will run until approximately 45%.</source>
        <translation>Μετά τη δημιουργία την επιλεγμένη διαμόρφωσης του δίσκου σας στα πρώτα 10% η πλήρη αντιγραφή του ISO θα διαρκέσει το μεγαλύτερο χρόνο αυτής της φάσης και θα εκτελείτε ως περίπου το 45%.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="76"/>
        <source>modules</source>
        <translation>αρθρώματα</translation>
    </message>
    <message>
        <location filename="../show.qml" line="77"/>
        <source>Once the ISO is copied some 25 post-install modules will run. This includes setting user specific options, removing Live Session only packages and adjusting hardware setup.</source>
        <translation>Μόλις ολοκληρωθεί η αντιγραφή του ISO θα εκτελεστούν περίπου 25 αρθρώματα μετεγκατάστασης. Αυτό περιλαμβάνει διαμόρφωση των επιλογών του χρήστη, αφαίρεση πακέτων που χρησιμοποιήθηκαν από τη ζωντανή συνεδρία και ρύθμιση του εξοπλισμού σας.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="80"/>
        <source>office suites</source>
        <translation>Σουίτες Γραφείου</translation>
    </message>
    <message>
        <location filename="../show.qml" line="81"/>
        <source>The default Office Suite is LibreOffice.</source>
        <translation>Η προεπιλεγμένη σουίτα γραφείου είναι το LibreOffice.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="82"/>
        <source>Calligra is available in the repositories</source>
        <translation>Το Calligra είναι διαθέσιμο στα αποθετήρια</translation>
    </message>
    <message>
        <location filename="../show.qml" line="85"/>
        <source>Package Management</source>
        <translation>Διαχείριση πακέτων</translation>
    </message>
    <message>
        <location filename="../show.qml" line="86"/>
        <source>For package management Octopi is the GUI application.</source>
        <translation>Το Octopi είναι η γραφική εφαρμογή για τη διαχείριση πακέτων.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="87"/>
        <source>Pacman is the cli application.</source>
        <translation>Το Pacman είναι η εφαρμογή του τερματικού.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="90"/>
        <source>internet</source>
        <translation>διαδίκτυο</translation>
    </message>
    <message>
        <location filename="../show.qml" line="91"/>
        <source>Qt/KDE specific internet applications include the Falkon web-browser, KDE Connect for device Synchronization, Kaidan for chat  and NeoChat, the Matrix client.</source>
        <translation>Qt/KDE εφαρμογές για το διαδίκτυο περιλαμβάνουν τον Περιηγητή ιστού Falkon, KDE connect για συγχρονισμό κινητών συσκευών, Kaidan για συνομιλίες και NeoChat ως πρόγραμμα πελάτη για το Matrix.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="94"/>
        <source>enjoy</source>
        <translation>απολαύστε</translation>
    </message>
    <message>
        <location filename="../show.qml" line="95"/>
        <source>May using KaOS be a pleasant experience for you.</source>
        <translation>Ας είναι η χρήση του KaOS να είναι μια ευχάριστη εμπειρία για εσάς.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="96"/>
        <source>Don&apos;t hesitate to give your opinion about KaOS in the Forum</source>
        <translation>Μη διστάσετε να μάς δώσετε τη γνώμη σας για το KaOS στο Forum</translation>
    </message>
</context>
</TS>