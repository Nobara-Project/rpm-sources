<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="it">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="72"/>
        <source>installation</source>
        <translation>installazione</translation>
    </message>
    <message>
        <location filename="../show.qml" line="73"/>
        <source>After creating your chosen disk setup in the first 10 % the full copying of the ISO will take the longest of this install phase and will run until approximately 45%.</source>
        <translation>Dopo aver creato la configurazione del disco nel primo 10%, la copia completa dell&apos;ISO richiede la maggior parte del tempo e durerà fino al 45% circa.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="76"/>
        <source>modules</source>
        <translation>moduli</translation>
    </message>
    <message>
        <location filename="../show.qml" line="77"/>
        <source>Once the ISO is copied some 25 post-install modules will run. This includes setting user specific options, removing Live Session only packages and adjusting hardware setup.</source>
        <translation>Una volta copiata la ISO, verranno eseguiti circa 25 moduli post-installazione. Questi includono l&apos;impostazione di opzioni specifiche per l&apos;utente, la rimozione di pacchetti riservati alla sessione Live e l&apos;ottimizzazione della configurazione hardware.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="80"/>
        <source>office suites</source>
        <translation>suite office</translation>
    </message>
    <message>
        <location filename="../show.qml" line="81"/>
        <source>The default Office Suite is LibreOffice.</source>
        <translation>La suite office predefinita è LibreOffice.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="82"/>
        <source>Calligra is available in the repositories</source>
        <translation>Calligra è disponibile nei repository.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="85"/>
        <source>Package Management</source>
        <translation>Gestione pacchetti</translation>
    </message>
    <message>
        <location filename="../show.qml" line="86"/>
        <source>For package management Octopi is the GUI application.</source>
        <translation>L&apos;applicazione grafica per la gestione dei pacchetti è Octopi.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="87"/>
        <source>Pacman is the cli application.</source>
        <translation>Il gestore da terminale è pacman.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="90"/>
        <source>internet</source>
        <translation>internet</translation>
    </message>
    <message>
        <location filename="../show.qml" line="91"/>
        <source>Qt/KDE specific internet applications include the Falkon web-browser, KDE Connect for device Synchronization, Kaidan for chat  and NeoChat, the Matrix client.</source>
        <translation>Le applicazioni internet Qt/KDE comprendono il browser web Falkon, KDE Connect per la sincronizzazione dei dispositivi, Kaidan per le chat e NeoChat, il client Matrix.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="94"/>
        <source>enjoy</source>
        <translation>divertiti</translation>
    </message>
    <message>
        <location filename="../show.qml" line="95"/>
        <source>May using KaOS be a pleasant experience for you.</source>
        <translation>Speriamo che usare KaOS sia una piacevole esperienza per te.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="96"/>
        <source>Don&apos;t hesitate to give your opinion about KaOS in the Forum</source>
        <translation>Non esitare a raccontarci la tua opinione su KaOS nel forum.</translation>
    </message>
</context>
</TS>