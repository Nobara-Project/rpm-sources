<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ru">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="72"/>
        <source>installation</source>
        <translation>установка</translation>
    </message>
    <message>
        <location filename="../show.qml" line="73"/>
        <source>After creating your chosen disk setup in the first 10 % the full copying of the ISO will take the longest of this install phase and will run until approximately 45%.</source>
        <translation>После создания выбранной вами настройки диска на первых 10 %, производится полное копирование ISO, занимающее больше всего времени на этом этапе установки и будет выполняться примерно до 45 %.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="76"/>
        <source>modules</source>
        <translation>модули</translation>
    </message>
    <message>
        <location filename="../show.qml" line="77"/>
        <source>Once the ISO is copied some 25 post-install modules will run. This includes setting user specific options, removing Live Session only packages and adjusting hardware setup.</source>
        <translation>После копирования ISO будут запущены около 25 постустановочных модулей. Этап включает в себя настройку параметров пользователя, удаление пакетов Live-сеанса и настройку оборудования.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="80"/>
        <source>office suites</source>
        <translation>офисные пакеты</translation>
    </message>
    <message>
        <location filename="../show.qml" line="81"/>
        <source>The default Office Suite is LibreOffice.</source>
        <translation>Офисный пакет по умолчанию — LibreOffice.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="82"/>
        <source>Calligra is available in the repositories</source>
        <translation>Пакет Calligra доступен в репозиториях</translation>
    </message>
    <message>
        <location filename="../show.qml" line="85"/>
        <source>Package Management</source>
        <translation>Управление пакетами</translation>
    </message>
    <message>
        <location filename="../show.qml" line="86"/>
        <source>For package management Octopi is the GUI application.</source>
        <translation>Для управления пакетами используется Octopi, приложение с графическим интерфейсом.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="87"/>
        <source>Pacman is the cli application.</source>
        <translation>Pacman — это CLI-приложение.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="90"/>
        <source>internet</source>
        <translation>интернет</translation>
    </message>
    <message>
        <location filename="../show.qml" line="91"/>
        <source>Qt/KDE specific internet applications include the Falkon web-browser, KDE Connect for device Synchronization, Kaidan for chat  and NeoChat, the Matrix client.</source>
        <translation>Специальные интернет-приложения Qt/KDE включают в себя веб-браузер Falkon, KDE Connect для синхронизации устройств, Kaidan для чата и NeoChat, клиент Matrix.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="94"/>
        <source>enjoy</source>
        <translation>наслаждайтесь</translation>
    </message>
    <message>
        <location filename="../show.qml" line="95"/>
        <source>May using KaOS be a pleasant experience for you.</source>
        <translation>Возможно использование KaOS, будет для Вас приятным опытом.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="96"/>
        <source>Don&apos;t hesitate to give your opinion about KaOS in the Forum</source>
        <translation>Не стесняйтесь высказывать свое мнение о KaOS на форуме</translation>
    </message>
</context>
</TS>