<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="id_ID">
<context>
    <name>show</name>
    <message>
        <location filename="../show.qml" line="72"/>
        <source>installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="73"/>
        <source>After creating your chosen disk setup in the first 10 % the full copying of the ISO will take the longest of this install phase and will run until approximately 45%.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="76"/>
        <source>modules</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="77"/>
        <source>Once the ISO is copied some 25 post-install modules will run. This includes setting user specific options, removing Live Session only packages and adjusting hardware setup.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="80"/>
        <source>office suites</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="81"/>
        <source>The default Office Suite is LibreOffice.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="82"/>
        <source>Calligra is available in the repositories</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="85"/>
        <source>Package Management</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="86"/>
        <source>For package management Octopi is the GUI application.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="87"/>
        <source>Pacman is the cli application.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="90"/>
        <source>internet</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="91"/>
        <source>Qt/KDE specific internet applications include the Falkon web-browser, KDE Connect for device Synchronization, Kaidan for chat  and NeoChat, the Matrix client.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="94"/>
        <source>enjoy</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../show.qml" line="95"/>
        <source>May using KaOS be a pleasant experience for you.</source>
        <translation>Mungkin menggunakan KaOS menjadi pengalaman yang menyenangkan bagimu.</translation>
    </message>
    <message>
        <location filename="../show.qml" line="96"/>
        <source>Don&apos;t hesitate to give your opinion about KaOS in the Forum</source>
        <translation type="unfinished"/>
    </message>
</context>
</TS>