# Wine Cellar
[![Project License](https://img.shields.io/github/license/FlashyReese/decky-wine-cellar?style=flat-square)](LICENSE)
[![Support Server](https://img.shields.io/discord/748363294749753484.svg?color=7289da&label=FlashyReese&logo=discord&style=flat-square)](https://discord.gg/MPHVG6MH4e)

A Decky Loader plugin to manage Steam Play compatibility tools.

## License
Wine Cellar is licensed under MIT, a free and open-source license. For more information, please see the [license file](LICENSE).
