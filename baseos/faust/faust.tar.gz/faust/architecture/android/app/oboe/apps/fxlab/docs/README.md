# Docs for Android FX Lab

* [How to Build the App](Dev-Guide.md)
* [Slides for Internal Architecture (PDF)](Presentation.pdf)
