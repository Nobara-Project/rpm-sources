//! NetworkManager D-Bus Client
//!
//! Provides access to NetworkManager daemon for network status monitoring and control.
//! Uses D-Bus to communicate with the NetworkManager service on the system bus.
//!
//! D-Bus Service: org.freedesktop.NetworkManager

const std = @import("std");
const Allocator = std.mem.Allocator;
const posix = std.posix;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const c = dbus.types.c;

const log = std.log.scoped(.network_manager);

/// D-Bus service constants
const nm_service = "org.freedesktop.NetworkManager";
const nm_path = "/org/freedesktop/NetworkManager";
const nm_interface = "org.freedesktop.NetworkManager";
const device_interface = "org.freedesktop.NetworkManager.Device";
const wireless_interface = "org.freedesktop.NetworkManager.Device.Wireless";
const ap_interface = "org.freedesktop.NetworkManager.AccessPoint";
const active_conn_interface = "org.freedesktop.NetworkManager.Connection.Active";
const ip4_interface = "org.freedesktop.NetworkManager.IP4Config";
const statistics_interface = "org.freedesktop.NetworkManager.Device.Statistics";
const settings_interface = "org.freedesktop.NetworkManager.Settings";
const settings_conn_interface = "org.freedesktop.NetworkManager.Settings.Connection";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// NM connectivity state
pub const NmState = enum(u32) {
    unknown = 0,
    asleep = 10,
    disconnected = 20,
    disconnecting = 30,
    connecting = 40,
    connected_local = 50,
    connected_site = 60,
    connected_global = 70,
    _,
};

/// Network device type
pub const DeviceType = enum(u32) {
    unknown = 0,
    ethernet = 1,
    wifi = 2,
    bluetooth = 5,
    wireguard = 14,
    _,
};

/// Network device state
pub const DeviceState = enum(u32) {
    unknown = 0,
    unmanaged = 10,
    unavailable = 20,
    disconnected = 30,
    prepare = 40,
    config_state = 50,
    need_auth = 60,
    ip_config = 70,
    ip_check = 80,
    secondaries = 90,
    activated = 100,
    deactivating = 110,
    failed = 120,
    _,
};

/// Active connection information (fixed-buffer, no heap)
pub const ConnectionInfo = struct {
    name: [64]u8 = undefined,
    name_len: usize = 0,
    iface_name: [64]u8 = undefined,
    iface_name_len: usize = 0,
    device_type: DeviceType = .unknown,
    device_state: DeviceState = .unknown,
    wifi_strength: u8 = 0,
    ssid: [32]u8 = undefined,
    ssid_len: usize = 0,
    wifi_freq: u32 = 0,
    is_vpn: bool = false,
    rx_bytes: u64 = 0,
    tx_bytes: u64 = 0,
    ip_address: [46]u8 = undefined,
    ip_address_len: usize = 0,
    device_path: [256]u8 = undefined,
    device_path_len: usize = 0,
    active_conn_path: [256]u8 = undefined,
    active_conn_path_len: usize = 0,

    pub fn getName(self: *const ConnectionInfo) []const u8 {
        return self.name[0..self.name_len];
    }

    pub fn getIfaceName(self: *const ConnectionInfo) []const u8 {
        return self.iface_name[0..self.iface_name_len];
    }

    pub fn getSsid(self: *const ConnectionInfo) []const u8 {
        return self.ssid[0..self.ssid_len];
    }

    pub fn getIpAddress(self: *const ConnectionInfo) []const u8 {
        return self.ip_address[0..self.ip_address_len];
    }

    pub fn getDevicePath(self: *const ConnectionInfo) []const u8 {
        return self.device_path[0..self.device_path_len];
    }

    pub fn getActiveConnPath(self: *const ConnectionInfo) []const u8 {
        return self.active_conn_path[0..self.active_conn_path_len];
    }

    /// Get WiFi signal level 0-4 using branchless thresholds (20/40/60/80)
    pub fn getSignalLevel(self: *const ConnectionInfo) u8 {
        const s = self.wifi_strength;
        return @as(u8, @intFromBool(s >= 20)) +
            @as(u8, @intFromBool(s >= 40)) +
            @as(u8, @intFromBool(s >= 60)) +
            @as(u8, @intFromBool(s >= 80));
    }
};

/// WiFi network scan result (fixed-buffer, no heap)
pub const WifiNetwork = struct {
    ssid: [32]u8 = undefined,
    ssid_len: usize = 0,
    strength: u8 = 0,
    frequency: u32 = 0,
    secured: bool = false,
    ap_path: [256]u8 = undefined,
    ap_path_len: usize = 0,

    pub fn getSsid(self: *const WifiNetwork) []const u8 {
        return self.ssid[0..self.ssid_len];
    }

    pub fn getApPath(self: *const WifiNetwork) []const u8 {
        return self.ap_path[0..self.ap_path_len];
    }
};

/// Saved/known connection (fixed-buffer, no heap)
pub const SavedConnection = struct {
    name: [64]u8 = undefined,
    name_len: usize = 0,
    conn_type: [32]u8 = undefined,
    conn_type_len: usize = 0,
    conn_path: [256]u8 = undefined,
    conn_path_len: usize = 0,
    is_vpn: bool = false,

    pub fn getName(self: *const SavedConnection) []const u8 {
        return self.name[0..self.name_len];
    }

    pub fn getConnType(self: *const SavedConnection) []const u8 {
        return self.conn_type[0..self.conn_type_len];
    }

    pub fn getConnPath(self: *const SavedConnection) []const u8 {
        return self.conn_path[0..self.conn_path_len];
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscription = struct {
    callback: StateChangeFn,
    context: ?*anyopaque,
};

pub const Error = dbus.types.Error || error{
    ParseError,
};

pub const NetworkManager = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    subscriptions: [max_subscribers]?Subscription = .{null} ** max_subscribers,
    subscription_count: usize = 0,

    connections: [8]?ConnectionInfo = .{null} ** 8,
    connection_count: usize = 0,

    wifi_networks: [32]?WifiNetwork = .{null} ** 32,
    wifi_network_count: usize = 0,

    saved_connections: [32]?SavedConnection = .{null} ** 32,
    saved_connection_count: usize = 0,

    state: NmState = .unknown,
    wireless_enabled: bool = false,
    available: bool = false,

    /// Aggregate byte counters across all active devices (from Device.Statistics)
    total_rx_bytes: u64 = 0,
    total_tx_bytes: u64 = 0,

    /// Cached WiFi device path (discovered via GetDevices, persists across disconnects)
    wifi_device_path: [256]u8 = undefined,
    wifi_device_path_len: usize = 0,

    /// Initialize the NetworkManager client.
    /// Connects to the system D-Bus.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location
    /// to enable D-Bus signal handling.
    pub fn init(allocator: Allocator) Error!NetworkManager {
        var conn = try dbus.Connection.open(allocator, .system);
        errdefer conn.deinit();

        var self = NetworkManager{
            .connection = conn,
            .allocator = allocator,
        };

        self.refresh() catch |err| {
            switch (err) {
                dbus.types.Error.ServiceUnknown, dbus.types.Error.NameHasNoOwner => {
                    log.info("NetworkManager service not available", .{});
                    self.available = false;
                    return self;
                },
                else => {
                    log.warn("Failed to load initial state: {s}", .{@errorName(err)});
                },
            }
        };

        return self;
    }

    /// Start monitoring for D-Bus property changes.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *NetworkManager) void {
        self.subscribeToSignals() catch |err| {
            log.warn("Failed to subscribe to signals: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *NetworkManager) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const NetworkManager) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    /// Returns true if there are more messages to process.
    pub fn process(self: *NetworkManager) bool {
        return self.connection.process();
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *NetworkManager, callback: StateChangeFn, context: ?*anyopaque) bool {
        if (self.subscription_count >= max_subscribers) return false;

        for (&self.subscriptions) |*slot| {
            if (slot.* == null) {
                slot.* = .{ .callback = callback, .context = context };
                self.subscription_count += 1;
                return true;
            }
        }
        return false;
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *NetworkManager, callback: StateChangeFn, context: ?*anyopaque) void {
        for (&self.subscriptions) |*slot| {
            if (slot.*) |sub| {
                if (sub.callback == callback and sub.context == context) {
                    slot.* = null;
                    self.subscription_count -|= 1;
                    return;
                }
            }
        }
    }

    /// Check if NM reports global connectivity.
    pub fn isConnected(self: *const NetworkManager) bool {
        return self.state == .connected_global;
    }

    /// Get the device type of the first active (non-VPN) connection.
    pub fn getPrimaryType(self: *const NetworkManager) DeviceType {
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (!conn.is_vpn) return conn.device_type;
            }
        }
        return .unknown;
    }

    /// Get the WiFi device object path (for activateConnection calls).
    pub fn getWifiDevicePath(self: *NetworkManager) ?[:0]const u8 {
        return self.findWifiDevicePath();
    }

    /// Get saved connections slice.
    pub fn getSavedConnections(self: *const NetworkManager) []const ?SavedConnection {
        return self.saved_connections[0..self.saved_connection_count];
    }

    /// Get WiFi signal strength of the first active WiFi connection.
    pub fn getWifiStrength(self: *const NetworkManager) u8 {
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (conn.device_type == .wifi) return conn.wifi_strength;
            }
        }
        return 0;
    }

    /// Get active connections slice.
    pub fn getConnections(self: *const NetworkManager) []const ?ConnectionInfo {
        return self.connections[0..self.connection_count];
    }

    /// Get scanned WiFi networks slice.
    pub fn getWifiNetworks(self: *const NetworkManager) []const ?WifiNetwork {
        return self.wifi_networks[0..self.wifi_network_count];
    }

    /// Re-read byte counters from Device.Statistics for all active devices.
    /// Lightweight poll — does NOT re-enumerate connections.
    pub fn refreshStatistics(self: *NetworkManager) void {
        if (!self.available) return;

        var rx_total: u64 = 0;
        var tx_total: u64 = 0;

        for (self.connections[0..self.connection_count]) |*maybe_conn| {
            if (maybe_conn.*) |*conn| {
                if (conn.is_vpn) continue;
                if (conn.device_path_len <= 1) continue;

                var path_buf: [256:0]u8 = undefined;
                const path_z = toSentinel(&path_buf, conn.device_path[0..conn.device_path_len]) orelse continue;

                // RxBytes
                {
                    var msg = self.connection.getProperty(nm_service, path_z, statistics_interface, "RxBytes") catch continue;
                    defer msg.unref();
                    if (msg.enterVariant("t") catch false) {
                        conn.rx_bytes = msg.readUint64() catch conn.rx_bytes;
                        msg.exitContainer() catch {};
                    }
                }

                // TxBytes
                {
                    var msg = self.connection.getProperty(nm_service, path_z, statistics_interface, "TxBytes") catch continue;
                    defer msg.unref();
                    if (msg.enterVariant("t") catch false) {
                        conn.tx_bytes = msg.readUint64() catch conn.tx_bytes;
                        msg.exitContainer() catch {};
                    }
                }

                rx_total += conn.rx_bytes;
                tx_total += conn.tx_bytes;
            }
        }

        self.total_rx_bytes = rx_total;
        self.total_tx_bytes = tx_total;
    }

    // --- Actions ---

    /// Activate a connection. Use "/" for unspecified paths.
    pub fn activateConnection(
        self: *NetworkManager,
        conn_path_z: [:0]const u8,
        device_path_z: [:0]const u8,
        specific_object_z: [:0]const u8,
    ) void {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        const ret = c.sd_bus_call_method(
            self.connection.bus,
            nm_service,
            nm_path,
            nm_interface,
            "ActivateConnection",
            &err,
            &reply,
            "ooo",
            conn_path_z.ptr,
            device_path_z.ptr,
            specific_object_z.ptr,
        );

        defer c.sd_bus_error_free(&err);
        if (reply) |r| _ = c.sd_bus_message_unref(r);

        if (ret < 0) {
            if (err.name != null) {
                log.warn("ActivateConnection failed: {s}", .{std.mem.span(err.name)});
            }
        }
    }

    /// Deactivate an active connection by its active connection path.
    pub fn deactivateConnection(self: *NetworkManager, active_conn_path_z: [:0]const u8) void {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        const ret = c.sd_bus_call_method(
            self.connection.bus,
            nm_service,
            nm_path,
            nm_interface,
            "DeactivateConnection",
            &err,
            &reply,
            "o",
            active_conn_path_z.ptr,
        );

        defer c.sd_bus_error_free(&err);
        if (reply) |r| _ = c.sd_bus_message_unref(r);

        if (ret < 0) {
            if (err.name != null) {
                log.warn("DeactivateConnection failed: {s}", .{std.mem.span(err.name)});
            }
        }
    }

    /// Enable or disable wireless networking.
    pub fn setWirelessEnabled(self: *NetworkManager, enabled: bool) void {
        // Properties.Set with boolean variant requires raw sd-bus
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        const val: c_int = @intFromBool(enabled);
        const ret = c.sd_bus_call_method(
            self.connection.bus,
            nm_service,
            nm_path,
            "org.freedesktop.DBus.Properties",
            "Set",
            &err,
            &reply,
            "ssv",
            nm_interface.ptr,
            @as([*:0]const u8, "WirelessEnabled"),
            @as([*:0]const u8, "b"),
            val,
        );

        defer c.sd_bus_error_free(&err);
        if (reply) |r| _ = c.sd_bus_message_unref(r);

        if (ret < 0) {
            if (err.name != null) {
                log.warn("SetWirelessEnabled failed: {s}", .{std.mem.span(err.name)});
            }
        }
    }

    /// Request a WiFi scan on the first wireless device found.
    pub fn requestWifiScan(self: *NetworkManager) void {
        // Find a WiFi device path from active connections
        const wifi_device = self.findWifiDevicePath() orelse {
            log.debug("No WiFi device found for scan", .{});
            return;
        };

        // RequestScan(a{sv}) — empty dict
        var msg: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        const ret = c.sd_bus_message_new_method_call(
            self.connection.bus,
            &msg,
            nm_service,
            wifi_device.ptr,
            wireless_interface,
            "RequestScan",
        );
        if (ret < 0 or msg == null) {
            log.debug("Failed to create RequestScan message", .{});
            return;
        }

        // Open empty a{sv} container
        if (c.sd_bus_message_open_container(msg.?, 'a', "{sv}") < 0) {
            _ = c.sd_bus_message_unref(msg.?);
            return;
        }
        if (c.sd_bus_message_close_container(msg.?) < 0) {
            _ = c.sd_bus_message_unref(msg.?);
            return;
        }

        var reply: ?*c.sd_bus_message = null;
        const call_ret = c.sd_bus_call(self.connection.bus, msg.?, 0, &err, &reply);
        _ = c.sd_bus_message_unref(msg.?);

        defer c.sd_bus_error_free(&err);
        if (reply) |r| _ = c.sd_bus_message_unref(r);

        if (call_ret < 0) {
            if (err.name != null) {
                log.debug("RequestScan failed: {s}", .{std.mem.span(err.name)});
            }
        }
    }

    /// Refresh the list of available WiFi networks from access points.
    pub fn refreshWifiNetworks(self: *NetworkManager) void {
        self.wifi_network_count = 0;

        const wifi_device = self.findWifiDevicePath() orelse return;

        // GetAccessPoints on the wireless device
        var reply_msg = self.connection.callMethod(
            nm_service,
            wifi_device,
            wireless_interface,
            "GetAccessPoints",
        ) catch return;
        defer reply_msg.unref();

        if (reply_msg.enterArray("o") catch false) {
            while (!reply_msg.atEnd() and self.wifi_network_count < 32) {
                const ap_path = reply_msg.readObjectPath() catch continue;
                var net = WifiNetwork{};
                self.readApProperties(ap_path, &net);
                if (net.ssid_len > 0) {
                    self.wifi_networks[self.wifi_network_count] = net;
                    self.wifi_network_count += 1;
                }
            }
            reply_msg.exitContainer() catch {};
        }
    }

    /// Refresh the list of saved/known connections.
    pub fn refreshSavedConnections(self: *NetworkManager) void {
        self.saved_connection_count = 0;

        var msg = self.connection.callMethod(
            nm_service,
            "/org/freedesktop/NetworkManager/Settings",
            settings_interface,
            "ListConnections",
        ) catch return;
        defer msg.unref();

        if (msg.enterArray("o") catch false) {
            while (!msg.atEnd() and self.saved_connection_count < 32) {
                const conn_path = msg.readObjectPath() catch continue;
                var saved = SavedConnection{};
                copyFixedBuf(&saved.conn_path, &saved.conn_path_len, conn_path);
                self.readSavedConnectionSettings(conn_path, &saved);
                self.saved_connections[self.saved_connection_count] = saved;
                self.saved_connection_count += 1;
            }
            msg.exitContainer() catch {};
        }
    }

    // --- Internal ---

    fn refresh(self: *NetworkManager) Error!void {
        self.refreshState() catch |err| {
            // Propagate service-not-found errors for init to handle
            switch (err) {
                dbus.types.Error.ServiceUnknown, dbus.types.Error.NameHasNoOwner => return err,
                else => {
                    log.debug("Failed to get NM state: {s}", .{@errorName(err)});
                },
            }
        };

        self.refreshWirelessEnabled() catch |err| {
            log.debug("Failed to get WirelessEnabled: {s}", .{@errorName(err)});
        };

        self.refreshActiveConnections() catch |err| {
            switch (err) {
                dbus.types.Error.ServiceUnknown, dbus.types.Error.NameHasNoOwner => return err,
                else => {
                    log.debug("Failed to get active connections: {s}", .{@errorName(err)});
                },
            }
        };

        self.available = true;
    }

    fn refreshState(self: *NetworkManager) Error!void {
        var msg = try self.connection.getProperty(nm_service, nm_path, nm_interface, "State");
        defer msg.unref();

        if (try msg.enterVariant("u")) {
            const val = msg.readUint32() catch return;
            self.state = @enumFromInt(val);
            try msg.exitContainer();
        }
    }

    fn refreshWirelessEnabled(self: *NetworkManager) Error!void {
        var msg = try self.connection.getProperty(nm_service, nm_path, nm_interface, "WirelessEnabled");
        defer msg.unref();

        if (try msg.enterVariant("b")) {
            self.wireless_enabled = msg.readBool() catch false;
            try msg.exitContainer();
        }
    }

    fn refreshActiveConnections(self: *NetworkManager) Error!void {
        self.connection_count = 0;

        var msg = try self.connection.getProperty(nm_service, nm_path, nm_interface, "ActiveConnections");
        defer msg.unref();

        if (try msg.enterVariant("ao")) {
            if (try msg.enterArray("o")) {
                while (!msg.atEnd() and self.connection_count < 8) {
                    const conn_path = msg.readObjectPath() catch continue;

                    var info = ConnectionInfo{};
                    copyFixedBuf(&info.active_conn_path, &info.active_conn_path_len, conn_path);
                    self.readActiveConnectionProperties(conn_path, &info);
                    self.connections[self.connection_count] = info;
                    self.connection_count += 1;
                }
                try msg.exitContainer();
            }
            try msg.exitContainer();
        }

        // Aggregate byte counters across all active devices
        var rx_total: u64 = 0;
        var tx_total: u64 = 0;
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (!conn.is_vpn) {
                    rx_total += conn.rx_bytes;
                    tx_total += conn.tx_bytes;
                }
            }
        }
        self.total_rx_bytes = rx_total;
        self.total_tx_bytes = tx_total;

        log.debug("Found {d} active connection(s), state={d}", .{
            self.connection_count,
            @intFromEnum(self.state),
        });
    }

    fn readActiveConnectionProperties(self: *NetworkManager, conn_path: []const u8, info: *ConnectionInfo) void {
        var path_buf: [256:0]u8 = undefined;
        const path_z = toSentinel(&path_buf, conn_path) orelse return;

        // Id (connection name)
        self.readPropString(path_z, active_conn_interface, "Id", &info.name, &info.name_len);

        // Vpn
        self.readPropBool(path_z, active_conn_interface, "Vpn", &info.is_vpn);

        // Devices — array of object paths
        var dev_msg = self.connection.getProperty(nm_service, path_z, active_conn_interface, "Devices") catch return;
        defer dev_msg.unref();

        if (dev_msg.enterVariant("ao") catch false) {
            if (dev_msg.enterArray("o") catch false) {
                if (!dev_msg.atEnd()) {
                    const dev_path = dev_msg.readObjectPath() catch {
                        dev_msg.exitContainer() catch {};
                        dev_msg.exitContainer() catch {};
                        return;
                    };
                    copyFixedBuf(&info.device_path, &info.device_path_len, dev_path);
                    self.readDeviceProperties(dev_path, info);
                }
                dev_msg.exitContainer() catch {};
            }
            dev_msg.exitContainer() catch {};
        }
    }

    fn readDeviceProperties(self: *NetworkManager, dev_path: []const u8, info: *ConnectionInfo) void {
        var path_buf: [256:0]u8 = undefined;
        const path_z = toSentinel(&path_buf, dev_path) orelse return;

        // DeviceType
        {
            var msg = self.connection.getProperty(nm_service, path_z, device_interface, "DeviceType") catch return;
            defer msg.unref();
            if (msg.enterVariant("u") catch false) {
                const val = msg.readUint32() catch 0;
                info.device_type = @enumFromInt(val);
                msg.exitContainer() catch {};
            }
        }

        // State
        {
            var msg = self.connection.getProperty(nm_service, path_z, device_interface, "State") catch return;
            defer msg.unref();
            if (msg.enterVariant("u") catch false) {
                const val = msg.readUint32() catch 0;
                info.device_state = @enumFromInt(val);
                msg.exitContainer() catch {};
            }
        }

        // Interface name
        self.readPropString(path_z, device_interface, "Interface", &info.iface_name, &info.iface_name_len);

        // WiFi-specific properties
        if (info.device_type == .wifi) {
            self.readWifiProperties(path_z, info);
        }

        // IP address
        self.readIpAddress(path_z, info);

        // Device.Statistics — RxBytes/TxBytes
        self.readDeviceStatistics(path_z, info);
    }

    fn readDeviceStatistics(self: *NetworkManager, device_path_z: [:0]const u8, info: *ConnectionInfo) void {
        // Enable statistics refresh (1000ms = 1 second polling)
        self.enableDeviceStatistics(device_path_z);

        // RxBytes (u64)
        {
            var msg = self.connection.getProperty(nm_service, device_path_z, statistics_interface, "RxBytes") catch return;
            defer msg.unref();
            if (msg.enterVariant("t") catch false) {
                info.rx_bytes = msg.readUint64() catch 0;
                msg.exitContainer() catch {};
            }
        }

        // TxBytes (u64)
        {
            var msg = self.connection.getProperty(nm_service, device_path_z, statistics_interface, "TxBytes") catch return;
            defer msg.unref();
            if (msg.enterVariant("t") catch false) {
                info.tx_bytes = msg.readUint64() catch 0;
                msg.exitContainer() catch {};
            }
        }
    }

    fn enableDeviceStatistics(self: *NetworkManager, device_path_z: [:0]const u8) void {
        // Set RefreshRateMs to 1000ms to enable statistics tracking
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        const refresh_rate: u32 = 1000;
        const ret = c.sd_bus_call_method(
            self.connection.bus,
            nm_service,
            device_path_z.ptr,
            "org.freedesktop.DBus.Properties",
            "Set",
            &err,
            &reply,
            "ssv",
            statistics_interface.ptr,
            @as([*:0]const u8, "RefreshRateMs"),
            @as([*:0]const u8, "u"),
            refresh_rate,
        );

        defer c.sd_bus_error_free(&err);
        if (reply) |r| _ = c.sd_bus_message_unref(r);

        if (ret < 0) {
            // Not critical — statistics just won't auto-update
            log.debug("Failed to enable device statistics refresh", .{});
        }
    }

    fn readWifiProperties(self: *NetworkManager, device_path_z: [:0]const u8, info: *ConnectionInfo) void {
        // ActiveAccessPoint
        var ap_msg = self.connection.getProperty(nm_service, device_path_z, wireless_interface, "ActiveAccessPoint") catch return;
        defer ap_msg.unref();

        if (ap_msg.enterVariant("o") catch false) {
            const ap_path = ap_msg.readObjectPath() catch {
                ap_msg.exitContainer() catch {};
                return;
            };
            ap_msg.exitContainer() catch {};

            // Skip if no active AP (path is "/" or empty)
            if (ap_path.len <= 1) return;

            var ap_buf: [256:0]u8 = undefined;
            const ap_z = toSentinel(&ap_buf, ap_path) orelse return;

            // Strength (byte)
            {
                var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Strength") catch return;
                defer msg.unref();
                if (msg.enterVariant("y") catch false) {
                    info.wifi_strength = msg.readByte() catch 0;
                    msg.exitContainer() catch {};
                }
            }

            // Ssid (byte array)
            {
                var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Ssid") catch return;
                defer msg.unref();
                if (msg.enterVariant("ay") catch false) {
                    if (msg.enterArray("y") catch false) {
                        var i: usize = 0;
                        while (!msg.atEnd() and i < 32) {
                            info.ssid[i] = msg.readByte() catch break;
                            i += 1;
                        }
                        info.ssid_len = i;
                        msg.exitContainer() catch {};
                    }
                    msg.exitContainer() catch {};
                }
            }

            // Frequency
            {
                var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Frequency") catch return;
                defer msg.unref();
                if (msg.enterVariant("u") catch false) {
                    info.wifi_freq = msg.readUint32() catch 0;
                    msg.exitContainer() catch {};
                }
            }
        }
    }

    fn readIpAddress(self: *NetworkManager, device_path_z: [:0]const u8, info: *ConnectionInfo) void {
        // Get Ip4Config object path
        var config_msg = self.connection.getProperty(nm_service, device_path_z, device_interface, "Ip4Config") catch return;
        defer config_msg.unref();

        if (config_msg.enterVariant("o") catch false) {
            const config_path = config_msg.readObjectPath() catch {
                config_msg.exitContainer() catch {};
                return;
            };
            config_msg.exitContainer() catch {};

            if (config_path.len <= 1) return;

            var cfg_buf: [256:0]u8 = undefined;
            const cfg_z = toSentinel(&cfg_buf, config_path) orelse return;

            // AddressData — a(a{sv})
            var addr_msg = self.connection.getProperty(nm_service, cfg_z, ip4_interface, "AddressData") catch return;
            defer addr_msg.unref();

            if (addr_msg.enterVariant("aa{sv}") catch false) {
                if (addr_msg.enterArray("a{sv}") catch false) {
                    // Read first address entry
                    if (!addr_msg.atEnd()) {
                        if (addr_msg.enterArray("{sv}") catch false) {
                            while (!addr_msg.atEnd()) {
                                if (addr_msg.enterDictEntry("sv") catch false) {
                                    const key = addr_msg.readString() catch {
                                        addr_msg.exitContainer() catch {};
                                        continue;
                                    };
                                    if (std.mem.eql(u8, key, "address")) {
                                        if (addr_msg.enterVariant("s") catch false) {
                                            const addr = addr_msg.readString() catch {
                                                addr_msg.exitContainer() catch {};
                                                addr_msg.exitContainer() catch {};
                                                continue;
                                            };
                                            copyFixedBuf(&info.ip_address, &info.ip_address_len, addr);
                                            addr_msg.exitContainer() catch {};
                                        }
                                    } else {
                                        addr_msg.skip("v") catch {};
                                    }
                                    addr_msg.exitContainer() catch {};
                                }
                            }
                            addr_msg.exitContainer() catch {};
                        }
                    }
                    addr_msg.exitContainer() catch {};
                }
                addr_msg.exitContainer() catch {};
            }
        }
    }

    fn readApProperties(self: *NetworkManager, ap_path: []const u8, net: *WifiNetwork) void {
        var path_buf: [256:0]u8 = undefined;
        const ap_z = toSentinel(&path_buf, ap_path) orelse return;

        copyFixedBuf(&net.ap_path, &net.ap_path_len, ap_path);

        // Strength
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Strength") catch return;
            defer msg.unref();
            if (msg.enterVariant("y") catch false) {
                net.strength = msg.readByte() catch 0;
                msg.exitContainer() catch {};
            }
        }

        // Ssid
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Ssid") catch return;
            defer msg.unref();
            if (msg.enterVariant("ay") catch false) {
                if (msg.enterArray("y") catch false) {
                    var i: usize = 0;
                    while (!msg.atEnd() and i < 32) {
                        net.ssid[i] = msg.readByte() catch break;
                        i += 1;
                    }
                    net.ssid_len = i;
                    msg.exitContainer() catch {};
                }
                msg.exitContainer() catch {};
            }
        }

        // Frequency
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Frequency") catch return;
            defer msg.unref();
            if (msg.enterVariant("u") catch false) {
                net.frequency = msg.readUint32() catch 0;
                msg.exitContainer() catch {};
            }
        }

        // Flags (WPA flags indicate secured)
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "WpaFlags") catch return;
            defer msg.unref();
            if (msg.enterVariant("u") catch false) {
                const flags = msg.readUint32() catch 0;
                net.secured = flags != 0;
                msg.exitContainer() catch {};
            }
        }

        // Also check RSN flags if WPA flags were zero
        if (!net.secured) {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "RsnFlags") catch return;
            defer msg.unref();
            if (msg.enterVariant("u") catch false) {
                const flags = msg.readUint32() catch 0;
                net.secured = flags != 0;
                msg.exitContainer() catch {};
            }
        }
    }

    fn readSavedConnectionSettings(self: *NetworkManager, conn_path: []const u8, saved: *SavedConnection) void {
        var path_buf: [256:0]u8 = undefined;
        const path_z = toSentinel(&path_buf, conn_path) orelse return;

        // GetSettings returns a{sa{sv}} — outer dict keyed by setting group
        var msg = self.connection.callMethod(nm_service, path_z, settings_conn_interface, "GetSettings") catch return;
        defer msg.unref();

        if (msg.enterArray("{sa{sv}}") catch false) {
            while (!msg.atEnd()) {
                if (msg.enterDictEntry("sa{sv}") catch false) {
                    const section = msg.readString() catch {
                        msg.exitContainer() catch {};
                        continue;
                    };

                    if (std.mem.eql(u8, section, "connection")) {
                        if (msg.enterArray("{sv}") catch false) {
                            while (!msg.atEnd()) {
                                if (msg.enterDictEntry("sv") catch false) {
                                    const key = msg.readString() catch {
                                        msg.exitContainer() catch {};
                                        continue;
                                    };
                                    if (std.mem.eql(u8, key, "id")) {
                                        if (msg.enterVariant("s") catch false) {
                                            const val = msg.readString() catch {
                                                msg.exitContainer() catch {};
                                                msg.exitContainer() catch {};
                                                continue;
                                            };
                                            copyFixedBuf(&saved.name, &saved.name_len, val);
                                            msg.exitContainer() catch {};
                                        }
                                    } else if (std.mem.eql(u8, key, "type")) {
                                        if (msg.enterVariant("s") catch false) {
                                            const val = msg.readString() catch {
                                                msg.exitContainer() catch {};
                                                msg.exitContainer() catch {};
                                                continue;
                                            };
                                            copyFixedBuf(&saved.conn_type, &saved.conn_type_len, val);
                                            saved.is_vpn = std.mem.eql(u8, val, "vpn");
                                            msg.exitContainer() catch {};
                                        }
                                    } else {
                                        msg.skip("v") catch {};
                                    }
                                    msg.exitContainer() catch {};
                                }
                            }
                            msg.exitContainer() catch {};
                        }
                    } else {
                        msg.skip("a{sv}") catch {};
                    }
                    msg.exitContainer() catch {};
                }
            }
            msg.exitContainer() catch {};
        }
    }

    fn readPropString(self: *NetworkManager, path: [:0]const u8, iface: [:0]const u8, prop: [:0]const u8, out: []u8, out_len: *usize) void {
        var msg = self.connection.getProperty(nm_service, path, iface, prop) catch return;
        defer msg.unref();
        if (msg.enterVariant("s") catch false) {
            const str = msg.readString() catch return;
            const len = @min(str.len, out.len);
            @memcpy(out[0..len], str[0..len]);
            out_len.* = len;
            msg.exitContainer() catch {};
        }
    }

    fn readPropBool(self: *NetworkManager, path: [:0]const u8, iface: [:0]const u8, prop: [:0]const u8, out: *bool) void {
        var msg = self.connection.getProperty(nm_service, path, iface, prop) catch return;
        defer msg.unref();
        if (msg.enterVariant("b") catch false) {
            out.* = msg.readBool() catch return;
            msg.exitContainer() catch {};
        }
    }

    fn findWifiDevicePath(self: *NetworkManager) ?[:0]const u8 {
        // Check active connections first
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (conn.device_type == .wifi and conn.device_path_len > 1) {
                    return conn.device_path[0..conn.device_path_len :0];
                }
            }
        }

        // Return cached path if available
        if (self.wifi_device_path_len > 1) {
            return self.wifi_device_path[0..self.wifi_device_path_len :0];
        }

        // Enumerate all NM devices to find a WiFi adapter
        self.discoverWifiDevice();
        if (self.wifi_device_path_len > 1) {
            return self.wifi_device_path[0..self.wifi_device_path_len :0];
        }

        return null;
    }

    /// Query NM GetDevices() and find the first WiFi device, caching its path.
    fn discoverWifiDevice(self: *NetworkManager) void {
        var msg = self.connection.callMethod(
            nm_service,
            nm_path,
            nm_interface,
            "GetDevices",
        ) catch return;
        defer msg.unref();

        if (msg.enterArray("o") catch false) {
            while (!msg.atEnd()) {
                const dev_path = msg.readObjectPath() catch continue;
                // Convert to sentinel-terminated for getProperty call
                var path_buf: [256:0]u8 = undefined;
                const dev_path_z = toSentinel(&path_buf, dev_path) orelse continue;
                // Read DeviceType property
                var prop_msg = self.connection.getProperty(
                    nm_service,
                    dev_path_z,
                    device_interface,
                    "DeviceType",
                ) catch continue;
                defer prop_msg.unref();
                if (prop_msg.enterVariant("u") catch false) {
                    const dev_type_raw = prop_msg.readUint32() catch continue;
                    prop_msg.exitContainer() catch {};
                    if (dev_type_raw == @intFromEnum(DeviceType.wifi)) {
                        copyFixedBuf(&self.wifi_device_path, &self.wifi_device_path_len, dev_path);
                        // Null-terminate for sentinel slice
                        if (self.wifi_device_path_len < self.wifi_device_path.len) {
                            self.wifi_device_path[self.wifi_device_path_len] = 0;
                        }
                        msg.exitContainer() catch {};
                        return;
                    }
                }
            }
            msg.exitContainer() catch {};
        }
    }

    fn subscribeToSignals(self: *NetworkManager) Error!void {
        // StateChanged signal on NM interface
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.NetworkManager'," ++
                "member='StateChanged'",
            handleStateChanged,
            self,
        );

        // PropertiesChanged on NM interface
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus.Properties'," ++
                "member='PropertiesChanged'," ++
                "path='/org/freedesktop/NetworkManager'," ++
                "arg0='org.freedesktop.NetworkManager'",
            handlePropertiesChanged,
            self,
        );

        // PropertiesChanged on AccessPoint interface (signal strength updates)
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus.Properties'," ++
                "member='PropertiesChanged'," ++
                "arg0='org.freedesktop.NetworkManager.AccessPoint'",
            handleApPropertiesChanged,
            self,
        );

        // PropertiesChanged on Device.Statistics interface (byte counter updates)
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus.Properties'," ++
                "member='PropertiesChanged'," ++
                "arg0='org.freedesktop.NetworkManager.Device.Statistics'",
            handleStatisticsChanged,
            self,
        );
    }

    fn handleStateChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;
        self.refresh() catch {};
        self.notify();
    }

    fn handlePropertiesChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;
        self.refresh() catch {};
        self.notify();
    }

    fn handleApPropertiesChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));

        // Get AP path and update WiFi strength for matching connections
        const ap_path = msg.getPath() orelse return;

        // Read the updated strength from the AP
        var strength: u8 = 0;
        var ap_buf: [256:0]u8 = undefined;
        const ap_z = toSentinel(&ap_buf, ap_path) orelse return;

        {
            var prop_msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Strength") catch return;
            defer prop_msg.unref();
            if (prop_msg.enterVariant("y") catch false) {
                strength = prop_msg.readByte() catch return;
                prop_msg.exitContainer() catch {};
            }
        }

        // Update any connections using this AP
        var changed = false;
        for (&self.connections) |*slot| {
            if (slot.*) |*conn| {
                if (conn.device_type == .wifi) {
                    conn.wifi_strength = strength;
                    changed = true;
                }
            }
        }

        if (changed) self.notify();
    }

    fn handleStatisticsChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;
        // Lightweight refresh: just re-read byte counters, don't re-enumerate
        self.refreshStatistics();
        self.notify();
    }

    fn notify(self: *const NetworkManager) void {
        for (self.subscriptions) |maybe_sub| {
            if (maybe_sub) |sub| {
                sub.callback(sub.context);
            }
        }
    }
};

// --- Utility functions ---

/// Copy a slice into a fixed-size buffer with length tracking.
fn copyFixedBuf(buf: []u8, len: *usize, src: []const u8) void {
    const n = @min(src.len, buf.len);
    @memcpy(buf[0..n], src[0..n]);
    len.* = n;
}

/// Create a sentinel-terminated slice from a runtime slice into a stack buffer.
fn toSentinel(buf: *[256:0]u8, src: []const u8) ?[:0]const u8 {
    if (src.len >= 256) return null;
    @memcpy(buf[0..src.len], src);
    buf[src.len] = 0;
    return buf[0..src.len :0];
}

test "NetworkManager types compile" {
    _ = NetworkManager;
    _ = ConnectionInfo;
    _ = WifiNetwork;
    _ = SavedConnection;
    _ = NmState;
    _ = DeviceType;
    _ = DeviceState;
    _ = StateChangeFn;
}

test "ConnectionInfo.getSignalLevel branchless" {
    var info = ConnectionInfo{};
    info.wifi_strength = 0;
    try std.testing.expectEqual(@as(u8, 0), info.getSignalLevel());
    info.wifi_strength = 25;
    try std.testing.expectEqual(@as(u8, 1), info.getSignalLevel());
    info.wifi_strength = 45;
    try std.testing.expectEqual(@as(u8, 2), info.getSignalLevel());
    info.wifi_strength = 65;
    try std.testing.expectEqual(@as(u8, 3), info.getSignalLevel());
    info.wifi_strength = 85;
    try std.testing.expectEqual(@as(u8, 4), info.getSignalLevel());
}
