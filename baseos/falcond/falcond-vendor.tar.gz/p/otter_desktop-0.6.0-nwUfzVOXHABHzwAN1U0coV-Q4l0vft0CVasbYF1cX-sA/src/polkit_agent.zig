//! Polkit Authentication Agent — D-Bus module
//!
//! Registers as a polkit authentication agent on the system bus,
//! receives BeginAuthentication / CancelAuthentication D-Bus calls,
//! and communicates with polkit-agent-helper-1 via Unix socket.
//!
//! D-Bus Service: org.freedesktop.PolicyKit1.AuthenticationAgent
//! Object Path: /org/freedesktop/PolicyKit1/AuthenticationAgent

const std = @import("std");
const mem = std.mem;
const posix = std.posix;
const Allocator = std.mem.Allocator;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const c = dbus.types.c;

const log = std.log.scoped(.polkit_agent);

// ============================================================================
// Types
// ============================================================================

pub fn FixedString(comptime max_len: usize) type {
    return struct {
        // +1 byte reserved for null sentinel used by getZ()
        data: [max_len + 1]u8 = undefined,
        len: usize = 0,

        const Self = @This();

        pub fn set(self: *Self, src: []const u8) void {
            const copy_len = @min(src.len, max_len);
            @memcpy(self.data[0..copy_len], src[0..copy_len]);
            self.len = copy_len;
        }

        pub fn get(self: *const Self) []const u8 {
            return self.data[0..self.len];
        }

        pub fn isEmpty(self: *const Self) bool {
            return self.len == 0;
        }

        /// Get as a null-terminated string (writes sentinel after data).
        pub fn getZ(self: *Self) [:0]const u8 {
            self.data[self.len] = 0;
            return self.data[0..self.len :0];
        }
    };
}

pub const Identity = struct {
    kind: FixedString(32) = .{}, // "unix-user"
    uid: u32 = 0,
    username: FixedString(64) = .{},
};

pub const AuthRequest = struct {
    action_id: FixedString(256) = .{},
    message: FixedString(512) = .{},
    icon_name: FixedString(128) = .{},
    cookie: FixedString(128) = .{},
    identities: [8]Identity = .{Identity{}} ** 8,
    identity_count: u8 = 0,
    /// Held reference to the pending D-Bus method call for deferred reply.
    pending_msg: ?*c.sd_bus_message = null,
};

pub const AuthResult = enum { success, failure, cancelled, helper_error };

/// Callback type invoked when polkit sends BeginAuthentication.
pub const AuthRequestCallback = *const fn (request: *AuthRequest, ctx: ?*anyopaque) void;

/// Callback type invoked when polkit sends CancelAuthentication.
pub const AuthCancelCallback = *const fn (cookie: []const u8, ctx: ?*anyopaque) void;

// ============================================================================
// D-Bus constants
// ============================================================================

const authority_bus = "org.freedesktop.PolicyKit1";
const authority_path = "/org/freedesktop/PolicyKit1/Authority";
const authority_iface = "org.freedesktop.PolicyKit1.Authority";
const agent_iface = "org.freedesktop.PolicyKit1.AuthenticationAgent";
const agent_path = "/org/freedesktop/PolicyKit1/AuthenticationAgent";

const introspect_iface = "org.freedesktop.DBus.Introspectable";

const introspection_xml: [*:0]const u8 =
    \\<!DOCTYPE node PUBLIC "-//freedesktop//DTD D-BUS Object Introspection 1.0//EN"
    \\"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd">
    \\<node>
    \\  <interface name="org.freedesktop.PolicyKit1.AuthenticationAgent">
    \\    <method name="BeginAuthentication">
    \\      <arg direction="in" type="s" name="action_id"/>
    \\      <arg direction="in" type="s" name="message"/>
    \\      <arg direction="in" type="s" name="icon_name"/>
    \\      <arg direction="in" type="a{ss}" name="details"/>
    \\      <arg direction="in" type="s" name="cookie"/>
    \\      <arg direction="in" type="a(sa{sv})" name="identities"/>
    \\    </method>
    \\    <method name="CancelAuthentication">
    \\      <arg direction="in" type="s" name="cookie"/>
    \\    </method>
    \\  </interface>
    \\  <interface name="org.freedesktop.DBus.Introspectable">
    \\    <method name="Introspect">
    \\      <arg direction="out" type="s" name="xml_data"/>
    \\    </method>
    \\  </interface>
    \\</node>
    \\
;

// ============================================================================
// PolkitAgent
// ============================================================================

pub const PolkitAgent = struct {
    connection: dbus.Connection,
    allocator: Allocator,

    on_auth_request: ?AuthRequestCallback = null,
    on_auth_cancel: ?AuthCancelCallback = null,
    callback_ctx: ?*anyopaque = null,

    /// Current pending auth request (only one at a time; polkit serializes).
    current_request: ?AuthRequest = null,

    pub fn init(allocator: Allocator) !PolkitAgent {
        var conn = dbus.Connection.open(allocator, .system) catch |err| {
            log.err("Failed to open system bus: {s}", .{@errorName(err)});
            return err;
        };
        errdefer conn.deinit();

        return .{
            .connection = conn,
            .allocator = allocator,
        };
    }

    /// Register as authentication agent with the polkit Authority.
    /// MUST be called after the struct is in its final memory location.
    pub fn start(self: *PolkitAgent) !void {
        // Register D-Bus object for incoming method calls
        self.connection.addObject(agent_path, handleMessage, self) catch |err| {
            log.err("Failed to register agent object: {s}", .{@errorName(err)});
            return err;
        };

        // Get session ID for registration
        const session_id = self.getSessionId();
        if (session_id.len == 0) {
            log.err("Could not determine session ID", .{});
            return error.ConnectionFailed;
        }

        // Get locale
        const locale = posix.getenv("LANG") orelse "en_US.UTF-8";

        // Call RegisterAuthenticationAgent on the Authority
        self.registerWithAuthority(session_id, locale) catch |err| {
            log.err("Failed to register with polkit authority: {s}", .{@errorName(err)});
            return err;
        };

        log.info("Polkit authentication agent registered (session={s})", .{session_id});
    }

    pub fn deinit(self: *PolkitAgent) void {
        // Try to unregister (best effort)
        self.unregisterFromAuthority();

        // Clean up any pending request
        if (self.current_request) |*req| {
            if (req.pending_msg) |msg| {
                _ = dbus.Connection.replyMethodError(
                    msg,
                    "org.freedesktop.PolicyKit1.Error.Failed",
                    "Agent shutting down",
                );
                _ = c.sd_bus_message_unref(msg);
                req.pending_msg = null;
            }
        }

        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const PolkitAgent) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages. Returns true if more to process.
    pub fn process(self: *PolkitAgent) bool {
        return self.connection.process();
    }

    /// Called by the UI after the user provides a password.
    /// Communicates with polkit-agent-helper-1 via socket.
    /// On failure, the request is kept alive for retry — call cancelAuth() to end it.
    pub fn authenticate(self: *PolkitAgent, request: *AuthRequest, password: []const u8) AuthResult {
        if (request.identity_count == 0) return .helper_error;

        // Get the username of the first identity
        const username = request.identities[0].username.get();
        if (username.len == 0) return .helper_error;

        const cookie = request.cookie.get();
        if (cookie.len == 0) return .helper_error;

        // Try socket-based helper first (polkit 127+)
        const result = self.authenticateViaSocket(username, cookie, password);

        switch (result) {
            .success => {
                // Reply to the pending BeginAuthentication method call.
                // The helper already communicates success to polkitd directly
                // (via socket or internal callback), so no AuthenticationAgentResponse needed.
                if (request.pending_msg) |msg| {
                    _ = dbus.Connection.replyMethodReturn(msg);
                    _ = c.sd_bus_message_unref(msg);
                    request.pending_msg = null;
                }
                self.current_request = null;
            },
            .cancelled => {
                if (request.pending_msg) |msg| {
                    _ = dbus.Connection.replyMethodError(
                        msg,
                        "org.freedesktop.PolicyKit1.Error.Cancelled",
                        "Authentication cancelled",
                    );
                    _ = c.sd_bus_message_unref(msg);
                    request.pending_msg = null;
                }
                self.current_request = null;
            },
            .failure, .helper_error => {
                // Do NOT reply or clear request — allow the UI to retry
            },
        }

        return result;
    }

    /// Cancel the current authentication request (user dismissed).
    pub fn cancelAuth(self: *PolkitAgent, request: *AuthRequest) void {
        if (request.pending_msg) |msg| {
            _ = dbus.Connection.replyMethodError(
                msg,
                "org.freedesktop.PolicyKit1.Error.Cancelled",
                "Authentication cancelled by user",
            );
            _ = c.sd_bus_message_unref(msg);
            request.pending_msg = null;
        }
        self.current_request = null;
    }

    /// Fail the current authentication request (retries exhausted).
    pub fn failAuth(self: *PolkitAgent, request: *AuthRequest) void {
        if (request.pending_msg) |msg| {
            _ = dbus.Connection.replyMethodError(
                msg,
                "org.freedesktop.PolicyKit1.Error.Failed",
                "Authentication failed",
            );
            _ = c.sd_bus_message_unref(msg);
            request.pending_msg = null;
        }
        self.current_request = null;
    }

    // --- Internal ---

    fn getSessionId(self: *const PolkitAgent) []const u8 {
        _ = self;
        // Try XDG_SESSION_ID first
        if (posix.getenv("XDG_SESSION_ID")) |sid| return sid;

        // Fallback: try to get from logind via D-Bus
        // For now, use a reasonable fallback
        return "";
    }

    fn registerWithAuthority(self: *PolkitAgent, session_id: []const u8, locale: []const u8) !void {
        // Build the method call manually:
        // RegisterAuthenticationAgent(
        //   subject: (sa{sv})  -- ("unix-session", {"session-id": <s session_id>})
        //   locale: s
        //   object_path: s
        // )
        var msg_ptr: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        const ret = c.sd_bus_call_method(
            self.connection.bus,
            authority_bus,
            authority_path,
            authority_iface,
            "RegisterAuthenticationAgent",
            &err,
            &msg_ptr,
            // signature: (sa{sv})ss
            // subject struct, locale string, object path string
            "(sa{sv})ss",
            // Subject: ("unix-session", {"session-id": variant<string>})
            "unix-session".ptr,
            @as(c_uint, 1), // array count for a{sv}
            "session-id".ptr,
            "s".ptr,
            session_id.ptr,
            // locale
            locale.ptr,
            // object path
            agent_path.ptr,
        );

        defer c.sd_bus_error_free(&err);
        if (msg_ptr) |m| _ = c.sd_bus_message_unref(m);

        if (ret < 0) {
            if (err.name != null) {
                log.err("Registration error: {s}", .{mem.span(err.name)});
            }
            return dbus.types.Error.MethodCallFailed;
        }
    }

    fn unregisterFromAuthority(self: *PolkitAgent) void {
        const session_id = self.getSessionId();
        if (session_id.len == 0) return;

        var msg_ptr: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };

        _ = c.sd_bus_call_method(
            self.connection.bus,
            authority_bus,
            authority_path,
            authority_iface,
            "UnregisterAuthenticationAgent",
            &err,
            &msg_ptr,
            "(sa{sv})s",
            "unix-session".ptr,
            @as(c_uint, 1),
            "session-id".ptr,
            "s".ptr,
            session_id.ptr,
            agent_path.ptr,
        );

        defer c.sd_bus_error_free(&err);
        if (msg_ptr) |m| _ = c.sd_bus_message_unref(m);
    }

    fn authenticateViaSocket(self: *PolkitAgent, username: []const u8, cookie: []const u8, password: []const u8) AuthResult {
        _ = self;
        const socket_path = "/run/polkit/agent-helper.socket";

        // Try to connect to the helper socket
        const sock = connectUnixSocket(socket_path) orelse {
            // Fallback: try spawning the helper directly
            return authenticateViaProcess(username, cookie, password);
        };
        defer posix.close(sock);

        // Socket protocol: write username\n, cookie\n, then read prompts
        writeAll(sock, username) catch return .helper_error;
        writeAll(sock, "\n") catch return .helper_error;
        writeAll(sock, cookie) catch return .helper_error;
        writeAll(sock, "\n") catch return .helper_error;

        // Read and handle prompts
        var read_buf: [4096]u8 = undefined;
        while (true) {
            const n = posix.read(sock, &read_buf) catch return .helper_error;
            if (n == 0) return .failure; // EOF without SUCCESS

            const line = mem.trimRight(u8, read_buf[0..n], "\n\r");

            if (mem.startsWith(u8, line, "PAM_PROMPT_ECHO_OFF") or
                mem.startsWith(u8, line, "PAM_PROMPT_ECHO_ON"))
            {
                // Send password
                writeAll(sock, password) catch return .helper_error;
                writeAll(sock, "\n") catch return .helper_error;
            } else if (mem.startsWith(u8, line, "SUCCESS")) {
                return .success;
            } else if (mem.startsWith(u8, line, "FAILURE")) {
                return .failure;
            } else if (mem.startsWith(u8, line, "PAM_ERROR_MSG")) {
                log.warn("PAM error: {s}", .{line});
            } else if (mem.startsWith(u8, line, "PAM_TEXT_INFO")) {
                log.info("PAM info: {s}", .{line});
            }
        }
    }

    // --- D-Bus message handler ---

    fn handleMessage(
        msg: ?*c.sd_bus_message,
        userdata: ?*anyopaque,
        _: [*c]c.sd_bus_error,
    ) callconv(.c) c_int {
        const raw = msg orelse return 0;
        const self: *PolkitAgent = @ptrCast(@alignCast(userdata orelse return 0));
        var wrapped = dbus.Message.wrap(raw);
        const iface = wrapped.getInterface() orelse return 0;
        const member_name = wrapped.getMember() orelse return 0;

        if (mem.eql(u8, iface, agent_iface)) {
            if (mem.eql(u8, member_name, "BeginAuthentication"))
                return self.handleBeginAuthentication(raw, &wrapped);
            if (mem.eql(u8, member_name, "CancelAuthentication"))
                return self.handleCancelAuthentication(&wrapped);
        } else if (mem.eql(u8, iface, introspect_iface)) {
            if (mem.eql(u8, member_name, "Introspect"))
                return handleIntrospect(raw);
        }

        return 0;
    }

    fn handleBeginAuthentication(self: *PolkitAgent, raw: *c.sd_bus_message, msg: *dbus.Message) c_int {
        // Parse: action_id(s), message(s), icon_name(s), details(a{ss}), cookie(s), identities(a(sa{sv}))
        var request = AuthRequest{};

        const action_id = msg.readString() catch return -1;
        request.action_id.set(action_id);

        const message = msg.readString() catch return -1;
        request.message.set(message);

        const icon_name = msg.readString() catch return -1;
        request.icon_name.set(icon_name);

        // Skip details: a{ss}
        if (msg.enterArray("{ss}") catch null) |entered| {
            if (entered) {
                while (!msg.atEnd()) {
                    msg.skip("{ss}") catch break;
                }
            }
            msg.exitContainer() catch {};
        }

        // Read cookie
        const cookie = msg.readString() catch return -1;
        request.cookie.set(cookie);

        // Read identities: a(sa{sv})
        if (msg.enterArray("(sa{sv})") catch null) |entered| {
            if (entered) {
                while (!msg.atEnd() and request.identity_count < 8) {
                    if (msg.enterStruct("sa{sv}") catch null) |s_entered| {
                        if (s_entered) {
                            const kind = msg.readString() catch {
                                msg.exitContainer() catch {};
                                break;
                            };

                            var identity = Identity{};
                            identity.kind.set(kind);

                            // Parse identity dict: a{sv}
                            if (msg.enterArray("{sv}") catch null) |d_entered| {
                                if (d_entered) {
                                    while (!msg.atEnd()) {
                                        const dict_entered = msg.enterDictEntry("sv") catch break;
                                        if (!dict_entered) break;

                                        const key = msg.readString() catch {
                                            msg.exitContainer() catch {};
                                            break;
                                        };

                                        if (mem.eql(u8, key, "uid")) {
                                            if (msg.enterVariant("u") catch null) |v_entered| {
                                                if (v_entered) {
                                                    if (msg.readUint32() catch null) |uid| {
                                                        identity.uid = uid;
                                                        // Look up username from uid
                                                        lookupUsername(uid, &identity.username);
                                                    }
                                                }
                                                msg.exitContainer() catch {};
                                            }
                                        } else {
                                            msg.skip("v") catch {};
                                        }

                                        msg.exitContainer() catch {};
                                    }
                                }
                                msg.exitContainer() catch {};
                            }

                            request.identities[request.identity_count] = identity;
                            request.identity_count += 1;
                        }
                        msg.exitContainer() catch {};
                    }
                }
            }
            msg.exitContainer() catch {};
        }

        // Hold the message reference for deferred reply
        _ = c.sd_bus_message_ref(raw);
        request.pending_msg = raw;

        log.info("Auth request: action={s} cookie={s} identities={d}", .{
            request.action_id.get(),
            request.cookie.get(),
            request.identity_count,
        });

        self.current_request = request;

        // Notify the UI layer
        if (self.on_auth_request) |cb| {
            cb(&self.current_request.?, self.callback_ctx);
        }

        // Return 1 to indicate we handled the message.
        // The actual D-Bus reply is deferred until authenticate() or cancelAuth().
        return 1;
    }

    fn handleCancelAuthentication(self: *PolkitAgent, msg: *dbus.Message) c_int {
        const cookie = msg.readString() catch return -1;

        log.info("Cancel authentication: cookie={s}", .{cookie});

        // Notify the UI layer
        if (self.on_auth_cancel) |cb| {
            cb(cookie, self.callback_ctx);
        }

        return 1;
    }

    fn handleIntrospect(raw: *c.sd_bus_message) c_int {
        return c.sd_bus_reply_method_return(raw, "s", introspection_xml);
    }
};

// ============================================================================
// Helper functions
// ============================================================================

fn connectUnixSocket(path: []const u8) ?posix.fd_t {
    const sock = posix.socket(posix.AF.UNIX, posix.SOCK.STREAM | posix.SOCK.CLOEXEC, 0) catch return null;

    var addr: posix.sockaddr.un = .{ .family = posix.AF.UNIX, .path = undefined };
    @memset(&addr.path, 0);
    const copy_len = @min(path.len, addr.path.len - 1);
    @memcpy(addr.path[0..copy_len], path[0..copy_len]);

    posix.connect(sock, @ptrCast(&addr), @sizeOf(posix.sockaddr.un)) catch {
        posix.close(sock);
        return null;
    };

    return sock;
}

fn authenticateViaProcess(username: []const u8, cookie: []const u8, password: []const u8) AuthResult {
    // Find the helper binary
    const helper_paths = [_][]const u8{
        "/usr/lib/polkit-1/polkit-agent-helper-1",
        "/usr/libexec/polkit-agent-helper-1",
        "/usr/lib/policykit-1/polkit-agent-helper-1",
    };

    var helper_path: ?[]const u8 = null;
    for (&helper_paths) |path| {
        if (std.fs.cwd().access(path, .{})) |_| {
            helper_path = path;
            break;
        } else |_| {}
    }

    if (helper_path == null) {
        log.err("Could not find polkit-agent-helper-1", .{});
        return .helper_error;
    }

    // Build null-terminated args
    var username_buf: [65]u8 = undefined;
    const u_len = @min(username.len, 64);
    @memcpy(username_buf[0..u_len], username[0..u_len]);
    username_buf[u_len] = 0;
    const username_z: [*:0]const u8 = username_buf[0..u_len :0];

    var path_buf: [256]u8 = undefined;
    const p_len = @min(helper_path.?.len, 255);
    @memcpy(path_buf[0..p_len], helper_path.?[0..p_len]);
    path_buf[p_len] = 0;
    const path_z: [*:0]const u8 = path_buf[0..p_len :0];

    const argv = [_:null]?[*:0]const u8{ path_z, username_z, null };

    // Create pipe for stdin
    const stdin_pipe = posix.pipe2(.{ .CLOEXEC = true }) catch return .helper_error;
    const stdout_pipe = posix.pipe2(.{ .CLOEXEC = true }) catch {
        posix.close(stdin_pipe[0]);
        posix.close(stdin_pipe[1]);
        return .helper_error;
    };

    const pid = posix.fork() catch {
        posix.close(stdin_pipe[0]);
        posix.close(stdin_pipe[1]);
        posix.close(stdout_pipe[0]);
        posix.close(stdout_pipe[1]);
        return .helper_error;
    };

    if (pid == 0) {
        // Child process
        posix.close(stdin_pipe[1]);
        posix.close(stdout_pipe[0]);

        // Redirect stdin/stdout
        posix.dup2(stdin_pipe[0], 0) catch posix.exit(126);
        posix.dup2(stdout_pipe[1], 1) catch posix.exit(126);
        posix.close(stdin_pipe[0]);
        posix.close(stdout_pipe[1]);

        const exec_err = posix.execvpeZ(path_z, &argv, @ptrCast(std.os.environ.ptr));
        log.err("exec helper failed: {s}", .{@errorName(exec_err)});
        posix.exit(127);
    }

    // Parent process
    posix.close(stdin_pipe[0]);
    posix.close(stdout_pipe[1]);

    const write_fd = stdin_pipe[1];
    const read_fd = stdout_pipe[0];
    defer posix.close(write_fd);
    defer posix.close(read_fd);

    // Write cookie first
    writeAll(write_fd, cookie) catch return .helper_error;
    writeAll(write_fd, "\n") catch return .helper_error;

    // Read prompts and respond
    var read_buf: [4096]u8 = undefined;
    while (true) {
        const n = posix.read(read_fd, &read_buf) catch return .helper_error;
        if (n == 0) break;

        const data = read_buf[0..n];
        var iter = mem.splitScalar(u8, data, '\n');
        while (iter.next()) |line| {
            if (line.len == 0) continue;
            if (mem.startsWith(u8, line, "PAM_PROMPT_ECHO_OFF") or
                mem.startsWith(u8, line, "PAM_PROMPT_ECHO_ON"))
            {
                writeAll(write_fd, password) catch return .helper_error;
                writeAll(write_fd, "\n") catch return .helper_error;
            } else if (mem.startsWith(u8, line, "SUCCESS")) {
                _ = posix.waitpid(pid, 0);
                return .success;
            } else if (mem.startsWith(u8, line, "FAILURE")) {
                _ = posix.waitpid(pid, 0);
                return .failure;
            }
        }
    }

    _ = posix.waitpid(pid, 0);
    return .failure;
}

fn writeAll(fd: posix.fd_t, data: []const u8) !void {
    var written: usize = 0;
    while (written < data.len) {
        const n = posix.write(fd, data[written..]) catch |err| return err;
        if (n == 0) return error.BrokenPipe;
        written += n;
    }
}

fn lookupUsername(uid: u32, out: *FixedString(64)) void {
    // Read /etc/passwd line by line to find username for uid
    const file = std.fs.cwd().openFile("/etc/passwd", .{}) catch return;
    defer file.close();

    var buf: [4096]u8 = undefined;
    var carry: usize = 0; // bytes from previous read that form a partial line

    while (true) {
        const n = file.read(buf[carry..]) catch return;
        if (n == 0) {
            // Process any remaining data
            if (carry > 0) {
                if (parsePasswdLine(buf[0..carry], uid, out)) return;
            }
            return;
        }
        const total = carry + n;

        var start: usize = 0;
        while (mem.indexOfScalarPos(u8, buf[0..total], start, '\n')) |nl| {
            if (parsePasswdLine(buf[start..nl], uid, out)) return;
            start = nl + 1;
        }

        // Carry forward any partial line
        carry = total - start;
        if (carry > 0 and start > 0) {
            mem.copyForwards(u8, buf[0..carry], buf[start..total]);
        }
    }
}

fn parsePasswdLine(line: []const u8, uid: u32, out: *FixedString(64)) bool {
    // username:x:uid:gid:...
    var fields = mem.splitScalar(u8, line, ':');
    const username = fields.next() orelse return false;
    _ = fields.next(); // skip password
    const uid_str = fields.next() orelse return false;
    const parsed_uid = std.fmt.parseInt(u32, uid_str, 10) catch return false;
    if (parsed_uid == uid) {
        out.set(username);
        return true;
    }
    return false;
}

// ============================================================================
// Tests
// ============================================================================

test "FixedString set and get" {
    var s: FixedString(32) = .{};
    try std.testing.expect(s.isEmpty());
    s.set("hello");
    try std.testing.expectEqualStrings("hello", s.get());
    try std.testing.expect(!s.isEmpty());
}

test "FixedString truncation" {
    var s: FixedString(4) = .{};
    s.set("hello world");
    try std.testing.expectEqual(@as(usize, 4), s.len);
    try std.testing.expectEqualStrings("hell", s.get());
}

test "Identity default" {
    const id = Identity{};
    try std.testing.expect(id.kind.isEmpty());
    try std.testing.expectEqual(@as(u32, 0), id.uid);
}

test "AuthRequest default" {
    const req = AuthRequest{};
    try std.testing.expect(req.action_id.isEmpty());
    try std.testing.expect(req.cookie.isEmpty());
    try std.testing.expectEqual(@as(u8, 0), req.identity_count);
    try std.testing.expect(req.pending_msg == null);
}

test "AuthResult enum" {
    const results = [_]AuthResult{ .success, .failure, .cancelled, .helper_error };
    try std.testing.expectEqual(@as(usize, 4), results.len);
}
