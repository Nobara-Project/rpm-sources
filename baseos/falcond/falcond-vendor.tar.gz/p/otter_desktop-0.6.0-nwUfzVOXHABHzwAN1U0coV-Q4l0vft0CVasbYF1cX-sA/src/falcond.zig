//! Falcond Status Monitor
//!
//! Provides access to falcond daemon status by parsing /var/lib/falcond/status.
//! Uses inotify to watch for file changes and notify subscribers.
//!
//! Status file location: /var/lib/falcond/status

const std = @import("std");
const mem = std.mem;
const fs = std.fs;
const posix = std.posix;
const Allocator = std.mem.Allocator;

const otter_utils = @import("otter_utils");
const InotifyWatcher = otter_utils.inotify.Watcher;

const log = std.log.scoped(.falcond);

/// Default path to falcond status file
pub const default_status_path = "/var/lib/falcond/status";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// Maximum number of SCX schedulers tracked
const max_schedulers = 16;

/// Maximum number of queued profiles tracked
const max_queued_profiles = 8;

/// Maximum length for string fields
const max_string_len = 64;

/// Maximum length for profile names
const max_profile_name_len = 128;

/// Read buffer size for file parsing
const read_buf_size = 4096;

/// Performance mode status
pub const PerformanceStatus = enum {
    active,
    inactive,
    unsupported,
    disabled,
    unknown,

    pub fn fromString(s: []const u8) PerformanceStatus {
        if (mem.eql(u8, s, "Active")) return .active;
        if (mem.eql(u8, s, "Inactive")) return .inactive;
        if (mem.eql(u8, s, "Unsupported")) return .unsupported;
        if (mem.startsWith(u8, s, "Disabled")) return .disabled;
        return .unknown;
    }

    pub fn toString(self: PerformanceStatus) []const u8 {
        return switch (self) {
            .active => "Active",
            .inactive => "Inactive",
            .unsupported => "Unsupported",
            .disabled => "Disabled",
            .unknown => "Unknown",
        };
    }
};

/// Fixed-size string storage
pub fn FixedString(comptime max_len: usize) type {
    return struct {
        data: [max_len]u8 = undefined,
        len: usize = 0,

        const Self = @This();

        pub fn set(self: *Self, value: []const u8) void {
            const copy_len = @min(value.len, max_len);
            @memcpy(self.data[0..copy_len], value[0..copy_len]);
            self.len = copy_len;
        }

        pub fn get(self: *const Self) []const u8 {
            return self.data[0..self.len];
        }

        pub fn isEmpty(self: *const Self) bool {
            return self.len == 0;
        }

        pub fn eql(self: *const Self, other: []const u8) bool {
            return mem.eql(u8, self.get(), other);
        }

        pub fn isNone(self: *const Self) bool {
            return self.eql("none") or self.eql("None") or self.isEmpty();
        }
    };
}

/// Falcond daemon status
pub const FalcondStatus = struct {
    // Features
    performance_mode_available: bool = false,

    // Config
    profile_mode: FixedString(max_string_len) = .{},
    global_vcache_mode: FixedString(max_string_len) = .{},
    global_scx_scheduler: FixedString(max_string_len) = .{},

    // Available SCX schedulers
    available_schedulers: [max_schedulers]FixedString(max_string_len) = [_]FixedString(max_string_len){.{}} ** max_schedulers,
    scheduler_count: usize = 0,

    // Profiles
    loaded_profiles: u32 = 0,
    active_profile: FixedString(max_profile_name_len) = .{},

    // Queued profiles
    queued_profiles: [max_queued_profiles]FixedString(max_profile_name_len) = [_]FixedString(max_profile_name_len){.{}} ** max_queued_profiles,
    queued_profile_count: usize = 0,

    // Current status
    performance_status: PerformanceStatus = .unknown,
    current_vcache: FixedString(max_string_len) = .{},
    current_scx: FixedString(max_string_len) = .{},
    screensaver_inhibit: bool = false,

    /// Get list of available schedulers
    pub fn getAvailableSchedulers(self: *const FalcondStatus) []const FixedString(max_string_len) {
        return self.available_schedulers[0..self.scheduler_count];
    }

    /// Get list of queued profiles
    pub fn getQueuedProfiles(self: *const FalcondStatus) []const FixedString(max_profile_name_len) {
        return self.queued_profiles[0..self.queued_profile_count];
    }

    /// Check if performance mode is active
    pub fn isPerformanceActive(self: *const FalcondStatus) bool {
        return self.performance_status == .active;
    }

    /// Check if any profile is active
    pub fn hasActiveProfile(self: *const FalcondStatus) bool {
        return !self.active_profile.isNone();
    }

    /// Check if SCX scheduler is running
    pub fn hasScxScheduler(self: *const FalcondStatus) bool {
        return !self.current_scx.isNone();
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscription = struct {
    callback: StateChangeFn,
    context: ?*anyopaque,
};

pub const Error = error{
    WatcherInitFailed,
    WatchAddFailed,
    FileNotFound,
    ReadFailed,
    ParseFailed,
};

/// Parsing state machine
const ParseSection = enum {
    none,
    features,
    config,
    available_scx_schedulers,
    loaded_profiles,
    active_profile,
    queued_profiles,
    current_status,
};

pub const Falcond = struct {
    watcher: ?InotifyWatcher = null,
    watch_descriptor: ?i32 = null,
    allocator: Allocator,
    subscriptions: [max_subscribers]?Subscription = .{null} ** max_subscribers,
    subscription_count: usize = 0,

    // Status file path
    status_path: []const u8,

    // Internal buffer
    read_buf: [read_buf_size]u8 = undefined,

    // Current status
    status: FalcondStatus = .{},

    // Previous status for change detection
    prev_performance: PerformanceStatus = .unknown,
    prev_profile_hash: u64 = 0,

    /// Initialize the Falcond status monitor.
    /// Optionally provide a custom path for testing.
    pub fn init(allocator: Allocator, path: ?[]const u8) Error!Falcond {
        const status_path = path orelse default_status_path;

        var self = Falcond{
            .allocator = allocator,
            .status_path = status_path,
        };

        // Try to set up inotify watcher
        self.watcher = InotifyWatcher.init(allocator) catch |err| {
            log.warn("Failed to initialize inotify: {s}", .{@errorName(err)});
            return self; // Continue without watching
        };

        if (self.watcher) |*w| {
            self.watch_descriptor = w.addWatch(status_path, InotifyWatcher.Mask.file_changes) catch |err| blk: {
                log.warn("Failed to add watch for {s}: {s}", .{ status_path, @errorName(err) });
                // Continue without watching - file may not exist yet
                break :blk null;
            };
        }

        // Load initial state
        _ = self.refresh() catch |err| {
            log.info("Failed to load initial state (file may not exist): {s}", .{@errorName(err)});
        };

        return self;
    }

    pub fn deinit(self: *Falcond) void {
        if (self.watcher) |*w| {
            w.deinit();
        }
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    /// Returns null if watcher is not available.
    pub fn getFd(self: *const Falcond) ?posix.fd_t {
        if (self.watcher) |*w| {
            return w.getFd();
        }
        return null;
    }

    /// Process pending inotify events.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if status actually changed.
    pub fn process(self: *Falcond) bool {
        var changed = false;

        if (self.watcher) |*w| {
            while (w.nextEvent()) |event| {
                if (event.isModified() or event.isCreated()) {
                    const did_change = self.refresh() catch |err| {
                        log.warn("Failed to refresh status: {s}", .{@errorName(err)});
                        continue;
                    };
                    if (did_change) changed = true;
                } else if (event.isDeleted() or event.isMoved()) {
                    // File was deleted/moved, clear status
                    self.status = .{};
                    self.prev_performance = .unknown;
                    self.prev_profile_hash = 0;
                    changed = true;
                } else if (event.isIgnored()) {
                    // Watch was removed, try to re-add
                    self.watch_descriptor = w.addWatch(self.status_path, InotifyWatcher.Mask.file_changes) catch null;
                }
            }
        }

        if (changed) {
            self.notify();
        }

        return changed;
    }

    /// Get the current status.
    pub fn getStatus(self: *const Falcond) *const FalcondStatus {
        return &self.status;
    }

    /// Manually refresh status from file. Returns true if status actually changed.
    pub fn refresh(self: *Falcond) Error!bool {
        const file = fs.cwd().openFile(self.status_path, .{}) catch {
            return Error.FileNotFound;
        };
        defer file.close();

        const bytes_read = file.read(&self.read_buf) catch {
            return Error.ReadFailed;
        };

        if (bytes_read == 0) {
            return Error.ReadFailed;
        }

        self.parseStatus(self.read_buf[0..bytes_read]);

        // Check if status actually changed
        const profile_hash = std.hash.Fnv1a_64.hash(self.status.active_profile.get());
        const changed = (self.status.performance_status != self.prev_performance) or
            (profile_hash != self.prev_profile_hash);

        if (changed) {
            self.prev_performance = self.status.performance_status;
            self.prev_profile_hash = profile_hash;
            log.debug("Status changed: performance={s}, active_profile={s}", .{
                self.status.performance_status.toString(),
                if (self.status.active_profile.isEmpty()) "none" else self.status.active_profile.get(),
            });
        }

        return changed;
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *Falcond, callback: StateChangeFn, context: ?*anyopaque) bool {
        if (self.subscription_count >= max_subscribers) return false;

        for (&self.subscriptions) |*slot| {
            if (slot.* == null) {
                slot.* = .{ .callback = callback, .context = context };
                self.subscription_count += 1;
                return true;
            }
        }
        return false;
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *Falcond, callback: StateChangeFn, context: ?*anyopaque) void {
        for (&self.subscriptions) |*slot| {
            if (slot.*) |sub| {
                if (sub.callback == callback and sub.context == context) {
                    slot.* = null;
                    self.subscription_count -|= 1;
                    return;
                }
            }
        }
    }

    // Internal methods

    fn parseStatus(self: *Falcond, content: []const u8) void {
        // Reset status
        self.status = .{};

        var section: ParseSection = .none;
        var lines = mem.splitScalar(u8, content, '\n');

        while (lines.next()) |line| {
            const trimmed = mem.trim(u8, line, " \t\r");
            if (trimmed.len == 0) continue;

            // Check for section headers
            if (mem.eql(u8, trimmed, "FEATURES:")) {
                section = .features;
                continue;
            } else if (mem.eql(u8, trimmed, "CONFIG:")) {
                section = .config;
                continue;
            } else if (mem.eql(u8, trimmed, "AVAILABLE_SCX_SCHEDULERS:")) {
                section = .available_scx_schedulers;
                continue;
            } else if (mem.startsWith(u8, trimmed, "LOADED_PROFILES:")) {
                section = .loaded_profiles;
                self.parseLoadedProfiles(trimmed);
                continue;
            } else if (mem.startsWith(u8, trimmed, "ACTIVE_PROFILE:")) {
                section = .active_profile;
                self.parseActiveProfile(trimmed);
                continue;
            } else if (mem.eql(u8, trimmed, "QUEUED_PROFILES:")) {
                section = .queued_profiles;
                continue;
            } else if (mem.eql(u8, trimmed, "CURRENT_STATUS:")) {
                section = .current_status;
                continue;
            }

            // Parse content based on current section
            switch (section) {
                .features => self.parseFeatureLine(trimmed),
                .config => self.parseConfigLine(trimmed),
                .available_scx_schedulers => self.parseSchedulerLine(trimmed),
                .queued_profiles => self.parseQueuedProfileLine(trimmed),
                .current_status => self.parseCurrentStatusLine(trimmed),
                else => {},
            }
        }
    }

    fn parseFeatureLine(self: *Falcond, line: []const u8) void {
        if (mem.startsWith(u8, line, "Performance Mode:")) {
            const value = self.extractValue(line, "Performance Mode:");
            self.status.performance_mode_available = mem.eql(u8, value, "Available");
        }
    }

    fn parseConfigLine(self: *Falcond, line: []const u8) void {
        if (mem.startsWith(u8, line, "Profile Mode:")) {
            const value = self.extractValue(line, "Profile Mode:");
            self.status.profile_mode.set(value);
        } else if (mem.startsWith(u8, line, "Global VCache Mode:")) {
            const value = self.extractValue(line, "Global VCache Mode:");
            self.status.global_vcache_mode.set(value);
        } else if (mem.startsWith(u8, line, "Global SCX Scheduler:")) {
            const value = self.extractValue(line, "Global SCX Scheduler:");
            self.status.global_scx_scheduler.set(value);
        }
    }

    fn parseSchedulerLine(self: *Falcond, line: []const u8) void {
        if (self.status.scheduler_count >= max_schedulers) return;

        // Lines are formatted as "  - scheduler_name"
        if (mem.startsWith(u8, line, "- ")) {
            const scheduler = mem.trim(u8, line[2..], " ");
            if (scheduler.len > 0) {
                self.status.available_schedulers[self.status.scheduler_count].set(scheduler);
                self.status.scheduler_count += 1;
            }
        }
    }

    fn parseLoadedProfiles(self: *Falcond, line: []const u8) void {
        const value = self.extractValue(line, "LOADED_PROFILES:");
        self.status.loaded_profiles = std.fmt.parseInt(u32, value, 10) catch 0;
    }

    fn parseActiveProfile(self: *Falcond, line: []const u8) void {
        const value = self.extractValue(line, "ACTIVE_PROFILE:");
        if (!mem.eql(u8, value, "None")) {
            self.status.active_profile.set(value);
        }
    }

    fn parseQueuedProfileLine(self: *Falcond, line: []const u8) void {
        if (self.status.queued_profile_count >= max_queued_profiles) return;

        // Check for "(None)" indicator
        if (mem.indexOf(u8, line, "(None)") != null) return;

        // Lines are formatted as "  - profile_name"
        if (mem.startsWith(u8, line, "- ")) {
            const profile = mem.trim(u8, line[2..], " ");
            if (profile.len > 0) {
                self.status.queued_profiles[self.status.queued_profile_count].set(profile);
                self.status.queued_profile_count += 1;
            }
        }
    }

    fn parseCurrentStatusLine(self: *Falcond, line: []const u8) void {
        if (mem.startsWith(u8, line, "Performance Mode:")) {
            const value = self.extractValue(line, "Performance Mode:");
            self.status.performance_status = PerformanceStatus.fromString(value);
        } else if (mem.startsWith(u8, line, "VCache Mode:")) {
            const value = self.extractValue(line, "VCache Mode:");
            self.status.current_vcache.set(value);
        } else if (mem.startsWith(u8, line, "SCX Scheduler:")) {
            const value = self.extractValue(line, "SCX Scheduler:");
            self.status.current_scx.set(value);
        } else if (mem.startsWith(u8, line, "Screensaver Inhibit:")) {
            const value = self.extractValue(line, "Screensaver Inhibit:");
            self.status.screensaver_inhibit = mem.eql(u8, value, "Active");
        }
    }

    fn extractValue(_: *Falcond, line: []const u8, prefix: []const u8) []const u8 {
        if (line.len <= prefix.len) return "";
        return mem.trim(u8, line[prefix.len..], " \t");
    }

    fn notify(self: *const Falcond) void {
        for (self.subscriptions) |maybe_sub| {
            if (maybe_sub) |sub| {
                sub.callback(sub.context);
            }
        }
    }
};

// Tests

test "Falcond types compile" {
    _ = Falcond;
    _ = FalcondStatus;
    _ = PerformanceStatus;
    _ = StateChangeFn;
}

test "PerformanceStatus fromString" {
    const testing = std.testing;

    try testing.expectEqual(PerformanceStatus.active, PerformanceStatus.fromString("Active"));
    try testing.expectEqual(PerformanceStatus.inactive, PerformanceStatus.fromString("Inactive"));
    try testing.expectEqual(PerformanceStatus.unsupported, PerformanceStatus.fromString("Unsupported"));
    try testing.expectEqual(PerformanceStatus.disabled, PerformanceStatus.fromString("Disabled/Unavailable"));
    try testing.expectEqual(PerformanceStatus.unknown, PerformanceStatus.fromString("SomethingElse"));
}

test "FixedString operations" {
    const testing = std.testing;

    var s = FixedString(32){};
    try testing.expect(s.isEmpty());

    s.set("hello");
    try testing.expectEqualStrings("hello", s.get());
    try testing.expect(!s.isEmpty());

    s.set("none");
    try testing.expect(s.isNone());
}

test "FalcondStatus default values" {
    const testing = std.testing;

    const status = FalcondStatus{};
    try testing.expect(!status.performance_mode_available);
    try testing.expectEqual(PerformanceStatus.unknown, status.performance_status);
    try testing.expectEqual(@as(u32, 0), status.loaded_profiles);
    try testing.expect(!status.screensaver_inhibit);
    try testing.expect(!status.isPerformanceActive());
    try testing.expect(!status.hasActiveProfile());
}

test "parseStatus basic parsing" {
    const testing = std.testing;

    const test_content =
        \\FEATURES:
        \\  Performance Mode: Available
        \\
        \\CONFIG:
        \\  Profile Mode: none
        \\  Global VCache Mode: none
        \\  Global SCX Scheduler: scx_bpfland
        \\
        \\AVAILABLE_SCX_SCHEDULERS:
        \\  - scx_bpfland
        \\  - scx_lavd
        \\
        \\LOADED_PROFILES: 5
        \\
        \\ACTIVE_PROFILE: gaming
        \\
        \\QUEUED_PROFILES:
        \\  (None)
        \\
        \\CURRENT_STATUS:
        \\  Performance Mode: Active
        \\  VCache Mode: none
        \\  SCX Scheduler: scx_bpfland
        \\  Screensaver Inhibit: Inactive
    ;

    // We can't easily test the full Falcond struct in unit tests without inotify
    // But we can verify the parsing logic by checking the struct fields
    var falcond = Falcond{
        .allocator = testing.allocator,
        .status_path = "/nonexistent",
    };

    falcond.parseStatus(test_content);

    const status = falcond.getStatus();
    try testing.expect(status.performance_mode_available);
    try testing.expectEqualStrings("none", status.profile_mode.get());
    try testing.expectEqualStrings("scx_bpfland", status.global_scx_scheduler.get());
    try testing.expectEqual(@as(usize, 2), status.scheduler_count);
    try testing.expectEqualStrings("scx_bpfland", status.available_schedulers[0].get());
    try testing.expectEqualStrings("scx_lavd", status.available_schedulers[1].get());
    try testing.expectEqual(@as(u32, 5), status.loaded_profiles);
    try testing.expectEqualStrings("gaming", status.active_profile.get());
    try testing.expectEqual(PerformanceStatus.active, status.performance_status);
    try testing.expectEqualStrings("scx_bpfland", status.current_scx.get());
    try testing.expect(!status.screensaver_inhibit);
}

test "parseStatus with None active profile" {
    const testing = std.testing;

    const test_content =
        \\ACTIVE_PROFILE: None
        \\
        \\CURRENT_STATUS:
        \\  Performance Mode: Inactive
    ;

    var falcond = Falcond{
        .allocator = testing.allocator,
        .status_path = "/nonexistent",
    };

    falcond.parseStatus(test_content);

    const status = falcond.getStatus();
    try testing.expect(status.active_profile.isEmpty());
    try testing.expect(!status.hasActiveProfile());
    try testing.expectEqual(PerformanceStatus.inactive, status.performance_status);
}

test "subscription management" {
    const testing = std.testing;

    var falcond = Falcond{
        .allocator = testing.allocator,
        .status_path = "/nonexistent",
    };

    var call_count: usize = 0;
    const callback = struct {
        fn cb(ctx: ?*anyopaque) void {
            const count: *usize = @ptrCast(@alignCast(ctx));
            count.* += 1;
        }
    }.cb;

    // Subscribe
    try testing.expect(falcond.subscribe(callback, &call_count));
    try testing.expectEqual(@as(usize, 1), falcond.subscription_count);

    // Notify
    falcond.notify();
    try testing.expectEqual(@as(usize, 1), call_count);

    // Unsubscribe
    falcond.unsubscribe(callback, &call_count);
    try testing.expectEqual(@as(usize, 0), falcond.subscription_count);

    // Notify after unsubscribe - should not increment
    falcond.notify();
    try testing.expectEqual(@as(usize, 1), call_count);
}
