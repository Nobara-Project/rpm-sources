//! Fprintd D-Bus Client — fingerprint verification
//!
//! D-Bus client for net.reactivated.Fprint service.
//! Provides fingerprint verification as an alternative to password auth.

const std = @import("std");
const mem = std.mem;
const posix = std.posix;
const Allocator = std.mem.Allocator;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const c = dbus.types.c;

const log = std.log.scoped(.fprintd);

pub fn FixedString(comptime max_len: usize) type {
    return struct {
        data: [max_len]u8 = undefined,
        len: usize = 0,

        const Self = @This();

        pub fn set(self: *Self, src: []const u8) void {
            const copy_len = @min(src.len, max_len);
            @memcpy(self.data[0..copy_len], src[0..copy_len]);
            self.len = copy_len;
        }

        pub fn get(self: *const Self) []const u8 {
            return self.data[0..self.len];
        }

        pub fn isEmpty(self: *const Self) bool {
            return self.len == 0;
        }
    };
}

// ============================================================================
// Types
// ============================================================================

pub const VerifyResult = enum {
    match,
    no_match,
    retry_scan,
    swipe_too_short,
    finger_not_centered,
    remove_and_retry,
    unknown,

    pub fn fromString(s: []const u8) VerifyResult {
        if (mem.eql(u8, s, "verify-match")) return .match;
        if (mem.eql(u8, s, "verify-no-match")) return .no_match;
        if (mem.eql(u8, s, "verify-retry-scan")) return .retry_scan;
        if (mem.eql(u8, s, "verify-swipe-too-short")) return .swipe_too_short;
        if (mem.eql(u8, s, "verify-finger-not-centered")) return .finger_not_centered;
        if (mem.eql(u8, s, "verify-remove-and-retry")) return .remove_and_retry;
        return .unknown;
    }
};

/// Callback type invoked when a VerifyStatus signal arrives.
pub const VerifyStatusCallback = *const fn (result: VerifyResult, done: bool, ctx: ?*anyopaque) void;

// ============================================================================
// D-Bus constants
// ============================================================================

const fprint_bus = "net.reactivated.Fprint";
const manager_path = "/net/reactivated/Fprint/Manager";
const manager_iface = "net.reactivated.Fprint.Manager";
const device_iface = "net.reactivated.Fprint.Device";

// ============================================================================
// Fprintd
// ============================================================================

pub const Fprintd = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    device_path: FixedString(256) = .{},
    available: bool = false,
    verifying: bool = false,

    on_verify_status: ?VerifyStatusCallback = null,
    callback_ctx: ?*anyopaque = null,

    pub fn init(allocator: Allocator) !Fprintd {
        var conn = dbus.Connection.open(allocator, .system) catch |err| {
            log.info("Could not open system bus for fprintd: {s}", .{@errorName(err)});
            return err;
        };
        errdefer conn.deinit();

        // Fast pre-check: ask the D-Bus daemon if fprintd is running.
        // This returns immediately (no service activation timeout).
        if (!conn.nameHasOwner(fprint_bus)) {
            log.info("Fprintd service not running on D-Bus", .{});
            return error.ServiceUnknown;
        }

        var self = Fprintd{
            .connection = conn,
            .allocator = allocator,
        };

        // Check if fprintd is available and get default device
        self.checkAvailability();

        return self;
    }

    pub fn deinit(self: *Fprintd) void {
        if (self.verifying) {
            self.stopVerify();
        }
        self.connection.deinit();
        self.* = undefined;
    }

    /// Check if fingerprint authentication is available.
    pub fn isAvailable(self: *const Fprintd) bool {
        return self.available;
    }

    /// Start fingerprint verification for a user.
    pub fn startVerify(self: *Fprintd, username: []const u8) !void {
        if (!self.available) return error.ServiceUnknown;

        const device_path = self.device_path.get();
        if (device_path.len == 0) return error.ServiceUnknown;

        // Build null-terminated strings
        var path_buf: [257]u8 = undefined;
        const dp_len = @min(device_path.len, 256);
        @memcpy(path_buf[0..dp_len], device_path[0..dp_len]);
        path_buf[dp_len] = 0;
        const path_z: [:0]const u8 = path_buf[0..dp_len :0];

        // Claim the device
        var user_buf: [65]u8 = undefined;
        const u_len = @min(username.len, 64);
        @memcpy(user_buf[0..u_len], username[0..u_len]);
        user_buf[u_len] = 0;
        const user_z: [:0]const u8 = user_buf[0..u_len :0];

        _ = self.connection.callMethodWithString(
            fprint_bus,
            path_z,
            device_iface,
            "Claim",
            user_z,
        ) catch |err| {
            log.warn("Failed to claim fingerprint device: {s}", .{@errorName(err)});
            return err;
        };

        // Subscribe to VerifyStatus signal
        self.connection.subscribeSignal(
            device_iface,
            "VerifyStatus",
            onVerifyStatus,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to VerifyStatus: {s}", .{@errorName(err)});
            // Try to release
            _ = self.connection.callMethod(fprint_bus, path_z, device_iface, "Release") catch {};
            return err;
        };

        // Start verification
        _ = self.connection.callMethodWithString(
            fprint_bus,
            path_z,
            device_iface,
            "VerifyStart",
            "any",
        ) catch |err| {
            log.warn("Failed to start fingerprint verify: {s}", .{@errorName(err)});
            _ = self.connection.callMethod(fprint_bus, path_z, device_iface, "Release") catch {};
            return err;
        };

        self.verifying = true;
        log.info("Fingerprint verification started for {s}", .{username});
    }

    /// Stop fingerprint verification and release the device.
    pub fn stopVerify(self: *Fprintd) void {
        if (!self.verifying) return;

        const device_path = self.device_path.get();
        if (device_path.len == 0) return;

        var path_buf: [257]u8 = undefined;
        const dp_len = @min(device_path.len, 256);
        @memcpy(path_buf[0..dp_len], device_path[0..dp_len]);
        path_buf[dp_len] = 0;
        const path_z: [:0]const u8 = path_buf[0..dp_len :0];

        _ = self.connection.callMethod(fprint_bus, path_z, device_iface, "VerifyStop") catch {};
        _ = self.connection.callMethod(fprint_bus, path_z, device_iface, "Release") catch {};

        self.verifying = false;
        log.info("Fingerprint verification stopped", .{});
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const Fprintd) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages. Returns true if more to process.
    pub fn process(self: *Fprintd) bool {
        return self.connection.process();
    }

    // --- Internal ---

    fn checkAvailability(self: *Fprintd) void {
        // Try to get the default device
        var reply = self.connection.callMethod(
            fprint_bus,
            manager_path,
            manager_iface,
            "GetDefaultDevice",
        ) catch {
            self.available = false;
            return;
        };

        const path = reply.readObjectPath() catch {
            self.available = false;
            return;
        };

        self.device_path.set(path);
        self.available = true;
        log.info("Fingerprint device found: {s}", .{path});
    }

    fn onVerifyStatus(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *Fprintd = @ptrCast(@alignCast(ctx orelse return));
        var m = msg;

        // VerifyStatus signal: (s result, b done)
        const result_str = m.readString() catch return;
        const done = m.readBool() catch return;

        const result = VerifyResult.fromString(result_str);

        log.info("Fingerprint status: {s} done={}", .{ result_str, done });

        if (self.on_verify_status) |cb| {
            cb(result, done, self.callback_ctx);
        }

        // If done, stop verifying
        if (done) {
            self.verifying = false;
        }
    }
};

// ============================================================================
// Tests
// ============================================================================

test "VerifyResult fromString" {
    try std.testing.expectEqual(VerifyResult.match, VerifyResult.fromString("verify-match"));
    try std.testing.expectEqual(VerifyResult.no_match, VerifyResult.fromString("verify-no-match"));
    try std.testing.expectEqual(VerifyResult.retry_scan, VerifyResult.fromString("verify-retry-scan"));
    try std.testing.expectEqual(VerifyResult.unknown, VerifyResult.fromString("something-else"));
}

test "FixedString operations" {
    var s: FixedString(16) = .{};
    try std.testing.expect(s.isEmpty());
    s.set("test");
    try std.testing.expectEqualStrings("test", s.get());
    try std.testing.expect(!s.isEmpty());
}
