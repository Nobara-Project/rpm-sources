//! D-Bus C bindings for sd-bus
//!
//! Provides raw C types and functions from libsystemd's sd-bus API.

const std = @import("std");
const posix = std.posix;

pub const c = @cImport({
    @cInclude("systemd/sd-bus.h");
});

/// Bus type for opening connections
pub const BusType = enum(c_int) {
    session = 0,
    system = 1,
};

/// Message types
pub const MessageType = enum(u8) {
    invalid = c.SD_BUS_MESSAGE_TYPE_INVALID,
    method_call = c.SD_BUS_MESSAGE_TYPE_METHOD_CALL,
    method_return = c.SD_BUS_MESSAGE_TYPE_METHOD_RETURN,
    method_error = c.SD_BUS_MESSAGE_TYPE_METHOD_ERROR,
    signal = c.SD_BUS_MESSAGE_TYPE_SIGNAL,
};

/// Common D-Bus errors
pub const Error = error{
    ConnectionFailed,
    MessageReadError,
    MessageWriteError,
    MethodCallFailed,
    InvalidArgument,
    NoMemory,
    Timeout,
    ServiceUnknown,
    NameHasNoOwner,
    Disconnected,
    UnknownError,
    NameAlreadyOwned,
    VtableRegistrationFailed,
    SignalEmitFailed,
};

/// Convert sd-bus error to Zig error
pub fn translateError(ret: c_int) Error {
    const E = posix.E;
    return switch (ret) {
        -@as(c_int, @intFromEnum(E.NOMEM)) => Error.NoMemory,
        -@as(c_int, @intFromEnum(E.INVAL)) => Error.InvalidArgument,
        -@as(c_int, @intFromEnum(E.TIMEDOUT)) => Error.Timeout,
        -@as(c_int, @intFromEnum(E.NOTCONN)), -@as(c_int, @intFromEnum(E.CONNRESET)) => Error.Disconnected,
        else => Error.UnknownError,
    };
}
