//! D-Bus Message parsing helpers
//!
//! Wraps sd_bus_message with type-safe reading operations.

const std = @import("std");
const types = @import("types.zig");
const c = types.c;

pub const Message = struct {
    msg: *c.sd_bus_message,

    /// Wrap an existing sd_bus_message pointer.
    /// Does not take ownership - caller must manage lifetime.
    pub fn wrap(msg: *c.sd_bus_message) Message {
        return .{ .msg = msg };
    }

    /// Reference the message (increment ref count).
    pub fn ref(self: *Message) void {
        _ = c.sd_bus_message_ref(self.msg);
    }

    /// Unreference the message (decrement ref count).
    pub fn unref(self: *Message) void {
        _ = c.sd_bus_message_unref(self.msg);
    }

    /// Read a string from the message.
    pub fn readString(self: *Message) types.Error![]const u8 {
        var str: [*c]const u8 = null;
        const ret = c.sd_bus_message_read_basic(self.msg, 's', @ptrCast(&str));
        if (ret < 0) return types.translateError(ret);
        if (str == null) return types.Error.MessageReadError;
        return std.mem.span(str);
    }

    /// Read an object path from the message.
    pub fn readObjectPath(self: *Message) types.Error![]const u8 {
        var str: [*c]const u8 = null;
        const ret = c.sd_bus_message_read_basic(self.msg, 'o', @ptrCast(&str));
        if (ret < 0) return types.translateError(ret);
        if (str == null) return types.Error.MessageReadError;
        return std.mem.span(str);
    }

    /// Read a signature from the message.
    pub fn readSignature(self: *Message) types.Error![]const u8 {
        var str: [*c]const u8 = null;
        const ret = c.sd_bus_message_read_basic(self.msg, 'g', @ptrCast(&str));
        if (ret < 0) return types.translateError(ret);
        if (str == null) return types.Error.MessageReadError;
        return std.mem.span(str);
    }

    /// Read a boolean from the message.
    pub fn readBool(self: *Message) types.Error!bool {
        var val: c_int = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'b', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val != 0;
    }

    /// Read a byte from the message.
    pub fn readByte(self: *Message) types.Error!u8 {
        var val: u8 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'y', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read an i16 from the message.
    pub fn readInt16(self: *Message) types.Error!i16 {
        var val: i16 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'n', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read a u16 from the message.
    pub fn readUint16(self: *Message) types.Error!u16 {
        var val: u16 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'q', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read an i32 from the message.
    pub fn readInt32(self: *Message) types.Error!i32 {
        var val: i32 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'i', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read a u32 from the message.
    pub fn readUint32(self: *Message) types.Error!u32 {
        var val: u32 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'u', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read an i64 from the message.
    pub fn readInt64(self: *Message) types.Error!i64 {
        var val: i64 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'x', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read a u64 from the message.
    pub fn readUint64(self: *Message) types.Error!u64 {
        var val: u64 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 't', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Read a double from the message.
    pub fn readDouble(self: *Message) types.Error!f64 {
        var val: f64 = 0;
        const ret = c.sd_bus_message_read_basic(self.msg, 'd', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
        return val;
    }

    /// Enter an array container.
    /// Returns true if there is data, false if the array is empty.
    pub fn enterArray(self: *Message, element_signature: [:0]const u8) types.Error!bool {
        const ret = c.sd_bus_message_enter_container(self.msg, 'a', element_signature.ptr);
        if (ret < 0) return types.translateError(ret);
        return ret > 0;
    }

    /// Enter a struct container.
    /// Returns true if there is data, false if empty.
    pub fn enterStruct(self: *Message, member_signature: [:0]const u8) types.Error!bool {
        const ret = c.sd_bus_message_enter_container(self.msg, 'r', member_signature.ptr);
        if (ret < 0) return types.translateError(ret);
        return ret > 0;
    }

    /// Enter a variant container.
    /// Returns true if there is data, false if empty.
    pub fn enterVariant(self: *Message, content_signature: [:0]const u8) types.Error!bool {
        const ret = c.sd_bus_message_enter_container(self.msg, 'v', content_signature.ptr);
        if (ret < 0) return types.translateError(ret);
        return ret > 0;
    }

    /// Enter a dict entry container.
    /// Returns true if there is data, false if empty.
    pub fn enterDictEntry(self: *Message, member_signature: [:0]const u8) types.Error!bool {
        const ret = c.sd_bus_message_enter_container(self.msg, 'e', member_signature.ptr);
        if (ret < 0) return types.translateError(ret);
        return ret > 0;
    }

    /// Exit the current container.
    pub fn exitContainer(self: *Message) types.Error!void {
        const ret = c.sd_bus_message_exit_container(self.msg);
        if (ret < 0) return types.translateError(ret);
    }

    /// Check if we're at the end of a container (no more elements).
    pub fn atEnd(self: *Message) bool {
        const ret = c.sd_bus_message_at_end(self.msg, 0);
        return ret > 0;
    }

    /// Skip the current value.
    pub fn skip(self: *Message, signature: [:0]const u8) types.Error!void {
        const ret = c.sd_bus_message_skip(self.msg, signature.ptr);
        if (ret < 0) return types.translateError(ret);
    }

    /// Peek at the type of the next element without consuming it.
    /// Returns the type character or 0 if at end.
    pub fn peekType(self: *Message) u8 {
        var type_char: u8 = 0;
        var contents: [*c]const u8 = null;
        const ret = c.sd_bus_message_peek_type(self.msg, &type_char, &contents);
        if (ret <= 0) return 0;
        return type_char;
    }

    /// Get the message path.
    pub fn getPath(self: *const Message) ?[]const u8 {
        const path = c.sd_bus_message_get_path(self.msg);
        if (path == null) return null;
        return std.mem.span(path);
    }

    /// Get the message interface.
    pub fn getInterface(self: *const Message) ?[]const u8 {
        const iface = c.sd_bus_message_get_interface(self.msg);
        if (iface == null) return null;
        return std.mem.span(iface);
    }

    /// Get the message member (method/signal name).
    pub fn getMember(self: *const Message) ?[]const u8 {
        const member = c.sd_bus_message_get_member(self.msg);
        if (member == null) return null;
        return std.mem.span(member);
    }

    /// Get the message sender.
    pub fn getSender(self: *const Message) ?[]const u8 {
        const sender = c.sd_bus_message_get_sender(self.msg);
        if (sender == null) return null;
        return std.mem.span(sender);
    }

    /// Check if this message is a method call.
    pub fn isMethodCall(self: *const Message, iface: ?[:0]const u8, member: ?[:0]const u8) bool {
        const ret = c.sd_bus_message_is_method_call(
            self.msg,
            if (iface) |i| i.ptr else null,
            if (member) |m| m.ptr else null,
        );
        return ret > 0;
    }

    /// Check if this message is a signal.
    pub fn isSignal(self: *const Message, iface: ?[:0]const u8, member: ?[:0]const u8) bool {
        const ret = c.sd_bus_message_is_signal(
            self.msg,
            if (iface) |i| i.ptr else null,
            if (member) |m| m.ptr else null,
        );
        return ret > 0;
    }

    /// Get the message type.
    pub fn getType(self: *const Message) types.MessageType {
        var msg_type: u8 = 0;
        _ = c.sd_bus_message_get_type(self.msg, &msg_type);
        return @enumFromInt(msg_type);
    }

    /// Rewind the message to the beginning for re-reading.
    pub fn rewind(self: *Message) types.Error!void {
        const ret = c.sd_bus_message_rewind(self.msg, 1);
        if (ret < 0) return types.translateError(ret);
    }

    // --- Write methods for building outgoing messages ---

    /// Append a string to the message.
    pub fn appendString(self: *Message, val: [*:0]const u8) types.Error!void {
        const ret = c.sd_bus_message_append_basic(self.msg, 's', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
    }

    /// Append an object path to the message.
    pub fn appendObjectPath(self: *Message, val: [*:0]const u8) types.Error!void {
        const ret = c.sd_bus_message_append_basic(self.msg, 'o', @ptrCast(&val));
        if (ret < 0) return types.translateError(ret);
    }

    /// Append a boolean to the message.
    pub fn appendBool(self: *Message, val: bool) types.Error!void {
        var int_val: c_int = @intFromBool(val);
        const ret = c.sd_bus_message_append_basic(self.msg, 'b', @ptrCast(&int_val));
        if (ret < 0) return types.translateError(ret);
    }

    /// Append an i32 to the message.
    pub fn appendInt32(self: *Message, val: i32) types.Error!void {
        var v = val;
        const ret = c.sd_bus_message_append_basic(self.msg, 'i', @ptrCast(&v));
        if (ret < 0) return types.translateError(ret);
    }

    /// Append a u32 to the message.
    pub fn appendUint32(self: *Message, val: u32) types.Error!void {
        var v = val;
        const ret = c.sd_bus_message_append_basic(self.msg, 'u', @ptrCast(&v));
        if (ret < 0) return types.translateError(ret);
    }

    /// Open a container (array, struct, variant, dict entry).
    pub fn openContainer(self: *Message, container_type: u8, contents: [*:0]const u8) types.Error!void {
        const ret = c.sd_bus_message_open_container(self.msg, container_type, contents);
        if (ret < 0) return types.translateError(ret);
    }

    /// Close the current container being built.
    pub fn closeContainer(self: *Message) types.Error!void {
        const ret = c.sd_bus_message_close_container(self.msg);
        if (ret < 0) return types.translateError(ret);
    }

    /// Read a byte array from the message (zero-copy via sd_bus_message_read_array).
    /// Returns a slice pointing into the message buffer — valid until message is unref'd.
    pub fn readByteArray(self: *Message) types.Error![]const u8 {
        var ptr: ?*const anyopaque = null;
        var size: usize = 0;
        const ret = c.sd_bus_message_read_array(self.msg, 'y', @ptrCast(&ptr), &size);
        if (ret < 0) return types.translateError(ret);
        if (ptr == null or size == 0) return &.{};
        const byte_ptr: [*]const u8 = @ptrCast(ptr.?);
        return byte_ptr[0..size];
    }
};
