//! otter-desktop: Desktop integration for the Otter desktop shell
//!
//! Provides XDG icon lookup, desktop file parsing, D-Bus client,
//! and application list management.

const build_options = @import("build_options");
pub const has_dbus = build_options.has_dbus;
pub const has_pipewire = build_options.has_pipewire;
pub const has_pam = build_options.has_pam;

// Always available (pure Zig, no C dependencies)

// Icon lookup
pub const icon_lookup = @import("icon_lookup.zig");
pub const IconCache = icon_lookup.IconCache;
pub const findIcon = icon_lookup.findIcon;

// Applications
pub const applications = struct {
    pub const DesktopEntry = @import("applications/desktop_entry.zig").DesktopEntry;
    pub const desktop_entry = @import("applications/desktop_entry.zig");
    pub const AppList = @import("applications/app_list.zig").AppList;
    pub const AppDirWatcher = @import("applications/watcher.zig").AppDirWatcher;
    pub const launcher = @import("applications/launcher.zig");
};

// Brightness control
pub const brightness = @import("brightness.zig");
pub const Brightness = brightness.Brightness;
pub const BacklightDevice = brightness.BacklightDevice;

// System information (CPU, memory, disk, temperature)
pub const sysinfo = @import("sysinfo.zig");
pub const SysInfo = sysinfo.SysInfo;
pub const MemoryInfo = sysinfo.MemoryInfo;
pub const DiskInfo = sysinfo.DiskInfo;
pub const TempSensor = sysinfo.TempSensor;

// Falcond status monitoring
pub const falcond = @import("falcond.zig");
pub const Falcond = falcond.Falcond;
pub const FalcondStatus = falcond.FalcondStatus;

// D-Bus conditional (void when disabled)
pub const dbus = if (has_dbus) struct {
    pub const Connection = @import("dbus/connection.zig").Connection;
    pub const Message = @import("dbus/message.zig").Message;
    pub const types = @import("dbus/types.zig");
    pub const BusType = types.BusType;
    pub const Error = types.Error;
} else void;

// Power profiles
pub const power_profiles = if (has_dbus) @import("power_profiles.zig") else void;
pub const PowerProfiles = if (has_dbus) @import("power_profiles.zig").PowerProfiles else void;

// UPower (battery monitoring)
pub const upower = if (has_dbus) @import("upower.zig") else void;
pub const UPower = if (has_dbus) @import("upower.zig").UPower else void;
pub const BatteryInfo = if (has_dbus) @import("upower.zig").BatteryInfo else void;

// MPRIS media player control
pub const mpris = if (has_dbus) @import("mpris.zig") else void;
pub const Mpris = if (has_dbus) @import("mpris.zig").Mpris else void;
pub const PlayerInfo = if (has_dbus) @import("mpris.zig").PlayerInfo else void;
pub const PlaybackStatus = if (has_dbus) @import("mpris.zig").PlaybackStatus else void;

// System Tray (StatusNotifierItem/Watcher)
pub const system_tray = if (has_dbus) @import("system_tray.zig") else void;
pub const SystemTray = if (has_dbus) @import("system_tray.zig").SystemTray else void;
pub const TrayItem = if (has_dbus) @import("system_tray.zig").TrayItem else void;
pub const status_notifier_watcher = if (has_dbus) @import("status_notifier_watcher.zig") else void;
pub const StatusNotifierWatcher = if (has_dbus) @import("status_notifier_watcher.zig").StatusNotifierWatcher else void;
pub const status_notifier_item = if (has_dbus) @import("status_notifier_item.zig") else void;
pub const ItemProperties = if (has_dbus) @import("status_notifier_item.zig").ItemProperties else void;
pub const dbus_menu = if (has_dbus) @import("dbus_menu.zig") else void;
pub const MenuLayout = if (has_dbus) @import("dbus_menu.zig").MenuLayout else void;
pub const MenuItem = if (has_dbus) @import("dbus_menu.zig").MenuItem else void;

// SCX Scheduler control
pub const scx_loader = if (has_dbus) @import("scx_loader.zig") else void;
pub const ScxLoader = if (has_dbus) @import("scx_loader.zig").ScxLoader else void;
pub const ScxScheduler = if (has_dbus) @import("scx_loader.zig").ScxScheduler else void;
pub const ScxMode = if (has_dbus) @import("scx_loader.zig").ScxMode else void;

// Screensaver inhibition
pub const screensaver = if (has_dbus) @import("screensaver.zig") else void;
pub const Screensaver = if (has_dbus) @import("screensaver.zig").Screensaver else void;

// systemd-logind integration (sleep signals, inhibitor locks)
pub const logind = if (has_dbus) @import("logind.zig") else void;
pub const Logind = if (has_dbus) @import("logind.zig").Logind else void;

// ScreenSaver inhibit service (server-side, tracks Inhibit/UnInhibit from apps)
pub const screensaver_service = if (has_dbus) @import("screensaver_service.zig") else void;
pub const ScreenSaverService = if (has_dbus) @import("screensaver_service.zig").ScreenSaverService else void;

// NetworkManager (network status monitoring and control)
pub const network_manager = if (has_dbus) @import("network_manager.zig") else void;
pub const NetworkManager = if (has_dbus) @import("network_manager.zig").NetworkManager else void;
pub const ConnectionInfo = if (has_dbus) @import("network_manager.zig").ConnectionInfo else void;
pub const WifiNetwork = if (has_dbus) @import("network_manager.zig").WifiNetwork else void;
pub const SavedConnection = if (has_dbus) @import("network_manager.zig").SavedConnection else void;

// Notification service (org.freedesktop.Notifications)
pub const notification_service = if (has_dbus) @import("notification_service.zig") else void;
pub const NotificationService = if (has_dbus) @import("notification_service.zig").NotificationService else void;
pub const Notification = if (has_dbus) @import("notification_service.zig").Notification else void;
pub const NotificationStore = if (has_dbus) @import("notification_service.zig").Store else void;

// Polkit authentication agent
pub const polkit_agent = if (has_dbus) @import("polkit_agent.zig") else void;
pub const PolkitAgent = if (has_dbus) @import("polkit_agent.zig").PolkitAgent else void;
pub const AuthRequest = if (has_dbus) @import("polkit_agent.zig").AuthRequest else void;

// Fprintd fingerprint verification
pub const fprintd = if (has_dbus) @import("fprintd.zig") else void;
pub const Fprintd = if (has_dbus) @import("fprintd.zig").Fprintd else void;

// PAM authentication
pub const pam = if (has_pam) @import("pam.zig") else void;
pub const PamAuth = if (has_pam) @import("pam.zig").PamAuth else void;
pub const PamResult = if (has_pam) @import("pam.zig").PamResult else void;

// PipeWire audio control
pub const pipewire = if (has_pipewire) @import("pipewire.zig") else void;
pub const PipeWire = if (has_pipewire) @import("pipewire.zig").PipeWire else void;
pub const AudioDevice = if (has_pipewire) @import("pipewire.zig").AudioDevice else void;

// Force evaluation of PipeWire Logger for static linking.
// The Logger module contains export functions needed by pipewire's va.c.
comptime {
    if (has_pipewire) {
        _ = @import("pipewire.zig").Logger;
    }
}

test {
    // Always available
    _ = @import("icon_lookup.zig");
    _ = @import("applications/desktop_entry.zig");
    _ = @import("applications/watcher.zig");
    _ = @import("applications/app_list.zig");
    _ = @import("applications/launcher.zig");
    _ = @import("brightness.zig");
    _ = @import("sysinfo.zig");
    _ = @import("falcond.zig");

    // D-Bus conditional
    if (has_dbus) {
        _ = @import("dbus/types.zig");
        _ = @import("dbus/message.zig");
        _ = @import("dbus/connection.zig");
        _ = @import("power_profiles.zig");
        _ = @import("upower.zig");
        _ = @import("mpris.zig");
        _ = @import("system_tray.zig");
        _ = @import("status_notifier_watcher.zig");
        _ = @import("status_notifier_item.zig");
        _ = @import("dbus_menu.zig");
        _ = @import("scx_loader.zig");
        _ = @import("screensaver.zig");
        _ = @import("logind.zig");
        _ = @import("screensaver_service.zig");
        _ = @import("notification_service.zig");
        _ = @import("network_manager.zig");
        _ = @import("polkit_agent.zig");
        _ = @import("fprintd.zig");
    }

    // PAM conditional
    if (has_pam) {
        _ = @import("pam.zig");
    }

    // PipeWire conditional
    if (has_pipewire) {
        _ = @import("pipewire.zig");
    }
}
