//! Brightness Service
//!
//! Provides access to display backlight brightness control via sysfs.
//! Supports internal displays (eDP, LVDS, DSI) through /sys/class/backlight/.

const std = @import("std");
const fs = std.fs;
const mem = std.mem;

const log = std.log.scoped(.brightness);

/// Maximum length for device paths
const max_path_len: usize = 256;

/// Maximum length for device names
const max_name_len: usize = 64;

/// Maximum number of backlight devices to track
const max_devices: usize = 4;

/// Sysfs backlight base path
const sysfs_backlight_path = "/sys/class/backlight";

/// Backlight device information
pub const BacklightDevice = struct {
    /// Device name (e.g., "intel_backlight", "amdgpu_bl0")
    name: [max_name_len]u8 = undefined,
    name_len: usize = 0,

    /// Maximum brightness value
    max_brightness: u64 = 0,

    /// File handle for brightness control
    brightness_file: ?fs.File = null,

    /// Whether we have write access
    can_write: bool = false,

    pub fn getName(self: *const BacklightDevice) []const u8 {
        return self.name[0..self.name_len];
    }

    /// Get current brightness as percentage (0-100)
    pub fn getBrightness(self: *BacklightDevice) u8 {
        const f = self.brightness_file orelse return 0;
        f.seekTo(0) catch return 0;

        var buf: [32]u8 = undefined;
        const bytes_read = f.read(&buf) catch return 0;
        if (bytes_read == 0) return 0;

        const trimmed = mem.trimRight(u8, buf[0..bytes_read], &[_]u8{ '\n', '\r', ' ' });
        const current = std.fmt.parseInt(u64, trimmed, 10) catch return 0;

        if (self.max_brightness == 0) return 0;
        return @intCast(@min(100, (current * 100) / self.max_brightness));
    }

    /// Set brightness as percentage (0-100), clamped to valid range
    pub fn setBrightness(self: *BacklightDevice, percent: u8) void {
        if (!self.can_write) return;
        const f = self.brightness_file orelse return;

        // Clamp to 0-100
        const clamped = @min(percent, 100);
        const value = (self.max_brightness * @as(u64, clamped)) / 100;

        var buf: [32]u8 = undefined;
        const str = std.fmt.bufPrint(&buf, "{d}", .{value}) catch return;

        f.seekTo(0) catch return;
        _ = f.write(str) catch return;
    }

    /// Adjust brightness by delta percentage, clamping to 0-100
    pub fn adjustBrightness(self: *BacklightDevice, delta: i32) u8 {
        const current: i32 = @intCast(self.getBrightness());
        const new_value: u8 = @intCast(std.math.clamp(current + delta, 0, 100));
        self.setBrightness(new_value);
        return new_value;
    }

    fn close(self: *BacklightDevice) void {
        if (self.brightness_file) |f| f.close();
        self.brightness_file = null;
    }
};

pub const Error = error{
    NoBacklightDevice,
    DeviceNotFound,
    PathTooLong,
    ReadFailed,
    ParseFailed,
    AccessDenied,
};

/// Brightness service for managing display backlight
pub const Brightness = struct {
    /// Path buffer for sysfs operations
    path_buf: [max_path_len]u8 = undefined,

    /// Tracked backlight devices
    devices: [max_devices]?BacklightDevice = .{null} ** max_devices,
    device_count: usize = 0,

    /// Primary device index (usually first internal display)
    primary_device: usize = 0,

    /// Initialize the brightness service
    pub fn init() Brightness {
        return .{};
    }

    /// Find the backlight device for a given connector name (e.g., "eDP-1", "DP-2")
    /// by resolving /sys/class/backlight/{device}/device symlink to find matching connector.
    /// Returns the device name (e.g., "intel_backlight") or null if not found.
    pub fn findBacklightForConnector(self: *Brightness, connector_name: []const u8) ?[]const u8 {
        var dir = fs.cwd().openDir(sysfs_backlight_path, .{ .iterate = true }) catch {
            return null;
        };
        defer dir.close();

        var iter = dir.iterate();
        while (iter.next() catch null) |entry| {
            if (entry.kind != .directory and entry.kind != .sym_link) continue;

            // Construct path to device symlink: /sys/class/backlight/{device}/device
            const device_link_path = std.fmt.bufPrint(&self.path_buf, "{s}/{s}/device", .{ sysfs_backlight_path, entry.name }) catch continue;

            // Read the symlink target
            var link_buf: [max_path_len]u8 = undefined;
            const link_target = fs.cwd().readLink(device_link_path, &link_buf) catch continue;

            // Look for connector pattern like "card0-eDP-1" or "card1-DP-2"
            // The connector name is after "cardN-"
            if (self.extractConnectorFromPath(link_target)) |extracted_connector| {
                if (mem.eql(u8, extracted_connector, connector_name)) {
                    // Found matching device - store name temporarily
                    const name_len = @min(entry.name.len, max_name_len);
                    @memcpy(self.path_buf[0..name_len], entry.name[0..name_len]);
                    return self.path_buf[0..name_len];
                }
            }
        }

        return null;
    }

    /// Extract connector name from a path containing "cardN-{connector}"
    /// e.g., "../../../devices/.../drm/card0/card0-eDP-1" -> "eDP-1"
    fn extractConnectorFromPath(self: *Brightness, path: []const u8) ?[]const u8 {
        _ = self;
        // Look for "card" followed by digit and dash
        var i: usize = 0;
        while (i < path.len) : (i += 1) {
            if (mem.startsWith(u8, path[i..], "card")) {
                // Skip "card"
                var j = i + 4;
                // Skip digits
                while (j < path.len and path[j] >= '0' and path[j] <= '9') : (j += 1) {}
                // Check for dash
                if (j < path.len and path[j] == '-') {
                    // Find end of connector name (slash or end)
                    const start = j + 1;
                    var end = start;
                    while (end < path.len and path[end] != '/') : (end += 1) {}
                    if (end > start) {
                        return path[start..end];
                    }
                }
            }
        }
        return null;
    }

    /// Open the backlight device matching a connector name
    pub fn openForConnector(self: *Brightness, connector_name: []const u8) Error!void {
        // First check if it's an internal display
        if (!isInternalDisplay(connector_name)) {
            return Error.NoBacklightDevice;
        }

        // Find matching backlight device
        if (self.findBacklightForConnector(connector_name)) |device_name| {
            // Need to copy since findBacklightForConnector uses path_buf
            var name_copy: [max_name_len]u8 = undefined;
            const copy_len = @min(device_name.len, max_name_len);
            @memcpy(name_copy[0..copy_len], device_name[0..copy_len]);
            try self.openDevice(name_copy[0..copy_len]);
        } else {
            // Fallback: enumerate all and use first available for internal display
            try self.enumerate();
        }
    }

    /// Deinitialize and close all device handles
    pub fn deinit(self: *Brightness) void {
        for (&self.devices) |*slot| {
            if (slot.*) |*device| {
                device.close();
                slot.* = null;
            }
        }
        self.device_count = 0;
    }

    /// Check if a connector name indicates an internal display
    pub fn isInternalDisplay(connector: []const u8) bool {
        return mem.startsWith(u8, connector, "eDP") or
            mem.startsWith(u8, connector, "LVDS") or
            mem.startsWith(u8, connector, "DSI");
    }

    /// Enumerate available backlight devices
    pub fn enumerate(self: *Brightness) Error!void {
        // Close existing devices
        for (&self.devices) |*slot| {
            if (slot.*) |*device| {
                device.close();
                slot.* = null;
            }
        }
        self.device_count = 0;

        var dir = fs.cwd().openDir(sysfs_backlight_path, .{ .iterate = true }) catch {
            log.warn("Cannot open {s}", .{sysfs_backlight_path});
            return Error.NoBacklightDevice;
        };
        defer dir.close();

        var iter = dir.iterate();
        while (iter.next() catch null) |entry| {
            if (self.device_count >= max_devices) break;

            if (entry.kind == .directory or entry.kind == .sym_link) {
                self.openDevice(entry.name) catch |err| {
                    log.debug("Skipping device {s}: {s}", .{ entry.name, @errorName(err) });
                    continue;
                };
            }
        }

        if (self.device_count == 0) {
            return Error.NoBacklightDevice;
        }

        log.info("Found {d} backlight device(s)", .{self.device_count});
    }

    /// Open a specific backlight device by name
    pub fn openDevice(self: *Brightness, device_name: []const u8) Error!void {
        if (self.device_count >= max_devices) return Error.NoBacklightDevice;

        var device = BacklightDevice{};

        // Store device name
        const name_len = @min(device_name.len, max_name_len);
        @memcpy(device.name[0..name_len], device_name[0..name_len]);
        device.name_len = name_len;

        // Read max brightness
        const max_path = std.fmt.bufPrint(&self.path_buf, "{s}/{s}/max_brightness", .{ sysfs_backlight_path, device_name }) catch return Error.PathTooLong;
        const max_file = fs.cwd().openFile(max_path, .{}) catch return Error.DeviceNotFound;
        defer max_file.close();

        var buf: [32]u8 = undefined;
        const bytes_read = max_file.read(&buf) catch return Error.ReadFailed;
        if (bytes_read == 0) return Error.ReadFailed;

        const trimmed = mem.trimRight(u8, buf[0..bytes_read], &[_]u8{ '\n', '\r', ' ' });
        device.max_brightness = std.fmt.parseInt(u64, trimmed, 10) catch return Error.ParseFailed;

        // Open brightness file for read/write
        const brightness_path = std.fmt.bufPrint(&self.path_buf, "{s}/{s}/brightness", .{ sysfs_backlight_path, device_name }) catch return Error.PathTooLong;

        device.brightness_file = fs.cwd().openFile(brightness_path, .{ .mode = .read_write }) catch |err| blk: {
            if (err == error.AccessDenied) {
                // Fall back to read-only
                device.can_write = false;
                break :blk fs.cwd().openFile(brightness_path, .{}) catch return Error.DeviceNotFound;
            }
            return Error.DeviceNotFound;
        };
        device.can_write = true;

        self.devices[self.device_count] = device;
        self.device_count += 1;

        log.info("Opened backlight device: {s}, max_brightness: {d}", .{ device_name, device.max_brightness });
    }

    /// Open a device by name, auto-enumerate if not found
    pub fn openDeviceByName(self: *Brightness, device_name: []const u8) Error!*BacklightDevice {
        // Check if already open
        for (&self.devices) |*slot| {
            if (slot.*) |*device| {
                if (mem.eql(u8, device.getName(), device_name)) {
                    return device;
                }
            }
        }

        // Try to open it
        try self.openDevice(device_name);

        // Return the newly opened device
        if (self.devices[self.device_count - 1]) |*device| {
            return device;
        }

        return Error.DeviceNotFound;
    }

    /// Get the primary backlight device (first one found)
    pub fn getPrimaryDevice(self: *Brightness) ?*BacklightDevice {
        if (self.device_count > 0) {
            if (self.devices[self.primary_device]) |*device| {
                return device;
            }
        }
        return null;
    }

    /// Get a device by index
    pub fn getDevice(self: *Brightness, index: usize) ?*BacklightDevice {
        if (index < self.device_count) {
            if (self.devices[index]) |*device| {
                return device;
            }
        }
        return null;
    }

    /// Get all devices
    pub fn getDevices(self: *Brightness) []?BacklightDevice {
        return self.devices[0..self.device_count];
    }

    /// Get brightness of primary device as percentage (0-100)
    pub fn getBrightness(self: *Brightness) u8 {
        if (self.getPrimaryDevice()) |device| {
            return device.getBrightness();
        }
        return 0;
    }

    /// Set brightness of primary device as percentage (0-100)
    pub fn setBrightness(self: *Brightness, percent: u8) void {
        if (self.getPrimaryDevice()) |device| {
            device.setBrightness(percent);
        }
    }

    /// Adjust brightness of primary device by delta percentage
    pub fn adjustBrightness(self: *Brightness, delta: i32) u8 {
        if (self.getPrimaryDevice()) |device| {
            return device.adjustBrightness(delta);
        }
        return 0;
    }

    /// Check if any writable device is available
    pub fn canWrite(self: *const Brightness) bool {
        for (self.devices[0..self.device_count]) |maybe_device| {
            if (maybe_device) |device| {
                if (device.can_write) return true;
            }
        }
        return false;
    }
};

test "Brightness types compile" {
    _ = Brightness;
    _ = BacklightDevice;
    _ = Error;
}

test "isInternalDisplay" {
    const testing = std.testing;

    try testing.expect(Brightness.isInternalDisplay("eDP-1"));
    try testing.expect(Brightness.isInternalDisplay("LVDS-1"));
    try testing.expect(Brightness.isInternalDisplay("DSI-1"));
    try testing.expect(!Brightness.isInternalDisplay("HDMI-1"));
    try testing.expect(!Brightness.isInternalDisplay("DP-1"));
}
