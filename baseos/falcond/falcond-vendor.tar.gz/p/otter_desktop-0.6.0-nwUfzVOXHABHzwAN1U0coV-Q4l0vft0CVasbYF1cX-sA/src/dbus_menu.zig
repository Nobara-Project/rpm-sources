//! DBusMenu Client
//!
//! Reads menu layouts from applications implementing com.canonical.dbusmenu.
//! Parses the recursive GetLayout response into a flat, cache-friendly array.
//!
//! D-Bus Interface: com.canonical.dbusmenu
//!
//! Reference: https://github.com/AyatanaIndicators/libdbusmenu

const std = @import("std");
const mem = std.mem;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
    const c = types.c;
};

const log = std.log.scoped(.dbusmenu);

/// D-Bus constants
const dbusmenu_interface = "com.canonical.dbusmenu";

/// Maximum menu items in a layout
const max_menu_items = 256;

/// Maximum label length
const max_label_len = 128;

/// Maximum icon name length
const max_icon_len = 128;

/// Shared icon data buffer size for all items in a layout
const max_icon_data_total: usize = 32768;

/// Maximum recursive depth when parsing layout
const max_depth = 8;

/// Menu item type
pub const MenuItemType = enum {
    standard,
    separator,

    pub fn fromString(s: []const u8) MenuItemType {
        if (mem.eql(u8, s, "separator")) return .separator;
        return .standard;
    }
};

/// Toggle type for checkable items
pub const ToggleType = enum {
    none,
    checkmark,
    radio,

    pub fn fromString(s: []const u8) ToggleType {
        if (mem.eql(u8, s, "checkmark")) return .checkmark;
        if (mem.eql(u8, s, "radio")) return .radio;
        return .none;
    }
};

/// Children display hint
pub const ChildrenDisplay = enum {
    none,
    submenu,

    pub fn fromString(s: []const u8) ChildrenDisplay {
        if (mem.eql(u8, s, "submenu")) return .submenu;
        return .none;
    }
};

/// A single menu item in flat layout.
/// Icon data is stored in the parent MenuLayout's shared buffer;
/// items reference it via offset + length for cache-friendly packing.
pub const MenuItem = struct {
    id: i32 = 0,
    item_type: MenuItemType = .standard,
    label: [max_label_len]u8 = undefined,
    label_len: usize = 0,
    enabled: bool = true,
    visible: bool = true,
    icon_name: [max_icon_len]u8 = undefined,
    icon_name_len: usize = 0,
    /// Offset into MenuLayout.icon_data_buf
    icon_data_offset: u32 = 0,
    /// Length of icon data (0 = no embedded icon data)
    icon_data_len: u16 = 0,
    toggle_type: ToggleType = .none,
    toggle_state: i32 = -1,
    children_display: ChildrenDisplay = .none,
    /// Index of first child in the flat array (0 = no children)
    first_child_index: u16 = 0,
    /// Number of direct children
    child_count: u16 = 0,
    /// Depth in the menu tree (0 = root)
    depth: u8 = 0,

    pub fn getLabel(self: *const MenuItem) []const u8 {
        return self.label[0..self.label_len];
    }

    pub fn getIconName(self: *const MenuItem) []const u8 {
        return self.icon_name[0..self.icon_name_len];
    }

    pub fn isSeparator(self: *const MenuItem) bool {
        return self.item_type == .separator;
    }

    pub fn isSubmenu(self: *const MenuItem) bool {
        return self.children_display == .submenu and self.child_count > 0;
    }

    pub fn isChecked(self: *const MenuItem) bool {
        return self.toggle_state > 0;
    }
};

/// Flat menu layout — items in pre-order traversal.
/// Icon pixel data from D-Bus `icon-data` properties is packed contiguously
/// in `icon_data_buf`; each MenuItem references its slice via offset + length.
pub const MenuLayout = struct {
    items: [max_menu_items]MenuItem = undefined,
    item_count: usize = 0,
    revision: u32 = 0,
    /// Shared icon data buffer — all items' icon-data packed contiguously
    icon_data_buf: [max_icon_data_total]u8 = undefined,
    icon_data_used: u32 = 0,

    /// Get icon data for a menu item (reads from shared buffer).
    pub fn getIconData(self: *const MenuLayout, item: *const MenuItem) []const u8 {
        if (item.icon_data_len == 0) return &.{};
        const end = item.icon_data_offset + item.icon_data_len;
        if (end > self.icon_data_used) return &.{};
        return self.icon_data_buf[item.icon_data_offset..end];
    }

    /// Get the children of a menu item at the given index.
    pub fn getChildren(self: *const MenuLayout, parent_index: usize) []const MenuItem {
        if (parent_index >= self.item_count) return &.{};
        const parent = &self.items[parent_index];
        if (parent.child_count == 0 or parent.first_child_index == 0) return &.{};
        const start = parent.first_child_index;
        const end = @min(start + parent.child_count, self.item_count);
        return self.items[start..end];
    }

    /// Get the top-level items (children of root, index 0).
    pub fn getTopLevel(self: *const MenuLayout) []const MenuItem {
        if (self.item_count == 0) return &.{};
        return self.getChildren(0);
    }

    /// Find a menu item by its D-Bus id.
    pub fn findById(self: *const MenuLayout, id: i32) ?*const MenuItem {
        for (self.items[0..self.item_count]) |*item| {
            if (item.id == id) return item;
        }
        return null;
    }
};

/// Fetch the menu layout from a DBusMenu service.
/// Writes directly into the caller-provided MenuLayout (avoids large stack temporaries).
/// Returns true on success, false on failure.
pub fn getLayout(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    parent_id: i32,
    depth: i32,
    out: *MenuLayout,
) bool {
    // Build and call GetLayout(iias)
    // parent_id: root item id (usually 0)
    // depth: recursion depth (-1 = all)
    // property_names: empty array = all properties
    var err: dbus.c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    var reply: ?*dbus.c.sd_bus_message = null;

    const ret = dbus.c.sd_bus_call_method(
        conn.bus,
        service.ptr,
        path.ptr,
        dbusmenu_interface,
        "GetLayout",
        &err,
        &reply,
        "iias",
        parent_id,
        depth,
        @as(?*const anyopaque, null), // empty array terminator
    );

    defer dbus.c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (err.name != null) {
            log.debug("GetLayout failed: {s}", .{mem.span(err.name)});
        }
        return false;
    }

    var msg = dbus.Message.wrap(reply.?);
    defer msg.unref();

    // Response: u revision, (ia{sv}av) layout
    const revision = msg.readUint32() catch return false;

    out.* = MenuLayout{};
    out.revision = revision;

    // Parse the root item recursively
    parseLayoutItem(&msg, out, 0);

    return true;
}

/// Send a click event for a menu item.
pub fn sendClickEvent(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    item_id: i32,
) void {
    // Event(isvu) — id, event_id, data (variant), timestamp
    var err: dbus.c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    var reply: ?*dbus.c.sd_bus_message = null;

    const ret = dbus.c.sd_bus_call_method(
        conn.bus,
        service.ptr,
        path.ptr,
        dbusmenu_interface,
        "Event",
        &err,
        &reply,
        "isvu",
        item_id,
        @as([*:0]const u8, "clicked"),
        @as([*:0]const u8, "i"),
        @as(i32, 0), // variant data
        @as(u32, 0), // timestamp
    );

    defer dbus.c.sd_bus_error_free(&err);
    if (reply) |r| _ = dbus.c.sd_bus_message_unref(r);

    if (ret < 0) {
        log.debug("Event(clicked) failed for item {d}", .{item_id});
    }
}

/// Notify the menu that an item is about to be shown.
/// Returns true if the menu layout needs refreshing.
pub fn aboutToShow(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    item_id: i32,
) bool {
    var err: dbus.c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    var reply: ?*dbus.c.sd_bus_message = null;

    const ret = dbus.c.sd_bus_call_method(
        conn.bus,
        service.ptr,
        path.ptr,
        dbusmenu_interface,
        "AboutToShow",
        &err,
        &reply,
        "i",
        item_id,
    );

    defer dbus.c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (reply) |r| _ = dbus.c.sd_bus_message_unref(r);
        return false;
    }

    var msg = dbus.Message.wrap(reply.?);
    defer msg.unref();

    // Response: b needsUpdate
    return msg.readBool() catch false;
}

// --- Internal layout parser ---

fn parseLayoutItem(msg: *dbus.Message, layout: *MenuLayout, depth: u8) void {
    if (layout.item_count >= max_menu_items) return;
    if (depth > max_depth) return;

    // Enter struct (ia{sv}av)
    if (!(msg.enterStruct("ia{sv}av") catch false)) return;

    const item_index = layout.item_count;
    layout.item_count += 1;

    // Read id
    const id = msg.readInt32() catch {
        msg.exitContainer() catch {};
        return;
    };

    layout.items[item_index] = MenuItem{};
    layout.items[item_index].id = id;
    layout.items[item_index].depth = depth;

    // Parse properties: a{sv}
    parseItemProperties(msg, &layout.items[item_index], layout);

    // Parse children: av (array of variants containing child structs)
    if (msg.enterArray("v") catch false) {
        const first_child = layout.item_count;
        var child_count: u16 = 0;

        while (!msg.atEnd()) {
            if (layout.item_count >= max_menu_items) break;

            // Each child is a variant containing (ia{sv}av)
            if (msg.enterVariant("(ia{sv}av)") catch false) {
                child_count += 1;
                parseLayoutItem(msg, layout, depth + 1);
                msg.exitContainer() catch {}; // exit variant
            }
        }

        msg.exitContainer() catch {}; // exit array

        if (child_count > 0) {
            layout.items[item_index].first_child_index = @intCast(first_child);
            layout.items[item_index].child_count = child_count;
        }
    }

    msg.exitContainer() catch {}; // exit struct
}

fn parseItemProperties(msg: *dbus.Message, item: *MenuItem, layout: *MenuLayout) void {
    if (!(msg.enterArray("{sv}") catch false)) return;

    while (!msg.atEnd()) {
        if (!(msg.enterDictEntry("sv") catch false)) break;

        const key = msg.readString() catch {
            msg.exitContainer() catch {};
            continue;
        };

        var consumed = false;

        if (mem.eql(u8, key, "type")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| {
                    item.item_type = MenuItemType.fromString(val);
                } else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "label")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| {
                    const copy_len = @min(val.len, max_label_len);
                    @memcpy(item.label[0..copy_len], val[0..copy_len]);
                    item.label_len = copy_len;
                } else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "enabled")) {
            if (msg.enterVariant("b") catch false) {
                item.enabled = msg.readBool() catch true;
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "visible")) {
            if (msg.enterVariant("b") catch false) {
                item.visible = msg.readBool() catch true;
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "icon-name")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| {
                    const copy_len = @min(val.len, max_icon_len);
                    @memcpy(item.icon_name[0..copy_len], val[0..copy_len]);
                    item.icon_name_len = copy_len;
                } else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "icon-data")) {
            if (msg.enterVariant("ay") catch false) {
                if (msg.readByteArray()) |data| {
                    const remaining = max_icon_data_total - layout.icon_data_used;
                    const copy_len: u32 = @intCast(@min(data.len, remaining));
                    if (copy_len > 0) {
                        const offset = layout.icon_data_used;
                        @memcpy(layout.icon_data_buf[offset..][0..copy_len], data[0..copy_len]);
                        item.icon_data_offset = offset;
                        item.icon_data_len = @intCast(copy_len);
                        layout.icon_data_used = offset + copy_len;
                    }
                } else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "toggle-type")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| {
                    item.toggle_type = ToggleType.fromString(val);
                } else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "toggle-state")) {
            if (msg.enterVariant("i") catch false) {
                item.toggle_state = msg.readInt32() catch -1;
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "children-display")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| {
                    item.children_display = ChildrenDisplay.fromString(val);
                } else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        }

        if (!consumed) {
            msg.skip("v") catch {};
        }

        msg.exitContainer() catch {}; // exit dict entry
    }

    msg.exitContainer() catch {}; // exit array
}

// Tests

test "DBusMenu types compile" {
    _ = MenuItem;
    _ = MenuLayout;
    _ = MenuItemType;
    _ = ToggleType;
    _ = ChildrenDisplay;
}

test "MenuItemType fromString" {
    const testing = std.testing;

    try testing.expectEqual(MenuItemType.separator, MenuItemType.fromString("separator"));
    try testing.expectEqual(MenuItemType.standard, MenuItemType.fromString("standard"));
    try testing.expectEqual(MenuItemType.standard, MenuItemType.fromString("other"));
}

test "ToggleType fromString" {
    const testing = std.testing;

    try testing.expectEqual(ToggleType.checkmark, ToggleType.fromString("checkmark"));
    try testing.expectEqual(ToggleType.radio, ToggleType.fromString("radio"));
    try testing.expectEqual(ToggleType.none, ToggleType.fromString(""));
}

test "ChildrenDisplay fromString" {
    const testing = std.testing;

    try testing.expectEqual(ChildrenDisplay.submenu, ChildrenDisplay.fromString("submenu"));
    try testing.expectEqual(ChildrenDisplay.none, ChildrenDisplay.fromString(""));
}

test "MenuItem default state" {
    const testing = std.testing;

    const item = MenuItem{};
    try testing.expectEqual(@as(i32, 0), item.id);
    try testing.expectEqual(MenuItemType.standard, item.item_type);
    try testing.expect(item.enabled);
    try testing.expect(item.visible);
    try testing.expect(!item.isSeparator());
    try testing.expect(!item.isSubmenu());
    try testing.expect(!item.isChecked());
    try testing.expectEqual(@as(usize, 0), item.label_len);
}

test "MenuLayout getChildren empty" {
    const testing = std.testing;

    const layout = MenuLayout{};
    try testing.expectEqual(@as(usize, 0), layout.item_count);
    try testing.expectEqual(@as(usize, 0), layout.getTopLevel().len);
    try testing.expectEqual(@as(usize, 0), layout.getChildren(0).len);
}

test "MenuLayout getChildren populated" {
    const testing = std.testing;

    var layout = MenuLayout{};

    // Root item at index 0
    layout.items[0] = MenuItem{ .id = 0, .depth = 0, .first_child_index = 1, .child_count = 2 };
    // Child 1 at index 1
    layout.items[1] = MenuItem{ .id = 1, .depth = 1 };
    // Child 2 at index 2
    layout.items[2] = MenuItem{ .id = 2, .depth = 1 };
    layout.item_count = 3;

    const children = layout.getChildren(0);
    try testing.expectEqual(@as(usize, 2), children.len);
    try testing.expectEqual(@as(i32, 1), children[0].id);
    try testing.expectEqual(@as(i32, 2), children[1].id);

    // Top level should be the same as children of root
    const top = layout.getTopLevel();
    try testing.expectEqual(@as(usize, 2), top.len);
}

test "MenuLayout findById" {
    const testing = std.testing;

    var layout = MenuLayout{};
    layout.items[0] = MenuItem{ .id = 0 };
    layout.items[1] = MenuItem{ .id = 42 };
    layout.items[2] = MenuItem{ .id = 99 };
    layout.item_count = 3;

    const found = layout.findById(42);
    try testing.expect(found != null);
    try testing.expectEqual(@as(i32, 42), found.?.id);

    try testing.expect(layout.findById(999) == null);
}

test "MenuLayout getIconData shared buffer" {
    const testing = std.testing;

    var layout = MenuLayout{};
    layout.item_count = 2;

    // Simulate two items with icon data packed into the shared buffer
    const data1 = [_]u8{ 0x89, 0x50, 0x4E, 0x47 }; // PNG header
    const data2 = [_]u8{ 0xFF, 0xD8, 0xFF, 0xE0, 0x00 }; // JPEG header

    @memcpy(layout.icon_data_buf[0..data1.len], &data1);
    layout.items[0] = MenuItem{ .id = 1, .icon_data_offset = 0, .icon_data_len = data1.len };
    layout.icon_data_used = data1.len;

    @memcpy(layout.icon_data_buf[data1.len..][0..data2.len], &data2);
    layout.items[1] = MenuItem{ .id = 2, .icon_data_offset = data1.len, .icon_data_len = data2.len };
    layout.icon_data_used = data1.len + data2.len;

    // Verify item 0's icon data
    const got1 = layout.getIconData(&layout.items[0]);
    try testing.expectEqual(data1.len, got1.len);
    try testing.expectEqualSlices(u8, &data1, got1);

    // Verify item 1's icon data
    const got2 = layout.getIconData(&layout.items[1]);
    try testing.expectEqual(data2.len, got2.len);
    try testing.expectEqualSlices(u8, &data2, got2);

    // Item with no icon data returns empty
    const empty_item = MenuItem{};
    try testing.expectEqual(@as(usize, 0), layout.getIconData(&empty_item).len);
}
