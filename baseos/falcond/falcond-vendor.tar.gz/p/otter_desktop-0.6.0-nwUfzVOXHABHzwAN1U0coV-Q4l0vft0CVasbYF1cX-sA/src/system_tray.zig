//! System Tray Orchestrator
//!
//! Combines StatusNotifierWatcher, StatusNotifierItem, and DBusMenu
//! into a single service for managing tray items. Uses the global
//! shared service pattern (like MPRIS/UPower).
//!
//! Shares the watcher's session bus connection for all client queries.

const std = @import("std");
const mem = std.mem;
const Allocator = std.mem.Allocator;
const posix = std.posix;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const snw = @import("status_notifier_watcher.zig");
const StatusNotifierWatcher = snw.StatusNotifierWatcher;
const RegisteredItem = snw.RegisteredItem;

const sni = @import("status_notifier_item.zig");
const ItemProperties = sni.ItemProperties;

const dbus_menu = @import("dbus_menu.zig");
const MenuLayout = dbus_menu.MenuLayout;

const log = std.log.scoped(.system_tray);

/// Maximum number of tray items
const max_items = 32;

/// Maximum subscribers
const max_subscribers = 8;

/// Maximum service/path string length
const max_id_len = 256;

/// A cached tray item with its properties and optional menu
pub const TrayItem = struct {
    service: [max_id_len]u8 = undefined,
    service_len: usize = 0,
    path: [max_id_len]u8 = undefined,
    path_len: usize = 0,
    properties: ItemProperties = .{},
    /// Heap-allocated menu layout (cold data, loaded on demand via right-click)
    menu: ?*MenuLayout = null,
    dirty: bool = true,

    pub fn getService(self: *const TrayItem) []const u8 {
        return self.service[0..self.service_len];
    }

    pub fn getPath(self: *const TrayItem) []const u8 {
        return self.path[0..self.path_len];
    }

    pub fn getServiceZ(self: *TrayItem) [:0]const u8 {
        if (self.service_len < max_id_len) {
            self.service[self.service_len] = 0;
            return self.service[0..self.service_len :0];
        }
        self.service[max_id_len - 1] = 0;
        return self.service[0 .. max_id_len - 1 :0];
    }

    pub fn getPathZ(self: *TrayItem) [:0]const u8 {
        if (self.path_len < max_id_len) {
            self.path[self.path_len] = 0;
            return self.path[0..self.path_len :0];
        }
        self.path[max_id_len - 1] = 0;
        return self.path[0 .. max_id_len - 1 :0];
    }

    fn deinit(self: *TrayItem, allocator: Allocator) void {
        self.freeMenu(allocator);
        self.properties.deinit();
    }

    fn freeMenu(self: *TrayItem, allocator: Allocator) void {
        if (self.menu) |m| {
            allocator.destroy(m);
            self.menu = null;
        }
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscription = struct {
    callback: StateChangeFn,
    context: ?*anyopaque,
};

pub const Error = dbus.types.Error || snw.Error;

pub const SystemTray = struct {
    allocator: Allocator,
    watcher: StatusNotifierWatcher,
    items: [max_items]?TrayItem = .{null} ** max_items,
    item_count: usize = 0,
    subscriptions: [max_subscribers]?Subscription = .{null} ** max_subscribers,
    subscription_count: usize = 0,
    initialized: bool = false,

    /// Initialize the system tray.
    /// Connects to the session D-Bus via the watcher.
    /// Call `startMonitoring()` AFTER the struct is in its final memory location.
    pub fn init(allocator: Allocator) Error!SystemTray {
        var watcher = try StatusNotifierWatcher.init(allocator);
        errdefer watcher.deinit();

        return SystemTray{
            .allocator = allocator,
            .watcher = watcher,
        };
    }

    /// Start monitoring — starts watcher and subscribes to signals.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *SystemTray) void {
        self.watcher.startMonitoring();

        // Subscribe to watcher changes
        _ = self.watcher.subscribe(onWatcherChanged, self);

        // Subscribe to SNI property change signals
        self.subscribeToItemSignals() catch |err| {
            log.warn("Failed to subscribe to item signals: {s}", .{@errorName(err)});
        };

        // Subscribe to DBusMenu LayoutUpdated
        self.subscribeToMenuSignals() catch |err| {
            log.warn("Failed to subscribe to menu signals: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *SystemTray) void {
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                item.deinit(self.allocator);
                slot.* = null;
            }
        }
        self.watcher.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const SystemTray) posix.fd_t {
        return self.watcher.getFd();
    }

    /// Process pending D-Bus messages.
    /// Returns true if there are more messages to process.
    pub fn process(self: *SystemTray) bool {
        // Deferred initialization — sync items on first process
        if (!self.initialized) {
            self.initialized = true;
            self.syncItems();
            self.refreshDirtyItems();
        }

        const more = self.watcher.process();

        // Check for dirty items that need property refresh
        self.refreshDirtyItems();

        return more;
    }

    /// Get all tray items.
    pub fn getItems(self: *const SystemTray) []const ?TrayItem {
        return &self.items;
    }

    /// Get number of tray items.
    pub fn getItemCount(self: *const SystemTray) usize {
        return self.item_count;
    }

    /// Activate a tray item (left click).
    pub fn activateItem(self: *SystemTray, index: usize, x: i32, y: i32) void {
        if (index >= max_items) return;
        if (self.items[index]) |*item| {
            sni.activate(&self.watcher.connection, item.getServiceZ(), item.getPathZ(), x, y);
        }
    }

    /// Secondary activate a tray item (middle click).
    pub fn secondaryActivateItem(self: *SystemTray, index: usize, x: i32, y: i32) void {
        if (index >= max_items) return;
        if (self.items[index]) |*item| {
            sni.secondaryActivate(&self.watcher.connection, item.getServiceZ(), item.getPathZ(), x, y);
        }
    }

    /// Show context menu for a tray item (right click).
    pub fn contextMenuItem(self: *SystemTray, index: usize, x: i32, y: i32) void {
        if (index >= max_items) return;
        if (self.items[index]) |*item| {
            sni.contextMenu(&self.watcher.connection, item.getServiceZ(), item.getPathZ(), x, y);
        }
    }

    /// Lazy-load a menu for a tray item. Heap-allocates MenuLayout on first access.
    pub fn loadItemMenu(self: *SystemTray, index: usize) ?*const MenuLayout {
        if (index >= max_items) return null;
        if (self.items[index]) |*item| {
            const menu_path = item.properties.menu_path.get();
            if (menu_path.len == 0) return null;

            // Fetch menu if not cached
            if (item.menu == null) {
                var path_buf: [max_id_len:0]u8 = undefined;
                const len = @min(menu_path.len, max_id_len);
                @memcpy(path_buf[0..len], menu_path[0..len]);
                path_buf[len] = 0;

                const ptr = self.allocator.create(MenuLayout) catch return null;
                if (dbus_menu.getLayout(
                    &self.watcher.connection,
                    item.getServiceZ(),
                    path_buf[0..len :0],
                    0,
                    -1,
                    ptr,
                )) {
                    item.menu = ptr;
                } else {
                    self.allocator.destroy(ptr);
                    return null;
                }
            }

            if (item.menu) |menu| return menu;
        }
        return null;
    }

    /// Send a click event for a menu item.
    pub fn clickMenuItem(self: *SystemTray, item_index: usize, menu_item_id: i32) void {
        if (item_index >= max_items) return;
        if (self.items[item_index]) |*item| {
            const menu_path = item.properties.menu_path.get();
            if (menu_path.len == 0) return;

            var path_buf: [max_id_len:0]u8 = undefined;
            const len = @min(menu_path.len, max_id_len);
            @memcpy(path_buf[0..len], menu_path[0..len]);
            path_buf[len] = 0;

            dbus_menu.sendClickEvent(
                &self.watcher.connection,
                item.getServiceZ(),
                path_buf[0..len :0],
                menu_item_id,
            );
        }
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *SystemTray, callback: StateChangeFn, context: ?*anyopaque) bool {
        if (self.subscription_count >= max_subscribers) return false;

        for (&self.subscriptions) |*slot| {
            if (slot.* == null) {
                slot.* = .{ .callback = callback, .context = context };
                self.subscription_count += 1;
                return true;
            }
        }
        return false;
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *SystemTray, callback: StateChangeFn, context: ?*anyopaque) void {
        for (&self.subscriptions) |*slot| {
            if (slot.*) |sub| {
                if (sub.callback == callback and sub.context == context) {
                    slot.* = null;
                    self.subscription_count -|= 1;
                    return;
                }
            }
        }
    }

    // --- Internal ---

    /// Sync cached items with watcher's registered items.
    fn syncItems(self: *SystemTray) void {
        const watcher_items = self.watcher.getItems();

        // Remove items no longer in watcher
        for (&self.items) |*slot| {
            if (slot.*) |*cached| {
                var found = false;
                for (watcher_items) |maybe_reg| {
                    if (maybe_reg) |reg| {
                        if (mem.eql(u8, cached.getService(), reg.getService()) and
                            mem.eql(u8, cached.getPath(), reg.getPath()))
                        {
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) {
                    cached.deinit(self.allocator);
                    slot.* = null;
                    self.item_count -|= 1;
                }
            }
        }

        // Add new items from watcher
        for (watcher_items) |maybe_reg| {
            if (maybe_reg) |reg| {
                // Check if already cached
                var exists = false;
                for (self.items) |maybe_cached| {
                    if (maybe_cached) |cached| {
                        if (mem.eql(u8, cached.getService(), reg.getService()) and
                            mem.eql(u8, cached.getPath(), reg.getPath()))
                        {
                            exists = true;
                            break;
                        }
                    }
                }

                if (!exists) {
                    // Find empty slot
                    for (&self.items) |*slot| {
                        if (slot.* == null) {
                            var tray_item = TrayItem{};
                            const s_len = @min(reg.service_len, max_id_len);
                            @memcpy(tray_item.service[0..s_len], reg.service[0..s_len]);
                            tray_item.service_len = s_len;
                            const p_len = @min(reg.path_len, max_id_len);
                            @memcpy(tray_item.path[0..p_len], reg.path[0..p_len]);
                            tray_item.path_len = p_len;
                            tray_item.dirty = true;
                            slot.* = tray_item;
                            self.item_count += 1;
                            break;
                        }
                    }
                }
            }
        }
    }

    /// Refresh properties for items marked dirty.
    fn refreshDirtyItems(self: *SystemTray) void {
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                if (item.dirty) {
                    item.properties.deinit();
                    item.properties = sni.readItemProperties(
                        &self.watcher.connection,
                        self.allocator,
                        item.getServiceZ(),
                        item.getPathZ(),
                    );
                    item.dirty = false;
                }
            }
        }
    }

    fn onWatcherChanged(ctx: ?*anyopaque) void {
        const self: *SystemTray = @ptrCast(@alignCast(ctx orelse return));
        self.syncItems();
        self.notify();
    }

    fn handleItemSignal(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *SystemTray = @ptrCast(@alignCast(ctx orelse return));
        const sender = msg.getSender() orelse return;

        // Mark matching items as dirty
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                if (mem.eql(u8, item.getService(), sender)) {
                    item.dirty = true;
                    item.freeMenu(self.allocator); // Invalidate cached menu
                }
            }
        }

        self.notify();
    }

    fn handleMenuLayoutUpdated(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *SystemTray = @ptrCast(@alignCast(ctx orelse return));
        const sender = msg.getSender() orelse return;

        // Invalidate cached menu for matching items
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                if (mem.eql(u8, item.getService(), sender)) {
                    item.freeMenu(self.allocator);
                }
            }
        }

        self.notify();
    }

    fn subscribeToItemSignals(self: *SystemTray) Error!void {
        // Subscribe to all SNI property change signals
        const signals = [_][]const u8{
            "NewIcon",
            "NewAttentionIcon",
            "NewOverlayIcon",
            "NewTitle",
            "NewStatus",
            "NewToolTip",
        };

        inline for (signals) |signal| {
            try self.watcher.connection.subscribeMatch(
                "type='signal'," ++
                    "interface='org.kde.StatusNotifierItem'," ++
                    "member='" ++ signal ++ "'",
                handleItemSignal,
                self,
            );
        }
    }

    fn subscribeToMenuSignals(self: *SystemTray) Error!void {
        try self.watcher.connection.subscribeMatch(
            "type='signal'," ++
                "interface='com.canonical.dbusmenu'," ++
                "member='LayoutUpdated'",
            handleMenuLayoutUpdated,
            self,
        );
    }

    fn notify(self: *const SystemTray) void {
        for (self.subscriptions) |maybe_sub| {
            if (maybe_sub) |sub| {
                sub.callback(sub.context);
            }
        }
    }
};

// Tests

test "SystemTray types compile" {
    _ = SystemTray;
    _ = TrayItem;
    _ = StateChangeFn;
    _ = Subscription;
}

test "TrayItem default state" {
    const testing = std.testing;

    var item = TrayItem{};
    try testing.expectEqual(@as(usize, 0), item.service_len);
    try testing.expectEqual(@as(usize, 0), item.path_len);
    try testing.expect(item.dirty);
    try testing.expect(item.menu == null);
    try testing.expectEqual(sni.Category.unknown, item.properties.category);
    try testing.expectEqual(sni.Status.unknown, item.properties.status);
    item.deinit(std.testing.allocator);
}

test "TrayItem field operations" {
    const testing = std.testing;

    var item = TrayItem{};
    const svc = ":1.42";
    @memcpy(item.service[0..svc.len], svc);
    item.service_len = svc.len;
    try testing.expectEqualStrings(":1.42", item.getService());

    const path = "/StatusNotifierItem";
    @memcpy(item.path[0..path.len], path);
    item.path_len = path.len;
    try testing.expectEqualStrings("/StatusNotifierItem", item.getPath());
    item.deinit(std.testing.allocator);
}
