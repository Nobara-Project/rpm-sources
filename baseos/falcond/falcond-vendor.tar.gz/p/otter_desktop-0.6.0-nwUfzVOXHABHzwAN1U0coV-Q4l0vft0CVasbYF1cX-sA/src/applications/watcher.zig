//! Application directory watcher using inotify
//!
//! Watches XDG application directories for changes to .desktop files.

const std = @import("std");
const mem = std.mem;
const posix = std.posix;
const Allocator = std.mem.Allocator;
const otter_utils = @import("otter_utils");

const InotifyWatcher = otter_utils.inotify.Watcher;

const log = std.log.scoped(.AppDirWatcher);

pub const AppDirWatcher = struct {
    inner: InotifyWatcher,

    pub const Event = struct {
        dir_path: []const u8,
        filename: ?[]const u8,
        kind: Kind,

        pub const Kind = enum {
            created,
            modified,
            deleted,
            moved,
        };
    };

    pub const InitError = InotifyWatcher.InitError;
    pub const WatchError = InotifyWatcher.WatchError;

    pub fn init(allocator: Allocator) InitError!AppDirWatcher {
        return .{ .inner = try InotifyWatcher.init(allocator) };
    }

    pub fn deinit(self: *AppDirWatcher) void {
        self.inner.deinit();
    }

    /// Add a directory to watch for .desktop file changes.
    pub fn watchDirectory(self: *AppDirWatcher, path: []const u8) WatchError!void {
        _ = try self.inner.addWatch(path, InotifyWatcher.Mask.dir_changes);
        log.debug("Watching directory: {s}", .{path});
    }

    /// Remove a directory from watching.
    pub fn unwatchDirectory(self: *AppDirWatcher, path: []const u8) void {
        self.inner.removeWatchByPath(path);
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const AppDirWatcher) posix.fd_t {
        return self.inner.getFd();
    }

    /// Read and iterate over pending events.
    /// Only returns events for .desktop files.
    pub fn nextEvent(self: *AppDirWatcher) ?Event {
        while (self.inner.nextEvent()) |raw_event| {
            // Filter to only .desktop files
            if (raw_event.name) |filename| {
                if (!mem.endsWith(u8, filename, ".desktop")) {
                    continue;
                }
            }

            const dir_path = self.inner.getPath(raw_event.wd) orelse continue;

            const kind: Event.Kind = if (raw_event.isCreated())
                .created
            else if (raw_event.isDeleted())
                .deleted
            else if (raw_event.isModified())
                .modified
            else if (raw_event.isMoved())
                .moved
            else
                continue;

            return Event{
                .dir_path = dir_path,
                .filename = raw_event.name,
                .kind = kind,
            };
        }
        return null;
    }

    /// Check if there are pending events (non-blocking).
    pub fn hasPendingEvents(self: *const AppDirWatcher) bool {
        return self.inner.hasPendingEvents();
    }
};

test "watcher init and deinit" {
    var watcher = try AppDirWatcher.init(std.testing.allocator);
    defer watcher.deinit();
    try std.testing.expect(watcher.getFd() >= 0);
}

test "event kind" {
    const event = AppDirWatcher.Event{
        .dir_path = "/usr/share/applications",
        .filename = "test.desktop",
        .kind = .created,
    };
    try std.testing.expectEqual(AppDirWatcher.Event.Kind.created, event.kind);
    try std.testing.expectEqualStrings("test.desktop", event.filename.?);
}
