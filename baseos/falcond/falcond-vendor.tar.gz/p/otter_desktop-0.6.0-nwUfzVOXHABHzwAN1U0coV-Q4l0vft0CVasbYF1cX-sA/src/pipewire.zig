//! PipeWire Audio Control
//!
//! Provides access to PipeWire for audio device enumeration and volume control.
//! Uses the native libpipewire-0.3 API for optimal integration.
//!
//! Features:
//! - Enumerate audio sinks (speakers, headphones) and sources (microphones)
//! - Get/set volume and mute state per device (by node ID or default device)
//! - Track default device changes via PipeWire metadata
//! - Switch default sink/source via metadata set_property
//! - Pub/sub for state change notifications

const std = @import("std");
const mem = std.mem;
const Allocator = std.mem.Allocator;
const posix = std.posix;

const log = std.log.scoped(.pipewire);

/// PipeWire C bindings (statically linked via allyourcodebase/pipewire)
const pipewire = @import("pipewire");
pub const c = pipewire.c;

/// Re-export the Logger module to force its evaluation.
/// This ensures the Logger's export functions (__nova_debugc_format, __log_enabled, __nova_logtv)
/// are included, which are needed by pipewire's src/lib/va.c for logging.
pub const Logger = pipewire.Logger;

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// Maximum number of tracked devices
const max_devices = 16;

/// Maximum length for device name/description
const max_string_len = 256;

/// Device type
pub const DeviceType = enum {
    sink, // Output (speakers, headphones)
    source, // Input (microphone)
};

/// Fixed-size string storage
fn FixedString(comptime max_len: usize) type {
    return struct {
        data: [max_len]u8 = undefined,
        len: usize = 0,

        const Self = @This();

        pub fn set(self: *Self, value: []const u8) void {
            const copy_len = @min(value.len, max_len);
            @memcpy(self.data[0..copy_len], value[0..copy_len]);
            self.len = copy_len;
        }

        pub fn setFromC(self: *Self, value: [*c]const u8) void {
            if (value == null) {
                self.len = 0;
                return;
            }
            const slice = mem.span(value);
            self.set(slice);
        }

        pub fn get(self: *const Self) []const u8 {
            return self.data[0..self.len];
        }

        pub fn isEmpty(self: *const Self) bool {
            return self.len == 0;
        }

        pub fn clear(self: *Self) void {
            self.len = 0;
        }
    };
}

/// Audio device information
pub const AudioDevice = struct {
    /// PipeWire node ID
    id: u32 = 0,

    /// Device name (internal identifier)
    name: FixedString(max_string_len) = .{},

    /// Human-readable description
    description: FixedString(max_string_len) = .{},

    /// Device type (sink or source)
    device_type: DeviceType = .sink,

    /// Volume level (0.0 to 1.0+)
    volume: f32 = 1.0,

    /// Number of channels
    channels: u32 = 2,

    /// Muted state
    muted: bool = false,

    /// Whether this is the default device
    is_default: bool = false,

    /// Media class (e.g., "Audio/Sink")
    media_class: FixedString(64) = .{},

    /// Check if device is an output (sink)
    pub fn isSink(self: *const AudioDevice) bool {
        return self.device_type == .sink;
    }

    /// Check if device is an input (source)
    pub fn isSource(self: *const AudioDevice) bool {
        return self.device_type == .source;
    }

    /// Get volume as percentage (0-150, PipeWire allows overamplification up to 1.5)
    pub fn getVolumePercent(self: *const AudioDevice) u8 {
        return @intFromFloat(@min(150.0, @max(0.0, self.volume * 100.0)));
    }
};

/// PipeWire metadata events (matches struct pw_metadata_events from extensions/metadata.h).
/// Used for tracking default device changes via metadata property callbacks.
const MetadataEvents = extern struct {
    version: u32 = 0, // PW_VERSION_METADATA_EVENTS
    property: ?*const fn (
        data: ?*anyopaque,
        subject: u32,
        key: [*c]const u8,
        type_str: [*c]const u8,
        value: [*c]const u8,
    ) callconv(.c) c_int = null,
};

/// PipeWire metadata methods (matches struct pw_metadata_methods from extensions/metadata.h).
/// Used for setting default device via set_property.
const MetadataMethods = extern struct {
    version: u32 = 0,
    add_listener: ?*const fn (?*anyopaque, [*c]c.spa_hook, ?*const anyopaque, ?*anyopaque) callconv(.c) c_int = null,
    set_property: ?*const fn (?*anyopaque, u32, [*c]const u8, [*c]const u8, [*c]const u8) callconv(.c) c_int = null,
    clear: ?*const fn (?*anyopaque) callconv(.c) c_int = null,
};

/// Per-node proxy tracking (separate from AudioDevice for stable listener addresses).
const NodeSlot = struct {
    parent: ?*PipeWire = null,
    node_id: u32 = 0,
    proxy: ?*c.struct_pw_node = null,
    listener: c.spa_hook = std.mem.zeroes(c.spa_hook),
    active: bool = false,

    fn deinit(self: *NodeSlot) void {
        if (self.proxy) |proxy| {
            c.spa_hook_remove(&self.listener);
            c.pw_proxy_destroy(@ptrCast(proxy));
        }
        self.* = .{};
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscription = struct {
    callback: StateChangeFn,
    context: ?*anyopaque,
};

pub const Error = error{
    InitFailed,
    ConnectionFailed,
    NoDevice,
    OperationFailed,
};

/// Registry event handlers
const RegistryEvents = extern struct {
    version: u32 = c.PW_VERSION_REGISTRY_EVENTS,
    global: ?*const fn (?*anyopaque, u32, u32, [*c]const u8, u32, ?*const c.spa_dict) callconv(.c) void = null,
    global_remove: ?*const fn (?*anyopaque, u32) callconv(.c) void = null,
};

/// Core event handlers
const CoreEvents = extern struct {
    version: u32 = c.PW_VERSION_CORE_EVENTS,
    info: ?*const fn (?*anyopaque, ?*const c.pw_core_info) callconv(.c) void = null,
    done: ?*const fn (?*anyopaque, u32, c_int) callconv(.c) void = null,
    ping: ?*const fn (?*anyopaque, u32, c_int) callconv(.c) void = null,
    @"error": ?*const fn (?*anyopaque, u32, c_int, c_int, [*c]const u8) callconv(.c) void = null,
    remove_id: ?*const fn (?*anyopaque, u32) callconv(.c) void = null,
    bound_id: ?*const fn (?*anyopaque, u32, u32) callconv(.c) void = null,
    add_mem: ?*const fn (?*anyopaque, u32, u32, c_int, u32) callconv(.c) void = null,
    remove_mem: ?*const fn (?*anyopaque, u32) callconv(.c) void = null,
    bound_props: ?*const fn (?*anyopaque, u32, u32, ?*const c.spa_dict) callconv(.c) void = null,
};

pub const PipeWire = struct {
    allocator: Allocator,
    subscriptions: [max_subscribers]?Subscription = .{null} ** max_subscribers,
    subscription_count: usize = 0,

    // PipeWire handles
    main_loop: ?*c.pw_main_loop = null,
    loop: ?*c.pw_loop = null,
    context: ?*c.pw_context = null,
    core: ?*c.pw_core = null,
    registry: ?*c.pw_registry = null,

    // Listener hooks (must be stable in memory)
    core_listener: c.spa_hook = undefined,
    registry_listener: c.spa_hook = undefined,

    // Event callbacks
    registry_events: RegistryEvents = .{},
    core_events: CoreEvents = .{},

    // Tracked devices
    sinks: [max_devices]?AudioDevice = .{null} ** max_devices,
    sink_count: usize = 0,
    sources: [max_devices]?AudioDevice = .{null} ** max_devices,
    source_count: usize = 0,

    // Node proxies for volume/mute control
    node_slots: [max_devices * 2]NodeSlot = std.mem.zeroes([max_devices * 2]NodeSlot),

    // Default device IDs
    default_sink_id: ?u32 = null,
    default_source_id: ?u32 = null,

    // Metadata proxy for default device tracking
    metadata_proxy: ?*c.struct_pw_proxy = null,
    metadata_listener: c.spa_hook = std.mem.zeroes(c.spa_hook),

    // Pending operations sync
    pending_seq: c_int = 0,
    initialized: bool = false,

    /// Initialize PipeWire connection.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location.
    pub fn init(allocator: Allocator) Error!PipeWire {
        // Initialize PipeWire library
        c.pw_init(null, null);

        var self = PipeWire{
            .allocator = allocator,
        };

        // Create main loop
        self.main_loop = c.pw_main_loop_new(null);
        if (self.main_loop == null) {
            log.err("Failed to create PipeWire main loop", .{});
            return Error.InitFailed;
        }

        self.loop = c.pw_main_loop_get_loop(self.main_loop);

        // Create context
        self.context = c.pw_context_new(self.loop, null, 0);
        if (self.context == null) {
            log.err("Failed to create PipeWire context", .{});
            c.pw_main_loop_destroy(self.main_loop);
            return Error.InitFailed;
        }

        // Connect to PipeWire
        self.core = c.pw_context_connect(self.context, null, 0);
        if (self.core == null) {
            log.err("Failed to connect to PipeWire", .{});
            c.pw_context_destroy(self.context);
            c.pw_main_loop_destroy(self.main_loop);
            return Error.ConnectionFailed;
        }

        // Get registry
        self.registry = c.pw_core_get_registry(self.core, c.PW_VERSION_REGISTRY, 0);
        if (self.registry == null) {
            log.err("Failed to get PipeWire registry", .{});
            _ = c.pw_core_disconnect(self.core);
            c.pw_context_destroy(self.context);
            c.pw_main_loop_destroy(self.main_loop);
            return Error.ConnectionFailed;
        }

        log.info("PipeWire connection established", .{});
        return self;
    }

    /// Start monitoring for registry events.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *PipeWire) void {
        // Initialize listener hooks
        self.core_listener = std.mem.zeroes(c.spa_hook);
        self.registry_listener = std.mem.zeroes(c.spa_hook);

        // Set up registry events
        self.registry_events = .{
            .global = registryGlobalCallback,
            .global_remove = registryGlobalRemoveCallback,
        };

        // Set up core events
        self.core_events = .{
            .done = coreDoneCallback,
        };

        // Add listeners
        _ = c.pw_core_add_listener(self.core, &self.core_listener, @ptrCast(&self.core_events), self);
        _ = c.pw_registry_add_listener(self.registry, &self.registry_listener, @ptrCast(&self.registry_events), self);

        // Trigger initial enumeration
        self.pending_seq = c.pw_core_sync(self.core, c.PW_ID_CORE, 0);

        log.debug("PipeWire monitoring started", .{});
    }

    pub fn deinit(self: *PipeWire) void {
        if (self.metadata_proxy) |proxy| {
            c.spa_hook_remove(&self.metadata_listener);
            c.pw_proxy_destroy(proxy);
        }
        for (&self.node_slots) |*slot| {
            if (slot.active) slot.deinit();
        }
        if (self.registry) |r| c.pw_proxy_destroy(@ptrCast(r));
        if (self.core) |core| {
            _ = c.pw_core_disconnect(core);
        }
        if (self.context) |ctx| c.pw_context_destroy(ctx);
        if (self.main_loop) |ml| c.pw_main_loop_destroy(ml);
        c.pw_deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const PipeWire) ?posix.fd_t {
        if (self.loop) |loop| {
            return c.pw_loop_get_fd(loop);
        }
        return null;
    }

    /// Process pending PipeWire events.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if more processing may be needed.
    pub fn process(self: *PipeWire) bool {
        if (self.loop == null) return false;

        // Process pending events (non-blocking)
        const result = c.pw_loop_iterate(self.loop, 0);
        return result > 0;
    }

    /// Get the default sink (output device).
    pub fn getDefaultSink(self: *const PipeWire) ?*const AudioDevice {
        if (self.default_sink_id) |id| {
            for (&self.sinks) |*slot| {
                if (slot.*) |*device| {
                    if (device.id == id) return device;
                }
            }
        }
        // Return first sink if no default set
        if (self.sink_count > 0) {
            if (self.sinks[0]) |*device| return device;
        }
        return null;
    }

    /// Get the default source (input device).
    pub fn getDefaultSource(self: *const PipeWire) ?*const AudioDevice {
        if (self.default_source_id) |id| {
            for (&self.sources) |*slot| {
                if (slot.*) |*device| {
                    if (device.id == id) return device;
                }
            }
        }
        // Return first source if no default set
        if (self.source_count > 0) {
            if (self.sources[0]) |*device| return device;
        }
        return null;
    }

    /// Get all sinks.
    pub fn getSinks(self: *const PipeWire) []const ?AudioDevice {
        return self.sinks[0..self.sink_count];
    }

    /// Get all sources.
    pub fn getSources(self: *const PipeWire) []const ?AudioDevice {
        return self.sources[0..self.source_count];
    }

    /// Set volume on default sink (0.0 to 1.0+).
    pub fn setSinkVolume(self: *PipeWire, volume: f32) Error!void {
        const device = self.getDefaultSinkMut() orelse return Error.NoDevice;
        try self.setDeviceVolume(device, volume);
    }

    /// Set volume on default source (0.0 to 1.0+).
    pub fn setSourceVolume(self: *PipeWire, volume: f32) Error!void {
        const device = self.getDefaultSourceMut() orelse return Error.NoDevice;
        try self.setDeviceVolume(device, volume);
    }

    /// Toggle mute on default sink.
    pub fn toggleSinkMute(self: *PipeWire) Error!void {
        const device = self.getDefaultSinkMut() orelse return Error.NoDevice;
        try self.setDeviceMute(device, !device.muted);
    }

    /// Toggle mute on default source.
    pub fn toggleSourceMute(self: *PipeWire) Error!void {
        const device = self.getDefaultSourceMut() orelse return Error.NoDevice;
        try self.setDeviceMute(device, !device.muted);
    }

    /// Set mute state on default sink.
    pub fn setSinkMute(self: *PipeWire, muted: bool) Error!void {
        const device = self.getDefaultSinkMut() orelse return Error.NoDevice;
        try self.setDeviceMute(device, muted);
    }

    /// Set mute state on default source.
    pub fn setSourceMute(self: *PipeWire, muted: bool) Error!void {
        const device = self.getDefaultSourceMut() orelse return Error.NoDevice;
        try self.setDeviceMute(device, muted);
    }

    /// Increase sink volume by step (default 5%).
    pub fn increaseSinkVolume(self: *PipeWire, step: f32) Error!void {
        const device = self.getDefaultSinkMut() orelse return Error.NoDevice;
        const new_volume = @min(1.5, roundToStep(device.volume + step, step));
        try self.setDeviceVolume(device, new_volume);
    }

    /// Decrease sink volume by step (default 5%).
    pub fn decreaseSinkVolume(self: *PipeWire, step: f32) Error!void {
        const device = self.getDefaultSinkMut() orelse return Error.NoDevice;
        const new_volume = @max(0.0, roundToStep(device.volume - step, step));
        try self.setDeviceVolume(device, new_volume);
    }

    /// Round volume to nearest step to avoid float drift from repeated add/subtract.
    fn roundToStep(value: f32, step: f32) f32 {
        if (step <= 0.0) return value;
        return @round(value / step) * step;
    }

    /// Set volume on any device by node ID (0.0 to 1.0+).
    pub fn setNodeVolume(self: *PipeWire, node_id: u32, volume: f32) Error!void {
        const device = self.findDeviceMut(node_id) orelse return Error.NoDevice;
        try self.setDeviceVolume(device, volume);
    }

    /// Set mute state on any device by node ID.
    pub fn setNodeMute(self: *PipeWire, node_id: u32, muted: bool) Error!void {
        const device = self.findDeviceMut(node_id) orelse return Error.NoDevice;
        try self.setDeviceMute(device, muted);
    }

    /// Toggle mute on any device by node ID.
    pub fn toggleNodeMute(self: *PipeWire, node_id: u32) Error!void {
        const device = self.findDeviceMut(node_id) orelse return Error.NoDevice;
        try self.setDeviceMute(device, !device.muted);
    }

    /// Set default sink via PipeWire metadata.
    pub fn setDefaultSink(self: *PipeWire, node_id: u32) Error!void {
        const device = self.findDeviceMut(node_id) orelse return Error.NoDevice;
        if (device.device_type != .sink) return Error.NoDevice;
        try self.setMetadataDefault("default.audio.sink", device);
    }

    /// Set default source via PipeWire metadata.
    pub fn setDefaultSource(self: *PipeWire, node_id: u32) Error!void {
        const device = self.findDeviceMut(node_id) orelse return Error.NoDevice;
        if (device.device_type != .source) return Error.NoDevice;
        try self.setMetadataDefault("default.audio.source", device);
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *PipeWire, callback: StateChangeFn, context: ?*anyopaque) bool {
        if (self.subscription_count >= max_subscribers) return false;

        for (&self.subscriptions) |*slot| {
            if (slot.* == null) {
                slot.* = .{ .callback = callback, .context = context };
                self.subscription_count += 1;
                return true;
            }
        }
        return false;
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *PipeWire, callback: StateChangeFn, context: ?*anyopaque) void {
        for (&self.subscriptions) |*slot| {
            if (slot.*) |sub| {
                if (sub.callback == callback and sub.context == context) {
                    slot.* = null;
                    self.subscription_count -|= 1;
                    return;
                }
            }
        }
    }

    // Internal methods

    fn getDefaultSinkMut(self: *PipeWire) ?*AudioDevice {
        if (self.default_sink_id) |id| {
            for (&self.sinks) |*slot| {
                if (slot.*) |*device| {
                    if (device.id == id) return device;
                }
            }
        }
        if (self.sink_count > 0) {
            if (self.sinks[0]) |*device| return device;
        }
        return null;
    }

    fn getDefaultSourceMut(self: *PipeWire) ?*AudioDevice {
        if (self.default_source_id) |id| {
            for (&self.sources) |*slot| {
                if (slot.*) |*device| {
                    if (device.id == id) return device;
                }
            }
        }
        if (self.source_count > 0) {
            if (self.sources[0]) |*device| return device;
        }
        return null;
    }

    fn setDeviceVolume(self: *PipeWire, device: *AudioDevice, volume: f32) Error!void {
        // Lazily bind proxy if not yet bound (handles metadata default changes
        // that arrive after bindDefaultProxies but before proxy swap completes)
        if (self.findNodeSlot(device.id) == null) {
            self.bindNodeProxy(device.id);
        }
        const slot = self.findNodeSlot(device.id) orelse return Error.NoDevice;
        const proxy = slot.proxy orelse return Error.NoDevice;

        var buffer: [1024]u8 = undefined;
        var builder: c.struct_spa_pod_builder = .{
            .data = &buffer,
            .size = buffer.len,
        };

        var frame: c.struct_spa_pod_frame = std.mem.zeroes(c.struct_spa_pod_frame);
        _ = c.spa_pod_builder_push_object(&builder, &frame, @bitCast(c.SPA_TYPE_OBJECT_Props), @bitCast(c.SPA_PARAM_Props));

        _ = c.spa_pod_builder_prop(&builder, @bitCast(c.SPA_PROP_channelVolumes), 0);

        var array_frame: c.struct_spa_pod_frame = std.mem.zeroes(c.struct_spa_pod_frame);
        _ = c.spa_pod_builder_push_array(&builder, &array_frame);

        const channels = @max(device.channels, 1);
        for (0..channels) |_| {
            _ = c.spa_pod_builder_float(&builder, volume);
        }

        _ = c.spa_pod_builder_pop(&builder, &array_frame);
        const pod: [*c]const c.struct_spa_pod = @ptrCast(@alignCast(c.spa_pod_builder_pop(&builder, &frame)));

        const result = c.pw_node_set_param(proxy, @bitCast(c.SPA_PARAM_Props), 0, pod);
        if (result < 0) {
            log.warn("pw_node_set_param(volume) failed: {d}", .{result});
            return Error.OperationFailed;
        }

        device.volume = volume;
        self.notify();
        log.debug("Volume set to {d:.2} for device {d}", .{ volume, device.id });
    }

    fn setDeviceMute(self: *PipeWire, device: *AudioDevice, muted: bool) Error!void {
        if (self.findNodeSlot(device.id) == null) {
            self.bindNodeProxy(device.id);
        }
        const slot = self.findNodeSlot(device.id) orelse return Error.NoDevice;
        const proxy = slot.proxy orelse return Error.NoDevice;

        var buffer: [256]u8 = undefined;
        var builder: c.struct_spa_pod_builder = .{
            .data = &buffer,
            .size = buffer.len,
        };

        var frame: c.struct_spa_pod_frame = std.mem.zeroes(c.struct_spa_pod_frame);
        _ = c.spa_pod_builder_push_object(&builder, &frame, @bitCast(c.SPA_TYPE_OBJECT_Props), @bitCast(c.SPA_PARAM_Props));
        _ = c.spa_pod_builder_prop(&builder, @bitCast(c.SPA_PROP_mute), 0);
        _ = c.spa_pod_builder_bool(&builder, muted);
        const pod: [*c]const c.struct_spa_pod = @ptrCast(@alignCast(c.spa_pod_builder_pop(&builder, &frame)));

        const result = c.pw_node_set_param(proxy, @bitCast(c.SPA_PARAM_Props), 0, pod);
        if (result < 0) {
            log.warn("pw_node_set_param(mute) failed: {d}", .{result});
            return Error.OperationFailed;
        }

        device.muted = muted;
        self.notify();
        log.debug("Mute set to {any} for device {d}", .{ muted, device.id });
    }

    fn addDevice(self: *PipeWire, id: u32, props: ?*const c.spa_dict) void {
        if (props == null) return;

        const media_class = spa_dict_lookup(props, "media.class") orelse return;

        var device = AudioDevice{ .id = id };

        // Get device properties
        if (spa_dict_lookup(props, "node.name")) |name| {
            device.name.setFromC(name);
        }
        if (spa_dict_lookup(props, "node.description")) |desc| {
            device.description.setFromC(desc);
        } else if (spa_dict_lookup(props, "node.nick")) |nick| {
            device.description.setFromC(nick);
        }
        device.media_class.setFromC(media_class);

        // Determine device type
        const class_str = mem.span(media_class);
        var became_default = false;
        if (mem.eql(u8, class_str, "Audio/Sink")) {
            device.device_type = .sink;
            if (self.sink_count < max_devices) {
                self.sinks[self.sink_count] = device;
                self.sink_count += 1;
                if (self.default_sink_id == null) {
                    self.default_sink_id = id;
                    self.sinks[self.sink_count - 1].?.is_default = true;
                    became_default = true;
                }
                log.debug("Added sink: {s} (id={d})", .{ device.name.get(), id });
            }
        } else if (mem.eql(u8, class_str, "Audio/Source")) {
            device.device_type = .source;
            if (self.source_count < max_devices) {
                self.sources[self.source_count] = device;
                self.source_count += 1;
                if (self.default_source_id == null) {
                    self.default_source_id = id;
                    self.sources[self.source_count - 1].?.is_default = true;
                    became_default = true;
                }
                log.debug("Added source: {s} (id={d})", .{ device.name.get(), id });
            }
        } else return;

        // Bind proxy immediately if this device became the new default
        // (e.g. after disconnect/reconnect when no other default existed).
        // Non-default proxies are bound on demand via bindAllProxies().
        if (became_default and self.initialized) {
            self.bindNodeProxy(id);
        }
    }

    fn bindNodeProxy(self: *PipeWire, id: u32) void {
        const registry = self.registry orelse return;

        // Find a free node slot
        const slot = blk: {
            for (&self.node_slots) |*s| {
                if (!s.active) break :blk s;
            }
            log.warn("No free node slots for id={d}", .{id});
            return;
        };

        const proxy: ?*c.struct_pw_node = @ptrCast(c.pw_registry_bind(
            registry,
            id,
            "PipeWire:Interface:Node",
            c.PW_VERSION_NODE,
            0,
        ));
        if (proxy == null) {
            log.warn("pw_registry_bind failed for node {d}", .{id});
            return;
        }

        slot.* = .{
            .parent = self,
            .node_id = id,
            .proxy = proxy,
            .listener = std.mem.zeroes(c.spa_hook),
            .active = true,
        };

        const node_events = comptime c.struct_pw_node_events{
            .version = c.PW_VERSION_NODE_EVENTS,
            .param = nodeParamCallback,
        };

        _ = c.pw_node_add_listener(proxy, &slot.listener, &node_events, slot);

        // Subscribe to Props param to get volume/mute updates
        var param_ids = [_]u32{@bitCast(c.SPA_PARAM_Props)};
        _ = c.pw_node_subscribe_params(proxy, &param_ids, 1);

        log.debug("Bound node proxy for id={d}", .{id});
    }

    /// Bind proxies only for current default sink and source.
    /// Called after initial enumeration completes and when defaults change.
    fn bindDefaultProxies(self: *PipeWire) void {
        if (self.default_sink_id) |id| {
            if (self.findNodeSlot(id) == null) {
                self.bindNodeProxy(id);
            }
        }
        if (self.default_source_id) |id| {
            if (self.findNodeSlot(id) == null) {
                self.bindNodeProxy(id);
            }
        }
    }

    /// Bind proxies for all known devices (for popup showing per-device controls).
    pub fn bindAllProxies(self: *PipeWire) void {
        for (&self.sinks) |*slot| {
            if (slot.*) |device| {
                if (self.findNodeSlot(device.id) == null) self.bindNodeProxy(device.id);
            }
        }
        for (&self.sources) |*slot| {
            if (slot.*) |device| {
                if (self.findNodeSlot(device.id) == null) self.bindNodeProxy(device.id);
            }
        }
    }

    /// Unbind proxies for all non-default devices (cleanup after popup closes).
    pub fn unbindNonDefaultProxies(self: *PipeWire) void {
        for (&self.node_slots) |*ns| {
            if (!ns.active) continue;
            const id = ns.node_id;
            const is_default_sink = if (self.default_sink_id) |sid| id == sid else false;
            const is_default_source = if (self.default_source_id) |sid| id == sid else false;
            if (!is_default_sink and !is_default_source) {
                ns.deinit();
            }
        }
    }

    fn removeDevice(self: *PipeWire, id: u32) void {
        // Clean up node proxy slot
        for (&self.node_slots) |*ns| {
            if (ns.active and ns.node_id == id) {
                ns.deinit();
                break;
            }
        }

        // Remove from sinks
        for (&self.sinks, 0..) |*slot, i| {
            if (slot.*) |device| {
                if (device.id == id) {
                    slot.* = null;
                    if (i < self.sink_count - 1) {
                        var j = i;
                        while (j < self.sink_count - 1) : (j += 1) {
                            self.sinks[j] = self.sinks[j + 1];
                        }
                        self.sinks[self.sink_count - 1] = null;
                    }
                    self.sink_count -|= 1;
                    if (self.default_sink_id == id) {
                        const new_default = if (self.sink_count > 0 and self.sinks[0] != null)
                            self.sinks[0].?.id
                        else
                            null;
                        self.default_sink_id = new_default;
                        // Bind proxy for the new fallback default
                        if (new_default) |new_id| {
                            if (self.findNodeSlot(new_id) == null) self.bindNodeProxy(new_id);
                        }
                    }
                    log.debug("Removed sink: id={d}", .{id});
                    return;
                }
            }
        }

        // Remove from sources
        for (&self.sources, 0..) |*slot, i| {
            if (slot.*) |device| {
                if (device.id == id) {
                    slot.* = null;
                    if (i < self.source_count - 1) {
                        var j = i;
                        while (j < self.source_count - 1) : (j += 1) {
                            self.sources[j] = self.sources[j + 1];
                        }
                        self.sources[self.source_count - 1] = null;
                    }
                    self.source_count -|= 1;
                    if (self.default_source_id == id) {
                        const new_default = if (self.source_count > 0 and self.sources[0] != null)
                            self.sources[0].?.id
                        else
                            null;
                        self.default_source_id = new_default;
                        // Bind proxy for the new fallback default
                        if (new_default) |new_id| {
                            if (self.findNodeSlot(new_id) == null) self.bindNodeProxy(new_id);
                        }
                    }
                    log.debug("Removed source: id={d}", .{id});
                    return;
                }
            }
        }
    }

    fn findNodeSlot(self: *PipeWire, node_id: u32) ?*NodeSlot {
        for (&self.node_slots) |*slot| {
            if (slot.active and slot.node_id == node_id) return slot;
        }
        return null;
    }

    fn findDeviceMut(self: *PipeWire, node_id: u32) ?*AudioDevice {
        for (&self.sinks) |*slot| {
            if (slot.*) |*device| {
                if (device.id == node_id) return device;
            }
        }
        for (&self.sources) |*slot| {
            if (slot.*) |*device| {
                if (device.id == node_id) return device;
            }
        }
        return null;
    }

    fn bindMetadata(self: *PipeWire, id: u32) void {
        const registry = self.registry orelse return;

        // Only bind one metadata object (the "default" one)
        if (self.metadata_proxy != null) return;

        const proxy: ?*c.struct_pw_proxy = @ptrCast(c.pw_registry_bind(
            registry,
            id,
            "PipeWire:Interface:Metadata",
            3, // PW_VERSION_METADATA
            0,
        ));
        if (proxy == null) {
            log.warn("pw_registry_bind failed for metadata {d}", .{id});
            return;
        }

        self.metadata_proxy = proxy;
        self.metadata_listener = std.mem.zeroes(c.spa_hook);

        const events = comptime MetadataEvents{
            .version = 0,
            .property = metadataPropertyCallback,
        };
        c.pw_proxy_add_object_listener(proxy, &self.metadata_listener, @ptrCast(&events), self);

        log.debug("Bound metadata proxy for id={d}", .{id});
    }

    fn setMetadataDefault(self: *PipeWire, key: [*:0]const u8, device: *const AudioDevice) Error!void {
        const proxy = self.metadata_proxy orelse return Error.OperationFailed;

        // Build JSON value: {"name":"<device_name>"}
        const name = device.name.get();
        if (name.len == 0) return Error.NoDevice;

        var buf: [max_string_len + 32]u8 = undefined;
        const json = std.fmt.bufPrint(&buf, "{{\"name\":\"{s}\"}}", .{name}) catch return Error.OperationFailed;
        buf[json.len] = 0;

        // Call set_property through the vtable (same pattern as pw_node_set_param)
        const iface: *c.struct_spa_interface = @ptrCast(@alignCast(proxy));
        const methods: ?*const MetadataMethods = @ptrCast(@alignCast(iface.cb.funcs));
        if (methods) |m| {
            if (m.set_property) |set_prop| {
                const result = set_prop(iface.cb.data, 0, key, "Spa:String:JSON", @ptrCast(buf[0..json.len :0]));
                if (result < 0) {
                    log.warn("metadata set_property failed: {d}", .{result});
                    return Error.OperationFailed;
                }
            } else return Error.OperationFailed;
        } else return Error.OperationFailed;

        log.debug("Set {s} to {s}", .{ mem.span(key), name });
    }

    fn updateDefaultByName(self: *PipeWire, name: []const u8, device_type: DeviceType) void {
        const devices = switch (device_type) {
            .sink => &self.sinks,
            .source => &self.sources,
        };

        const old_default_id: ?u32 = switch (device_type) {
            .sink => self.default_sink_id,
            .source => self.default_source_id,
        };

        var found_id: ?u32 = null;
        for (devices) |*slot| {
            if (slot.*) |*device| {
                const is_match: bool = mem.eql(u8, device.name.get(), name);
                device.is_default = is_match;
                if (is_match) found_id = device.id;
            }
        }

        const new_id = found_id orelse switch (device_type) {
            .sink => self.default_sink_id,
            .source => self.default_source_id,
        };

        switch (device_type) {
            .sink => self.default_sink_id = new_id,
            .source => self.default_source_id = new_id,
        }

        // Swap proxy from old default to new default
        if (new_id != old_default_id) {
            // Unbind old default proxy
            if (old_default_id) |old_id| {
                for (&self.node_slots) |*ns| {
                    if (ns.active and ns.node_id == old_id) {
                        ns.deinit();
                        break;
                    }
                }
            }
        }
        // Ensure proxy is bound for current default (covers both swap and
        // race where default_sink_id was set before updateDefaultByName ran)
        if (new_id) |id| {
            if (self.findNodeSlot(id) == null) {
                self.bindNodeProxy(id);
            }
        }
    }

    fn notify(self: *const PipeWire) void {
        for (self.subscriptions) |maybe_sub| {
            if (maybe_sub) |sub| {
                sub.callback(sub.context);
            }
        }
    }

    // C callback wrappers

    fn registryGlobalCallback(
        data: ?*anyopaque,
        id: u32,
        permissions: u32,
        type_str: [*c]const u8,
        version: u32,
        props: ?*const c.spa_dict,
    ) callconv(.c) void {
        _ = permissions;
        _ = version;

        const self: *PipeWire = @ptrCast(@alignCast(data orelse return));

        if (type_str == null) return;
        const type_name = mem.span(type_str);

        if (mem.eql(u8, type_name, "PipeWire:Interface:Node")) {
            self.addDevice(id, props);
        } else if (mem.eql(u8, type_name, "PipeWire:Interface:Metadata")) {
            // Bind the "default" metadata for default device tracking
            if (props) |p| {
                const name = spa_dict_lookup(p, "metadata.name");
                if (name != null and mem.eql(u8, mem.span(name.?), "default")) {
                    self.bindMetadata(id);
                }
            }
        }
    }

    fn registryGlobalRemoveCallback(data: ?*anyopaque, id: u32) callconv(.c) void {
        const self: *PipeWire = @ptrCast(@alignCast(data orelse return));

        // Check if the removed global is our metadata proxy
        if (self.metadata_proxy) |proxy| {
            if (c.pw_proxy_get_bound_id(proxy) == id) {
                c.spa_hook_remove(&self.metadata_listener);
                c.pw_proxy_destroy(proxy);
                self.metadata_proxy = null;
                self.metadata_listener = std.mem.zeroes(c.spa_hook);
                log.debug("Metadata proxy removed", .{});
            }
        }

        self.removeDevice(id);
        self.notify();
    }

    fn metadataPropertyCallback(
        data: ?*anyopaque,
        subject: u32,
        key_c: [*c]const u8,
        _: [*c]const u8,
        value_c: [*c]const u8,
    ) callconv(.c) c_int {
        _ = subject;
        const self: *PipeWire = @ptrCast(@alignCast(data orelse return 0));

        if (key_c == null or value_c == null) return 0;

        const key = mem.span(key_c);
        const value = mem.span(value_c);

        // Parse device name from JSON value: {"name":"<name>"}
        const name = parseMetadataName(value) orelse return 0;

        if (mem.eql(u8, key, "default.audio.sink")) {
            self.updateDefaultByName(name, .sink);
            self.notify();
            log.debug("Default sink changed to: {s}", .{name});
        } else if (mem.eql(u8, key, "default.audio.source")) {
            self.updateDefaultByName(name, .source);
            self.notify();
            log.debug("Default source changed to: {s}", .{name});
        }

        return 0;
    }

    fn nodeParamCallback(
        data: ?*anyopaque,
        seq: c_int,
        id: u32,
        index: u32,
        next: u32,
        param: [*c]const c.struct_spa_pod,
    ) callconv(.c) void {
        _ = seq;
        _ = index;
        _ = next;

        if (id != @as(u32, @bitCast(c.SPA_PARAM_Props))) return;

        const slot: *NodeSlot = @ptrCast(@alignCast(data orelse return));
        const self = slot.parent orelse return;
        const device = self.findDeviceMut(slot.node_id) orelse return;

        // Parse mute
        const mute_prop = c.spa_pod_object_find_prop(
            @ptrCast(param),
            null,
            @bitCast(c.SPA_PROP_mute),
        );
        if (mute_prop != null) {
            var muted: bool = false;
            // value field is at offset after key + flags
            const value_pod: [*c]const c.struct_spa_pod = &mute_prop.*.value;
            if (c.spa_pod_get_bool(value_pod, &muted) >= 0) {
                device.muted = muted;
            }
        }

        // Parse channelVolumes
        const vol_prop = c.spa_pod_object_find_prop(
            @ptrCast(param),
            null,
            @bitCast(c.SPA_PROP_channelVolumes),
        );
        if (vol_prop != null) {
            // channelVolumes is an Array of Floats
            // The value pod is the array — extract first float element
            const value_pod: [*c]const c.struct_spa_pod = &vol_prop.*.value;
            const pod_bytes: [*]const u8 = @ptrCast(value_pod);
            // Array pod header: size(4) + type(4) + child_size(4) + child_type(4)
            // Then float data starts at offset 16
            const arr_header_size: usize = 16;
            const pod_size = value_pod.*.size;
            if (pod_size >= arr_header_size + @sizeOf(f32) - 8) {
                // Float data starts after the array body header (8 bytes for child pod)
                const float_offset = @sizeOf(c.struct_spa_pod) + 8; // pod header + child pod header
                const float_ptr: *align(1) const f32 = @ptrCast(pod_bytes + float_offset);
                const vol = float_ptr.*;
                if (vol >= 0.0 and vol <= 10.0) {
                    device.volume = vol;
                    // Count channels from array size
                    const data_size = pod_size - 8; // subtract child pod header
                    const n_channels = data_size / @sizeOf(f32);
                    if (n_channels > 0 and n_channels <= 64) {
                        device.channels = @intCast(n_channels);
                    }
                }
            }
        }

        self.notify();
    }

    fn coreDoneCallback(data: ?*anyopaque, id: u32, seq: c_int) callconv(.c) void {
        const self: *PipeWire = @ptrCast(@alignCast(data orelse return));
        _ = id;

        if (seq == self.pending_seq) {
            if (!self.initialized) {
                self.initialized = true;
                self.bindDefaultProxies();
                log.info("PipeWire enumeration complete: {d} sinks, {d} sources", .{
                    self.sink_count,
                    self.source_count,
                });
            }
            self.notify();
        }
    }
};

/// Helper to lookup spa_dict value
fn spa_dict_lookup(dict: ?*const c.spa_dict, key: [*:0]const u8) ?[*:0]const u8 {
    if (dict == null) return null;
    return c.spa_dict_lookup(dict, key);
}

/// Parse device name from PipeWire metadata JSON value: {"name":"<name>"}
/// Uses direct byte scanning for zero-allocation parsing.
fn parseMetadataName(value: []const u8) ?[]const u8 {
    // Find "name":" pattern
    const needle = "\"name\":\"";
    const start_idx = mem.indexOf(u8, value, needle) orelse return null;
    const name_start = start_idx + needle.len;
    if (name_start >= value.len) return null;

    // Find closing quote
    const name_end = mem.indexOfScalarPos(u8, value, name_start, '"') orelse return null;
    if (name_end <= name_start) return null;

    return value[name_start..name_end];
}

// Tests

test "PipeWire types compile" {
    _ = PipeWire;
    _ = AudioDevice;
    _ = DeviceType;
    _ = StateChangeFn;
}

test "DeviceType values" {
    const testing = std.testing;

    const sink = DeviceType.sink;
    const source = DeviceType.source;

    try testing.expect(sink == .sink);
    try testing.expect(source == .source);
}

test "AudioDevice default values" {
    const testing = std.testing;

    const device = AudioDevice{};
    try testing.expectEqual(@as(u32, 0), device.id);
    try testing.expectEqual(DeviceType.sink, device.device_type);
    try testing.expectEqual(@as(f32, 1.0), device.volume);
    try testing.expect(!device.muted);
    try testing.expect(!device.is_default);
    try testing.expect(device.isSink());
    try testing.expect(!device.isSource());
}

test "AudioDevice volume percentage" {
    const testing = std.testing;

    var device = AudioDevice{};
    device.volume = 0.5;
    try testing.expectEqual(@as(u8, 50), device.getVolumePercent());

    device.volume = 1.0;
    try testing.expectEqual(@as(u8, 100), device.getVolumePercent());

    device.volume = 0.0;
    try testing.expectEqual(@as(u8, 0), device.getVolumePercent());

    // Test overamplification
    device.volume = 1.5;
    try testing.expectEqual(@as(u8, 150), device.getVolumePercent());

    // Test clamping at max
    device.volume = 2.0;
    try testing.expectEqual(@as(u8, 150), device.getVolumePercent());
}

test "FixedString operations" {
    const testing = std.testing;

    var s = FixedString(64){};
    try testing.expect(s.isEmpty());

    s.set("test device");
    try testing.expectEqualStrings("test device", s.get());
    try testing.expect(!s.isEmpty());

    s.clear();
    try testing.expect(s.isEmpty());
}

test "subscription management" {
    const testing = std.testing;

    // We can't fully test PipeWire without a running daemon,
    // but we can test the subscription logic
    var pw = PipeWire{
        .allocator = testing.allocator,
    };

    var call_count: usize = 0;
    const callback = struct {
        fn cb(ctx: ?*anyopaque) void {
            const count: *usize = @ptrCast(@alignCast(ctx));
            count.* += 1;
        }
    }.cb;

    // Subscribe
    try testing.expect(pw.subscribe(callback, &call_count));
    try testing.expectEqual(@as(usize, 1), pw.subscription_count);

    // Notify
    pw.notify();
    try testing.expectEqual(@as(usize, 1), call_count);

    // Unsubscribe
    pw.unsubscribe(callback, &call_count);
    try testing.expectEqual(@as(usize, 0), pw.subscription_count);

    // Notify after unsubscribe
    pw.notify();
    try testing.expectEqual(@as(usize, 1), call_count);
}

test "parseMetadataName" {
    const testing = std.testing;

    // Standard PipeWire metadata JSON format
    const result1 = parseMetadataName("{\"name\":\"alsa_output.pci-0000_00_1f.3.analog-stereo\"}");
    try testing.expect(result1 != null);
    try testing.expectEqualStrings("alsa_output.pci-0000_00_1f.3.analog-stereo", result1.?);

    // Empty value
    try testing.expect(parseMetadataName("") == null);

    // No name key
    try testing.expect(parseMetadataName("{\"foo\":\"bar\"}") == null);

    // Malformed: missing closing quote
    try testing.expect(parseMetadataName("{\"name\":\"unterminated") == null);

    // Empty name value
    try testing.expect(parseMetadataName("{\"name\":\"\"}") == null);
}

test "updateDefaultByName" {
    const testing = std.testing;

    var pw = PipeWire{
        .allocator = testing.allocator,
    };

    // Add two sinks manually
    pw.sinks[0] = AudioDevice{ .id = 42, .device_type = .sink };
    pw.sinks[0].?.name.set("alsa_output.hdmi");
    pw.sinks[1] = AudioDevice{ .id = 99, .device_type = .sink };
    pw.sinks[1].?.name.set("alsa_output.analog");
    pw.sink_count = 2;
    pw.default_sink_id = 42;

    // Switch default to analog
    pw.updateDefaultByName("alsa_output.analog", .sink);
    try testing.expectEqual(@as(?u32, 99), pw.default_sink_id);
    try testing.expect(!pw.sinks[0].?.is_default);
    try testing.expect(pw.sinks[1].?.is_default);

    // Non-existent name should keep current default
    pw.updateDefaultByName("nonexistent", .sink);
    try testing.expectEqual(@as(?u32, 99), pw.default_sink_id);
}

test "findDeviceMut across sinks and sources" {
    const testing = std.testing;

    var pw = PipeWire{
        .allocator = testing.allocator,
    };

    pw.sinks[0] = AudioDevice{ .id = 10, .device_type = .sink, .volume = 0.5 };
    pw.sink_count = 1;
    pw.sources[0] = AudioDevice{ .id = 20, .device_type = .source, .volume = 0.8 };
    pw.source_count = 1;

    // Find sink by ID
    const sink = pw.findDeviceMut(10);
    try testing.expect(sink != null);
    try testing.expectEqual(@as(f32, 0.5), sink.?.volume);

    // Find source by ID
    const source = pw.findDeviceMut(20);
    try testing.expect(source != null);
    try testing.expectEqual(@as(f32, 0.8), source.?.volume);

    // Non-existent ID
    try testing.expect(pw.findDeviceMut(99) == null);
}

test "MetadataEvents layout" {
    const testing = std.testing;

    // Verify the extern struct has the expected layout for C interop
    const events = MetadataEvents{};
    try testing.expectEqual(@as(u32, 0), events.version);
    try testing.expect(events.property == null);
}

test "MetadataMethods layout" {
    const testing = std.testing;

    const methods = MetadataMethods{};
    try testing.expectEqual(@as(u32, 0), methods.version);
    try testing.expect(methods.add_listener == null);
    try testing.expect(methods.set_property == null);
    try testing.expect(methods.clear == null);
}
