//! D-Bus Screensaver client
//!
//! Provides inhibit/uninhibit control via the org.freedesktop.ScreenSaver D-Bus interface.
//! Action-oriented client — no signal monitoring or polling required.

const std = @import("std");
const Allocator = std.mem.Allocator;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.screensaver);

const service = "org.freedesktop.ScreenSaver";
const object_path = "/org/freedesktop/ScreenSaver";
const interface_name = "org.freedesktop.ScreenSaver";

pub const Error = dbus.types.Error || error{NotInhibited};

pub const Screensaver = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    inhibit_cookie: ?u32 = null,

    /// Open a session bus connection for screensaver control.
    pub fn init(allocator: Allocator) Error!Screensaver {
        const connection = try dbus.Connection.open(allocator, .session);
        return .{
            .connection = connection,
            .allocator = allocator,
        };
    }

    /// Close the connection, uninhibiting first if needed.
    pub fn deinit(self: *Screensaver) void {
        if (self.inhibit_cookie != null) {
            self.uninhibit() catch |err| {
                log.warn("Failed to uninhibit screensaver on deinit: {}", .{err});
            };
        }
        self.connection.deinit();
    }

    /// Inhibit the screensaver. Returns the cookie for later uninhibit.
    pub fn inhibit(self: *Screensaver, app_name: [:0]const u8, reason: [:0]const u8) Error!u32 {
        var reply = try self.connection.callMethodWithTwoStrings(
            service,
            object_path,
            interface_name,
            "Inhibit",
            app_name,
            reason,
        );
        defer reply.unref();

        const cookie = try reply.readUint32();
        self.inhibit_cookie = cookie;
        log.info("Screensaver inhibited (cookie={d})", .{cookie});
        return cookie;
    }

    /// Uninhibit the screensaver using the stored cookie.
    pub fn uninhibit(self: *Screensaver) Error!void {
        const cookie = self.inhibit_cookie orelse return error.NotInhibited;

        var reply = try self.connection.callMethodWithUint32(
            service,
            object_path,
            interface_name,
            "UnInhibit",
            cookie,
        );
        defer reply.unref();

        self.inhibit_cookie = null;
        log.info("Screensaver uninhibited (cookie={d})", .{cookie});
    }

    /// Check whether the screensaver is currently inhibited by this client.
    pub fn isInhibited(self: *const Screensaver) bool {
        return self.inhibit_cookie != null;
    }
};

test "Screensaver types compile" {
    _ = Screensaver;
    _ = Error;
}

test "Screensaver initial state" {
    // Cannot test init without D-Bus, but verify struct layout
    const s = Screensaver{
        .connection = undefined,
        .allocator = std.testing.allocator,
    };
    try std.testing.expect(!s.isInhibited());
    try std.testing.expectEqual(@as(?u32, null), s.inhibit_cookie);
}
