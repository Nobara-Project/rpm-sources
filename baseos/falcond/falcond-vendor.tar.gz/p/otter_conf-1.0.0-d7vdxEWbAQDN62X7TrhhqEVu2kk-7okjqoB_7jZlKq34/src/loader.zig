const std = @import("std");
const posix = std.posix;
const Parser = @import("parser.zig").Parser;

pub const LoadError = error{
    FileTooLarge,
    FileNotFound,
    AccessDenied,
    InvalidPath,
    MmapFailed,
} || std.fs.File.OpenError || std.fs.File.ReadError || std.posix.MMapError || @import("parser.zig").ParseError;

/// Configuration options for loading.
pub const LoadOptions = struct {
    /// Maximum file size to load (default 64MB).
    max_file_size: usize = 64 * 1024 * 1024,
};

/// Result containing the parsed config and metadata about the load.
pub fn LoadResult(comptime T: type) type {
    return struct {
        config: T,
        /// File size in bytes.
        file_size: usize,
        /// Modification time in nanoseconds since epoch.
        mtime_ns: i128,
    };
}

/// Load and parse a configuration file using memory-mapped I/O.
pub fn load(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!T {
    const result = try loadWithMetadata(T, allocator, path, options);
    return result.config;
}

/// Load and parse a configuration file, returning metadata about the load.
pub fn loadWithMetadata(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!LoadResult(T) {
    const file = std.fs.openFileAbsolute(path, .{ .mode = .read_only }) catch |err| {
        return switch (err) {
            error.FileNotFound => error.FileNotFound,
            error.AccessDenied => error.AccessDenied,
            else => err,
        };
    };
    defer file.close();

    // Shared lock prevents concurrent truncation during mmap (avoids SIGBUS
    // when another otter-shell app normalizes the same config/theme file).
    file.lock(.shared) catch {};

    const stat = try file.stat();
    const size: usize = @intCast(stat.size);

    if (size > options.max_file_size) return error.FileTooLarge;

    const config = if (size == 0) blk: {
        // Handle empty file - return default-initialized struct
        var parser = Parser(T).init(allocator, "");
        break :blk try parser.parse();
    } else blk: {
        const mapped = posix.mmap(
            null,
            size,
            posix.PROT.READ,
            .{ .TYPE = .PRIVATE },
            file.handle,
            0,
        ) catch return error.MmapFailed;
        defer posix.munmap(mapped);

        const content = mapped[0..size];
        var parser = Parser(T).init(allocator, content);
        break :blk try parser.parse();
    };

    return .{
        .config = config,
        .file_size = size,
        .mtime_ns = stat.mtime,
    };
}

/// Load from a byte slice directly (useful for embedded configs or testing).
pub fn loadFromSlice(
    comptime T: type,
    allocator: std.mem.Allocator,
    content: []const u8,
) @import("parser.zig").ParseError!T {
    var parser = Parser(T).init(allocator, content);
    return parser.parse();
}

/// Check if a config file has been modified since the given mtime.
pub fn hasChanged(path: []const u8, last_mtime_ns: i128) !bool {
    const file = try std.fs.openFileAbsolute(path, .{ .mode = .read_only });
    defer file.close();

    const stat = try file.stat();
    return stat.mtime != last_mtime_ns;
}

/// Get the modification time of a config file.
pub fn getMtime(path: []const u8) !i128 {
    const file = try std.fs.openFileAbsolute(path, .{ .mode = .read_only });
    defer file.close();

    const stat = try file.stat();
    return stat.mtime;
}

// ============================================================================
// Tests
// ============================================================================

test "loadFromSlice basic" {
    const TestConfig = struct {
        name: []const u8 = "default",
        count: i64 = 0,
    };

    const content =
        \\name = "test"
        \\count = 42
    ;

    const config = try loadFromSlice(TestConfig, std.testing.allocator, content);
    defer std.testing.allocator.free(config.name);

    try std.testing.expectEqualStrings("test", config.name);
    try std.testing.expectEqual(@as(i64, 42), config.count);
}

test "loadFromSlice empty" {
    const TestConfig = struct {
        value: i64 = 100,
    };

    const config = try loadFromSlice(TestConfig, std.testing.allocator, "");
    try std.testing.expectEqual(@as(i64, 100), config.value);
}

test "load options default" {
    const opts = LoadOptions{};
    try std.testing.expectEqual(@as(usize, 64 * 1024 * 1024), opts.max_file_size);
}
