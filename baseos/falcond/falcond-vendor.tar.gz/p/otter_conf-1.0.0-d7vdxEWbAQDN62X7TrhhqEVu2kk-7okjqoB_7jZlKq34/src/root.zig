//! otter-conf: Comptime-generic configuration library for Zig.
//!
//! Features:
//! - Comptime-generic parser works with any struct type
//! - Booleans, integers, floats, strings, enums, arrays, and optionals
//! - Memory-mapped file loading
//! - Directory loading with override support
//! - Serialization back to config format
//!
//! ## Basic Usage
//!
//! ```zig
//! const otter = @import("otter_conf");
//!
//! const Config = struct {
//!     name: []const u8 = "default",
//!     port: u16 = 8080,
//!     debug: bool = false,
//!     timeout: f64 = 30.0,
//! };
//!
//! // Load from file
//! const config = try otter.load(Config, allocator, "/etc/myapp/config.conf", .{});
//!
//! // Or parse from string
//! const config2 = try otter.loadFromSlice(Config, allocator, "name = \"test\"\nport = 9000");
//! ```

const std = @import("std");

// Re-export parser
pub const Parser = @import("parser.zig").Parser;
pub const ParseError = @import("parser.zig").ParseError;

// Re-export loader
pub const LoadOptions = @import("loader.zig").LoadOptions;
pub const LoadResult = @import("loader.zig").LoadResult;
pub const LoadError = @import("loader.zig").LoadError;

// Re-export directory loader
pub const DirLoadOptions = @import("dir_loader.zig").DirLoadOptions;
pub const DirEntry = @import("dir_loader.zig").DirEntry;
pub const DirLoadResult = @import("dir_loader.zig").DirLoadResult;
pub const DirLoadError = @import("dir_loader.zig").DirLoadError;

// Re-export serializer
pub const SerializeOptions = @import("serializer.zig").SerializeOptions;
pub const serialize = @import("serializer.zig").serialize;
pub const serializeDefaults = @import("serializer.zig").serializeDefaults;

// Re-export file watcher
pub const Watcher = @import("watcher.zig").Watcher;
pub const WatchEvent = Watcher.Event;

// ============================================================================
// Loading
// ============================================================================

/// Load and parse a configuration file.
pub fn load(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!T {
    return @import("loader.zig").load(T, allocator, path, options);
}

/// Load and parse a configuration file, returning metadata.
pub fn loadWithMetadata(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!LoadResult(T) {
    return @import("loader.zig").loadWithMetadata(T, allocator, path, options);
}

/// Parse configuration from a byte slice.
pub fn loadFromSlice(
    comptime T: type,
    allocator: std.mem.Allocator,
    content: []const u8,
) ParseError!T {
    return @import("loader.zig").loadFromSlice(T, allocator, content);
}

/// Load all config files from a directory.
pub fn loadDir(
    comptime T: type,
    allocator: std.mem.Allocator,
    dir_path: []const u8,
    options: DirLoadOptions,
) DirLoadError!DirLoadResult(T) {
    return @import("dir_loader.zig").loadDir(T, allocator, dir_path, options);
}

/// Load configs with user override support.
pub fn loadWithOverrides(
    comptime T: type,
    allocator: std.mem.Allocator,
    base_dir: []const u8,
    override_dir: ?[]const u8,
    options: DirLoadOptions,
) DirLoadError!DirLoadResult(T) {
    return @import("dir_loader.zig").loadWithOverrides(T, allocator, base_dir, override_dir, options);
}

/// Check if a config file has been modified.
pub fn hasChanged(path: []const u8, last_mtime_ns: i128) !bool {
    return @import("loader.zig").hasChanged(path, last_mtime_ns);
}

/// Get the modification time of a config file.
pub fn getMtime(path: []const u8) !i128 {
    return @import("loader.zig").getMtime(path);
}

// ============================================================================
// Saving
// ============================================================================

/// Save a config struct to a file.
pub fn save(
    comptime T: type,
    allocator: std.mem.Allocator,
    config: T,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const content = try serialize(T, allocator, config, options);
    defer allocator.free(content);

    // Open/create without truncation so we can acquire an exclusive lock
    // before modifying the file. Prevents SIGBUS in concurrent readers
    // that have the file mmap'd (e.g. another otter-shell app loading
    // the same theme.conf).
    const file = try std.fs.createFileAbsolute(path, .{ .truncate = false });
    defer file.close();

    file.lock(.exclusive) catch {};
    file.setEndPos(0) catch {};
    try file.writeAll(content);
}

/// Save a config struct to a relative path.
pub fn saveRelative(
    comptime T: type,
    allocator: std.mem.Allocator,
    config: T,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const content = try serialize(T, allocator, config, options);
    defer allocator.free(content);

    const file = try std.fs.cwd().createFile(path, .{});
    defer file.close();

    try file.writeAll(content);
}

/// Save a default config file (using struct default values).
pub fn saveDefaults(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const defaults: T = .{};
    try save(T, allocator, defaults, path, options);
}

/// Save a default config file to a relative path.
pub fn saveDefaultsRelative(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const defaults: T = .{};
    try saveRelative(T, allocator, defaults, path, options);
}

/// Create a config file if it doesn't exist, using defaults.
pub fn ensureConfigExists(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: SerializeOptions,
) !bool {
    std.fs.accessAbsolute(path, .{}) catch {
        try saveDefaults(T, allocator, path, options);
        return true;
    };
    return false;
}

/// Load a config, creating it with defaults if it doesn't exist.
pub fn loadOrCreate(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    load_options: LoadOptions,
    save_options: SerializeOptions,
) !T {
    if (std.fs.path.dirname(path)) |dir| {
        std.fs.makeDirAbsolute(dir) catch |err| {
            if (err != error.PathAlreadyExists) {}
        };
    }

    return load(T, allocator, path, load_options) catch |err| {
        if (err == error.FileNotFound) {
            try saveDefaults(T, allocator, path, save_options);
            return T{};
        }
        return err;
    };
}

// ============================================================================
// Memory management
// ============================================================================

/// Free all allocated strings in a config struct.
pub fn freeConfig(comptime T: type, allocator: std.mem.Allocator, config: *T) void {
    @import("dir_loader.zig").freeConfigStrings(T, allocator, config);
}

// ============================================================================
// Tests
// ============================================================================

test "round-trip parse and serialize" {
    const TestConfig = struct {
        name: []const u8 = "",
        count: i64 = 0,
        enabled: bool = false,
    };

    const original =
        \\name = "round-trip"
        \\count = 123
        \\enabled = true
    ;

    const config = try loadFromSlice(TestConfig, std.testing.allocator, original);
    defer std.testing.allocator.free(config.name);

    const serialized = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(serialized);

    const config2 = try loadFromSlice(TestConfig, std.testing.allocator, serialized);
    defer std.testing.allocator.free(config2.name);

    try std.testing.expectEqualStrings("round-trip", config2.name);
    try std.testing.expectEqual(@as(i64, 123), config2.count);
    try std.testing.expect(config2.enabled);
}

test "round-trip with unknown fields" {
    const TestConfig = struct {
        name: []const u8 = "default",
        count: i64 = 0,
        enabled: bool = false,
    };

    const content_with_unknowns =
        \\name = "hello"
        \\removed_field = "should be stripped"
        \\count = 42
        \\old_setting = true
        \\enabled = true
    ;

    // Parse with unknown fields (should succeed, unknowns skipped)
    const config = try loadFromSlice(TestConfig, std.testing.allocator, content_with_unknowns);
    defer std.testing.allocator.free(config.name);

    try std.testing.expectEqualStrings("hello", config.name);
    try std.testing.expectEqual(@as(i64, 42), config.count);
    try std.testing.expect(config.enabled);

    // Serialize (unknown fields gone)
    const serialized = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(serialized);

    // Re-parse serialized output
    const config2 = try loadFromSlice(TestConfig, std.testing.allocator, serialized);
    defer std.testing.allocator.free(config2.name);

    try std.testing.expectEqualStrings("hello", config2.name);
    try std.testing.expectEqual(@as(i64, 42), config2.count);
    try std.testing.expect(config2.enabled);
}

test {
    _ = @import("parser.zig");
    _ = @import("loader.zig");
    _ = @import("dir_loader.zig");
    _ = @import("serializer.zig");
    _ = @import("watcher.zig");
}
