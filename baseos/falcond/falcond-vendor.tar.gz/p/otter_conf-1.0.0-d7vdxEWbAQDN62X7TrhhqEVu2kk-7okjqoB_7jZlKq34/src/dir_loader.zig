const std = @import("std");
const loader = @import("loader.zig");
const Parser = @import("parser.zig").Parser;

pub const DirLoadError = loader.LoadError || std.fs.Dir.OpenError || error{
    NotADirectory,
};

/// Options for loading a directory of config files.
pub const DirLoadOptions = struct {
    /// File extension to filter (e.g., ".conf"). If null, loads all files.
    extension: ?[]const u8 = ".conf",

    /// Whether to recurse into subdirectories.
    recursive: bool = false,

    /// Loading options passed to individual file loads.
    load_options: loader.LoadOptions = .{},
};

/// Result of loading a single file from a directory.
pub fn DirEntry(comptime T: type) type {
    return struct {
        /// The parsed configuration.
        config: T,
        /// The filename (not full path).
        filename: []const u8,
        /// Full path to the file (allocated).
        path: []const u8,
        /// Modification time in nanoseconds.
        mtime_ns: i128,
    };
}

/// Result of loading all configs from a directory.
pub fn DirLoadResult(comptime T: type) type {
    return struct {
        const Self = @This();

        entries: []DirEntry(T),
        allocator: std.mem.Allocator,

        /// Free all allocated memory.
        pub fn deinit(self: *Self, comptime free_config_strings: bool) void {
            for (self.entries) |*entry| {
                if (free_config_strings) {
                    freeConfigStrings(T, self.allocator, &entry.config);
                }
                self.allocator.free(entry.path);
            }
            self.allocator.free(self.entries);
        }

        /// Get a config by filename.
        pub fn getByFilename(self: Self, filename: []const u8) ?*const T {
            for (self.entries) |*entry| {
                if (std.mem.eql(u8, entry.filename, filename)) {
                    return &entry.config;
                }
            }
            return null;
        }

        /// Get a config by a field value (useful for "name" fields).
        pub fn getByField(
            self: Self,
            comptime field_name: []const u8,
            value: []const u8,
        ) ?*const T {
            for (self.entries) |*entry| {
                const field_value = @field(entry.config, field_name);
                if (@TypeOf(field_value) == []const u8) {
                    if (std.mem.eql(u8, field_value, value)) {
                        return &entry.config;
                    }
                }
            }
            return null;
        }
    };
}

/// Check if a type is a container struct (nested struct without custom parse).
fn isContainerStruct(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    if (@hasDecl(FieldType, "parse")) return false;
    return std.meta.fields(FieldType).len > 0;
}

/// Free string fields allocated by the parser.
/// Recurses into nested container structs and uses pointer comparison with
/// default values to avoid freeing comptime string literals.
pub fn freeConfigStrings(comptime T: type, allocator: std.mem.Allocator, config: *T) void {
    const defaults: T = .{};
    inline for (std.meta.fields(T)) |field| {
        const field_ptr = &@field(config.*, field.name);
        switch (@typeInfo(field.type)) {
            .@"struct" => {
                if (comptime isContainerStruct(field.type)) {
                    freeConfigStrings(field.type, allocator, field_ptr);
                }
            },
            .pointer => |ptr_info| {
                if (ptr_info.size == .slice) {
                    const default_val = @field(defaults, field.name);
                    if (ptr_info.child == u8) {
                        // String field — only free if allocated (ptr differs from default)
                        if (field_ptr.*.len > 0 and field_ptr.*.ptr != default_val.ptr) {
                            allocator.free(field_ptr.*);
                        }
                    } else if (ptr_info.child == []const u8) {
                        // Array of strings
                        if (field_ptr.*.len > 0 and field_ptr.*.ptr != default_val.ptr) {
                            for (field_ptr.*) |s| {
                                allocator.free(s);
                            }
                            allocator.free(field_ptr.*);
                        }
                    } else if (ptr_info.child == i64 or ptr_info.child == f64) {
                        // Array of numbers
                        if (field_ptr.*.len > 0 and field_ptr.*.ptr != default_val.ptr) {
                            allocator.free(field_ptr.*);
                        }
                    }
                }
            },
            .optional => |opt_info| {
                switch (@typeInfo(opt_info.child)) {
                    .pointer => |ptr_info| {
                        if (ptr_info.size == .slice and ptr_info.child == u8) {
                            if (field_ptr.*) |s| {
                                allocator.free(s);
                            }
                        }
                    },
                    else => {},
                }
            },
            else => {},
        }
    }
}

/// Load all config files from a directory.
pub fn loadDir(
    comptime T: type,
    allocator: std.mem.Allocator,
    dir_path: []const u8,
    options: DirLoadOptions,
) DirLoadError!DirLoadResult(T) {
    var dir = std.fs.openDirAbsolute(dir_path, .{ .iterate = true }) catch |err| {
        return switch (err) {
            error.NotDir => error.NotADirectory,
            else => err,
        };
    };
    defer dir.close();

    var entries = std.ArrayList(DirEntry(T)){};
    errdefer {
        for (entries.items) |*entry| {
            allocator.free(entry.path);
        }
        entries.deinit(allocator);
    }

    var iter = dir.iterate();
    while (try iter.next()) |entry| {
        // Skip directories (unless recursive)
        if (entry.kind == .directory) {
            if (options.recursive) {
                const subdir_path = try std.fs.path.join(allocator, &.{ dir_path, entry.name });
                defer allocator.free(subdir_path);

                const sub_result = try loadDir(T, allocator, subdir_path, options);
                defer allocator.free(sub_result.entries);

                for (sub_result.entries) |sub_entry| {
                    try entries.append(allocator, sub_entry);
                }
            }
            continue;
        }

        // Check extension filter
        if (options.extension) |ext| {
            if (!std.mem.endsWith(u8, entry.name, ext)) continue;
        }

        // Skip non-files
        if (entry.kind != .file) continue;

        const path = try std.fs.path.join(allocator, &.{ dir_path, entry.name });
        errdefer allocator.free(path);

        const result = loader.loadWithMetadata(T, allocator, path, options.load_options) catch |err| {
            allocator.free(path);
            return err;
        };

        try entries.append(allocator, .{
            .config = result.config,
            .filename = path[dir_path.len + 1 ..],
            .path = path,
            .mtime_ns = result.mtime_ns,
        });
    }

    return .{
        .entries = try entries.toOwnedSlice(allocator),
        .allocator = allocator,
    };
}

/// Load configs with user override support.
/// Files in override_dir replace files with the same name from base_dir.
pub fn loadWithOverrides(
    comptime T: type,
    allocator: std.mem.Allocator,
    base_dir: []const u8,
    override_dir: ?[]const u8,
    options: DirLoadOptions,
) DirLoadError!DirLoadResult(T) {
    // Load base configs
    var base_result = try loadDir(T, allocator, base_dir, options);
    errdefer base_result.deinit(true);

    if (override_dir) |override_path| {
        // Check if override directory exists
        std.fs.accessAbsolute(override_path, .{}) catch return .{
            .entries = base_result.entries,
            .allocator = allocator,
        };

        const override_result = loadDir(T, allocator, override_path, options) catch |err| {
            switch (err) {
                error.FileNotFound, error.NotADirectory => return .{
                    .entries = base_result.entries,
                    .allocator = allocator,
                },
                else => return err,
            }
        };
        defer allocator.free(override_result.entries);

        // Merge: override replaces base entries with same filename
        for (override_result.entries) |override_entry| {
            var found = false;
            for (base_result.entries) |*base_entry| {
                if (std.mem.eql(u8, base_entry.filename, override_entry.filename)) {
                    // Free old config strings and path
                    freeConfigStrings(T, allocator, &base_entry.config);
                    allocator.free(base_entry.path);

                    // Replace with override
                    base_entry.* = override_entry;
                    found = true;
                    break;
                }
            }

            if (!found) {
                // Add new entry from override
                var new_entries = try allocator.alloc(DirEntry(T), base_result.entries.len + 1);
                @memcpy(new_entries[0..base_result.entries.len], base_result.entries);
                new_entries[base_result.entries.len] = override_entry;
                allocator.free(base_result.entries);
                base_result.entries = new_entries;
            }
        }
    }

    return base_result;
}

/// Check if any file in a directory has changed since the given mtimes.
pub fn hasAnyChanged(
    entries: anytype,
) !bool {
    for (entries) |entry| {
        if (try loader.hasChanged(entry.path, entry.mtime_ns)) {
            return true;
        }
    }
    return false;
}

// ============================================================================
// Tests
// ============================================================================

test "DirLoadOptions defaults" {
    const opts = DirLoadOptions{};
    try std.testing.expectEqualStrings(".conf", opts.extension.?);
    try std.testing.expect(!opts.recursive);
}

test "freeConfigStrings" {
    const TestConfig = struct {
        name: []const u8 = "",
        values: []const i64 = &[_]i64{},
        opt_str: ?[]const u8 = null,
    };

    // Test that it handles empty/default values without crashing
    var config = TestConfig{};
    freeConfigStrings(TestConfig, std.testing.allocator, &config);
}

test "freeConfigStrings with non-empty default" {
    const TestConfig = struct {
        label: []const u8 = "default_label",
        count: u32 = 0,
    };

    // Default comptime string should NOT be freed
    var config = TestConfig{};
    freeConfigStrings(TestConfig, std.testing.allocator, &config);

    // Allocated string SHOULD be freed
    var config2 = TestConfig{
        .label = try std.testing.allocator.dupe(u8, "allocated"),
    };
    freeConfigStrings(TestConfig, std.testing.allocator, &config2);
}

test "freeConfigStrings recurses into nested structs" {
    const Inner = struct {
        font_family: []const u8 = "Inter",
        size: u16 = 14,
    };
    const Outer = struct {
        name: []const u8 = "",
        inner: Inner = .{},
    };

    // Default nested string should NOT be freed
    var config = Outer{};
    freeConfigStrings(Outer, std.testing.allocator, &config);

    // Allocated nested string SHOULD be freed
    var config2 = Outer{
        .inner = .{
            .font_family = try std.testing.allocator.dupe(u8, "Noto Sans"),
        },
    };
    freeConfigStrings(Outer, std.testing.allocator, &config2);
}
