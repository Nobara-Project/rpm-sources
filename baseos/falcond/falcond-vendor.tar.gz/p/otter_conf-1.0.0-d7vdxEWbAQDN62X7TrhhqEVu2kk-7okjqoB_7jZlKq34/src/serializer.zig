//! Serialization of config structs to otter-conf format.

const std = @import("std");

fn hasParseFn(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    return @hasDecl(FieldType, "parse");
}

fn hasToStrFn(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    return @hasDecl(FieldType, "toStr");
}

fn isContainerStruct(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    if (hasParseFn(FieldType)) return false;
    return std.meta.fields(FieldType).len > 0;
}

/// Options for serializing a config to text.
pub const SerializeOptions = struct {
    /// Include a comment header.
    header_comment: ?[]const u8 = null,

    /// Add blank lines between fields.
    spacing: bool = true,

    /// Include type comments above each field.
    include_type_comments: bool = false,
};

/// Serialize a config struct to the otter-conf format.
pub fn serialize(
    comptime T: type,
    allocator: std.mem.Allocator,
    config: T,
    options: SerializeOptions,
) ![]const u8 {
    var buffer = std.ArrayList(u8){};
    errdefer buffer.deinit(allocator);

    const writer = buffer.writer(allocator);

    if (options.header_comment) |header| {
        var lines = std.mem.splitScalar(u8, header, '\n');
        while (lines.next()) |line| {
            try writer.print("# {s}\n", .{line});
        }
        try writer.writeByte('\n');
    }

    const top_fields = std.meta.fields(T);
    inline for (top_fields, 0..) |field, i| {
        if (comptime isContainerStruct(field.type)) {
            // Nested struct: serialize sub-fields with prefix
            const inner_value = @field(config, field.name);
            inline for (std.meta.fields(field.type)) |inner_field| {
                if (options.include_type_comments) {
                    try writer.print("# type: {s}\n", .{@typeName(inner_field.type)});
                }
                const inner_val = @field(inner_value, inner_field.name);
                const prefix = comptime field.name ++ "_" ++ inner_field.name;
                try serializeField(writer, prefix, inner_field.type, inner_val);
            }
        } else {
            if (options.include_type_comments) {
                try writer.print("# type: {s}\n", .{@typeName(field.type)});
            }
            const value = @field(config, field.name);
            try serializeField(writer, field.name, field.type, value);
        }

        if (options.spacing and i < top_fields.len - 1) {
            try writer.writeByte('\n');
        }
    }

    return buffer.toOwnedSlice(allocator);
}

fn serializeField(
    writer: anytype,
    name: []const u8,
    comptime FieldType: type,
    value: FieldType,
) !void {
    switch (@typeInfo(FieldType)) {
        .@"struct" => {
            if (comptime hasToStrFn(FieldType)) {
                try writer.print("{s} = ", .{name});
                const str = value.toStr();
                try serializeString(writer, &str);
            } else {
                try writer.print("{s} = \"\"\n", .{name});
            }
            return;
        },
        .optional => |opt_info| {
            if (value) |v| {
                try writer.print("{s} = ", .{name});
                if (comptime @typeInfo(opt_info.child) == .@"struct" and hasToStrFn(opt_info.child)) {
                    const str = v.toStr();
                    try serializeString(writer, &str);
                } else {
                    try serializeValue(writer, opt_info.child, v);
                }
            } else {
                // Skip null optionals for non-string types; emit "" for string types
                if (comptime @typeInfo(opt_info.child) == .pointer) {
                    try writer.print("{s} = \"\"\n", .{name});
                }
                // Non-string null optionals: skip entirely
            }
            return;
        },
        else => {},
    }

    try writer.print("{s} = ", .{name});

    switch (@typeInfo(FieldType)) {
        .bool => {
            try writer.print("{s}\n", .{if (value) "true" else "false"});
        },
        .int => {
            try writer.print("{d}\n", .{value});
        },
        .float => {
            try writer.print("{d}\n", .{value});
        },
        .@"enum" => {
            try writer.print("{s}\n", .{@tagName(value)});
        },
        .pointer => |ptr_info| {
            if (ptr_info.size == .slice) {
                try serializeSlice(writer, ptr_info.child, value);
            } else {
                try writer.writeAll("\"\"\n");
            }
        },
        .array => |array_info| {
            try serializeArray(writer, array_info.child, array_info.len, &value);
        },
        else => {
            try writer.writeAll("\"\"\n");
        },
    }
}

fn serializeValue(
    writer: anytype,
    comptime T: type,
    value: T,
) !void {
    switch (@typeInfo(T)) {
        .bool => try writer.print("{s}\n", .{if (value) "true" else "false"}),
        .int => try writer.print("{d}\n", .{value}),
        .float => try writer.print("{d}\n", .{value}),
        .@"enum" => try writer.print("{s}\n", .{@tagName(value)}),
        .pointer => |ptr_info| {
            if (ptr_info.size == .slice and ptr_info.child == u8) {
                try serializeString(writer, value);
            } else {
                try serializeSlice(writer, ptr_info.child, value);
            }
        },
        else => try writer.writeAll("\"\"\n"),
    }
}

fn serializeString(writer: anytype, str: []const u8) !void {
    try writer.writeByte('"');
    for (str) |c| {
        switch (c) {
            '"' => try writer.writeAll("\\\""),
            '\\' => try writer.writeAll("\\\\"),
            '\n' => try writer.writeAll("\\n"),
            '\r' => try writer.writeAll("\\r"),
            '\t' => try writer.writeAll("\\t"),
            0 => try writer.writeAll("\\0"),
            else => try writer.writeByte(c),
        }
    }
    try writer.writeAll("\"\n");
}

fn serializeSlice(writer: anytype, comptime Child: type, slice: anytype) !void {
    if (Child == u8) {
        try serializeString(writer, slice);
    } else if (Child == []const u8) {
        try writer.writeByte('[');
        for (slice, 0..) |s, i| {
            try writer.writeByte('"');
            for (s) |c| {
                switch (c) {
                    '"' => try writer.writeAll("\\\""),
                    '\\' => try writer.writeAll("\\\\"),
                    else => try writer.writeByte(c),
                }
            }
            try writer.writeByte('"');
            if (i < slice.len - 1) try writer.writeAll(", ");
        }
        try writer.writeAll("]\n");
    } else {
        try writer.writeByte('[');
        for (slice, 0..) |v, i| {
            try writer.print("{d}", .{v});
            if (i < slice.len - 1) try writer.writeAll(", ");
        }
        try writer.writeAll("]\n");
    }
}

fn serializeArray(
    writer: anytype,
    comptime Child: type,
    comptime len: usize,
    array: *const [len]Child,
) !void {
    try writer.writeByte('[');
    for (array, 0..) |v, i| {
        try writer.print("{d}", .{v});
        if (i < len - 1) try writer.writeAll(", ");
    }
    try writer.writeAll("]\n");
}

/// Serialize a default config (using struct default values).
pub fn serializeDefaults(
    comptime T: type,
    allocator: std.mem.Allocator,
    options: SerializeOptions,
) ![]const u8 {
    const defaults: T = .{};
    return serialize(T, allocator, defaults, options);
}

// ============================================================================
// Tests
// ============================================================================

test "serialize basic config" {
    const TestConfig = struct {
        name: []const u8 = "test",
        count: i32 = 42,
        enabled: bool = true,
        ratio: f64 = 3.14,
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "name = \"test\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "count = 42") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "enabled = true") != null);
}

test "serialize with header" {
    const TestConfig = struct {
        value: i32 = 1,
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{
        .header_comment = "My Config\nVersion 1.0",
        .spacing = false,
    });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "# My Config") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "# Version 1.0") != null);
}

test "serialize string escaping" {
    const TestConfig = struct {
        text: []const u8 = "hello \"world\"\nnewline",
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "\\\"world\\\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "\\n") != null);
}

test "serialize enum" {
    const Mode = enum { Debug, Release, Test };
    const TestConfig = struct {
        mode: Mode = .Release,
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "mode = Release") != null);
}

test "serialize array" {
    const TestConfig = struct {
        values: [3]i64 = .{ 1, 2, 3 },
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "values = [1, 2, 3]") != null);
}

test "serialize nested struct" {
    const Inner = struct {
        enabled: bool = true,
        count: u32 = 10,
    };
    const NestedConfig = struct {
        section: Inner = .{},
        other: i64 = 5,
    };

    const config = NestedConfig{};
    const output = try serialize(NestedConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "section_enabled = true") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "section_count = 10") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "other = 5") != null);
}

test "serialize custom type with toStr" {
    const MockColor = struct {
        r: u8,
        g: u8,

        pub fn toStr(self: @This()) [5]u8 {
            const hex = "0123456789ABCDEF";
            return .{ '#', hex[self.r >> 4], hex[self.r & 0xF], hex[self.g >> 4], hex[self.g & 0xF] };
        }

        pub fn parse(_: []const u8) !@This() {
            return .{ .r = 0, .g = 0 };
        }
    };
    const CustomConfig = struct {
        color: MockColor = .{ .r = 0xFF, .g = 0xAB },
    };

    const config = CustomConfig{};
    const output = try serialize(CustomConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "color = \"#FFAB\"") != null);
}

test "serialize nested struct with custom type" {
    const MockColor = struct {
        val: u8,

        pub fn toStr(self: @This()) [3]u8 {
            const hex = "0123456789ABCDEF";
            return .{ '#', hex[self.val >> 4], hex[self.val & 0xF] };
        }

        pub fn parse(_: []const u8) !@This() {
            return .{ .val = 0 };
        }
    };
    const Inner = struct {
        text_color: MockColor = .{ .val = 0xAA },
        enabled: bool = false,
    };
    const Config = struct {
        widget: Inner = .{},
    };

    const config = Config{};
    const output = try serialize(Config, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "widget_text_color = \"#AA\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "widget_enabled = false") != null);
}

test "serialize optional null skipped for non-string" {
    const Config = struct {
        opt_int: ?i32 = null,
        name: []const u8 = "test",
    };

    const config = Config{};
    const output = try serialize(Config, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    // null optional int should not appear in output
    try std.testing.expect(std.mem.indexOf(u8, output, "opt_int") == null);
    try std.testing.expect(std.mem.indexOf(u8, output, "name = \"test\"") != null);
}

test "serialize round-trip nested with custom type" {
    const parser_mod = @import("parser.zig");

    const MockColor = struct {
        r: u8,
        g: u8,
        b: u8,
        a: u8 = 0xFF,

        pub fn parse(str: []const u8) error{InvalidColor}!@This() {
            if (str.len < 7 or str[0] != '#') return error.InvalidColor;
            return .{
                .r = std.fmt.parseInt(u8, str[1..3], 16) catch return error.InvalidColor,
                .g = std.fmt.parseInt(u8, str[3..5], 16) catch return error.InvalidColor,
                .b = std.fmt.parseInt(u8, str[5..7], 16) catch return error.InvalidColor,
            };
        }

        pub fn toStr(self: @This()) [9]u8 {
            const hex = "0123456789ABCDEF";
            return .{ '#', hex[self.r >> 4], hex[self.r & 0xF], hex[self.g >> 4], hex[self.g & 0xF], hex[self.b >> 4], hex[self.b & 0xF], hex[self.a >> 4], hex[self.a & 0xF] };
        }
    };
    const Inner = struct {
        color: MockColor = .{ .r = 0xAA, .g = 0xBB, .b = 0xCC },
        enabled: bool = true,
    };
    const Config = struct {
        widget: Inner = .{},
    };

    // Serialize
    const original = Config{};
    const text = try serialize(Config, std.testing.allocator, original, .{ .spacing = false });
    defer std.testing.allocator.free(text);

    // Parse back
    var p = parser_mod.Parser(Config).init(std.testing.allocator, text);
    const parsed = try p.parse();

    try std.testing.expectEqual(original.widget.color.r, parsed.widget.color.r);
    try std.testing.expectEqual(original.widget.color.g, parsed.widget.color.g);
    try std.testing.expectEqual(original.widget.color.b, parsed.widget.color.b);
    try std.testing.expectEqual(original.widget.enabled, parsed.widget.enabled);
}
