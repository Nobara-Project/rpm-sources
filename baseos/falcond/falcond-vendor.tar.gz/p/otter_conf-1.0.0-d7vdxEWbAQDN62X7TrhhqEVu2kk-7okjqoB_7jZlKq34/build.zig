const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    // =========================================================================
    // Dependencies
    // =========================================================================

    const otter_utils = b.dependency("otter_utils", .{
        .target = target,
        .optimize = optimize,
    }).module("otter_utils");

    // =========================================================================
    // Library Module
    // =========================================================================

    const mod = b.createModule(.{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
        .imports = &.{
            .{ .name = "otter_utils", .module = otter_utils },
        },
    });

    // Export module for external use via zig fetch
    const exported_mod = b.addModule("otter_conf", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
    });
    exported_mod.addImport("otter_utils", otter_utils);

    // =========================================================================
    // Library Tests
    // =========================================================================

    const lib_tests = b.addTest(.{
        .root_module = mod,
    });

    const run_lib_tests = b.addRunArtifact(lib_tests);

    const test_step = b.step("test", "Run all unit tests");
    test_step.dependOn(&run_lib_tests.step);

    // =========================================================================
    // Example: Basic
    // =========================================================================

    const basic_module = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "examples/basic.zig" },
        .target = target,
        .optimize = optimize,
        .imports = &.{
            .{ .name = "otter_conf", .module = mod },
        },
    });

    const basic_example = b.addExecutable(.{
        .name = "example-basic",
        .root_module = basic_module,
    });

    const run_basic = b.addRunArtifact(basic_example);

    const basic_step = b.step("example-basic", "Run basic usage example");
    basic_step.dependOn(&run_basic.step);

    // =========================================================================
    // Example: Advanced
    // =========================================================================

    const advanced_module = b.createModule(.{
        .root_source_file = .{ .cwd_relative = "examples/advanced.zig" },
        .target = target,
        .optimize = optimize,
        .imports = &.{
            .{ .name = "otter_conf", .module = mod },
        },
    });

    const advanced_example = b.addExecutable(.{
        .name = "example-advanced",
        .root_module = advanced_module,
    });

    const run_advanced = b.addRunArtifact(advanced_example);

    const advanced_step = b.step("example-advanced", "Run advanced usage example");
    advanced_step.dependOn(&run_advanced.step);

    // =========================================================================
    // Run All Examples
    // =========================================================================

    const examples_step = b.step("examples", "Run all examples");
    examples_step.dependOn(&run_basic.step);
    examples_step.dependOn(&run_advanced.step);

    // =========================================================================
    // Install Artifacts
    // =========================================================================

    b.installArtifact(basic_example);
    b.installArtifact(advanced_example);

    // Note: Benchmarks have their own build.zig in benchmarks/
    // Run: cd benchmarks && zig build
}
