//! otter-utils: Generic utilities for the Otter desktop shell
//!
//! Stack-allocated bounded arrays, path handling, logging, inotify, and other utilities.

pub const BoundedArray = @import("bounded_array.zig").BoundedArray;
pub const FilePath = @import("file_path.zig");
pub const log = @import("log.zig");
pub const inotify = @import("inotify.zig");
pub const process = @import("process.zig");

const c = @cImport(@cInclude("malloc.h"));

/// Asks glibc to return freed heap pages to the OS. Safe to call regardless
/// of allocator — jemalloc provides a no-op malloc_trim, and mimalloc doesn't
/// use glibc's heap so glibc's malloc_trim is harmless.
pub inline fn mallocTrim() void {
    _ = c.malloc_trim(0);
}

test {
    _ = @import("bounded_array.zig");
    _ = @import("file_path.zig");
    _ = @import("log.zig");
    _ = @import("inotify.zig");
    _ = @import("process.zig");
}
