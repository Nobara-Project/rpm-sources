//! inotify wrapper for file/directory watching
//!
//! Provides a generic inotify interface that can be used for file watching
//! (config hot-reload) or directory watching (application list changes).

const std = @import("std");
const mem = std.mem;
const posix = std.posix;
const Allocator = std.mem.Allocator;

pub const Watcher = struct {
    fd: posix.fd_t,
    watches: WatchMap,
    allocator: Allocator,
    event_buffer: [4096]u8 = undefined,
    event_len: usize = 0,
    event_offset: usize = 0,

    const WatchMap = std.AutoHashMap(i32, []const u8);

    pub const Event = struct {
        wd: i32,
        mask: u32,
        cookie: u32,
        name: ?[]const u8,

        pub fn isModified(self: Event) bool {
            return self.mask & std.os.linux.IN.CLOSE_WRITE != 0;
        }

        pub fn isDeleted(self: Event) bool {
            return self.mask & (std.os.linux.IN.DELETE_SELF | std.os.linux.IN.DELETE) != 0;
        }

        pub fn isCreated(self: Event) bool {
            return self.mask & std.os.linux.IN.CREATE != 0;
        }

        pub fn isMoved(self: Event) bool {
            return self.mask & (std.os.linux.IN.MOVE_SELF | std.os.linux.IN.MOVED_FROM | std.os.linux.IN.MOVED_TO) != 0;
        }

        pub fn isIgnored(self: Event) bool {
            return self.mask & std.os.linux.IN.IGNORED != 0;
        }
    };

    pub const Mask = struct {
        pub const file_changes = std.os.linux.IN.CLOSE_WRITE |
            std.os.linux.IN.DELETE_SELF |
            std.os.linux.IN.MOVE_SELF |
            std.os.linux.IN.MODIFY;

        pub const dir_changes = std.os.linux.IN.CREATE |
            std.os.linux.IN.DELETE |
            std.os.linux.IN.CLOSE_WRITE |
            std.os.linux.IN.MOVED_FROM |
            std.os.linux.IN.MOVED_TO;
    };

    pub const InitError = error{
        SystemResources,
        ProcessFdQuotaExceeded,
        Unexpected,
    };

    pub fn init(allocator: Allocator) InitError!Watcher {
        const flags: u32 = std.os.linux.IN.CLOEXEC | std.os.linux.IN.NONBLOCK;
        const fd = posix.inotify_init1(flags) catch |err| {
            return switch (err) {
                error.SystemResources => error.SystemResources,
                error.ProcessFdQuotaExceeded => error.ProcessFdQuotaExceeded,
                else => error.Unexpected,
            };
        };

        return .{
            .fd = fd,
            .watches = WatchMap.init(allocator),
            .allocator = allocator,
        };
    }

    pub fn deinit(self: *Watcher) void {
        var iter = self.watches.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.value_ptr.*);
            _ = posix.inotify_rm_watch(self.fd, entry.key_ptr.*);
        }
        self.watches.deinit();
        posix.close(self.fd);
        self.* = undefined;
    }

    pub const WatchError = error{
        AccessDenied,
        FileNotFound,
        SystemResources,
        UserResourceLimitReached,
        NameTooLong,
        OutOfMemory,
        Unexpected,
    };

    pub fn addWatch(self: *Watcher, path: []const u8, mask: u32) WatchError!i32 {
        const path_z = std.fs.path.joinZ(self.allocator, &.{path}) catch return error.OutOfMemory;
        defer self.allocator.free(path_z);

        const wd = posix.inotify_add_watch(self.fd, path_z, mask) catch |err| {
            return switch (err) {
                error.AccessDenied => error.AccessDenied,
                error.FileNotFound => error.FileNotFound,
                error.SystemResources => error.SystemResources,
                error.UserResourceLimitReached => error.UserResourceLimitReached,
                error.NameTooLong => error.NameTooLong,
                else => error.Unexpected,
            };
        };

        const path_copy = self.allocator.dupe(u8, path) catch return error.OutOfMemory;
        errdefer self.allocator.free(path_copy);

        self.watches.put(wd, path_copy) catch {
            self.allocator.free(path_copy);
            _ = posix.inotify_rm_watch(self.fd, wd);
            return error.OutOfMemory;
        };

        return wd;
    }

    pub fn removeWatch(self: *Watcher, wd: i32) void {
        if (self.watches.fetchRemove(wd)) |entry| {
            self.allocator.free(entry.value);
            _ = posix.inotify_rm_watch(self.fd, wd);
        }
    }

    pub fn removeWatchByPath(self: *Watcher, path: []const u8) void {
        var to_remove: ?i32 = null;
        var iter = self.watches.iterator();
        while (iter.next()) |entry| {
            if (mem.eql(u8, entry.value_ptr.*, path)) {
                to_remove = entry.key_ptr.*;
                break;
            }
        }
        if (to_remove) |wd| {
            self.removeWatch(wd);
        }
    }

    pub fn getFd(self: *const Watcher) posix.fd_t {
        return self.fd;
    }

    pub fn getPath(self: *const Watcher, wd: i32) ?[]const u8 {
        return self.watches.get(wd);
    }

    pub fn nextEvent(self: *Watcher) ?Event {
        if (self.event_offset >= self.event_len) {
            const bytes_read = posix.read(self.fd, &self.event_buffer) catch |err| {
                switch (err) {
                    error.WouldBlock => return null,
                    else => return null,
                }
            };
            if (bytes_read == 0) return null;
            self.event_len = bytes_read;
            self.event_offset = 0;
        }

        if (self.event_offset + @sizeOf(std.os.linux.inotify_event) > self.event_len) {
            return null;
        }

        const event_ptr: *align(1) const std.os.linux.inotify_event = @ptrCast(&self.event_buffer[self.event_offset]);

        const name: ?[]const u8 = if (event_ptr.len > 0) blk: {
            const name_start = self.event_offset + @sizeOf(std.os.linux.inotify_event);
            const name_end = name_start + event_ptr.len;
            if (name_end > self.event_len) break :blk null;

            const name_bytes = self.event_buffer[name_start..name_end];
            const null_pos = mem.indexOfScalar(u8, name_bytes, 0) orelse name_bytes.len;
            break :blk name_bytes[0..null_pos];
        } else null;

        self.event_offset += @sizeOf(std.os.linux.inotify_event) + event_ptr.len;

        return Event{
            .wd = event_ptr.wd,
            .mask = event_ptr.mask,
            .cookie = event_ptr.cookie,
            .name = name,
        };
    }

    pub fn hasPendingEvents(self: *const Watcher) bool {
        var fds = [_]posix.pollfd{
            .{ .fd = self.fd, .events = posix.POLL.IN, .revents = 0 },
        };
        const result = posix.poll(&fds, 0) catch return false;
        return result > 0 and (fds[0].revents & posix.POLL.IN != 0);
    }
};

test "watcher init and deinit" {
    var watcher = try Watcher.init(std.testing.allocator);
    defer watcher.deinit();
    try std.testing.expect(watcher.fd >= 0);
}

test "event flags" {
    const event = Watcher.Event{
        .wd = 1,
        .mask = std.os.linux.IN.CLOSE_WRITE,
        .cookie = 0,
        .name = null,
    };
    try std.testing.expect(event.isModified());
    try std.testing.expect(!event.isDeleted());
    try std.testing.expect(!event.isCreated());
}

test "mask constants" {
    try std.testing.expect(Watcher.Mask.file_changes != 0);
    try std.testing.expect(Watcher.Mask.dir_changes != 0);
}
