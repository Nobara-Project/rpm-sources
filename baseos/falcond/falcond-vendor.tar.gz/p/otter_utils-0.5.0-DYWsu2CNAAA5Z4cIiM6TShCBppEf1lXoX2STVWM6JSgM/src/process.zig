//! Process spawning utilities for fire-and-forget commands.
//!
//! All Otter Shell apps that spawn external commands (bar buttons, network
//! widget, launcher) must go through these helpers to ensure child processes
//! are properly reaped and never left as zombies.

const std = @import("std");
const posix = std.posix;
const Allocator = std.mem.Allocator;

const log = @import("log.zig").Scoped("process");

/// Spawn a shell command via `/bin/sh -c` and reap the child asynchronously.
/// A detached thread calls waitpid to prevent zombies — same principle as
/// falcond's screensaver.zig but non-blocking so the event loop isn't stalled.
pub fn spawnCommand(allocator: Allocator, cmd: []const u8) void {
    const argv = [_][]const u8{ "/bin/sh", "-c", cmd };

    var child = std.process.Child.init(&argv, allocator);
    child.stdin_behavior = .Ignore;
    child.stdout_behavior = .Ignore;
    child.stderr_behavior = .Ignore;

    child.spawn() catch |err| {
        log.err("Failed to spawn command '{s}': {s}", .{ cmd, @errorName(err) });
        return;
    };

    reapChild(child.id);
}

/// Spawn an argv command and reap the child asynchronously.
pub fn spawnArgv(allocator: Allocator, argv: []const []const u8) void {
    var child = std.process.Child.init(argv, allocator);
    child.stdin_behavior = .Ignore;
    child.stdout_behavior = .Ignore;
    child.stderr_behavior = .Ignore;

    child.spawn() catch |err| {
        log.err("Failed to spawn process: {s}", .{@errorName(err)});
        return;
    };

    reapChild(child.id);
}

/// Detached thread that calls waitpid(pid, 0) to reap the child.
fn reapChild(pid: posix.pid_t) void {
    const thread = std.Thread.spawn(.{}, struct {
        fn run(child_pid: posix.pid_t) void {
            _ = posix.waitpid(child_pid, 0);
        }
    }.run, .{pid}) catch |err| {
        log.err("Failed to spawn reaper thread for pid {d}: {s}", .{ pid, @errorName(err) });
        return;
    };
    thread.detach();
}
