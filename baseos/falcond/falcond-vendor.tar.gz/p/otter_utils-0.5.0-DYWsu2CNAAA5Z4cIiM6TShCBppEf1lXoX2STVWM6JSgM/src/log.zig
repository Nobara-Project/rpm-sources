//! Zero-allocation high-performance logging for Otter shell components
//!
//! Features:
//! - Zero heap allocations (stack buffers only)
//! - Comptime level filtering (disabled levels compile to nothing)
//! - Scoped loggers with fixed-width prefixes
//! - Integrated performance counters
//! - Direct stderr writes with minimal syscalls

const std = @import("std");
const builtin = @import("builtin");

/// Log levels in order of severity
pub const Level = enum(u3) {
    err = 0,
    warn = 1,
    info = 2,
    debug = 3,
    trace = 4,

    pub fn asText(self: Level) []const u8 {
        return switch (self) {
            .err => "ERR",
            .warn => "WRN",
            .info => "INF",
            .debug => "DBG",
            .trace => "TRC",
        };
    }
};

/// Runtime log level (can be changed at runtime)
pub var runtime_level: Level = if (builtin.mode == .Debug) .debug else .info;

/// Buffer size for log messages
const LOG_BUFFER_SIZE = 512;

/// Scoped logger - zero-cost abstraction for component logging
pub fn Scoped(comptime scope: []const u8) type {
    return struct {
        const scope_tag = scope;

        /// Comptime minimum level for this scope (set via build options)
        const min_level: Level = .trace;

        pub inline fn err(comptime fmt: []const u8, args: anytype) void {
            log(.err, fmt, args);
        }

        pub inline fn warn(comptime fmt: []const u8, args: anytype) void {
            log(.warn, fmt, args);
        }

        pub inline fn info(comptime fmt: []const u8, args: anytype) void {
            log(.info, fmt, args);
        }

        pub inline fn debug(comptime fmt: []const u8, args: anytype) void {
            log(.debug, fmt, args);
        }

        pub inline fn trace(comptime fmt: []const u8, args: anytype) void {
            log(.trace, fmt, args);
        }

        inline fn log(comptime level: Level, comptime fmt: []const u8, args: anytype) void {
            // Comptime filtering - if level > min_level, this entire function disappears
            if (comptime @intFromEnum(level) > @intFromEnum(min_level)) return;

            // Runtime filtering
            if (@intFromEnum(level) > @intFromEnum(runtime_level)) return;

            writeLog(level, scope_tag, fmt, args);
        }
    };
}

fn writeLog(level: Level, scope: []const u8, comptime fmt: []const u8, args: anytype) void {
    var buf: [LOG_BUFFER_SIZE]u8 = undefined;
    var pos: usize = 0;

    const level_text = level.asText();
    @memcpy(buf[pos..][0..3], level_text);
    pos += 3;

    buf[pos] = ' ';
    pos += 1;

    const scope_len = @min(scope.len, 16);
    @memcpy(buf[pos..][0..scope_len], scope[0..scope_len]);
    pos += scope_len;

    const pad_len = 16 - scope_len;
    @memset(buf[pos..][0..pad_len], ' ');
    pos += pad_len;

    buf[pos] = ' ';
    pos += 1;

    const remaining = buf[pos..];
    const written = std.fmt.bufPrint(remaining, fmt, args) catch {
        @memcpy(buf[LOG_BUFFER_SIZE - 4 ..][0..3], "...");
        pos = LOG_BUFFER_SIZE - 1;
        buf[pos] = '\n';
        _ = std.posix.write(std.posix.STDERR_FILENO, buf[0 .. pos + 1]) catch {};
        return;
    };
    pos += written.len;

    if (pos < LOG_BUFFER_SIZE) {
        buf[pos] = '\n';
        pos += 1;
    } else {
        buf[LOG_BUFFER_SIZE - 1] = '\n';
    }

    _ = std.posix.write(std.posix.STDERR_FILENO, buf[0..pos]) catch {};
}

pub const Counter = struct {
    value: u64 = 0,

    pub inline fn inc(self: *Counter) void {
        self.value +%= 1;
    }

    pub inline fn add(self: *Counter, n: u64) void {
        self.value +%= n;
    }

    pub inline fn reset(self: *Counter) u64 {
        const v = self.value;
        self.value = 0;
        return v;
    }

    pub inline fn get(self: *const Counter) u64 {
        return self.value;
    }
};

pub const Timer = struct {
    start: i128 = 0,

    pub inline fn begin(self: *Timer) void {
        self.start = std.time.nanoTimestamp();
    }

    pub inline fn elapsed(self: *const Timer) i128 {
        return std.time.nanoTimestamp() - self.start;
    }

    pub inline fn elapsedMs(self: *const Timer) f64 {
        return @as(f64, @floatFromInt(self.elapsed())) / std.time.ns_per_ms;
    }

    pub inline fn elapsedUs(self: *const Timer) f64 {
        return @as(f64, @floatFromInt(self.elapsed())) / std.time.ns_per_us;
    }
};

pub fn Reporter(comptime scope: []const u8, comptime interval_seconds: u32) type {
    return struct {
        const Self = @This();
        const reporter_log = Scoped(scope);

        last_report: i128 = 0,

        pub fn init() Self {
            return .{};
        }

        pub fn start(self: *Self) void {
            self.last_report = std.time.nanoTimestamp();
        }

        pub fn shouldReport(self: *Self) ?f64 {
            const now = std.time.nanoTimestamp();

            if (self.last_report == 0) {
                self.last_report = now;
                return null;
            }

            const elapsed = now - self.last_report;
            const interval_ns: i128 = @as(i128, interval_seconds) * std.time.ns_per_s;

            if (elapsed >= interval_ns) {
                self.last_report = now;
                return @as(f64, @floatFromInt(elapsed)) / std.time.ns_per_s;
            }
            return null;
        }

        pub fn report1(self: *Self, comptime name: []const u8, counter: *Counter) void {
            if (self.shouldReport()) |elapsed_secs| {
                const count = counter.reset();
                reporter_log.info("{s}: {} in {d:.1}s ({d:.1}/s)", .{
                    name,
                    count,
                    elapsed_secs,
                    @as(f64, @floatFromInt(count)) / elapsed_secs,
                });
            }
        }

        pub fn reportFmt(self: *Self, comptime fmt: []const u8, args: anytype) void {
            if (self.shouldReport()) |_| {
                reporter_log.info(fmt, args);
            }
        }
    };
}

pub fn stdLogFn(
    comptime level: std.log.Level,
    comptime scope: @TypeOf(.enum_literal),
    comptime fmt: []const u8,
    args: anytype,
) void {
    const otter_level: Level = switch (level) {
        .err => .err,
        .warn => .warn,
        .info => .info,
        .debug => .debug,
    };
    writeLog(otter_level, @tagName(scope), fmt, args);
}

test "scoped logger" {
    const TestLog = Scoped("test");
    TestLog.info("test message: {}", .{42});
    TestLog.debug("debug message", .{});
}

test "counter" {
    var c = Counter{};
    c.inc();
    c.inc();
    c.add(5);
    try std.testing.expectEqual(@as(u64, 7), c.get());
    try std.testing.expectEqual(@as(u64, 7), c.reset());
    try std.testing.expectEqual(@as(u64, 0), c.get());
}

test "timer" {
    var t = Timer{};
    t.begin();
    const elapsed = t.elapsedMs();
    try std.testing.expect(elapsed >= 0);
}

test "timer elapsedUs" {
    var t = Timer{};
    t.begin();
    const elapsed = t.elapsedUs();
    try std.testing.expect(elapsed >= 0);
}

test "Level asText" {
    try std.testing.expectEqualStrings("ERR", Level.err.asText());
    try std.testing.expectEqualStrings("WRN", Level.warn.asText());
    try std.testing.expectEqualStrings("INF", Level.info.asText());
    try std.testing.expectEqualStrings("DBG", Level.debug.asText());
    try std.testing.expectEqualStrings("TRC", Level.trace.asText());
}

test "Reporter init and shouldReport" {
    const TestReporter = Reporter("test-reporter", 1);
    var reporter = TestReporter.init();

    const first = reporter.shouldReport();
    try std.testing.expectEqual(@as(?f64, null), first);

    const second = reporter.shouldReport();
    try std.testing.expectEqual(@as(?f64, null), second);
}

test "Reporter start" {
    const TestReporter = Reporter("test-reporter", 1);
    var reporter = TestReporter.init();
    reporter.start();
    try std.testing.expect(reporter.last_report != 0);
}

test "scoped logger all levels" {
    const TestLog = Scoped("test-all");
    TestLog.err("error message", .{});
    TestLog.warn("warning message", .{});
    TestLog.info("info message", .{});
    TestLog.debug("debug message", .{});
    TestLog.trace("trace message", .{});
}

test "runtime_level filtering" {
    const saved = runtime_level;
    defer runtime_level = saved;

    runtime_level = .err;
    const TestLog = Scoped("level-test");
    TestLog.info("should not appear", .{});
    TestLog.err("should appear", .{});
}
