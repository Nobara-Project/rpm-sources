//! Stack-allocated file path with builder operations.

const std = @import("std");
const math = std.math;
const mem = std.mem;
const fs = std.fs;
const Allocator = std.mem.Allocator;
const assert = std.debug.assert;

pub const FilePath = @This();

pub const Len = math.IntFittingRange(0, fs.max_path_bytes - 1);

buf: [fs.max_path_bytes - 1:0]u8 = .{0} ** (fs.max_path_bytes - 1),
len: Len = 0,

pub const empty: FilePath = .{};

pub fn slice(self: *const FilePath) [:0]const u8 {
    self.assertValid();
    return self.buf[0..self.len :0];
}

pub fn mutSlice(self: *FilePath) [:0]u8 {
    self.assertValid();
    return self.buf[0..self.len :0];
}

pub fn toOwned(self: *const FilePath, allocator: Allocator) Allocator.Error![:0]const u8 {
    return allocator.dupeZ(u8, self.slice());
}

pub fn from(path: []const u8) error{PathTooLong}!FilePath {
    var result: FilePath = .{};
    result.len = math.cast(Len, path.len) orelse return error.PathTooLong;
    @memcpy(result.buf[0..path.len], path);
    result.ensureTerminator();
    result.assertValid();
    return result;
}

pub fn fromMany(segments: []const []const u8) error{PathTooLong}!FilePath {
    var result: FilePath = .{};
    try result.appendMany(segments);
    return result;
}

pub fn appendSegment(self: *FilePath, segment: []const u8) error{PathTooLong}!void {
    if (self.len != 0) try self.appendByte(fs.path.sep);
    try self.appendSlice(segment);
}

pub fn appendMany(self: *FilePath, segments: []const []const u8) error{PathTooLong}!void {
    // Pre-validate total length to leave self untouched on overflow
    var length: Len = 0;
    for (segments, 0..) |segment, idx| {
        const segment_len = math.cast(Len, segment.len) orelse return error.PathTooLong;
        if (idx != 0 or self.len != 0) length += 1;
        length = math.add(Len, length, segment_len) catch return error.PathTooLong;
    }
    if (self.len + length >= fs.max_path_bytes) return error.PathTooLong;

    for (segments) |segment| {
        if (self.len != 0) self.appendByteUnchecked(fs.path.sep);
        @memcpy(self.buf[self.len..][0..segment.len], segment);
        self.len += @intCast(segment.len);
        self.ensureTerminator();
    }
    self.assertValid();
}

pub fn pop(self: *FilePath) ?[]const u8 {
    const idx = mem.lastIndexOfScalar(u8, self.slice(), fs.path.sep) orelse idx: {
        if (self.len == 0) return null;
        break :idx 0;
    };
    const popped = if (idx < self.len - 1) self.buf[idx + 1 .. self.len] else null;
    self.len = @intCast(idx);
    self.ensureTerminator();
    self.assertValid();
    return popped;
}

pub fn resize(self: *FilePath, len: Len) void {
    self.len = len;
    self.ensureTerminator();
    self.assertValid();
}

fn appendByte(self: *FilePath, byte: u8) error{PathTooLong}!void {
    if (self.len >= fs.max_path_bytes - 1) return error.PathTooLong;
    self.appendByteUnchecked(byte);
}

fn appendByteUnchecked(self: *FilePath, byte: u8) void {
    self.buf[self.len] = byte;
    self.len += 1;
    self.ensureTerminator();
}

fn appendSlice(self: *FilePath, bytes: []const u8) error{PathTooLong}!void {
    if (self.len + bytes.len >= fs.max_path_bytes) return error.PathTooLong;
    @memcpy(self.buf[self.len..][0..bytes.len], bytes);
    self.len += @intCast(bytes.len);
    self.ensureTerminator();
    self.assertValid();
}

fn ensureTerminator(self: *FilePath) void {
    if (self.len < fs.max_path_bytes - 1) self.buf[self.len] = 0;
}

fn assertValid(self: *const FilePath) void {
    assert(self.len < fs.max_path_bytes);
    assert(self.buf[self.len] == 0);
}

test "empty" {
    const p: FilePath = .empty;
    try std.testing.expectEqual(@as(Len, 0), p.len);
    try std.testing.expectEqualStrings("", p.slice());
}

test "from" {
    const p = try FilePath.from("/home/user/test");
    try std.testing.expectEqualStrings("/home/user/test", p.slice());
}

test "from overflow" {
    const long = "a" ** fs.max_path_bytes;
    try std.testing.expectError(error.PathTooLong, FilePath.from(long));
}

test "fromMany" {
    const p = try FilePath.fromMany(&.{ "home", "user", "docs" });
    try std.testing.expectEqualStrings("home/user/docs", p.slice());
}

test "appendSegment" {
    var p = try FilePath.from("/home");
    try p.appendSegment("user");
    try p.appendSegment("docs");
    try std.testing.expectEqualStrings("/home/user/docs", p.slice());
}

test "appendMany with existing path" {
    var p = try FilePath.from("/root");
    try p.appendMany(&.{ "home", "user" });
    try std.testing.expectEqualStrings("/root/home/user", p.slice());
}

test "pop" {
    var p = try FilePath.from("home/user/docs");
    const popped1 = p.pop();
    try std.testing.expectEqualStrings("docs", popped1.?);
    try std.testing.expectEqualStrings("home/user", p.slice());

    const popped2 = p.pop();
    try std.testing.expectEqualStrings("user", popped2.?);
    try std.testing.expectEqualStrings("home", p.slice());

    _ = p.pop();
    const popped4 = p.pop();
    try std.testing.expectEqual(@as(?[]const u8, null), popped4);
}

test "toOwned" {
    const p = try FilePath.from("/test/path");
    const allocator = std.testing.allocator;
    const owned = try p.toOwned(allocator);
    defer allocator.free(owned);
    try std.testing.expectEqualStrings("/test/path", owned);
}

test "mutSlice" {
    var p = try FilePath.from("test/path");
    p.mutSlice()[0] = 'T';
    try std.testing.expectEqualStrings("Test/path", p.slice());
}

test "resize" {
    var p = try FilePath.from("hello world");
    p.resize(5);
    try std.testing.expectEqualStrings("hello", p.slice());
}
