//! Desktop Entry Parser
//!
//! Parses XDG .desktop files following the Desktop Entry Specification.

const std = @import("std");
const otter_utils_io = @import("otter_utils");
inline fn io_global() std.Io { return otter_utils_io.io.get(); }

const mem = std.mem;
const fs = std.fs;
const posix = std.posix;
const Allocator = std.mem.Allocator;

fn strToU32(comptime s: *const [4]u8) u32 {
    return @bitCast(s.*);
}

const KEY_TYPE: u32 = strToU32("Type");
const KEY_NAME: u32 = strToU32("Name");
const KEY_EXEC: u32 = strToU32("Exec");
const KEY_ICON: u32 = strToU32("Icon");
const KEY_HIDD: u32 = strToU32("Hidd"); // Hidden prefix
const KEY_TERM: u32 = strToU32("Term"); // Terminal prefix
const KEY_NODI: u32 = strToU32("NoDi"); // NoDisplay prefix
const KEY_COMM: u32 = strToU32("Comm"); // Comment prefix
const KEY_CATE: u32 = strToU32("Cate"); // Categories prefix
const KEY_KEYW: u32 = strToU32("Keyw"); // Keywords prefix

// Value constants
const VAL_TRUE: u32 = strToU32("true");
const VAL_APPL: u32 = strToU32("Appl"); // Application prefix

/// Returns true if value is exactly "true", false otherwise.
inline fn parseBool(value: []const u8) bool {
    if (value.len != 4) return false;
    const val4: u32 = @bitCast(value[0..4].*);
    return val4 == VAL_TRUE;
}

const log = std.log.scoped(.DesktopEntry);

/// Maximum file size to parse (1MB)
pub const max_file_size = 1024 * 1024;

/// Parsed desktop entry
pub const DesktopEntry = struct {
    /// Application ID (filename without .desktop extension)
    id: []const u8,
    /// Localized application name
    name: []const u8,
    /// Localized description/comment
    comment: ?[]const u8,
    /// Command to execute
    exec: []const u8,
    /// Icon name or path
    icon: ?[]const u8,
    /// Whether to run in a terminal
    terminal: bool,
    /// Semicolon-separated categories
    categories: []const []const u8,
    /// Semicolon-separated keywords for search
    keywords: []const []const u8,
    /// Do not display in menus
    no_display: bool,
    /// Hidden from menus
    hidden: bool,
    /// Source file path
    path: []const u8,

    allocator: Allocator,

    pub fn deinit(self: *DesktopEntry) void {
        self.allocator.free(self.id);
        self.allocator.free(self.name);
        if (self.comment) |c| self.allocator.free(c);
        self.allocator.free(self.exec);
        if (self.icon) |i| self.allocator.free(i);
        for (self.categories) |cat| self.allocator.free(cat);
        self.allocator.free(self.categories);
        for (self.keywords) |kw| self.allocator.free(kw);
        self.allocator.free(self.keywords);
        self.allocator.free(self.path);
        self.* = undefined;
    }

    /// Check if this entry should be visible in application lists.
    pub fn isVisible(self: *const DesktopEntry) bool {
        return !self.no_display and !self.hidden;
    }
};

pub const ParseOptions = struct {
    /// Locale string (e.g., "en_US.UTF-8"). If null, uses environment.
    locale: ?[]const u8 = null,
};

pub const ParseError = error{
    FileNotFound,
    FileTooLarge,
    InvalidFormat,
    NotAnApplication,
    MissingName,
    MissingExec,
    OutOfMemory,
    IoError,
};

/// Parse a .desktop file from the given path.
pub fn parse(allocator: Allocator, file_path: []const u8, options: ParseOptions) ParseError!DesktopEntry {
    const file = std.Io.Dir.cwd().openFile(io_global(), file_path, .{}) catch return ParseError.FileNotFound;
    defer file.close(io_global());

    const stat = file.stat(io_global()) catch return ParseError.IoError;
    if (stat.size == 0) return ParseError.InvalidFormat;
    if (stat.size > max_file_size) return ParseError.FileTooLarge;

    const size: usize = @intCast(stat.size);
    const mapped = posix.mmap(null, size, .{ .READ = true }, .{ .TYPE = .PRIVATE }, file.handle, 0) catch return ParseError.IoError;
    defer posix.munmap(mapped);

    const content = mapped[0..size];
    return parseContent(allocator, content, file_path, options);
}

/// Parse desktop entry content from a slice.
pub fn parseContent(
    allocator: Allocator,
    content: []const u8,
    file_path: []const u8,
    options: ParseOptions,
) ParseError!DesktopEntry {
    const locale = options.locale orelse getLocale();
    const locale_parts = parseLocale(locale);

    var entry = EntryBuilder{};
    var in_desktop_entry = false;

    var lines = mem.splitScalar(u8, content, '\n');
    while (lines.next()) |raw_line| {
        if (raw_line.len == 0) continue;
        const first_byte = raw_line[0];

        if (first_byte == '#') continue;

        if (first_byte == '[') {
            if (raw_line.len >= 15) {
                const header8: u64 = @bitCast(raw_line[0..8].*);
                const expected8: u64 = @bitCast([8]u8{ '[', 'D', 'e', 's', 'k', 't', 'o', 'p' });
                if (header8 == expected8 and raw_line[8] == ' ' and raw_line[14] == ']') {
                    in_desktop_entry = true;
                    continue;
                }
            }
            if (in_desktop_entry) break;
            continue;
        }

        if (!in_desktop_entry) continue;

        const eq_pos = mem.indexOfScalar(u8, raw_line, '=') orelse continue;
        if (eq_pos < 4) continue; // Minimum key length is 4 (Type, Name, Exec, Icon)

        const key = raw_line[0..eq_pos];
        const value = if (eq_pos + 1 < raw_line.len) blk: {
            const v = raw_line[eq_pos + 1 ..];
            break :blk mem.trimEnd(u8, v, &.{ '\r', ' ', '\t' });
        } else "";

        // Get first 4 bytes as u32 for key matching
        const key4: u32 = @bitCast(key[0..4].*);
        const key_len = key.len;

        // Check localized keys first (Name[xx], Comment[xx]) - they have '[' at specific positions
        if (key4 == KEY_NAME) {
            if (key_len == 4) {
                if (entry.name == null and entry.name_priority == 0) {
                    entry.name = value;
                }
            } else if (key_len > 5 and key[4] == '[') {
                const locale_tag = key[5 .. key_len - 1];
                entry.trySetLocalizedName(value, locale_tag, locale_parts);
            }
        } else if (key4 == KEY_COMM) {
            if (key_len == 7 and key[4] == 'e' and key[5] == 'n' and key[6] == 't') {
                if (entry.comment == null and entry.comment_priority == 0) {
                    entry.comment = value;
                }
            } else if (key_len > 8 and key[7] == '[' and key[4] == 'e' and key[5] == 'n' and key[6] == 't') {
                const locale_tag = key[8 .. key_len - 1];
                entry.trySetLocalizedComment(value, locale_tag, locale_parts);
            }
        } else if (key_len == 4) {
            // Other 4-char keys: Type, Exec, Icon
            if (key4 == KEY_TYPE) {
                if (value.len != 11) return ParseError.NotAnApplication;
                const val4: u32 = @bitCast(value[0..4].*);
                if (val4 != VAL_APPL) return ParseError.NotAnApplication;
                if (!mem.eql(u8, value[4..], "ication")) return ParseError.NotAnApplication;
            } else if (key4 == KEY_EXEC) {
                entry.exec = value;
            } else if (key4 == KEY_ICON) {
                entry.icon = value;
            }
        } else if (key_len == 6 and key4 == KEY_HIDD and key[4] == 'e' and key[5] == 'n') {
            entry.hidden = parseBool(value);
        } else if (key_len == 8) {
            if (key4 == KEY_TERM) {
                const suffix: u32 = @bitCast(key[4..8].*);
                if (suffix == strToU32("inal")) {
                    entry.terminal = parseBool(value);
                }
            } else if (key4 == KEY_KEYW) {
                const suffix: u32 = @bitCast(key[4..8].*);
                if (suffix == strToU32("ords")) {
                    entry.keywords = value;
                }
            }
        } else if (key_len == 9 and key4 == KEY_NODI and mem.eql(u8, key[4..9], "splay")) {
            entry.no_display = parseBool(value);
        } else if (key_len == 10 and key4 == KEY_CATE and mem.eql(u8, key[4..10], "gories")) {
            entry.categories = value;
        }
    }

    // Validate required fields
    const name = entry.name orelse return ParseError.MissingName;
    const exec = entry.exec orelse return ParseError.MissingExec;

    // Extract ID from filename
    const basename = fs.path.basename(file_path);
    const id = if (mem.endsWith(u8, basename, ".desktop"))
        basename[0 .. basename.len - 8]
    else
        basename;

    // Allocate and copy all strings
    const result_id = allocator.dupe(u8, id) catch return ParseError.OutOfMemory;
    errdefer allocator.free(result_id);

    const result_name = allocator.dupe(u8, name) catch return ParseError.OutOfMemory;
    errdefer allocator.free(result_name);

    const result_comment: ?[]const u8 = if (entry.comment) |c|
        allocator.dupe(u8, c) catch return ParseError.OutOfMemory
    else
        null;
    errdefer if (result_comment) |c| allocator.free(c);

    const result_exec = allocator.dupe(u8, exec) catch return ParseError.OutOfMemory;
    errdefer allocator.free(result_exec);

    const result_icon: ?[]const u8 = if (entry.icon) |i|
        allocator.dupe(u8, i) catch return ParseError.OutOfMemory
    else
        null;
    errdefer if (result_icon) |i| allocator.free(i);

    const result_path = allocator.dupe(u8, file_path) catch return ParseError.OutOfMemory;
    errdefer allocator.free(result_path);

    const result_categories = parseSemicolonList(allocator, entry.categories) catch return ParseError.OutOfMemory;
    errdefer {
        for (result_categories) |cat| allocator.free(cat);
        allocator.free(result_categories);
    }

    const result_keywords = parseSemicolonList(allocator, entry.keywords) catch return ParseError.OutOfMemory;
    errdefer {
        for (result_keywords) |kw| allocator.free(kw);
        allocator.free(result_keywords);
    }

    return .{
        .id = result_id,
        .name = result_name,
        .comment = result_comment,
        .exec = result_exec,
        .icon = result_icon,
        .terminal = entry.terminal,
        .categories = result_categories,
        .keywords = result_keywords,
        .no_display = entry.no_display,
        .hidden = entry.hidden,
        .path = result_path,
        .allocator = allocator,
    };
}

const EntryBuilder = struct {
    name: ?[]const u8 = null,
    name_priority: u8 = 0, // Higher = better match
    comment: ?[]const u8 = null,
    comment_priority: u8 = 0,
    exec: ?[]const u8 = null,
    icon: ?[]const u8 = null,
    terminal: bool = false,
    no_display: bool = false,
    hidden: bool = false,
    categories: ?[]const u8 = null,
    keywords: ?[]const u8 = null,

    fn trySetLocalizedName(self: *EntryBuilder, value: []const u8, locale_tag: []const u8, locale_parts: LocaleParts) void {
        const priority = matchLocale(locale_tag, locale_parts);
        if (priority > self.name_priority) {
            self.name = value;
            self.name_priority = priority;
        }
    }

    fn trySetLocalizedComment(self: *EntryBuilder, value: []const u8, locale_tag: []const u8, locale_parts: LocaleParts) void {
        const priority = matchLocale(locale_tag, locale_parts);
        if (priority > self.comment_priority) {
            self.comment = value;
            self.comment_priority = priority;
        }
    }
};

const LocaleParts = struct {
    lang: ?[]const u8 = null,
    country: ?[]const u8 = null,
    encoding: ?[]const u8 = null,
    modifier: ?[]const u8 = null,
};

fn parseLocale(locale: []const u8) LocaleParts {
    var parts = LocaleParts{};

    // Format: lang_COUNTRY.ENCODING@MODIFIER
    var remaining = locale;

    // Check for modifier
    if (mem.indexOfScalar(u8, remaining, '@')) |at_pos| {
        parts.modifier = remaining[at_pos + 1 ..];
        remaining = remaining[0..at_pos];
    }

    // Check for encoding
    if (mem.indexOfScalar(u8, remaining, '.')) |dot_pos| {
        parts.encoding = remaining[dot_pos + 1 ..];
        remaining = remaining[0..dot_pos];
    }

    // Check for country
    if (mem.indexOfScalar(u8, remaining, '_')) |underscore_pos| {
        parts.country = remaining[underscore_pos + 1 ..];
        parts.lang = remaining[0..underscore_pos];
    } else {
        parts.lang = remaining;
    }

    return parts;
}

fn matchLocale(locale_tag: []const u8, target: LocaleParts) u8 {
    // Parse the locale tag from the .desktop file
    const tag_parts = parseLocale(locale_tag);

    // Early exit if no target language
    const target_lang = target.lang orelse return 0;
    const tag_lang = tag_parts.lang orelse return 0;

    // Language must match
    if (!mem.eql(u8, tag_lang, target_lang)) return 0;

    // Modifier must match: reject tags with a different modifier than the
    // user's locale (e.g. en@shaw must not match plain en_US). Per the XDG
    // spec, a localized key with modifier only matches when the user locale
    // carries the same modifier.
    const tag_mod = tag_parts.modifier;
    const target_mod = target.modifier;
    if (tag_mod != null or target_mod != null) {
        if (tag_mod == null or target_mod == null) return 0;
        if (!mem.eql(u8, tag_mod.?, target_mod.?)) return 0;
    }

    // Language-only match (tag has no country)
    if (tag_parts.country == null) return 2;

    // Tag has country - check if it matches target country
    const target_country = target.country orelse return 0;
    if (!mem.eql(u8, tag_parts.country.?, target_country)) return 0;

    // Country matches - check encoding for highest priority
    if (target.encoding != null and tag_parts.encoding != null) {
        if (mem.eql(u8, tag_parts.encoding.?, target.encoding.?)) {
            return 4; // lang_COUNTRY.encoding
        }
    }

    return 3; // lang_COUNTRY
}

fn getLocale() []const u8 {
    // Check environment variables in order
    if (blk: { if (std.c.getenv("LC_MESSAGES")) |raw| break :blk std.mem.span(raw); break :blk @as(?[]const u8, null); }) |lc| return lc;
    if (blk: { if (std.c.getenv("LC_ALL")) |raw| break :blk std.mem.span(raw); break :blk @as(?[]const u8, null); }) |lc| return lc;
    if (blk: { if (std.c.getenv("LANG")) |raw| break :blk std.mem.span(raw); break :blk @as(?[]const u8, null); }) |lang| return lang;
    return "C";
}

fn parseSemicolonList(allocator: Allocator, value: ?[]const u8) Allocator.Error![]const []const u8 {
    const str = value orelse return &[_][]const u8{};
    if (str.len == 0) return &[_][]const u8{};

    // Use stack buffer for small lists, count semicolons for estimate
    // Most category/keyword lists have < 16 items
    const max_stack_items = 16;
    var stack_buf: [max_stack_items][]const u8 = undefined;
    var count: usize = 0;

    var iter = mem.splitScalar(u8, str, ';');
    while (iter.next()) |item| {
        if (item.len > 0) {
            if (count < max_stack_items) {
                stack_buf[count] = item;
            }
            count += 1;
        }
    }

    if (count == 0) return &[_][]const u8{};

    // Allocate result array
    const result = try allocator.alloc([]const u8, count);
    errdefer allocator.free(result);

    // If all items fit in stack buffer, copy from there
    if (count <= max_stack_items) {
        for (stack_buf[0..count], 0..) |item, i| {
            result[i] = try allocator.dupe(u8, item);
        }
    } else {
        // Rare case: re-iterate for large lists
        var i: usize = 0;
        iter = mem.splitScalar(u8, str, ';');
        while (iter.next()) |item| {
            if (item.len > 0) {
                result[i] = try allocator.dupe(u8, item);
                i += 1;
            }
        }
    }

    return result;
}

// Tests
test "parse basic desktop entry" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Comment=Web Browser
        \\Exec=firefox %u
        \\Icon=firefox
        \\Categories=Network;WebBrowser;
        \\Keywords=web;browser;internet;
    ;

    var entry = try parseContent(std.testing.allocator, content, "/usr/share/applications/firefox.desktop", .{});
    defer entry.deinit();

    try std.testing.expectEqualStrings("firefox", entry.id);
    try std.testing.expectEqualStrings("Firefox", entry.name);
    try std.testing.expectEqualStrings("Web Browser", entry.comment.?);
    try std.testing.expectEqualStrings("firefox %u", entry.exec);
    try std.testing.expectEqualStrings("firefox", entry.icon.?);
    try std.testing.expect(!entry.terminal);
    try std.testing.expect(!entry.no_display);
    try std.testing.expect(!entry.hidden);
    try std.testing.expectEqual(@as(usize, 2), entry.categories.len);
    try std.testing.expectEqualStrings("Network", entry.categories[0]);
    try std.testing.expectEqualStrings("WebBrowser", entry.categories[1]);
    try std.testing.expectEqual(@as(usize, 3), entry.keywords.len);
}

test "parse with localized name - exact locale match" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Name[de]=Feuerfuchs
        \\Name[de_DE]=Feuerfuchs DE
        \\Exec=firefox
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{ .locale = "de_DE.UTF-8" });
    defer entry.deinit();

    try std.testing.expectEqualStrings("Feuerfuchs DE", entry.name);
}

test "parse with localized name - language fallback" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Name[de]=Feuerfuchs
        \\Exec=firefox
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{ .locale = "de_AT.UTF-8" });
    defer entry.deinit();

    try std.testing.expectEqualStrings("Feuerfuchs", entry.name);
}

test "parse with localized name - default fallback" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Name[de]=Feuerfuchs
        \\Exec=firefox
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{ .locale = "fr_FR.UTF-8" });
    defer entry.deinit();

    try std.testing.expectEqualStrings("Firefox", entry.name);
}

test "skip NoDisplay=true entries" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Hidden App
        \\Exec=hidden
        \\NoDisplay=true
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{});
    defer entry.deinit();

    try std.testing.expect(entry.no_display);
    try std.testing.expect(!entry.isVisible());
}

test "skip Hidden=true entries" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Hidden App
        \\Exec=hidden
        \\Hidden=true
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{});
    defer entry.deinit();

    try std.testing.expect(entry.hidden);
    try std.testing.expect(!entry.isVisible());
}

test "skip non-Application types" {
    const content =
        \\[Desktop Entry]
        \\Type=Link
        \\Name=Some Link
        \\URL=https://example.com
    ;

    const result = parseContent(std.testing.allocator, content, "test.desktop", .{});
    try std.testing.expectError(ParseError.NotAnApplication, result);
}

test "parse Terminal=true" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Terminal App
        \\Exec=some-cli
        \\Terminal=true
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{});
    defer entry.deinit();

    try std.testing.expect(entry.terminal);
}

test "parse categories semicolon-separated" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Test
        \\Exec=test
        \\Categories=A;B;C;
    ;

    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{});
    defer entry.deinit();

    try std.testing.expectEqual(@as(usize, 3), entry.categories.len);
    try std.testing.expectEqualStrings("A", entry.categories[0]);
    try std.testing.expectEqualStrings("B", entry.categories[1]);
    try std.testing.expectEqualStrings("C", entry.categories[2]);
}

test "handle missing required fields" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Comment=No name here
        \\Exec=test
    ;

    const result = parseContent(std.testing.allocator, content, "test.desktop", .{});
    try std.testing.expectError(ParseError.MissingName, result);
}

test "handle missing Exec field" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=No Exec
    ;

    const result = parseContent(std.testing.allocator, content, "test.desktop", .{});
    try std.testing.expectError(ParseError.MissingExec, result);
}

test "parseLocale" {
    {
        const parts = parseLocale("en_US.UTF-8");
        try std.testing.expectEqualStrings("en", parts.lang.?);
        try std.testing.expectEqualStrings("US", parts.country.?);
        try std.testing.expectEqualStrings("UTF-8", parts.encoding.?);
    }
    {
        const parts = parseLocale("de");
        try std.testing.expectEqualStrings("de", parts.lang.?);
        try std.testing.expect(parts.country == null);
        try std.testing.expect(parts.encoding == null);
    }
    {
        const parts = parseLocale("sr_RS@latin");
        try std.testing.expectEqualStrings("sr", parts.lang.?);
        try std.testing.expectEqualStrings("RS", parts.country.?);
        try std.testing.expectEqualStrings("latin", parts.modifier.?);
    }
}

test "locale modifier mismatch rejects Shavian for plain English locale" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Name[en@shaw]=\xf0\x90\x91\x93\xf0\x90\x91\xb2\xf0\x90\x91\xae\xf0\x90\x91\x93\xf0\x90\x91\xaa\xf0\x90\x91\x92\xf0\x90\x91\x95
        \\Exec=firefox
    ;

    // User locale is en_US — should NOT pick up en@shaw
    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{ .locale = "en_US.UTF-8" });
    defer entry.deinit();

    try std.testing.expectEqualStrings("Firefox", entry.name);
}

test "locale modifier match selects correct variant" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Name[sr@latin]=Fajerfoks
        \\Exec=firefox
    ;

    // User locale has matching modifier — should pick up sr@latin
    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{ .locale = "sr@latin" });
    defer entry.deinit();

    try std.testing.expectEqualStrings("Fajerfoks", entry.name);
}

test "locale modifier absent in tag matches plain locale" {
    const content =
        \\[Desktop Entry]
        \\Type=Application
        \\Name=Firefox
        \\Name[en]=Firefox EN
        \\Exec=firefox
    ;

    // Tag has no modifier, user has no modifier — should match
    var entry = try parseContent(std.testing.allocator, content, "test.desktop", .{ .locale = "en_US.UTF-8" });
    defer entry.deinit();

    try std.testing.expectEqualStrings("Firefox EN", entry.name);
}
