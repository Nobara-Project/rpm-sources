//! D-Bus systemd-logind client
//!
//! Provides integration with org.freedesktop.login1 for:
//! - PrepareForSleep signal handling (before/after suspend)
//! - Delay inhibitor locks (run pre-sleep commands before sleep proceeds)
//! - Idle inhibitor checking (query active idle inhibitors)

const std = @import("std");
const posix = std.posix;
const Allocator = std.mem.Allocator;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const c = dbus.types.c;

const log = std.log.scoped(.logind);

const service = "org.freedesktop.login1";
const object_path = "/org/freedesktop/login1";
const manager_interface = "org.freedesktop.login1.Manager";

pub const Error = dbus.types.Error;

pub const Logind = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    inhibit_fd: ?posix.fd_t = null,

    on_prepare_sleep: ?*const fn (going_to_sleep: bool, ctx: ?*anyopaque) void = null,
    on_lock: ?*const fn (ctx: ?*anyopaque) void = null,
    on_unlock: ?*const fn (ctx: ?*anyopaque) void = null,
    context: ?*anyopaque = null,

    pub fn init(allocator: Allocator) Error!Logind {
        const connection = try dbus.Connection.open(allocator, .system);

        return .{
            .connection = connection,
            .allocator = allocator,
        };
    }

    /// Subscribe to logind signals. Must be called after the struct is at its
    /// final address (not a local returned by value from init).
    pub fn subscribe(self: *Logind) void {
        // Subscribe to PrepareForSleep signal
        self.connection.subscribeSignal(
            manager_interface,
            "PrepareForSleep",
            onPrepareForSleep,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to PrepareForSleep: {}", .{err});
        };

        // Subscribe to Lock signal (session lock request)
        self.connection.subscribeMatch(
            "type='signal',interface='org.freedesktop.login1.Session',member='Lock'",
            onLock,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to Lock signal: {}", .{err});
        };

        // Subscribe to Unlock signal
        self.connection.subscribeMatch(
            "type='signal',interface='org.freedesktop.login1.Session',member='Unlock'",
            onUnlock,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to Unlock signal: {}", .{err});
        };
    }

    pub fn deinit(self: *Logind) void {
        self.releaseInhibitLock();
        self.connection.deinit();
        self.* = undefined;
    }

    pub fn getFd(self: *const Logind) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages. Returns true if more messages to process.
    pub fn process(self: *Logind) bool {
        return self.connection.process();
    }

    /// Take a delay inhibitor lock for sleep. Returns FD; closing releases the lock.
    pub fn takeInhibitLock(self: *Logind) void {
        if (self.inhibit_fd != null) return;

        // Use raw sd_bus_call_method for the Inhibit call which returns a unix fd
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };

        const ret = c.sd_bus_call_method(
            self.connection.bus,
            service.ptr,
            object_path.ptr,
            manager_interface.ptr,
            "Inhibit",
            &err,
            &reply,
            "ssss",
            @as([*:0]const u8, "sleep"),
            @as([*:0]const u8, "otter-idle"),
            @as([*:0]const u8, "Run pre-sleep commands"),
            @as([*:0]const u8, "delay"),
        );

        defer c.sd_bus_error_free(&err);

        if (ret < 0) {
            if (err.name != null) {
                log.warn("Failed to take sleep inhibitor: {s}", .{std.mem.span(err.name)});
            } else {
                log.warn("Failed to take sleep inhibitor: {d}", .{ret});
            }
            return;
        }

        if (reply) |r| {
            defer _ = c.sd_bus_message_unref(r);
            var fd: posix.fd_t = -1;
            if (c.sd_bus_message_read_basic(r, 'h', @ptrCast(&fd)) >= 0 and fd >= 0) {
                // Dup the fd because sd-bus owns the original
                const dup_rc = std.os.linux.dup(fd);
                switch (std.posix.errno(dup_rc)) {
                    .SUCCESS => {
                        self.inhibit_fd = @intCast(dup_rc);
                        log.info("Sleep inhibitor lock acquired (fd={d})", .{self.inhibit_fd.?});
                    },
                    else => {
                        log.warn("Failed to dup inhibit fd", .{});
                        return;
                    },
                }
            }
        }
    }

    /// Release the delay inhibitor lock, allowing sleep to proceed.
    pub fn releaseInhibitLock(self: *Logind) void {
        if (self.inhibit_fd) |fd| {
            _ = std.posix.system.close(fd);
            self.inhibit_fd = null;
            log.info("Sleep inhibitor lock released", .{});
        }
    }

    /// Check if any idle inhibitors are active via ListInhibitors.
    pub fn isIdleInhibited(self: *Logind) bool {
        var reply = self.connection.callMethod(
            service,
            object_path,
            manager_interface,
            "ListInhibitors",
        ) catch return false;
        defer reply.unref();

        // ListInhibitors returns a(ssssuu) — array of structs
        const has_data = reply.enterArray("(ssssuu)") catch return false;
        if (!has_data) return false;

        while (!reply.atEnd()) {
            const entered = reply.enterStruct("ssssuu") catch break;
            if (!entered) break;

            const what = reply.readString() catch break;
            // Skip who, why, mode
            _ = reply.readString() catch break;
            _ = reply.readString() catch break;
            _ = reply.readString() catch break;
            _ = reply.readUint32() catch break;
            _ = reply.readUint32() catch break;
            reply.exitContainer() catch break;

            // Check if this inhibitor is for "idle"
            if (containsWord(what, "idle")) return true;
        }

        reply.exitContainer() catch {};
        return false;
    }

    fn onPrepareForSleep(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *Logind = @ptrCast(@alignCast(ctx));
        var m = msg;
        const going_to_sleep = m.readBool() catch return;

        log.info("PrepareForSleep: going_to_sleep={}", .{going_to_sleep});

        if (self.on_prepare_sleep) |cb| {
            cb(going_to_sleep, self.context);
        }
    }

    fn onLock(msg: dbus.Message, ctx: ?*anyopaque) void {
        _ = msg;
        const self: *Logind = @ptrCast(@alignCast(ctx));
        log.info("Session Lock signal received", .{});
        if (self.on_lock) |cb| {
            cb(self.context);
        }
    }

    fn onUnlock(msg: dbus.Message, ctx: ?*anyopaque) void {
        _ = msg;
        const self: *Logind = @ptrCast(@alignCast(ctx));
        log.info("Session Unlock signal received", .{});
        if (self.on_unlock) |cb| {
            cb(self.context);
        }
    }
};

/// Check if a comma-separated list contains a specific word.
fn containsWord(list: []const u8, word: []const u8) bool {
    var remaining = list;
    while (remaining.len > 0) {
        // Find next colon separator
        const sep = std.mem.indexOfScalar(u8, remaining, ':');
        const token = if (sep) |s| remaining[0..s] else remaining;
        if (std.mem.eql(u8, token, word)) return true;
        remaining = if (sep) |s| remaining[s + 1 ..] else &.{};
    }
    return false;
}

test "Logind types compile" {
    _ = Logind;
    _ = Error;
}

test "containsWord" {
    try std.testing.expect(containsWord("idle", "idle"));
    try std.testing.expect(containsWord("sleep:idle", "idle"));
    try std.testing.expect(containsWord("idle:sleep", "idle"));
    try std.testing.expect(containsWord("shutdown:sleep:idle", "idle"));
    try std.testing.expect(!containsWord("sleep:shutdown", "idle"));
    try std.testing.expect(!containsWord("", "idle"));
}
