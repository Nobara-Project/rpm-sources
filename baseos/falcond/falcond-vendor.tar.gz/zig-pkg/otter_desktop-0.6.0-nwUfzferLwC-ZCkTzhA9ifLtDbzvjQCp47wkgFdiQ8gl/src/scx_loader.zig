//! SCX Loader D-Bus Client
//!
//! Provides access to scx_loader for getting/setting SCX schedulers
//! and subscribing to scheduler change notifications via D-Bus.
//!
//! D-Bus Interface: org.scx.Loader
//! Object Path: /org/scx/Loader
//! Bus: System

const std = @import("std");
const Allocator = std.mem.Allocator;
const posix = std.posix;
const BoundedArray = @import("otter_utils").BoundedArray;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.scx_loader);

/// D-Bus service constants
const service = "org.scx.Loader";
const object_path = "/org/scx/Loader";
const interface_name = "org.scx.Loader";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// Maximum number of supported schedulers
const max_supported = 32;

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscription = struct {
    callback: StateChangeFn,
    context: ?*anyopaque,
};

pub const Error = dbus.types.Error || error{
    InvalidScheduler,
    ParseError,
};

/// SCX scheduler variants
pub const ScxScheduler = enum {
    bpfland,
    central,
    flash,
    flatcg,
    lavd,
    layered,
    nest,
    pair,
    qmap,
    rlfifo,
    rustland,
    rusty,
    sdt,
    simple,
    userland,
    vder,
    p2dq,
    tickless,
    cosmos,
    cake,
    beerland,
    pandemonium,
    none,

    /// Return the scx_ prefixed name for this scheduler.
    /// Returns "" for .none.
    pub fn toScxName(self: ScxScheduler) [:0]const u8 {
        return switch (self) {
            .none => "",
            inline else => |tag| "scx_" ++ @tagName(tag),
        };
    }

    /// Parse a scheduler name string (e.g., "scx_bpfland") into a ScxScheduler.
    /// Accepts "none", "scx_none", and "unknown" as .none.
    /// Returns error.InvalidScheduler for unrecognized strings.
    pub fn fromString(s: []const u8) Error!ScxScheduler {
        if (std.mem.eql(u8, s, "none") or
            std.mem.eql(u8, s, "scx_none") or
            std.mem.eql(u8, s, "unknown"))
        {
            return .none;
        }

        // Strip "scx_" prefix if present
        const name = if (std.mem.startsWith(u8, s, "scx_"))
            s[4..]
        else
            return error.InvalidScheduler;

        // Match against all non-none variants
        inline for (@typeInfo(ScxScheduler).@"enum".fields) |field| {
            if (!std.mem.eql(u8, field.name, "none")) {
                if (std.mem.eql(u8, name, field.name)) {
                    return @enumFromInt(field.value);
                }
            }
        }

        return error.InvalidScheduler;
    }
};

/// SCX operating mode
pub const ScxMode = enum(u32) {
    default = 0,
    gaming = 1,
    power = 2,
    latency = 3,
    server = 4,

    /// Return the integer representation of this mode.
    pub fn toInt(self: ScxMode) u32 {
        return @intFromEnum(self);
    }

    /// Convert an integer to an ScxMode, or null if invalid.
    pub fn fromInt(val: u32) ?ScxMode {
        inline for (std.meta.fields(ScxMode)) |f| {
            if (val == f.value) return @enumFromInt(val);
        }
        return null;
    }
};

pub const ScxLoader = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    subscriptions: [max_subscribers]?Subscription = .{null} ** max_subscribers,
    subscription_count: usize = 0,

    // Cached state
    current_scheduler: ?ScxScheduler = null,
    scheduler_mode: ScxMode = .default,
    supported_schedulers: BoundedArray(ScxScheduler, max_supported) = .{},

    /// Initialize the SCX Loader client.
    /// Connects to the system D-Bus.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location
    /// to enable D-Bus signal handling.
    pub fn init(allocator: Allocator) Error!ScxLoader {
        var conn = try dbus.Connection.open(allocator, .system);
        errdefer conn.deinit();

        var self = ScxLoader{
            .connection = conn,
            .allocator = allocator,
        };

        // Load initial state (but don't subscribe yet - pointer would be invalid)
        self.refresh() catch |err| {
            log.warn("Failed to load initial state: {s}", .{@errorName(err)});
        };

        return self;
    }

    /// Start monitoring for D-Bus property changes.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *ScxLoader) void {
        self.subscribeToPropertyChanges() catch |err| {
            log.warn("Failed to subscribe to property changes: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *ScxLoader) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const ScxLoader) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if there are more messages to process.
    pub fn process(self: *ScxLoader) bool {
        return self.connection.process();
    }

    /// Get the currently active scheduler.
    pub fn getCurrentScheduler(self: *const ScxLoader) ?ScxScheduler {
        return self.current_scheduler;
    }

    /// Get the current scheduler mode.
    pub fn getSchedulerMode(self: *const ScxLoader) ScxMode {
        return self.scheduler_mode;
    }

    /// Get the list of supported schedulers.
    pub fn getSupportedSchedulers(self: *const ScxLoader) []const ScxScheduler {
        return self.supported_schedulers.constSlice();
    }

    /// Switch to a different scheduler with the given mode.
    pub fn switchScheduler(self: *ScxLoader, scheduler: ScxScheduler, mode: ScxMode) Error!void {
        const name = scheduler.toScxName();
        var msg = try self.connection.callMethodWithStringAndUint32(
            service,
            object_path,
            interface_name,
            "SwitchScheduler",
            name,
            mode.toInt(),
        );
        msg.unref();

        // Update cache immediately
        self.current_scheduler = scheduler;
        self.scheduler_mode = mode;
    }

    /// Stop the currently running scheduler.
    pub fn stopScheduler(self: *ScxLoader) Error!void {
        var msg = try self.connection.callMethod(
            service,
            object_path,
            interface_name,
            "StopScheduler",
        );
        msg.unref();

        // Update cache immediately
        self.current_scheduler = .none;
        self.scheduler_mode = .default;
    }

    /// Subscribe to scheduler changes.
    pub fn subscribe(self: *ScxLoader, callback: StateChangeFn, context: ?*anyopaque) bool {
        if (self.subscription_count >= max_subscribers) return false;

        for (&self.subscriptions) |*slot| {
            if (slot.* == null) {
                slot.* = .{ .callback = callback, .context = context };
                self.subscription_count += 1;
                return true;
            }
        }
        return false;
    }

    /// Unsubscribe from scheduler changes.
    pub fn unsubscribe(self: *ScxLoader, callback: StateChangeFn, context: ?*anyopaque) void {
        for (&self.subscriptions) |*slot| {
            if (slot.*) |sub| {
                if (sub.callback == callback and sub.context == context) {
                    slot.* = null;
                    self.subscription_count -|= 1;
                    return;
                }
            }
        }
    }

    /// Refresh the cached state from D-Bus.
    pub fn refresh(self: *ScxLoader) Error!void {
        // Get CurrentScheduler property
        {
            var msg = try self.connection.getProperty(
                service,
                object_path,
                interface_name,
                "CurrentScheduler",
            );
            defer msg.unref();

            if (try msg.enterVariant("s")) {
                const sched_str = try msg.readString();
                self.current_scheduler = ScxScheduler.fromString(sched_str) catch .none;
                try msg.exitContainer();
            }
        }

        // Get SchedulerMode property
        {
            var msg = try self.connection.getProperty(
                service,
                object_path,
                interface_name,
                "SchedulerMode",
            );
            defer msg.unref();

            if (try msg.enterVariant("u")) {
                const mode_val = try msg.readUint32();
                self.scheduler_mode = ScxMode.fromInt(mode_val) orelse .default;
                try msg.exitContainer();
            }
        }

        // Get SupportedSchedulers property
        {
            var msg = try self.connection.getProperty(
                service,
                object_path,
                interface_name,
                "SupportedSchedulers",
            );
            defer msg.unref();

            self.supported_schedulers = .{};

            if (try msg.enterVariant("as")) {
                if (try msg.enterArray("s")) {
                    while (!msg.atEnd()) {
                        const sched_str = msg.readString() catch break;
                        const sched = ScxScheduler.fromString(sched_str) catch continue;
                        self.supported_schedulers.append(sched) catch break;
                    }
                    msg.exitContainer() catch {};
                }
                msg.exitContainer() catch {};
            }
        }

        log.debug("Loaded scheduler: {s}, mode: {d}, supported: {d}", .{
            if (self.current_scheduler) |s| s.toScxName() else "none",
            self.scheduler_mode.toInt(),
            self.supported_schedulers.len,
        });
    }

    // Internal methods

    fn subscribeToPropertyChanges(self: *ScxLoader) Error!void {
        const match_rule =
            "type='signal'," ++
            "interface='org.freedesktop.DBus.Properties'," ++
            "member='PropertiesChanged'," ++
            "path='/org/scx/Loader'," ++
            "arg0='org.scx.Loader'";

        try self.connection.subscribeMatch(
            match_rule,
            handlePropertyChanged,
            self,
        );
    }

    fn handlePropertyChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *ScxLoader = @ptrCast(@alignCast(ctx orelse return));

        var mutable_msg = msg;

        // Signal signature: PropertiesChanged(s interface_name, a{sv} changed_properties, as invalidated)
        // Skip interface name (we already filtered by arg0)
        mutable_msg.skip("s") catch return;

        // Enter changed_properties dict
        if (mutable_msg.enterArray("{sv}") catch return) {
            while (!mutable_msg.atEnd()) {
                if (mutable_msg.enterDictEntry("sv") catch return) {
                    const prop_name = mutable_msg.readString() catch {
                        mutable_msg.exitContainer() catch {};
                        continue;
                    };

                    if (std.mem.eql(u8, prop_name, "CurrentScheduler")) {
                        if (mutable_msg.enterVariant("s") catch false) {
                            if (mutable_msg.readString()) |sched_str| {
                                self.current_scheduler = ScxScheduler.fromString(sched_str) catch .none;
                                self.notify();
                            } else |_| {}
                            mutable_msg.exitContainer() catch {};
                        }
                    } else if (std.mem.eql(u8, prop_name, "SchedulerMode")) {
                        if (mutable_msg.enterVariant("u") catch false) {
                            if (mutable_msg.readUint32()) |mode_val| {
                                self.scheduler_mode = ScxMode.fromInt(mode_val) orelse .default;
                                self.notify();
                            } else |_| {}
                            mutable_msg.exitContainer() catch {};
                        }
                    } else {
                        // Skip other properties
                        mutable_msg.skip("v") catch {};
                    }

                    mutable_msg.exitContainer() catch {};
                }
            }
            mutable_msg.exitContainer() catch {};
        }
    }

    fn notify(self: *const ScxLoader) void {
        for (self.subscriptions) |maybe_sub| {
            if (maybe_sub) |sub| {
                sub.callback(sub.context);
            }
        }
    }
};

test "ScxLoader types compile" {
    _ = ScxLoader;
    _ = ScxScheduler;
    _ = ScxMode;
}

test "ScxScheduler toScxName round-trip" {
    try std.testing.expectEqualStrings("scx_bpfland", ScxScheduler.bpfland.toScxName());
    try std.testing.expectEqualStrings("scx_layered", ScxScheduler.layered.toScxName());
    try std.testing.expectEqualStrings("", ScxScheduler.none.toScxName());
}

test "ScxScheduler fromString" {
    try std.testing.expectEqual(ScxScheduler.bpfland, try ScxScheduler.fromString("scx_bpfland"));
    try std.testing.expectEqual(ScxScheduler.none, try ScxScheduler.fromString("none"));
    try std.testing.expectEqual(ScxScheduler.none, try ScxScheduler.fromString("unknown"));
    try std.testing.expectError(error.InvalidScheduler, ScxScheduler.fromString("garbage"));
}

test "ScxMode conversion" {
    try std.testing.expectEqual(@as(u32, 0), ScxMode.default.toInt());
    try std.testing.expectEqual(@as(u32, 1), ScxMode.gaming.toInt());
    try std.testing.expectEqual(ScxMode.power, ScxMode.fromInt(2).?);
    try std.testing.expectEqual(@as(?ScxMode, null), ScxMode.fromInt(99));
}
