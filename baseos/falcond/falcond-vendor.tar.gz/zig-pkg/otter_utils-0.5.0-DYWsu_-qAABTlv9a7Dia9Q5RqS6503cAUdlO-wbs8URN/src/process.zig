//! Process spawning utilities for fire-and-forget commands.
//!
//! All Otter Shell apps that spawn external commands (bar buttons, network
//! widget, launcher) must go through these helpers to ensure child processes
//! are properly reaped and never left as zombies.

const std = @import("std");
const posix = std.posix;

const log = @import("log.zig").Scoped("process");

pub const EnvBehavior = enum {
    inherit_io,
    live_snapshot,
};

pub const SpawnOptions = struct {
    env_behavior: EnvBehavior = .inherit_io,
};

fn currentEnvironMap(allocator: std.mem.Allocator) !std.process.Environ.Map {
    const env_block: std.process.Environ.Block = switch (@import("builtin").os.tag) {
        .wasi, .emscripten => .empty,
        else => blk: {
            const c_environ = std.c.environ;
            var env_count: usize = 0;
            while (c_environ[env_count] != null) : (env_count += 1) {}
            break :blk .{ .slice = c_environ[0..env_count :null] };
        },
    };
    return std.process.Environ.createMap(.{ .block = env_block }, allocator);
}

fn resolveEnvironMap(options: SpawnOptions) !?std.process.Environ.Map {
    return switch (options.env_behavior) {
        .inherit_io => null,
        .live_snapshot => try currentEnvironMap(std.heap.c_allocator),
    };
}

/// Spawn a shell command via `/bin/sh -c` and reap the child asynchronously.
/// A detached thread calls waitpid to prevent zombies — same principle as
/// falcond's screensaver.zig but non-blocking so the event loop isn't stalled.
pub fn spawnCommand(io: std.Io, cmd: []const u8) void {
    spawnCommandWithOptions(io, cmd, .{});
}

pub fn spawnCommandWithOptions(io: std.Io, cmd: []const u8, options: SpawnOptions) void {
    const argv = [_][]const u8{ "/bin/sh", "-c", cmd };
    var environ_map = resolveEnvironMap(options) catch |err| {
        log.err("Failed to prepare environment for command '{s}': {s}", .{ cmd, @errorName(err) });
        return;
    };
    defer if (environ_map) |*map| map.deinit();

    const child = std.process.spawn(io, .{
        .argv = &argv,
        .environ_map = if (environ_map) |*map| map else null,
        .stdin = .ignore,
        .stdout = .ignore,
        .stderr = .ignore,
    }) catch |err| {
        log.err("Failed to spawn command '{s}': {s}", .{ cmd, @errorName(err) });
        return;
    };

    if (child.id) |pid| reapChild(pid);
}

/// Spawn an argv command and reap the child asynchronously.
pub fn spawnArgv(io: std.Io, argv: []const []const u8) void {
    spawnArgvWithOptions(io, argv, .{});
}

pub fn spawnArgvWithOptions(io: std.Io, argv: []const []const u8, options: SpawnOptions) void {
    var environ_map = resolveEnvironMap(options) catch |err| {
        log.err("Failed to prepare environment for process: {s}", .{@errorName(err)});
        return;
    };
    defer if (environ_map) |*map| map.deinit();

    const child = std.process.spawn(io, .{
        .argv = argv,
        .environ_map = if (environ_map) |*map| map else null,
        .stdin = .ignore,
        .stdout = .ignore,
        .stderr = .ignore,
    }) catch |err| {
        log.err("Failed to spawn process: {s}", .{@errorName(err)});
        return;
    };

    if (child.id) |pid| reapChild(pid);
}

/// Detached thread that calls waitpid(pid, 0) to reap the child.
fn reapChild(pid: posix.pid_t) void {
    const thread = std.Thread.spawn(.{}, struct {
        fn run(child_pid: posix.pid_t) void {
            var status: c_int = 0;
            // std.posix.waitpid was removed in 0.16; use the cross-platform libc call directly.
            _ = std.posix.system.waitpid(child_pid, &status, 0);
        }
    }.run, .{pid}) catch |err| {
        log.err("Failed to spawn reaper thread for pid {d}: {s}", .{ pid, @errorName(err) });
        return;
    };
    thread.detach();
}
