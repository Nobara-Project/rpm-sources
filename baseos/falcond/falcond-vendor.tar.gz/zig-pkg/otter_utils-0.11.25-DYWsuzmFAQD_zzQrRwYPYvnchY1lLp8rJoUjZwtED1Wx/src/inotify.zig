//! inotify wrapper for file/directory watching
//!
//! Provides a generic inotify interface that can be used for file watching
//! (config hot-reload) or directory watching (application list changes).

const std = @import("std");
const mem = std.mem;
const posix = std.posix;
const linux = std.os.linux;
const system = std.posix.system;
const Allocator = std.mem.Allocator;

const log = std.log.scoped(.inotify);

// Zig 0.16 removed the `std.posix.inotify_*`/`posix.close`/`posix.write` wrappers.
// The sanctioned replacement for raw syscalls in non-`Io` code is to call the
// platform-specific syscall directly and translate with `std.posix.errno`.
// We go through `std.posix.system.*` so libc vs. raw-syscall builds both work.
inline fn inotifyInit1(flags: u32) !posix.fd_t {
    const rc = system.inotify_init1(flags);
    return switch (posix.errno(rc)) {
        .SUCCESS => @intCast(rc),
        .MFILE, .NFILE => error.ProcessFdQuotaExceeded,
        .NOMEM => error.SystemResources,
        else => error.Unexpected,
    };
}

inline fn inotifyAddWatch(fd: posix.fd_t, path_z: [*:0]const u8, mask: u32) !i32 {
    const rc = system.inotify_add_watch(fd, path_z, mask);
    return switch (posix.errno(rc)) {
        .SUCCESS => @intCast(rc),
        .ACCES => error.AccessDenied,
        .NOENT => error.FileNotFound,
        .NOMEM => error.SystemResources,
        .NOSPC => error.UserResourceLimitReached,
        .NAMETOOLONG => error.NameTooLong,
        else => error.Unexpected,
    };
}

inline fn inotifyRmWatch(fd: posix.fd_t, wd: i32) void {
    _ = system.inotify_rm_watch(fd, wd);
}

inline fn closeFd(fd: posix.fd_t) void {
    _ = system.close(fd);
}

pub const Watcher = struct {
    fd: posix.fd_t,
    watches: WatchMap,
    allocator: Allocator,
    event_buffer: [4096]u8 = undefined,
    event_len: usize = 0,
    event_offset: usize = 0,
    dropped_events: usize = 0,

    const WatchMap = std.AutoHashMap(i32, []const u8);

    pub const Event = struct {
        wd: i32,
        mask: u32,
        cookie: u32,
        name: ?[]const u8,

        pub fn isModified(self: Event) bool {
            return self.mask & linux.IN.CLOSE_WRITE != 0;
        }

        pub fn isDeleted(self: Event) bool {
            return self.mask & (linux.IN.DELETE_SELF | linux.IN.DELETE) != 0;
        }

        pub fn isCreated(self: Event) bool {
            return self.mask & linux.IN.CREATE != 0;
        }

        pub fn isMoved(self: Event) bool {
            return self.mask & (linux.IN.MOVE_SELF | linux.IN.MOVED_FROM | linux.IN.MOVED_TO) != 0;
        }

        pub fn isIgnored(self: Event) bool {
            return self.mask & linux.IN.IGNORED != 0;
        }
    };

    pub const Mask = struct {
        pub const file_changes = linux.IN.CLOSE_WRITE |
            linux.IN.DELETE_SELF |
            linux.IN.MOVE_SELF |
            linux.IN.MODIFY;

        pub const dir_changes = linux.IN.CREATE |
            linux.IN.DELETE |
            linux.IN.CLOSE_WRITE |
            linux.IN.MOVED_FROM |
            linux.IN.MOVED_TO;
    };

    pub const InitError = error{
        SystemResources,
        ProcessFdQuotaExceeded,
        Unexpected,
    };

    pub fn init(allocator: Allocator) InitError!Watcher {
        const flags: u32 = linux.IN.CLOEXEC | linux.IN.NONBLOCK;
        const fd = inotifyInit1(flags) catch |err| return switch (err) {
            error.ProcessFdQuotaExceeded => error.ProcessFdQuotaExceeded,
            error.SystemResources => error.SystemResources,
            else => error.Unexpected,
        };

        return .{
            .fd = fd,
            .watches = WatchMap.init(allocator),
            .allocator = allocator,
        };
    }

    pub fn deinit(self: *Watcher) void {
        var iter = self.watches.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.value_ptr.*);
            inotifyRmWatch(self.fd, entry.key_ptr.*);
        }
        self.watches.deinit();
        closeFd(self.fd);
        self.* = undefined;
    }

    pub const WatchError = error{
        AccessDenied,
        FileNotFound,
        SystemResources,
        UserResourceLimitReached,
        NameTooLong,
        OutOfMemory,
        Unexpected,
    };

    pub fn addWatch(self: *Watcher, path: []const u8, mask: u32) WatchError!i32 {
        const path_z = std.fs.path.joinZ(self.allocator, &.{path}) catch return error.OutOfMemory;
        defer self.allocator.free(path_z);

        const wd = inotifyAddWatch(self.fd, path_z, mask) catch |err| return switch (err) {
            error.AccessDenied => error.AccessDenied,
            error.FileNotFound => error.FileNotFound,
            error.SystemResources => error.SystemResources,
            error.UserResourceLimitReached => error.UserResourceLimitReached,
            error.NameTooLong => error.NameTooLong,
            else => error.Unexpected,
        };

        const path_copy = self.allocator.dupe(u8, path) catch return error.OutOfMemory;

        const replaced = self.watches.fetchPut(wd, path_copy) catch {
            self.allocator.free(path_copy);
            inotifyRmWatch(self.fd, wd);
            return error.OutOfMemory;
        };
        if (replaced) |entry| {
            self.allocator.free(entry.value);
        }

        return wd;
    }

    pub fn removeWatch(self: *Watcher, wd: i32) void {
        if (self.watches.fetchRemove(wd)) |entry| {
            self.allocator.free(entry.value);
            inotifyRmWatch(self.fd, wd);
        }
    }

    pub fn removeWatchByPath(self: *Watcher, path: []const u8) void {
        var to_remove: ?i32 = null;
        var iter = self.watches.iterator();
        while (iter.next()) |entry| {
            if (mem.eql(u8, entry.value_ptr.*, path)) {
                to_remove = entry.key_ptr.*;
                break;
            }
        }
        if (to_remove) |wd| {
            self.removeWatch(wd);
        }
    }

    pub fn getFd(self: *const Watcher) posix.fd_t {
        return self.fd;
    }

    pub fn getPath(self: *const Watcher, wd: i32) ?[]const u8 {
        return self.watches.get(wd);
    }

    pub fn nextEvent(self: *Watcher) ?Event {
        if (self.event_offset >= self.event_len) {
            const bytes_read = posix.read(self.fd, &self.event_buffer) catch |err| {
                switch (err) {
                    error.WouldBlock => return null,
                    else => {
                        log.warn("read failed: {}", .{err});
                        return null;
                    },
                }
            };
            if (bytes_read == 0) return null;
            self.event_len = bytes_read;
            self.event_offset = 0;
        }

        if (self.event_offset + @sizeOf(std.os.linux.inotify_event) > self.event_len) {
            self.dropped_events += 1;
            self.event_offset = self.event_len;
            return null;
        }

        const event_ptr: *align(1) const std.os.linux.inotify_event = @ptrCast(&self.event_buffer[self.event_offset]);

        const name: ?[]const u8 = if (event_ptr.len > 0) blk: {
            const name_start = self.event_offset + @sizeOf(std.os.linux.inotify_event);
            const name_end = name_start + event_ptr.len;
            if (name_end > self.event_len) {
                self.dropped_events += 1;
                self.event_offset = self.event_len;
                return null;
            }

            const name_bytes = self.event_buffer[name_start..name_end];
            const null_pos = mem.indexOfScalar(u8, name_bytes, 0) orelse name_bytes.len;
            break :blk name_bytes[0..null_pos];
        } else null;

        self.event_offset += @sizeOf(std.os.linux.inotify_event) + event_ptr.len;

        return Event{
            .wd = event_ptr.wd,
            .mask = event_ptr.mask,
            .cookie = event_ptr.cookie,
            .name = name,
        };
    }

    pub fn droppedEventCount(self: *const Watcher) usize {
        return self.dropped_events;
    }

    pub fn hasPendingEvents(self: *const Watcher) bool {
        var fds = [_]posix.pollfd{
            .{ .fd = self.fd, .events = posix.POLL.IN, .revents = 0 },
        };
        const result = posix.poll(&fds, 0) catch return false;
        return result > 0 and (fds[0].revents & posix.POLL.IN != 0);
    }
};

test "watcher init and deinit" {
    var watcher = try Watcher.init(std.testing.allocator);
    defer watcher.deinit();
    try std.testing.expect(watcher.fd >= 0);
}

test "duplicate watch replaces path without leaking" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(std.testing.io, .{ .sub_path = "watched", .data = "" });

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path_len = try tmp.dir.realPathFile(std.testing.io, "watched", &path_buf);
    const path = path_buf[0..path_len];

    var watcher = try Watcher.init(std.testing.allocator);
    defer watcher.deinit();

    _ = try watcher.addWatch(path, Watcher.Mask.file_changes);
    _ = try watcher.addWatch(path, Watcher.Mask.file_changes);
}

test "event flags" {
    const event = Watcher.Event{
        .wd = 1,
        .mask = linux.IN.CLOSE_WRITE,
        .cookie = 0,
        .name = null,
    };
    try std.testing.expect(event.isModified());
    try std.testing.expect(!event.isDeleted());
    try std.testing.expect(!event.isCreated());
}

test "mask constants" {
    try std.testing.expect(Watcher.Mask.file_changes != 0);
    try std.testing.expect(Watcher.Mask.dir_changes != 0);
}

test "nextEvent counts truncated header as dropped" {
    var watcher = Watcher{
        .fd = -1,
        .watches = Watcher.WatchMap.init(std.testing.allocator),
        .allocator = std.testing.allocator,
        .event_len = @sizeOf(std.os.linux.inotify_event) - 1,
    };
    defer watcher.watches.deinit();

    try std.testing.expectEqual(@as(?Watcher.Event, null), watcher.nextEvent());
    try std.testing.expectEqual(@as(usize, 1), watcher.droppedEventCount());
}

test "nextEvent counts truncated name as dropped" {
    var watcher = Watcher{
        .fd = -1,
        .watches = Watcher.WatchMap.init(std.testing.allocator),
        .allocator = std.testing.allocator,
    };
    defer watcher.watches.deinit();

    const event = std.os.linux.inotify_event{
        .wd = 1,
        .mask = linux.IN.CREATE,
        .cookie = 0,
        .len = 8,
    };
    const event_bytes = std.mem.asBytes(&event);
    @memcpy(watcher.event_buffer[0..event_bytes.len], event_bytes);
    watcher.event_len = event_bytes.len + 4;

    try std.testing.expectEqual(@as(?Watcher.Event, null), watcher.nextEvent());
    try std.testing.expectEqual(@as(usize, 1), watcher.droppedEventCount());
}
