//! Session-private IPC authentication tokens for otter-shell datagram sockets.

const std = @import("std");
const config_paths = @import("config_paths.zig");

pub const token_file_name = "ipc-token";
pub const token_bytes = 32;
pub const separator: u8 = '\t';

pub fn tokenPath(buffer: []u8) ?[]const u8 {
    return config_paths.otterRuntimePath(buffer, token_file_name);
}

pub fn readToken(io: std.Io, buffer: []u8) ?[]const u8 {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path = tokenPath(&path_buf) orelse return null;
    const file = std.Io.Dir.openFileAbsolute(io, path, .{}) catch return null;
    defer file.close(io);
    const stat = file.stat(io) catch return null;
    if (stat.size == 0 or stat.size > buffer.len) return null;
    var rbuf: [64]u8 = undefined;
    var reader = file.reader(io, &rbuf);
    const len = reader.interface.readSliceShort(buffer) catch return null;
    return std.mem.trim(u8, buffer[0..len], " \t\r\n");
}

pub fn ensureToken(io: std.Io, buffer: []u8) ?[]const u8 {
    if (readToken(io, buffer)) |existing| {
        if (existing.len == token_bytes * 2) return existing;
    }
    if (!config_paths.ensureOtterRuntimeDir(io)) return null;
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path = tokenPath(&path_buf) orelse return null;

    var random_bytes: [token_bytes]u8 = undefined;
    io.random(&random_bytes);
    const hex = std.fmt.bytesToHex(random_bytes, .lower);
    if (hex.len > buffer.len) return null;
    @memcpy(buffer[0..hex.len], &hex);
    const hex_len = buffer[0..hex.len];

    var file = std.Io.Dir.createFileAbsolute(io, path, .{}) catch return null;
    defer file.close(io);
    _ = file.writeStreamingAll(io, hex_len) catch return null;
    return hex_len;
}

pub fn stripTokenPrefix(message: []const u8, token: []const u8) ?[]const u8 {
    if (message.len <= token.len + 1) return null;
    if (!std.mem.startsWith(u8, message, token)) return null;
    if (message[token.len] != separator) return null;
    return message[token.len + 1 ..];
}

pub fn formatMessage(buffer: []u8, token: []const u8, payload: []const u8) ?[]const u8 {
    if (token.len + 1 + payload.len > buffer.len) return null;
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(token) catch return null;
    writer.writeByte(separator) catch return null;
    writer.writeAll(payload) catch return null;
    return buffer[0..writer.end];
}

pub fn validateInstancePayload(wire: []const u8, io: std.Io, expected: []const u8) bool {
    var token_buf: [token_bytes * 2]u8 = undefined;
    const token = readToken(io, &token_buf) orelse return false;
    const payload = stripTokenPrefix(wire, token) orelse return false;
    return std.mem.eql(u8, payload, expected);
}

pub fn authenticatedInstanceMessage(
    buffer: []u8,
    io: std.Io,
    payload: []const u8,
) ?[]const u8 {
    var token_buf: [token_bytes * 2]u8 = undefined;
    const token = readToken(io, &token_buf) orelse return null;
    return formatMessage(buffer, token, payload);
}

test "format and strip token prefix" {
    var buf: [128]u8 = undefined;
    const msg = formatMessage(&buf, "abcd1234", "volume-up\n").?;
    try std.testing.expectEqualStrings("abcd1234\tvolume-up\n", msg);
    try std.testing.expectEqualStrings("volume-up\n", stripTokenPrefix(msg, "abcd1234").?);
    try std.testing.expect(stripTokenPrefix("bad", "abcd1234") == null);
}

test "validateInstancePayload checks payload after token strip" {
    var buf: [128]u8 = undefined;
    const msg = formatMessage(&buf, "deadbeef", "close") orelse unreachable;
    try std.testing.expect(stripTokenPrefix(msg, "deadbeef") != null);
    try std.testing.expectEqualStrings("close", stripTokenPrefix(msg, "deadbeef").?);
    try std.testing.expect(stripTokenPrefix(msg, "cafebabe") == null);
}
