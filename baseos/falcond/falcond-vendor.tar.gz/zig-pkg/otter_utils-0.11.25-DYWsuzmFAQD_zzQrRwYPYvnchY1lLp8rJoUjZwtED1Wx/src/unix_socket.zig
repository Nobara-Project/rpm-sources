const std = @import("std");
const posix = std.posix;

pub const UnixAddr = struct {
    addr: posix.sockaddr.un,
    len: u32,
};

pub fn addr(path: []const u8) !UnixAddr {
    var result: posix.sockaddr.un = .{ .family = posix.AF.UNIX, .path = undefined };
    if (path.len >= result.path.len) return error.PathTooLong;
    @memcpy(result.path[0..path.len], path);
    result.path[path.len] = 0;
    return .{
        .addr = result,
        .len = @intCast(@sizeOf(u16) + path.len + 1),
    };
}

test "addr writes nul terminated path and length" {
    const path = "/tmp/otter-test.sock";
    const unix_addr = try addr(path);

    try std.testing.expectEqual(posix.AF.UNIX, unix_addr.addr.family);
    try std.testing.expectEqual(@as(u32, @intCast(@sizeOf(u16) + path.len + 1)), unix_addr.len);
    try std.testing.expectEqualStrings(path, std.mem.sliceTo(unix_addr.addr.path[0..], 0));
}

test "addr rejects oversized path" {
    var path = [_]u8{'x'} ** 108;
    try std.testing.expectError(error.PathTooLong, addr(&path));
}
