//! Config-command parsing and spawning.

const std = @import("std");
const process = @import("process.zig");

const log = @import("log.zig").Scoped("command");

pub const max_command_bytes = 4096;
pub const max_argv = 32;

pub const ValidateError = error{
    EmptyCommand,
    CommandTooLong,
    InvalidCommand,
};

pub fn validateConfigCommand(cmd: []const u8) ValidateError!void {
    if (cmd.len == 0) return error.EmptyCommand;
    if (cmd.len > max_command_bytes) return error.CommandTooLong;
    for (cmd) |c| {
        if (c == '\n' or c == '\r') return error.InvalidCommand;
    }
}

fn needsShell(cmd: []const u8) bool {
    for (cmd) |c| {
        if (std.mem.indexOfScalar(u8, "&|;`\\$()<>{}[]!#*?~", c) != null) return true;
    }
    return false;
}

pub fn parseSimpleCommand(
    cmd: []const u8,
    argv_out: *[max_argv][]const u8,
    storage: *[max_command_bytes]u8,
) !usize {
    var argc: usize = 0;
    var storage_len: usize = 0;
    var i: usize = 0;
    while (i < cmd.len) {
        while (i < cmd.len and cmd[i] == ' ') : (i += 1) {}
        if (i >= cmd.len) break;
        if (argc >= max_argv) return error.CommandTooLong;

        var token_start = i;
        var token_len: usize = 0;
        if (cmd[i] == '\'' or cmd[i] == '"') {
            const quote = cmd[i];
            i += 1;
            token_start = i;
            while (i < cmd.len and cmd[i] != quote) : (i += 1) {}
            token_len = i - token_start;
            if (i < cmd.len) i += 1;
        } else {
            while (i < cmd.len and cmd[i] != ' ') : (i += 1) {}
            token_len = i - token_start;
        }
        if (token_len == 0) continue;
        if (storage_len + token_len > storage.len) return error.CommandTooLong;
        @memcpy(storage[storage_len .. storage_len + token_len], cmd[token_start .. token_start + token_len]);
        argv_out[argc] = storage[storage_len .. storage_len + token_len];
        storage_len += token_len;
        argc += 1;
    }
    return argc;
}

/// Spawn a user-configured command. Simple commands use argv directly; legacy
/// shell syntax still goes through `/bin/sh -c` for config compatibility.
pub fn spawnConfigCommand(io: std.Io, cmd: []const u8) void {
    validateConfigCommand(cmd) catch |err| {
        log.warn("Rejected config command: {s}", .{@errorName(err)});
        return;
    };

    if (needsShell(cmd)) {
        process.spawnCommand(io, cmd);
        return;
    }

    var argv_buf: [max_argv][]const u8 = undefined;
    var storage: [max_command_bytes]u8 = undefined;
    const argc = parseSimpleCommand(cmd, &argv_buf, &storage) catch |err| {
        log.warn("Failed to parse config command: {s}", .{@errorName(err)});
        return;
    };
    if (argc == 0) return;
    process.spawnArgv(io, argv_buf[0..argc]);
}

test "validate rejects invalid command lines" {
    try std.testing.expectError(error.InvalidCommand, validateConfigCommand("foo\nbar"));
    try validateConfigCommand("otter-launcher");
    try validateConfigCommand("sh -c 'notify-send hi'");
}

test "shell detection preserves legacy config commands" {
    try std.testing.expect(needsShell("foo; bar"));
    try std.testing.expect(needsShell("notify-send $USER"));
    try std.testing.expect(!needsShell("otter-launcher --query 'clip history'"));
}

test "parse simple and quoted argv" {
    var argv: [max_argv][]const u8 = undefined;
    var storage: [max_command_bytes]u8 = undefined;
    const argc = try parseSimpleCommand("otter-launcher --query clip", &argv, &storage);
    try std.testing.expectEqual(@as(usize, 3), argc);
    try std.testing.expectEqualStrings("otter-launcher", argv[0]);
    try std.testing.expectEqualStrings("--query", argv[1]);
    try std.testing.expectEqualStrings("clip", argv[2]);

    const argc2 = try parseSimpleCommand("'otter note' popup", &argv, &storage);
    try std.testing.expectEqual(@as(usize, 2), argc2);
    try std.testing.expectEqualStrings("otter note", argv[0]);
}
