//! Heuristic matching between desktop/pinned ids and Wayland app_id strings.

const std = @import("std");
const ascii = std.ascii;
const mem = std.mem;

fn stripDesktopSuffix(id: []const u8) []const u8 {
    const suf = ".desktop";
    if (id.len > suf.len and mem.endsWith(u8, id, suf)) {
        return id[0 .. id.len - suf.len];
    }
    return id;
}

/// True if `a` and `b` are probably the same application (pinned "firefox" vs "org.mozilla.firefox").
pub fn likelyEqual(a: []const u8, b: []const u8) bool {
    if (a.len == 0 or b.len == 0) return false;
    if (mem.eql(u8, a, b)) return true;

    const da = stripDesktopSuffix(a);
    const db = stripDesktopSuffix(b);
    if (mem.eql(u8, da, db)) return true;

    if (da.len > 256 or db.len > 256) return false;
    var la: [256]u8 = undefined;
    var lb: [256]u8 = undefined;
    for (da, 0..) |c, i| la[i] = ascii.toLower(c);
    for (db, 0..) |c, i| lb[i] = ascii.toLower(c);
    const al = la[0..da.len];
    const bl = lb[0..db.len];
    if (mem.eql(u8, al, bl)) return true;

    if (mem.lastIndexOfScalar(u8, bl, '.')) |bi| {
        const last_b = bl[bi + 1 ..];
        if (last_b.len > 0 and mem.eql(u8, al, last_b)) return true;
    }
    if (mem.lastIndexOfScalar(u8, al, '.')) |ai| {
        const last_a = al[ai + 1 ..];
        if (last_a.len > 0 and mem.eql(u8, last_a, bl)) return true;
    }
    return false;
}

test "exact and desktop suffix" {
    try std.testing.expect(likelyEqual("firefox", "firefox"));
    try std.testing.expect(likelyEqual("firefox.desktop", "firefox"));
    try std.testing.expect(likelyEqual("firefox", "firefox.desktop"));
}

test "reverse dns vs short id" {
    try std.testing.expect(likelyEqual("firefox", "org.mozilla.firefox"));
    try std.testing.expect(likelyEqual("org.mozilla.firefox", "firefox"));
}

test "case only" {
    try std.testing.expect(likelyEqual("Firefox", "firefox"));
}

test "unrelated" {
    try std.testing.expect(!likelyEqual("firefox", "chromium"));
    try std.testing.expect(!likelyEqual("", "x"));
}
