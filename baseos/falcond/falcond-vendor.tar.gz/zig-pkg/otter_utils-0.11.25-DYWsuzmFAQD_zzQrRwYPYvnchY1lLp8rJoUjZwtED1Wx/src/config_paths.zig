//! Shared Otter config path helpers.
//!
//! Facade kept for downstream compatibility. Focused implementations live in
//! `xdg_paths.zig`, `legacy_paths.zig`, and `runtime_paths.zig`.

const std = @import("std");
const xdg_paths = @import("xdg_paths.zig");
const legacy_paths = @import("legacy_paths.zig");
const runtime_paths = @import("runtime_paths.zig");

pub const user_config_dir = xdg_paths.user_config_dir;
pub const user_data_suffix = xdg_paths.user_data_suffix;
pub const user_cache_suffix = xdg_paths.user_cache_suffix;
pub const otter_runtime_subdir = xdg_paths.otter_runtime_subdir;

pub const legacy_weather_cache_path = legacy_paths.legacy_weather_cache_path;
pub const legacy_clip_history_path = legacy_paths.legacy_clip_history_path;
pub const legacy_clip_store_path = legacy_paths.legacy_clip_store_path;

pub const max_runtime_socket_path_len = runtime_paths.max_runtime_socket_path_len;

pub const env = xdg_paths.env;
pub const home = xdg_paths.home;
pub const loginUserName = runtime_paths.loginUserName;
pub const xdgDataHome = xdg_paths.xdgDataHome;
pub const xdgRuntimeDir = xdg_paths.xdgRuntimeDir;
pub const xdgCacheHome = xdg_paths.xdgCacheHome;

pub const otterConfigPath = xdg_paths.otterConfigPath;
pub const otterConfigDir = xdg_paths.otterConfigDir;
pub const otterConfigPathFromHome = xdg_paths.otterConfigPathFromHome;
pub const otterConfigDirFromHome = xdg_paths.otterConfigDirFromHome;
pub const otterDataPath = xdg_paths.otterDataPath;
pub const otterDataDir = xdg_paths.otterDataDir;
pub const otterDataPathFromBase = xdg_paths.otterDataPathFromBase;
pub const otterDataDirFromBase = xdg_paths.otterDataDirFromBase;
pub const otterDataPathFromHome = xdg_paths.otterDataPathFromHome;
pub const otterDataDirFromHome = xdg_paths.otterDataDirFromHome;
pub const otterCacheDir = xdg_paths.otterCacheDir;
pub const otterCacheDirFromBase = xdg_paths.otterCacheDirFromBase;
pub const otterCacheDirFromHome = xdg_paths.otterCacheDirFromHome;
pub const otterCachePath = xdg_paths.otterCachePath;
pub const otterCachePathFromBase = xdg_paths.otterCachePathFromBase;
pub const otterCachePathFromHome = xdg_paths.otterCachePathFromHome;
pub const ensureOtterCacheDir = xdg_paths.ensureOtterCacheDir;

pub const otterRuntimeDir = runtime_paths.otterRuntimeDir;
pub const otterRuntimeDirFromBase = runtime_paths.otterRuntimeDirFromBase;
pub const otterRuntimePath = runtime_paths.otterRuntimePath;
pub const otterRuntimePathFromBase = runtime_paths.otterRuntimePathFromBase;
pub const ensureOtterRuntimeDir = runtime_paths.ensureOtterRuntimeDir;
pub const restrictSocketFd = runtime_paths.restrictSocketFd;
pub const runtimeSocketPath = runtime_paths.runtimeSocketPath;

pub const isLegacyTmpOtterPath = legacy_paths.isLegacyTmpOtterPath;
pub const resolveWeatherCachePath = legacy_paths.resolveWeatherCachePath;
pub const resolveClipHistoryPath = legacy_paths.resolveClipHistoryPath;
pub const migrateLegacyFileIfMissing = legacy_paths.migrateLegacyFileIfMissing;
pub const resolveClipStorePath = legacy_paths.resolveClipStorePath;

test "facade preserves config path exports" {
    var buf: [128]u8 = undefined;
    const path = otterConfigPathFromHome(&buf, "/home/user", "otter-bar.conf").?;
    try std.testing.expectEqualStrings("/home/user/.config/otter-shell/otter-bar.conf", path);
}

test "facade preserves runtime and legacy exports" {
    var buf: [128]u8 = undefined;
    const path = otterRuntimePathFromBase(&buf, "/run/user/1000", "otter-clip-store").?;
    try std.testing.expectEqualStrings("/run/user/1000/otter-shell/otter-clip-store", path);
    try std.testing.expect(isLegacyTmpOtterPath(legacy_weather_cache_path));
}

test {
    _ = xdg_paths;
    _ = legacy_paths;
    _ = runtime_paths;
}
