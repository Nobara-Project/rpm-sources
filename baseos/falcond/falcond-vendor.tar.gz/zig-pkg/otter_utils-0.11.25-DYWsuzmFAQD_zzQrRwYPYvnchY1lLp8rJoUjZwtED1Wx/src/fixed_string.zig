const std = @import("std");

pub fn FixedString(comptime max_len: usize) type {
    return struct {
        data: [max_len + 1]u8 = undefined,
        len: usize = 0,

        const Self = @This();

        pub fn set(self: *Self, value: []const u8) void {
            const copy_len = @min(value.len, max_len);
            @memcpy(self.data[0..copy_len], value[0..copy_len]);
            self.len = copy_len;
        }

        pub fn setFromC(self: *Self, value: [*c]const u8) void {
            if (value == null) {
                self.len = 0;
                return;
            }
            self.set(std.mem.span(value));
        }

        pub fn get(self: *const Self) []const u8 {
            return self.data[0..self.len];
        }

        pub fn slice(self: *const Self) []const u8 {
            return self.get();
        }

        pub fn isEmpty(self: *const Self) bool {
            return self.len == 0;
        }

        pub fn clear(self: *Self) void {
            self.len = 0;
        }

        pub fn eql(self: *const Self, other: []const u8) bool {
            return std.mem.eql(u8, self.get(), other);
        }

        pub fn isNone(self: *const Self) bool {
            return self.isEmpty() or self.eql("none") or self.eql("None");
        }

        pub fn getZ(self: *Self) [:0]const u8 {
            self.data[self.len] = 0;
            return self.data[0..self.len :0];
        }
    };
}

test "FixedString stores bounded text" {
    var s = FixedString(4){};
    s.set("abcdef");
    try std.testing.expectEqualStrings("abcd", s.get());
}

test "FixedString clear and predicates" {
    var s = FixedString(8){};
    try std.testing.expect(s.isEmpty());
    s.set("None");
    try std.testing.expect(s.isNone());
    try std.testing.expect(s.eql("None"));
    s.clear();
    try std.testing.expect(s.isEmpty());
}

test "FixedString getZ returns sentinel slice" {
    var s = FixedString(4){};
    s.set("abc");
    try std.testing.expectEqualStrings("abc", s.getZ());
    s.set("abcd");
    try std.testing.expectEqualStrings("abcd", s.getZ());
}
