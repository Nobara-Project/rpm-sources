//! A BoundedArray replacement for Zig 0.15+ using a fixed buffer.
//! This provides the same API as the removed std.BoundedArray.

const std = @import("std");
const assert = std.debug.assert;

pub fn BoundedArray(comptime T: type, comptime buffer_capacity: usize) type {
    return struct {
        const Self = @This();
        buffer: [buffer_capacity]T = undefined,
        len: usize = 0,

        pub fn init(initial_len: usize) error{Overflow}!Self {
            if (initial_len > buffer_capacity) return error.Overflow;
            return .{ .len = initial_len };
        }

        pub fn fromSlice(items: []const T) error{Overflow}!Self {
            if (items.len > buffer_capacity) return error.Overflow;
            var self = Self{};
            @memcpy(self.buffer[0..items.len], items);
            self.len = items.len;
            return self;
        }

        pub fn slice(self: anytype) if (@TypeOf(self) == *const Self) []const T else []T {
            return self.buffer[0..self.len];
        }

        pub fn constSlice(self: *const Self) []const T {
            return self.buffer[0..self.len];
        }

        pub fn append(self: *Self, item: T) error{Overflow}!void {
            if (self.len >= buffer_capacity) return error.Overflow;
            self.buffer[self.len] = item;
            self.len += 1;
        }

        pub fn appendAssumeCapacity(self: *Self, item: T) void {
            assert(self.len < buffer_capacity);
            self.buffer[self.len] = item;
            self.len += 1;
        }

        pub fn appendSlice(self: *Self, items: []const T) error{Overflow}!void {
            if (items.len > buffer_capacity - self.len) return error.Overflow;
            @memcpy(self.buffer[self.len..][0..items.len], items);
            self.len += items.len;
        }

        pub fn appendSliceAssumeCapacity(self: *Self, items: []const T) void {
            assert(items.len <= buffer_capacity - self.len);
            @memcpy(self.buffer[self.len..][0..items.len], items);
            self.len += items.len;
        }

        pub fn appendNTimes(self: *Self, item: T, n: usize) error{Overflow}!void {
            if (n > buffer_capacity - self.len) return error.Overflow;
            @memset(self.buffer[self.len..][0..n], item);
            self.len += n;
        }

        pub fn appendNTimesAssumeCapacity(self: *Self, item: T, n: usize) void {
            assert(n <= buffer_capacity - self.len);
            @memset(self.buffer[self.len..][0..n], item);
            self.len += n;
        }

        pub fn insert(self: *Self, index: usize, item: T) error{ Overflow, OutOfBounds }!void {
            if (index > self.len) return error.OutOfBounds;
            if (self.len >= buffer_capacity) return error.Overflow;
            if (index < self.len) {
                std.mem.copyBackwards(
                    T,
                    self.buffer[index + 1 .. self.len + 1],
                    self.buffer[index..self.len],
                );
            }
            self.buffer[index] = item;
            self.len += 1;
        }

        pub fn insertAssumeCapacity(self: *Self, index: usize, item: T) void {
            assert(index <= self.len);
            assert(self.len < buffer_capacity);
            if (index < self.len) {
                std.mem.copyBackwards(
                    T,
                    self.buffer[index + 1 .. self.len + 1],
                    self.buffer[index..self.len],
                );
            }
            self.buffer[index] = item;
            self.len += 1;
        }

        pub fn pop(self: *Self) ?T {
            if (self.len == 0) return null;
            self.len -= 1;
            return self.buffer[self.len];
        }

        pub fn popOrNull(self: *Self) ?T {
            return self.pop();
        }

        pub fn orderedRemove(self: *Self, index: usize) T {
            assert(index < self.len);
            const item = self.buffer[index];
            if (index < self.len - 1) {
                std.mem.copyForwards(
                    T,
                    self.buffer[index .. self.len - 1],
                    self.buffer[index + 1 .. self.len],
                );
            }
            self.len -= 1;
            return item;
        }

        pub fn swapRemove(self: *Self, index: usize) T {
            assert(index < self.len);
            const item = self.buffer[index];
            self.buffer[index] = self.buffer[self.len - 1];
            self.len -= 1;
            return item;
        }

        /// Linear scan for `target`, then swap-remove it. No-op if not found.
        pub fn swapRemoveByValue(self: *Self, target: T) void {
            for (self.slice(), 0..) |item, i| {
                if (item == target) {
                    _ = self.swapRemove(i);
                    return;
                }
            }
        }

        pub fn get(self: *const Self, index: usize) T {
            assert(index < self.len);
            return self.buffer[index];
        }

        pub fn set(self: *Self, index: usize, item: T) void {
            assert(index < self.len);
            self.buffer[index] = item;
        }

        pub fn resize(self: *Self, new_len: usize) error{Overflow}!void {
            if (new_len > buffer_capacity) return error.Overflow;
            self.len = new_len;
        }

        pub fn clear(self: *Self) void {
            self.len = 0;
        }

        pub fn capacity(self: *const Self) usize {
            _ = self;
            return buffer_capacity;
        }

        pub fn unusedCapacitySlice(self: *Self) []T {
            return self.buffer[self.len..];
        }
    };
}

test "BoundedArray basic operations" {
    var arr = BoundedArray(u8, 10){};

    try arr.append(1);
    try arr.append(2);
    try arr.append(3);

    try std.testing.expectEqual(@as(usize, 3), arr.len);
    try std.testing.expectEqual(@as(u8, 1), arr.get(0));
    try std.testing.expectEqual(@as(u8, 2), arr.get(1));
    try std.testing.expectEqual(@as(u8, 3), arr.get(2));

    _ = arr.pop();
    try std.testing.expectEqual(@as(usize, 2), arr.len);
}

test "BoundedArray overflow" {
    var arr = BoundedArray(u8, 2){};

    try arr.append(1);
    try arr.append(2);
    try std.testing.expectError(error.Overflow, arr.append(3));
}

test "BoundedArray fromSlice" {
    const data = [_]u8{ 1, 2, 3, 4, 5 };
    const arr = try BoundedArray(u8, 10).fromSlice(&data);

    try std.testing.expectEqual(@as(usize, 5), arr.len);
    try std.testing.expectEqualSlices(u8, &data, arr.constSlice());
}

test "BoundedArray init" {
    const arr = try BoundedArray(u8, 10).init(5);
    try std.testing.expectEqual(@as(usize, 5), arr.len);

    try std.testing.expectError(error.Overflow, BoundedArray(u8, 10).init(11));
}

test "BoundedArray fromSlice overflow" {
    const data = [_]u8{ 1, 2, 3, 4, 5 };
    try std.testing.expectError(error.Overflow, BoundedArray(u8, 3).fromSlice(&data));
}

test "BoundedArray appendSlice" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3 });
    try std.testing.expectEqual(@as(usize, 3), arr.len);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2, 3 }, arr.constSlice());

    try arr.appendSlice(&[_]u8{ 4, 5 });
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2, 3, 4, 5 }, arr.constSlice());

    try std.testing.expectError(error.Overflow, arr.appendSlice(&[_]u8{ 6, 7, 8, 9, 10, 11 }));
}

test "BoundedArray appendSliceAssumeCapacity" {
    var arr = BoundedArray(u8, 10){};
    arr.appendSliceAssumeCapacity(&[_]u8{ 1, 2, 3 });
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2, 3 }, arr.constSlice());
}

test "BoundedArray appendNTimes" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendNTimes(42, 5);
    try std.testing.expectEqual(@as(usize, 5), arr.len);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 42, 42, 42, 42, 42 }, arr.constSlice());

    try std.testing.expectError(error.Overflow, arr.appendNTimes(1, 6));
}

test "BoundedArray appendNTimesAssumeCapacity" {
    var arr = BoundedArray(u8, 10){};
    arr.appendNTimesAssumeCapacity(7, 3);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 7, 7, 7 }, arr.constSlice());
}

test "BoundedArray insert" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 3, 4 });
    try arr.insert(1, 2);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2, 3, 4 }, arr.constSlice());

    try arr.insert(0, 0);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 0, 1, 2, 3, 4 }, arr.constSlice());

    try arr.insert(5, 5);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 0, 1, 2, 3, 4, 5 }, arr.constSlice());
}

test "BoundedArray insert overflow" {
    var arr = BoundedArray(u8, 3){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3 });
    try std.testing.expectError(error.Overflow, arr.insert(1, 4));
}

test "BoundedArray insert rejects index past length" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2 });
    try std.testing.expectError(error.OutOfBounds, arr.insert(3, 9));
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2 }, arr.constSlice());
}

test "BoundedArray insertAssumeCapacity" {
    var arr = BoundedArray(u8, 10){};
    arr.appendSliceAssumeCapacity(&[_]u8{ 1, 3 });
    arr.insertAssumeCapacity(1, 2);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2, 3 }, arr.constSlice());
}

test "BoundedArray orderedRemove" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3, 4, 5 });

    const removed = arr.orderedRemove(2);
    try std.testing.expectEqual(@as(u8, 3), removed);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2, 4, 5 }, arr.constSlice());
}

test "BoundedArray swapRemove" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3, 4, 5 });

    const removed = arr.swapRemove(1);
    try std.testing.expectEqual(@as(u8, 2), removed);
    try std.testing.expectEqual(@as(usize, 4), arr.len);
    try std.testing.expectEqual(@as(u8, 5), arr.get(1));
}

test "BoundedArray swapRemoveByValue" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 10, 20, 30, 40 });

    arr.swapRemoveByValue(20);
    try std.testing.expectEqual(@as(usize, 3), arr.len);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 10, 40, 30 }, arr.constSlice());

    // no-op for missing value
    arr.swapRemoveByValue(99);
    try std.testing.expectEqual(@as(usize, 3), arr.len);
}

test "BoundedArray swapRemoveByValue pointer" {
    var a: u32 = 1;
    var b: u32 = 2;
    var d: u32 = 3;
    var arr = BoundedArray(*u32, 10){};
    try arr.append(&a);
    try arr.append(&b);
    try arr.append(&d);

    arr.swapRemoveByValue(&b);
    try std.testing.expectEqual(@as(usize, 2), arr.len);
    try std.testing.expectEqual(&a, arr.get(0));
    try std.testing.expectEqual(&d, arr.get(1));
}

test "BoundedArray set" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3 });
    arr.set(1, 99);
    try std.testing.expectEqual(@as(u8, 99), arr.get(1));
}

test "BoundedArray resize" {
    var arr = BoundedArray(u8, 10){};
    try arr.resize(5);
    try std.testing.expectEqual(@as(usize, 5), arr.len);

    try arr.resize(2);
    try std.testing.expectEqual(@as(usize, 2), arr.len);

    try std.testing.expectError(error.Overflow, arr.resize(11));
}

test "BoundedArray clear" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3 });
    arr.clear();
    try std.testing.expectEqual(@as(usize, 0), arr.len);
}

test "BoundedArray capacity and unusedCapacitySlice" {
    var arr = BoundedArray(u8, 10){};
    try std.testing.expectEqual(@as(usize, 10), arr.capacity());

    try arr.appendSlice(&[_]u8{ 1, 2, 3 });
    try std.testing.expectEqual(@as(usize, 7), arr.unusedCapacitySlice().len);
}

test "BoundedArray slice mutable" {
    var arr = BoundedArray(u8, 10){};
    try arr.appendSlice(&[_]u8{ 1, 2, 3 });
    const s = arr.slice();
    s[0] = 99;
    try std.testing.expectEqual(@as(u8, 99), arr.get(0));
}

test "BoundedArray popOrNull" {
    var arr = BoundedArray(u8, 10){};
    try std.testing.expectEqual(@as(?u8, null), arr.popOrNull());

    try arr.append(42);
    try std.testing.expectEqual(@as(?u8, 42), arr.popOrNull());
}

test "BoundedArray appendAssumeCapacity" {
    var arr = BoundedArray(u8, 10){};
    arr.appendAssumeCapacity(1);
    arr.appendAssumeCapacity(2);
    try std.testing.expectEqualSlices(u8, &[_]u8{ 1, 2 }, arr.constSlice());
}
