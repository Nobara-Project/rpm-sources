const std = @import("std");
const otter_io = @import("io.zig");
const config_paths = @import("config_paths.zig");

pub const wallpaper_state_file_name = "wallpaper-state";

pub fn wallpaperStatePath(buffer: []u8) ?[]const u8 {
    return config_paths.otterRuntimePath(buffer, wallpaper_state_file_name);
}

pub fn legacyWallpaperStatePath(buffer: []u8) ?[]const u8 {
    var fbs = std.Io.Writer.fixed(buffer);
    fbs.print("/tmp/{d}/otter-wallpaper-state", .{std.posix.system.getuid()}) catch return null;
    return buffer[0..fbs.end];
}

pub fn ensureWallpaperStateDir(io: std.Io) bool {
    return config_paths.ensureOtterRuntimeDir(io);
}

pub fn ensureUserTmpDir() bool {
    return ensureWallpaperStateDir(otter_io.get());
}

pub fn openWallpaperStateFile(io: std.Io, path_buffer: []u8) ?std.Io.File {
    if (wallpaperStatePath(path_buffer)) |path| {
        if (std.Io.Dir.openFileAbsolute(io, path, .{})) |file| {
            if (file.stat(io)) |stat| {
                if (stat.size > 0) return file;
            } else |_| {}
            file.close(io);
        } else |_| {}
    }
    if (legacyWallpaperStatePath(path_buffer)) |legacy| {
        if (std.Io.Dir.openFileAbsolute(io, legacy, .{})) |file| return file else |_| {}
    }
    return null;
}

pub fn wallpaperStateWatchPath(buffer: []u8) ?[]const u8 {
    const io = otter_io.get();
    var legacy_buf: [std.fs.max_path_bytes]u8 = undefined;
    if (wallpaperStatePath(buffer)) |path| {
        if (std.Io.Dir.openFileAbsolute(io, path, .{})) |file| {
            defer file.close(io);
            if (file.stat(io)) |stat| {
                if (stat.size > 0) return path;
            } else |_| {}
        } else |_| {}
    }
    if (legacyWallpaperStatePath(&legacy_buf)) |legacy| {
        if (std.Io.Dir.accessAbsolute(io, legacy, .{})) |_| {
            if (legacy.len <= buffer.len) {
                @memcpy(buffer[0..legacy.len], legacy);
                return buffer[0..legacy.len];
            }
        } else |_| {}
    }
    return wallpaperStatePath(buffer);
}

pub const WallpaperEntry = struct {
    output_name: []const u8,
    path: []const u8,
};

pub const WallpaperStateIterator = struct {
    lines: std.mem.SplitIterator(u8, .scalar),

    pub fn init(content: []const u8) WallpaperStateIterator {
        return .{ .lines = std.mem.splitScalar(u8, content, '\n') };
    }

    pub fn next(self: *WallpaperStateIterator) ?WallpaperEntry {
        while (self.lines.next()) |line| {
            const trimmed = std.mem.trim(u8, line, " \t\r");
            if (trimmed.len == 0 or trimmed[0] == '#') continue;
            const eq = std.mem.indexOfScalar(u8, trimmed, '=') orelse continue;
            const output_name = std.mem.trim(u8, trimmed[0..eq], " \t\r");
            const path = std.mem.trim(u8, trimmed[eq + 1 ..], " \t\r");
            if (output_name.len == 0 or !isValidWallpaperPath(path)) continue;
            return .{ .output_name = output_name, .path = path };
        }
        return null;
    }
};

pub fn isValidWallpaperPath(path: []const u8) bool {
    if (path.len == 0) return false;
    if (path[0] != '/') return false;
    if (std.mem.indexOf(u8, path, "..") != null) return false;
    return true;
}

pub fn firstWallpaperPath(content: []const u8) ?[]const u8 {
    var iter = WallpaperStateIterator.init(content);
    const entry = iter.next() orelse return null;
    return entry.path;
}

pub fn wallpaperPathForOutput(content: []const u8, output_name: []const u8) ?[]const u8 {
    var first_path: ?[]const u8 = null;
    var iter = WallpaperStateIterator.init(content);
    while (iter.next()) |entry| {
        if (first_path == null) first_path = entry.path;
        if (std.mem.eql(u8, entry.output_name, output_name)) return entry.path;
    }
    return first_path;
}

test "wallpaper state path uses otter runtime dir" {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path = wallpaperStatePath(&path_buf) orelse {
        try std.testing.expect(config_paths.xdgRuntimeDir() == null);
        return;
    };
    try std.testing.expect(std.mem.endsWith(u8, path, "/otter-shell/wallpaper-state"));
}

test "legacy wallpaper state path is user scoped tmp" {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path = legacyWallpaperStatePath(&path_buf).?;
    try std.testing.expect(std.mem.startsWith(u8, path, "/tmp/"));
    try std.testing.expect(std.mem.endsWith(u8, path, "/otter-wallpaper-state"));
}

test "wallpaper state iterator skips comments and invalid paths" {
    const content =
        \\# comment
        \\eDP-1=/wallpapers/a.png
        \\invalid=relative.png
        \\HDMI-1=/wallpapers/b.png
        \\
    ;
    var iter = WallpaperStateIterator.init(content);
    const first = iter.next().?;
    try std.testing.expectEqualStrings("eDP-1", first.output_name);
    try std.testing.expectEqualStrings("/wallpapers/a.png", first.path);
    const second = iter.next().?;
    try std.testing.expectEqualStrings("HDMI-1", second.output_name);
    try std.testing.expectEqualStrings("/wallpapers/b.png", second.path);
    try std.testing.expect(iter.next() == null);
}

test "wallpaper path lookup falls back to first valid entry" {
    const content = "HDMI-1=/wallpapers/b.png\neDP-1=/wallpapers/a.png\n";
    try std.testing.expectEqualStrings("/wallpapers/b.png", wallpaperPathForOutput(content, "HDMI-1").?);
    try std.testing.expectEqualStrings("/wallpapers/b.png", wallpaperPathForOutput(content, "DP-2").?);
}
