//! Legacy `/tmp/otter-*` migration and app path compatibility helpers.

const std = @import("std");
const runtime_paths = @import("runtime_paths.zig");
const xdg_paths = @import("xdg_paths.zig");

pub const legacy_weather_cache_path = "/tmp/otter-weather-cache";
pub const legacy_clip_history_path = "/tmp/otter-clip-history";
pub const legacy_clip_store_path = "/tmp/otter-clip-store";

pub fn isLegacyTmpOtterPath(path: []const u8) bool {
    return std.mem.startsWith(u8, path, "/tmp/otter-");
}

pub fn resolveWeatherCachePath(config_path: []const u8, buffer: []u8) ?[]const u8 {
    if (config_path.len == 0 or std.mem.eql(u8, config_path, legacy_weather_cache_path) or isLegacyTmpOtterPath(config_path)) {
        return xdg_paths.otterCachePath(buffer, "otter-weather-cache");
    }
    return copyCustomPath(config_path, buffer);
}

pub fn resolveClipHistoryPath(config_path: []const u8, buffer: []u8) ?[]const u8 {
    if (config_path.len == 0 or std.mem.eql(u8, config_path, legacy_clip_history_path) or isLegacyTmpOtterPath(config_path)) {
        return xdg_paths.otterCachePath(buffer, "otter-clip-history");
    }
    return copyCustomPath(config_path, buffer);
}

fn ensureParentDirAbsolute(io: std.Io, path: []const u8) void {
    const slash = std.mem.lastIndexOfScalar(u8, path, '/') orelse return;
    if (slash == 0) return;
    std.Io.Dir.createDirAbsolute(io, path[0..slash], @enumFromInt(0o700)) catch |err| {
        if (err != error.PathAlreadyExists) return;
    };
}

/// Copy a legacy `/tmp/otter-*` file into its XDG target when the target is missing.
pub fn migrateLegacyFileIfMissing(io: std.Io, legacy_path: []const u8, target_path: []const u8) void {
    if (std.Io.Dir.accessAbsolute(io, target_path, .{})) |_| return else |_| {}
    var legacy_file = std.Io.Dir.openFileAbsolute(io, legacy_path, .{}) catch return;
    defer legacy_file.close(io);
    _ = xdg_paths.ensureOtterCacheDir(io);
    ensureParentDirAbsolute(io, target_path);
    var target_file = std.Io.Dir.createFileAbsolute(io, target_path, .{}) catch return;
    defer target_file.close(io);
    var buf: [8192]u8 = undefined;
    var rbuf: [4096]u8 = undefined;
    var reader = legacy_file.reader(io, &rbuf);
    while (true) {
        const n = reader.interface.readSliceShort(&buf) catch break;
        if (n == 0) break;
        target_file.writeStreamingAll(io, buf[0..n]) catch return;
    }
}

pub fn resolveClipStorePath(config_path: []const u8, buffer: []u8) ?[]const u8 {
    if (config_path.len == 0 or std.mem.eql(u8, config_path, legacy_clip_store_path) or isLegacyTmpOtterPath(config_path)) {
        return runtime_paths.otterRuntimePath(buffer, "otter-clip-store");
    }
    return copyCustomPath(config_path, buffer);
}

fn copyCustomPath(config_path: []const u8, buffer: []u8) ?[]const u8 {
    if (config_path.len > buffer.len) return null;
    @memcpy(buffer[0..config_path.len], config_path);
    return buffer[0..config_path.len];
}

test "isLegacyTmpOtterPath detects tmp otter paths" {
    try std.testing.expect(isLegacyTmpOtterPath("/tmp/otter-weather-cache"));
    try std.testing.expect(isLegacyTmpOtterPath("/tmp/otter-clip-history"));
    try std.testing.expect(!isLegacyTmpOtterPath("/run/user/1000/otter-shell/cache"));
    try std.testing.expect(!isLegacyTmpOtterPath(""));
}

test "resolveWeatherCachePath keeps custom path" {
    var buf: [128]u8 = undefined;
    const custom = resolveWeatherCachePath("/custom/cache", &buf).?;
    try std.testing.expectEqualStrings("/custom/cache", custom);
}

test "resolve paths target expected migrated filenames" {
    var buf: [128]u8 = undefined;
    try std.testing.expectEqualStrings(
        "/home/user/.cache/otter-shell/otter-weather-cache",
        xdg_paths.otterCachePathFromHome(&buf, "/home/user", "otter-weather-cache").?,
    );
    try std.testing.expectEqualStrings(
        "/home/user/.cache/otter-shell/otter-clip-history",
        xdg_paths.otterCachePathFromHome(&buf, "/home/user", "otter-clip-history").?,
    );
    try std.testing.expectEqualStrings(
        "/run/user/1000/otter-shell/otter-clip-store",
        runtime_paths.otterRuntimePathFromBase(&buf, "/run/user/1000", "otter-clip-store").?,
    );
}

test "legacy constants are legacy tmp otter paths" {
    try std.testing.expect(isLegacyTmpOtterPath(legacy_weather_cache_path));
    try std.testing.expect(isLegacyTmpOtterPath(legacy_clip_history_path));
    try std.testing.expect(isLegacyTmpOtterPath(legacy_clip_store_path));
}
