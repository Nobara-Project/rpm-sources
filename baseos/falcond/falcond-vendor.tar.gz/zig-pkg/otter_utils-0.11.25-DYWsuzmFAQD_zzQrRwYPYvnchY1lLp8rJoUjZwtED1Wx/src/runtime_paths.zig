//! Runtime directory, socket path, and runtime security helpers.

const std = @import("std");
const posix = std.posix;
const xdg_paths = @import("xdg_paths.zig");

pub const max_runtime_socket_path_len: usize = 108;

/// Real login name for the current uid (not spoofable USER/LOGNAME env).
pub fn loginUserName(buffer: []u8) ?[]const u8 {
    const uid = posix.system.getuid();
    var pwd: std.c.passwd = undefined;
    var result: ?*std.c.passwd = null;
    var pwd_buf: [1024]u8 = undefined;
    if (std.c.getpwuid_r(uid, &pwd, &pwd_buf, pwd_buf.len, &result) != 0 or result == null) return null;
    const name = std.mem.span(result.?.name orelse return null);
    if (name.len > buffer.len) return null;
    @memcpy(buffer[0..name.len], name);
    return buffer[0..name.len];
}

pub fn otterRuntimeDir(buffer: []u8) ?[]const u8 {
    return otterRuntimeDirFromBase(buffer, xdg_paths.xdgRuntimeDir() orelse return null);
}

pub fn otterRuntimeDirFromBase(buffer: []u8, runtime_dir: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(runtime_dir) catch return null;
    writer.writeAll(xdg_paths.otter_runtime_subdir) catch return null;
    return buffer[0..writer.end];
}

pub fn otterRuntimePath(buffer: []u8, file_name: []const u8) ?[]const u8 {
    return otterRuntimePathFromBase(buffer, xdg_paths.xdgRuntimeDir() orelse return null, file_name);
}

pub fn otterRuntimePathFromBase(buffer: []u8, runtime_dir: []const u8, file_name: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(runtime_dir) catch return null;
    writer.writeAll(xdg_paths.otter_runtime_subdir) catch return null;
    writer.writeAll(file_name) catch return null;
    return buffer[0..writer.end];
}

pub fn ensureOtterRuntimeDir(io: std.Io) bool {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path = otterRuntimeDir(&path_buf) orelse return false;
    std.Io.Dir.createDirAbsolute(io, path, @enumFromInt(0o700)) catch |err| {
        if (err != error.PathAlreadyExists) return false;
    };
    return true;
}

pub fn restrictSocketFd(fd: posix.fd_t) !void {
    if (std.c.fchmod(fd, 0o700) != 0) return error.SocketChmodFailed;
}

pub fn runtimeSocketPath(buf: []u8, prefix: []const u8, suffix: []const u8) ?usize {
    const runtime_dir = xdg_paths.xdgRuntimeDir() orelse return null;
    const display = xdg_paths.env("WAYLAND_DISPLAY") orelse return null;
    return runtimeSocketPathFromValues(buf, runtime_dir, display, prefix, suffix);
}

fn runtimeSocketPathFromValues(
    buf: []u8,
    runtime_dir: []const u8,
    display: []const u8,
    prefix: []const u8,
    suffix: []const u8,
) ?usize {
    const total = runtime_dir.len + xdg_paths.otter_runtime_subdir.len + prefix.len + display.len + suffix.len;
    if (total >= buf.len or total >= max_runtime_socket_path_len) return null;

    var writer = std.Io.Writer.fixed(buf);
    writer.writeAll(runtime_dir) catch return null;
    writer.writeAll(xdg_paths.otter_runtime_subdir) catch return null;
    writer.writeAll(prefix) catch return null;
    writer.writeAll(display) catch return null;
    writer.writeAll(suffix) catch return null;
    return writer.end;
}

test "otter runtime path from base" {
    var buf: [128]u8 = undefined;
    const path = otterRuntimePathFromBase(&buf, "/run/user/1000", "otter-clip-store").?;
    try std.testing.expectEqualStrings("/run/user/1000/otter-shell/otter-clip-store", path);
}

test "otter runtime dir from base" {
    var buf: [128]u8 = undefined;
    const path = otterRuntimeDirFromBase(&buf, "/run/user/1000").?;
    try std.testing.expectEqualStrings("/run/user/1000/otter-shell/", path);
}

test "runtimeSocketPath builds otter-shell socket path" {
    var buf: [max_runtime_socket_path_len]u8 = undefined;
    const len = runtimeSocketPathFromValues(&buf, "/run/user/1000", "wayland-1", "otter-render-server.", ".sock").?;
    try std.testing.expectEqualStrings("/run/user/1000/otter-shell/otter-render-server.wayland-1.sock", buf[0..len]);
}

test "runtimeSocketPath rejects oversized paths" {
    var buf: [32]u8 = undefined;
    try std.testing.expectEqual(@as(?usize, null), runtimeSocketPathFromValues(
        &buf,
        "/run/user/1000/with/a/very/long/runtime/directory",
        "wayland-1",
        "otter-render-server.",
        ".sock",
    ));
}
