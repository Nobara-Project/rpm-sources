//! XDG config, data, cache, and environment path helpers.

const std = @import("std");

pub const user_config_dir = "/.config/otter-shell/";
pub const user_data_suffix = "/.local/share/otter-shell/";
pub const user_cache_suffix = "/.cache/otter-shell/";
pub const otter_runtime_subdir = "/otter-shell/";

pub fn env(name: [:0]const u8) ?[]const u8 {
    const raw = std.c.getenv(name.ptr) orelse return null;
    return std.mem.span(raw);
}

pub fn home() ?[]const u8 {
    return env("HOME");
}

pub fn xdgDataHome() ?[]const u8 {
    return env("XDG_DATA_HOME");
}

pub fn xdgRuntimeDir() ?[]const u8 {
    return env("XDG_RUNTIME_DIR");
}

pub fn xdgCacheHome() ?[]const u8 {
    return env("XDG_CACHE_HOME");
}

pub fn otterConfigPath(buffer: []u8, file_name: []const u8) ?[]const u8 {
    return otterConfigPathFromHome(buffer, home() orelse return null, file_name);
}

pub fn otterConfigDir(buffer: []u8) ?[]const u8 {
    return otterConfigDirFromHome(buffer, home() orelse return null);
}

pub fn otterConfigPathFromHome(buffer: []u8, home_dir: []const u8, file_name: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(home_dir) catch return null;
    writer.writeAll(user_config_dir) catch return null;
    writer.writeAll(file_name) catch return null;
    return buffer[0..writer.end];
}

pub fn otterConfigDirFromHome(buffer: []u8, home_dir: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(home_dir) catch return null;
    writer.writeAll(user_config_dir) catch return null;
    return buffer[0..writer.end];
}

pub fn otterDataPath(buffer: []u8, file_name: []const u8) ?[]const u8 {
    if (xdgDataHome()) |data_home| {
        return otterDataPathFromBase(buffer, data_home, file_name);
    }
    return otterDataPathFromHome(buffer, home() orelse return null, file_name);
}

pub fn otterDataDir(buffer: []u8) ?[]const u8 {
    if (xdgDataHome()) |data_home| {
        return otterDataDirFromBase(buffer, data_home);
    }
    return otterDataDirFromHome(buffer, home() orelse return null);
}

pub fn otterDataPathFromBase(buffer: []u8, data_home: []const u8, file_name: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(data_home) catch return null;
    writer.writeAll(otter_runtime_subdir) catch return null;
    writer.writeAll(file_name) catch return null;
    return buffer[0..writer.end];
}

pub fn otterDataDirFromBase(buffer: []u8, data_home: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(data_home) catch return null;
    writer.writeAll(otter_runtime_subdir) catch return null;
    return buffer[0..writer.end];
}

pub fn otterDataPathFromHome(buffer: []u8, home_dir: []const u8, file_name: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(home_dir) catch return null;
    writer.writeAll(user_data_suffix) catch return null;
    writer.writeAll(file_name) catch return null;
    return buffer[0..writer.end];
}

pub fn otterDataDirFromHome(buffer: []u8, home_dir: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(home_dir) catch return null;
    writer.writeAll(user_data_suffix) catch return null;
    return buffer[0..writer.end];
}

pub fn otterCacheDir(buffer: []u8) ?[]const u8 {
    if (xdgCacheHome()) |cache_home| {
        return otterCacheDirFromBase(buffer, cache_home);
    }
    return otterCacheDirFromHome(buffer, home() orelse return null);
}

pub fn otterCacheDirFromBase(buffer: []u8, cache_home: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(cache_home) catch return null;
    writer.writeAll(otter_runtime_subdir) catch return null;
    return buffer[0..writer.end];
}

pub fn otterCacheDirFromHome(buffer: []u8, home_dir: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(home_dir) catch return null;
    writer.writeAll(user_cache_suffix) catch return null;
    return buffer[0..writer.end];
}

pub fn otterCachePath(buffer: []u8, file_name: []const u8) ?[]const u8 {
    if (xdgCacheHome()) |cache_home| {
        return otterCachePathFromBase(buffer, cache_home, file_name);
    }
    return otterCachePathFromHome(buffer, home() orelse return null, file_name);
}

pub fn otterCachePathFromBase(buffer: []u8, cache_home: []const u8, file_name: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(cache_home) catch return null;
    writer.writeAll(otter_runtime_subdir) catch return null;
    writer.writeAll(file_name) catch return null;
    return buffer[0..writer.end];
}

pub fn otterCachePathFromHome(buffer: []u8, home_dir: []const u8, file_name: []const u8) ?[]const u8 {
    var writer = std.Io.Writer.fixed(buffer);
    writer.writeAll(home_dir) catch return null;
    writer.writeAll(user_cache_suffix) catch return null;
    writer.writeAll(file_name) catch return null;
    return buffer[0..writer.end];
}

pub fn ensureOtterCacheDir(io: std.Io) bool {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path = otterCacheDir(&path_buf) orelse return false;
    std.Io.Dir.createDirAbsolute(io, path, @enumFromInt(0o700)) catch |err| {
        if (err != error.PathAlreadyExists) return false;
    };
    return true;
}

test "otter config path from home" {
    var buf: [128]u8 = undefined;
    const path = otterConfigPathFromHome(&buf, "/home/user", "otter-bar.conf").?;
    try std.testing.expectEqualStrings("/home/user/.config/otter-shell/otter-bar.conf", path);
}

test "otter config dir from home" {
    var buf: [128]u8 = undefined;
    const path = otterConfigDirFromHome(&buf, "/home/user").?;
    try std.testing.expectEqualStrings("/home/user/.config/otter-shell/", path);
}

test "otter config path rejects too-small buffer" {
    var buf: [8]u8 = undefined;
    try std.testing.expectEqual(@as(?[]const u8, null), otterConfigPathFromHome(&buf, "/home/user", "otter-bar.conf"));
}

test "otter data path honors xdg data base" {
    var buf: [128]u8 = undefined;
    const path = otterDataPathFromBase(&buf, "/run/user/1000/data", "notes.md").?;
    try std.testing.expectEqualStrings("/run/user/1000/data/otter-shell/notes.md", path);
}

test "otter data path falls back under home local share" {
    var buf: [128]u8 = undefined;
    const path = otterDataPathFromHome(&buf, "/home/user", "notes.md").?;
    try std.testing.expectEqualStrings("/home/user/.local/share/otter-shell/notes.md", path);
}

test "otter cache path from base" {
    var buf: [128]u8 = undefined;
    const path = otterCachePathFromBase(&buf, "/home/user/.cache", "otter-weather-cache").?;
    try std.testing.expectEqualStrings("/home/user/.cache/otter-shell/otter-weather-cache", path);
}

test "otter cache path falls back under home cache" {
    var buf: [128]u8 = undefined;
    const path = otterCachePathFromHome(&buf, "/home/user", "otter-clip-history").?;
    try std.testing.expectEqualStrings("/home/user/.cache/otter-shell/otter-clip-history", path);
}
