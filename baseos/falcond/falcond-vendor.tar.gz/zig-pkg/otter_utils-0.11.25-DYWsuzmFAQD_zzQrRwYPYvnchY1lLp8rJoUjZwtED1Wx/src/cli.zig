const std = @import("std");

/// Returns true when `arg` is `-h` or `--help`.
pub fn isHelp(arg: []const u8) bool {
    return std.mem.eql(u8, arg, "-h") or std.mem.eql(u8, arg, "--help");
}

/// Returns true when any argument after argv[0] is a help request.
pub fn wantsHelp(args: []const []const u8) bool {
    if (args.len <= 1) return false;
    for (args[1..]) |arg| {
        if (isHelp(arg)) return true;
    }
    return false;
}

test "isHelp recognizes help flags" {
    try std.testing.expect(isHelp("--help"));
    try std.testing.expect(isHelp("-h"));
    try std.testing.expect(!isHelp("--help-me"));
    try std.testing.expect(!isHelp("-help"));
}

test "wantsHelp scans argv after program name" {
    try std.testing.expect(wantsHelp(&.{ "otter-idle", "--help" }));
    try std.testing.expect(wantsHelp(&.{ "otter-idle", "-h" }));
    try std.testing.expect(!wantsHelp(&.{"otter-idle"}));
    try std.testing.expect(!wantsHelp(&.{ "otter-idle", "--model", "x" }));
}
