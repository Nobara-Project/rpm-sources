const std = @import("std");
const posix = std.posix;
const linux = std.os.linux;

pub const Signals = struct {
    fd: posix.fd_t,
    mask: posix.sigset_t,

    pub fn init() !Signals {
        var mask = posix.sigemptyset();
        posix.sigaddset(&mask, .INT);
        posix.sigaddset(&mask, .TERM);
        posix.sigaddset(&mask, .HUP);
        posix.sigaddset(&mask, .QUIT);

        posix.sigprocmask(posix.SIG.BLOCK, &mask, null);
        const fd = posix.signalfd(-1, &mask, linux.SFD.CLOEXEC | linux.SFD.NONBLOCK) catch |err| {
            posix.sigprocmask(posix.SIG.UNBLOCK, &mask, null);
            return err;
        };

        return .{ .fd = fd, .mask = mask };
    }

    pub fn deinit(self: *Signals) void {
        _ = posix.system.close(self.fd);
        posix.sigprocmask(posix.SIG.UNBLOCK, &self.mask, null);
    }

    pub fn drain(self: *Signals) void {
        var infos: [4]linux.signalfd_siginfo = undefined;
        const bytes = std.mem.asBytes(&infos);

        while (true) {
            const n = posix.read(self.fd, bytes) catch |err| switch (err) {
                error.WouldBlock => return,
                else => return,
            };
            if (n < @sizeOf(linux.signalfd_siginfo) or n < bytes.len) return;
        }
    }
};

test "shutdown signals init and deinit" {
    var signals = try Signals.init();
    signals.deinit();
}
