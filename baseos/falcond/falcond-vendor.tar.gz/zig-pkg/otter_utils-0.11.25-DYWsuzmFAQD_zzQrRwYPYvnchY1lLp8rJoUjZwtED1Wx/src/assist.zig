const std = @import("std");

pub const max_request_bytes = 64 * 1024;
pub const default_system_prompt = "You are a concise local assistant.";

pub const Role = enum {
    system,
    user,
    assistant,
    tool,
};

pub const Message = struct {
    role: Role,
    content: []const u8,
};

pub const Options = struct {
    max_tokens: ?i32 = null,
    ctx: ?i32 = null,
    temperature: ?f32 = null,
};

pub const Request = struct {
    version: u8 = 1,
    stream: bool = true,
    system: ?[]const u8 = null,
    messages: []Message,
    options: Options = .{},
};

pub fn parseRequest(allocator: std.mem.Allocator, json: []const u8) !std.json.Parsed(Request) {
    return std.json.parseFromSlice(Request, allocator, json, .{ .ignore_unknown_fields = true });
}

pub fn formatSinglePrompt(allocator: std.mem.Allocator, prompt: []const u8, system: ?[]const u8) ![]u8 {
    const message = [_]Message{.{ .role = .user, .content = prompt }};
    return formatMessages(allocator, system orelse default_system_prompt, &message);
}

pub fn formatChatPrompt(allocator: std.mem.Allocator, request: Request) ![]u8 {
    const has_system = request.system != null and request.system.?.len != 0;
    if (!has_system and request.messages.len == 0) return error.EmptyPrompt;
    return formatMessages(allocator, request.system, request.messages);
}

pub fn formatMessages(allocator: std.mem.Allocator, system: ?[]const u8, messages: []const Message) ![]u8 {
    var out = std.ArrayList(u8).empty;
    errdefer out.deinit(allocator);
    try out.appendSlice(allocator, "<|startoftext|>");
    if (system) |text| {
        if (text.len != 0) try appendMessage(allocator, &out, .system, text);
    }
    for (messages) |message| try appendMessage(allocator, &out, message.role, message.content);
    try out.appendSlice(allocator, "<|im_start|>assistant\n");
    return out.toOwnedSlice(allocator);
}

fn appendMessage(allocator: std.mem.Allocator, out: *std.ArrayList(u8), role: Role, content: []const u8) !void {
    try out.appendSlice(allocator, "<|im_start|>");
    try out.appendSlice(allocator, @tagName(role));
    try out.appendSlice(allocator, "\n");
    try out.appendSlice(allocator, content);
    try out.appendSlice(allocator, "<|im_end|>\n");
}

test "parse chat request" {
    var parsed = try parseRequest(std.testing.allocator,
        \\{"system":"Be terse.","messages":[{"role":"user","content":"hi"}],"options":{"max_tokens":8,"temperature":0}}
    );
    defer parsed.deinit();
    try std.testing.expectEqualStrings("Be terse.", parsed.value.system.?);
    try std.testing.expectEqual(Role.user, parsed.value.messages[0].role);
    try std.testing.expectEqual(@as(i32, 8), parsed.value.options.max_tokens.?);
}

test "format chat prompt" {
    const messages = [_]Message{
        .{ .role = .user, .content = "hi" },
        .{ .role = .assistant, .content = "hello" },
        .{ .role = .user, .content = "again" },
    };
    const prompt = try formatMessages(std.testing.allocator, "Be terse.", &messages);
    defer std.testing.allocator.free(prompt);
    try std.testing.expect(std.mem.indexOf(u8, prompt, "<|im_start|>system\nBe terse.<|im_end|>\n") != null);
    try std.testing.expect(std.mem.endsWith(u8, prompt, "<|im_start|>assistant\n"));
}
