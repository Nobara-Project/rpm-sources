//! Process spawning utilities for fire-and-forget commands.
//!
//! All Otter Shell apps that spawn external commands (bar buttons, network
//! widget, launcher) must go through these helpers to ensure child processes
//! are properly reaped and never left as zombies.

const std = @import("std");
const posix = std.posix;

const log = @import("log.zig").Scoped("process");

const max_reaper_pids = 64;
const reaper_sleep_ns = 50_000_000;

const ReaperQueue = struct {
    slots: [max_reaper_pids]std.atomic.Value(posix.pid_t) = initSlots(),

    fn initSlots() [max_reaper_pids]std.atomic.Value(posix.pid_t) {
        return .{std.atomic.Value(posix.pid_t).init(0)} ** max_reaper_pids;
    }

    fn tryPush(self: *ReaperQueue, pid: posix.pid_t) bool {
        std.debug.assert(pid > 0);
        for (&self.slots) |*slot| {
            if (slot.cmpxchgStrong(0, pid, .release, .monotonic) == null) {
                return true;
            }
        }
        return false;
    }

    fn pop(self: *ReaperQueue) ?posix.pid_t {
        for (&self.slots) |*slot| {
            const pid = slot.swap(0, .acquire);
            if (pid != 0) return pid;
        }
        return null;
    }
};

var reaper_queue = ReaperQueue{};
var reaper_started = std.atomic.Value(bool).init(false);

pub const EnvBehavior = enum {
    inherit_io,
    live_snapshot,
};

pub const SpawnOptions = struct {
    env_behavior: EnvBehavior = .inherit_io,
};

pub fn otterExecutable(io: std.Io, buffer: []u8, name: []const u8) []const u8 {
    var exe_buf: [std.fs.max_path_bytes]u8 = undefined;
    const exe_len = std.Io.Dir.cwd().readLink(io, "/proc/self/exe", &exe_buf) catch return name;
    if (siblingExecutableFromPath(buffer, exe_buf[0..exe_len], name)) |path| {
        if (isExecutable(path)) return path;
    }
    if (workspaceExecutableFromPath(buffer, exe_buf[0..exe_len], name)) |path| {
        if (isExecutable(path)) return path;
    }
    return name;
}

fn isExecutable(path: []const u8) bool {
    var z_buf: [std.fs.max_path_bytes:0]u8 = undefined;
    if (path.len >= z_buf.len) return false;
    @memcpy(z_buf[0..path.len], path);
    z_buf[path.len] = 0;
    return std.os.linux.access(z_buf[0..path.len :0].ptr, std.os.linux.X_OK) == 0;
}

pub fn siblingExecutableFromPath(buffer: []u8, self_path: []const u8, name: []const u8) ?[]const u8 {
    const slash = std.mem.lastIndexOfScalar(u8, self_path, '/') orelse return null;
    const dir = self_path[0..slash];
    if (dir.len + 1 + name.len > buffer.len) return null;
    @memcpy(buffer[0..dir.len], dir);
    buffer[dir.len] = '/';
    @memcpy(buffer[dir.len + 1 ..][0..name.len], name);
    return buffer[0 .. dir.len + 1 + name.len];
}

pub fn workspaceExecutableFromPath(buffer: []u8, self_path: []const u8, name: []const u8) ?[]const u8 {
    const marker = "/zig-out/bin/";
    const marker_index = std.mem.lastIndexOf(u8, self_path, marker) orelse return null;
    const package_dir = self_path[0..marker_index];
    const slash = std.mem.lastIndexOfScalar(u8, package_dir, '/') orelse return null;
    const workspace = package_dir[0..slash];
    const mid = "/zig-out/bin/";
    if (workspace.len + 1 + name.len + mid.len + name.len > buffer.len) return null;
    var len: usize = 0;
    @memcpy(buffer[len..][0..workspace.len], workspace);
    len += workspace.len;
    buffer[len] = '/';
    len += 1;
    @memcpy(buffer[len..][0..name.len], name);
    len += name.len;
    @memcpy(buffer[len..][0..mid.len], mid);
    len += mid.len;
    @memcpy(buffer[len..][0..name.len], name);
    len += name.len;
    return buffer[0..len];
}

fn currentEnvironMap(allocator: std.mem.Allocator) !std.process.Environ.Map {
    const env_block: std.process.Environ.Block = switch (@import("builtin").os.tag) {
        .wasi, .emscripten => .empty,
        else => blk: {
            const c_environ = std.c.environ;
            var env_count: usize = 0;
            while (c_environ[env_count] != null) : (env_count += 1) {}
            break :blk .{ .slice = c_environ[0..env_count :null] };
        },
    };
    return std.process.Environ.createMap(.{ .block = env_block }, allocator);
}

fn resolveEnvironMap(options: SpawnOptions) !?std.process.Environ.Map {
    return switch (options.env_behavior) {
        .inherit_io => null,
        .live_snapshot => try currentEnvironMap(std.heap.c_allocator),
    };
}

/// Spawn a shell command via `/bin/sh -c` and reap the child asynchronously.
/// A detached thread calls waitpid to prevent zombies — same principle as
/// falcond's screensaver.zig but non-blocking so the event loop isn't stalled.
pub fn spawnCommand(io: std.Io, cmd: []const u8) void {
    spawnCommandWithOptions(io, cmd, .{});
}

pub fn spawnCommandWithOptions(io: std.Io, cmd: []const u8, options: SpawnOptions) void {
    const argv = [_][]const u8{ "/bin/sh", "-c", cmd };
    spawnPrepared(io, &argv, options, .command, cmd);
}

const SpawnLogKind = enum { command, process };

fn spawnPrepared(io: std.Io, argv: []const []const u8, options: SpawnOptions, comptime log_kind: SpawnLogKind, label: []const u8) void {
    var environ_map = resolveEnvironMap(options) catch |err| {
        switch (log_kind) {
            .command => log.err("Failed to prepare environment for command '{s}': {s}", .{ label, @errorName(err) }),
            .process => log.err("Failed to prepare environment for process: {s}", .{@errorName(err)}),
        }
        return;
    };
    defer if (environ_map) |*map| map.deinit();

    const child = std.process.spawn(io, .{
        .argv = argv,
        .environ_map = if (environ_map) |*map| map else null,
        .stdin = .ignore,
        .stdout = .ignore,
        .stderr = .ignore,
    }) catch |err| {
        switch (log_kind) {
            .command => log.err("Failed to spawn command '{s}': {s}", .{ label, @errorName(err) }),
            .process => log.err("Failed to spawn process: {s}", .{@errorName(err)}),
        }
        return;
    };

    if (child.id) |pid| reapChild(pid);
}

/// Spawn an argv command and reap the child asynchronously.
pub fn spawnArgv(io: std.Io, argv: []const []const u8) void {
    spawnArgvWithOptions(io, argv, .{});
}

pub fn spawnArgvWithOptions(io: std.Io, argv: []const []const u8, options: SpawnOptions) void {
    spawnPrepared(io, argv, options, .process, "");
}

/// Queue child for the single reaper thread. Falls back to synchronous wait
/// when the fixed queue is full so zombies are not traded for unbounded threads.
fn reapChild(pid: posix.pid_t) void {
    if (!ensureReaperThread()) {
        waitForChild(pid);
        return;
    }

    if (!reaper_queue.tryPush(pid)) {
        log.warn("Reaper queue full; waiting synchronously for pid {d}", .{pid});
        waitForChild(pid);
    }
}

fn ensureReaperThread() bool {
    if (reaper_started.load(.acquire)) return true;
    if (reaper_started.cmpxchgStrong(false, true, .acq_rel, .acquire) != null) return true;

    const thread = std.Thread.spawn(.{}, reaperMain, .{}) catch |err| {
        reaper_started.store(false, .release);
        log.err("Failed to spawn reaper thread: {s}", .{@errorName(err)});
        return false;
    };
    thread.detach();
    return true;
}

fn reaperMain() void {
    while (true) {
        if (reaper_queue.pop()) |pid| {
            waitForChild(pid);
            continue;
        }
        sleepReaper();
    }
}

fn waitForChild(pid: posix.pid_t) void {
    var status: c_int = 0;
    // std.posix.waitpid was removed in 0.16; use the cross-platform libc call directly.
    _ = std.posix.system.waitpid(pid, &status, 0);
}

fn sleepReaper() void {
    const ts = std.posix.timespec{
        .sec = 0,
        .nsec = reaper_sleep_ns,
    };
    _ = std.c.nanosleep(&ts, null);
}

test "reaper queue rejects overflow without growing" {
    var queue = ReaperQueue{};
    for (0..max_reaper_pids) |i| {
        try std.testing.expect(queue.tryPush(@intCast(i + 1)));
    }
    try std.testing.expect(!queue.tryPush(@intCast(max_reaper_pids + 1)));
}

test "reaper queue drains slots for reuse" {
    var queue = ReaperQueue{};
    try std.testing.expect(queue.tryPush(11));
    try std.testing.expectEqual(@as(?posix.pid_t, 11), queue.pop());
    try std.testing.expectEqual(@as(?posix.pid_t, null), queue.pop());
    try std.testing.expect(queue.tryPush(12));
}

test "sibling executable uses current binary directory" {
    var buf: [128]u8 = undefined;
    const path = siblingExecutableFromPath(&buf, "/tmp/otter/bin/otter-note", "otter-launcher").?;
    try std.testing.expectEqualStrings("/tmp/otter/bin/otter-launcher", path);
}

test "sibling executable rejects paths without room" {
    var buf: [8]u8 = undefined;
    try std.testing.expectEqual(@as(?[]const u8, null), siblingExecutableFromPath(&buf, "/tmp/otter-note", "otter-launcher"));
}

test "workspace executable resolves monorepo zig-out layout" {
    var buf: [160]u8 = undefined;
    const path = workspaceExecutableFromPath(
        &buf,
        "/home/user/otter-shell/otter-note/zig-out/bin/otter-note",
        "otter-launcher",
    ).?;
    try std.testing.expectEqualStrings(
        "/home/user/otter-shell/otter-launcher/zig-out/bin/otter-launcher",
        path,
    );
}
