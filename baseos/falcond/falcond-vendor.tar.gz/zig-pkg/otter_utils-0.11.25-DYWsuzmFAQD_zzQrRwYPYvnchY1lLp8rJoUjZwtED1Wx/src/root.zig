//! otter-utils: Generic utilities for the Otter desktop shell
//!
//! Stack-allocated bounded arrays, path handling, logging, inotify, and other utilities.

pub const BoundedArray = @import("bounded_array.zig").BoundedArray;
pub const FilePath = @import("file_path.zig");
pub const log = @import("log.zig");
pub const inotify = @import("inotify.zig");
pub const process = @import("process.zig");
pub const command = @import("command.zig");
pub const app_id_match = @import("app_id_match.zig");
pub const config_paths = @import("config_paths.zig");
pub const FixedString = @import("fixed_string.zig").FixedString;
pub const io = @import("io.zig");
pub const shutdown = @import("shutdown.zig");
pub const runtime_state = @import("runtime_state.zig");
pub const runtime_auth = @import("runtime_auth.zig");
pub const SubscriberList = @import("subscriber_list.zig").SubscriberList;
pub const unix_socket = @import("unix_socket.zig");
pub const cli = @import("cli.zig");
pub const assist = @import("assist.zig");

const c = @import("malloc_c");

/// Asks glibc to return freed heap pages to the OS. Safe to call regardless
/// of allocator — jemalloc provides a no-op malloc_trim, and mimalloc doesn't
/// use glibc's heap so glibc's malloc_trim is harmless.
pub inline fn mallocTrim() void {
    _ = c.malloc_trim(0);
}

test {
    _ = @import("bounded_array.zig");
    _ = @import("file_path.zig");
    _ = @import("log.zig");
    _ = @import("inotify.zig");
    _ = @import("process.zig");
    _ = @import("command.zig");
    _ = @import("app_id_match.zig");
    _ = @import("config_paths.zig");
    _ = @import("fixed_string.zig");
    _ = @import("shutdown.zig");
    _ = @import("runtime_state.zig");
    _ = @import("runtime_auth.zig");
    _ = @import("subscriber_list.zig");
    _ = @import("unix_socket.zig");
    _ = @import("cli.zig");
    _ = @import("assist.zig");
}
