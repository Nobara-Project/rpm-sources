//! App-wide `std.Io` singleton. Apps install their real `Io` from
//! `std.process.Init` in `main()`, and shared libraries read it via
//! `get()` when they need to open files, spawn processes, etc. This keeps
//! library APIs free of the `io` parameter noise while still routing I/O
//! through the app's actual `Io` implementation — **not** `std.Options.debug_io`,
//! which is intended only for low-level panic/debug output.

const std = @import("std");

var current_io: std.Io = undefined;
var installed: bool = false;

/// Register the app's `std.Io`. Call once from `main()` before any library
/// code does I/O.
pub fn install(io: std.Io) void {
    current_io = io;
    installed = true;
}

/// Retrieve the installed `std.Io`. Falls back to `std.Options.debug_io` when
/// `install` has not run, so tests and one-off tools work unchanged. Apps
/// should call `install()` from `main()` so library code uses the real
/// production `Io` (with proper cancelation / threading semantics) instead of
/// the debug singleton.
pub fn get() std.Io {
    if (installed) return current_io;
    return std.Options.debug_io;
}

/// Returns true once `install` has run. For libraries that want to
/// short-circuit a path rather than panic.
pub fn isInstalled() bool {
    return installed;
}
