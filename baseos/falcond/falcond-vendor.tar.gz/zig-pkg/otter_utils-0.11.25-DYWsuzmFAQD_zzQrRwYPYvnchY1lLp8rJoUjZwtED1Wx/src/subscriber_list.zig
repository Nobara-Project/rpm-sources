const std = @import("std");

pub fn SubscriberList(comptime Callback: type, comptime capacity: usize) type {
    if (capacity == 0 or capacity > 64) {
        @compileError("SubscriberList capacity must be 1..64");
    }

    return struct {
        slots: [capacity]Subscription = undefined,
        mask: u64 = 0,

        const Self = @This();
        const full_mask: u64 = if (capacity == 64) std.math.maxInt(u64) else (@as(u64, 1) << capacity) - 1;

        pub const Subscription = struct {
            callback: Callback,
            context: ?*anyopaque,
        };

        pub fn subscribe(self: *Self, callback: Callback, context: ?*anyopaque) bool {
            const free = ~self.mask & full_mask;
            if (free == 0) return false;

            const index = @ctz(free);
            self.slots[index] = .{ .callback = callback, .context = context };
            self.mask |= @as(u64, 1) << @intCast(index);
            return true;
        }

        pub fn unsubscribe(self: *Self, callback: Callback, context: ?*anyopaque) void {
            var mask = self.mask;
            while (mask != 0) {
                const index = @ctz(mask);
                const slot = self.slots[index];
                if (slot.callback == callback and slot.context == context) {
                    self.mask &= ~(@as(u64, 1) << @intCast(index));
                    return;
                }
                mask &= mask - 1;
            }
        }

        pub fn notify(self: *const Self) void {
            var mask = self.mask;
            while (mask != 0) {
                const index = @ctz(mask);
                const slot = self.slots[index];
                slot.callback(slot.context);
                mask &= mask - 1;
            }
        }

        pub fn clear(self: *Self) void {
            self.mask = 0;
        }

        pub fn count(self: *const Self) usize {
            return @popCount(self.mask);
        }
    };
}

fn increment(ctx: ?*anyopaque) void {
    const count: *usize = @ptrCast(@alignCast(ctx.?));
    count.* += 1;
}

test "SubscriberList subscribe notify unsubscribe" {
    const List = SubscriberList(*const fn (?*anyopaque) void, 2);
    var list = List{};
    var calls: usize = 0;

    try std.testing.expect(list.subscribe(increment, &calls));
    try std.testing.expectEqual(@as(usize, 1), list.count());
    list.notify();
    try std.testing.expectEqual(@as(usize, 1), calls);

    list.unsubscribe(increment, &calls);
    try std.testing.expectEqual(@as(usize, 0), list.count());
    list.notify();
    try std.testing.expectEqual(@as(usize, 1), calls);
}

test "SubscriberList capacity limit and slot reuse" {
    const List = SubscriberList(*const fn (?*anyopaque) void, 2);
    var list = List{};
    var first: usize = 0;
    var second: usize = 0;
    var third: usize = 0;

    try std.testing.expect(list.subscribe(increment, &first));
    try std.testing.expect(list.subscribe(increment, &second));
    try std.testing.expect(!list.subscribe(increment, &third));

    list.unsubscribe(increment, &first);
    try std.testing.expect(list.subscribe(increment, &third));
    list.notify();

    try std.testing.expectEqual(@as(usize, 0), first);
    try std.testing.expectEqual(@as(usize, 1), second);
    try std.testing.expectEqual(@as(usize, 1), third);
}
