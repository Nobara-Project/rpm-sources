//! Benchmarks for otter-conf parsing performance.
//!
//! Run with: zig build bench
//!
//! This benchmark compares:
//! - Memory-mapped (mmap) file loading
//! - Direct slice parsing (baseline, no file I/O)

const std = @import("std");
const otter = @import("root.zig");

/// Benchmark configuration struct - simulates a real-world config.
const BenchConfig = struct {
    // Strings
    name: []const u8 = "",
    description: []const u8 = "",
    author: []const u8 = "",
    version: []const u8 = "",

    // Numbers
    port: u16 = 0,
    max_connections: i32 = 0,
    timeout_ms: i64 = 0,
    buffer_size: u32 = 0,

    // Floats
    rate_limit: f64 = 0.0,
    threshold: f32 = 0.0,

    // Booleans
    enabled: bool = false,
    debug: bool = false,
    verbose: bool = false,

    // Enums
    log_level: enum { Debug, Info, Warn, Error } = .Info,
    mode: enum { Development, Staging, Production } = .Development,

    // Arrays
    allowed_hosts: []const []const u8 = &[_][]const u8{},
    ports: []const i64 = &[_]i64{},
};

const SizeCategory = enum { small, medium, large, huge };

/// Generate test config content of specified size category.
fn generateConfig(allocator: std.mem.Allocator, size_category: SizeCategory) ![]const u8 {
    var buffer: std.ArrayList(u8) = .empty;
    errdefer buffer.deinit(allocator);
    var allocating_writer: std.Io.Writer.Allocating = .fromArrayList(allocator, &buffer);
    defer buffer = allocating_writer.toArrayList();
    const writer = &allocating_writer.writer;

    // Base config
    try writer.writeAll(
        \\# Benchmark configuration file
        \\name = "benchmark-test-config"
        \\description = "A configuration file for benchmarking otter-conf performance"
        \\author = "otter-conf benchmark suite"
        \\version = "1.0.0"
        \\
        \\port = 8080
        \\max_connections = 1000
        \\timeout_ms = 30000
        \\buffer_size = 65536
        \\
        \\rate_limit = 100.5
        \\threshold = 0.95
        \\
        \\enabled = true
        \\debug = false
        \\verbose = true
        \\
        \\log_level = Info
        \\mode = Production
        \\
        \\allowed_hosts = ["localhost", "127.0.0.1", "example.com"]
        \\ports = [80, 443, 8080, 8443]
        \\
    );

    // Add padding based on size category
    const padding_lines: usize = switch (size_category) {
        .small => 0, // ~500 bytes
        .medium => 100, // ~5KB
        .large => 1000, // ~50KB
        .huge => 10000, // ~500KB
    };

    for (0..padding_lines) |i| {
        try writer.print("# Comment line {d} - padding to increase file size for benchmarking\n", .{i});
    }

    return buffer.toOwnedSlice(allocator);
}

/// Timer helper for benchmarking.
const Timer = struct {
    start: i128,

    fn begin() Timer {
        return .{ .start = std.Io.Clock.Timestamp.now(std.Options.debug_io, .awake).raw.nanoseconds };
    }

    fn elapsed(self: Timer) u64 {
        const end = std.Io.Clock.Timestamp.now(std.Options.debug_io, .awake).raw.nanoseconds;
        return @intCast(end - self.start);
    }

    fn elapsedMs(self: Timer) f64 {
        return @as(f64, @floatFromInt(self.elapsed())) / 1_000_000.0;
    }
};

/// Benchmark result.
const BenchResult = struct {
    name: []const u8,
    iterations: usize,
    total_ns: u64,
    min_ns: u64,
    max_ns: u64,

    fn avgNs(self: BenchResult) u64 {
        return self.total_ns / self.iterations;
    }

    fn avgMs(self: BenchResult) f64 {
        return @as(f64, @floatFromInt(self.avgNs())) / 1_000_000.0;
    }

    fn opsPerSec(self: BenchResult) f64 {
        const avg_secs = @as(f64, @floatFromInt(self.avgNs())) / 1_000_000_000.0;
        return 1.0 / avg_secs;
    }
};

/// Run benchmark for mmap file loading.
fn runMmapBenchmark(
    allocator: std.mem.Allocator,
    content: []const u8,
    iterations: usize,
    tmp_path: []const u8,
) !BenchResult {
    // Write content to temp file
    {
        const file = try std.Io.Dir.createFileAbsolute(std.Options.debug_io, tmp_path, .{});
        defer file.close(std.Options.debug_io);
        try file.writeStreamingAll(std.Options.debug_io, content);
    }

    var total_ns: u64 = 0;
    var min_ns: u64 = std.math.maxInt(u64);
    var max_ns: u64 = 0;

    // Warmup
    for (0..5) |_| {
        var config = try otter.load(BenchConfig, allocator, tmp_path, .{});
        otter.freeConfig(BenchConfig, allocator, &config);
    }

    // Actual benchmark
    for (0..iterations) |_| {
        const timer = Timer.begin();
        var config = try otter.load(BenchConfig, allocator, tmp_path, .{});
        const ns = timer.elapsed();

        otter.freeConfig(BenchConfig, allocator, &config);

        total_ns += ns;
        min_ns = @min(min_ns, ns);
        max_ns = @max(max_ns, ns);
    }

    return .{
        .name = "mmap",
        .iterations = iterations,
        .total_ns = total_ns,
        .min_ns = min_ns,
        .max_ns = max_ns,
    };
}

/// Run benchmark for direct slice parsing (no file I/O).
fn runSliceBenchmark(
    allocator: std.mem.Allocator,
    content: []const u8,
    iterations: usize,
) !BenchResult {
    var total_ns: u64 = 0;
    var min_ns: u64 = std.math.maxInt(u64);
    var max_ns: u64 = 0;

    // Warmup
    for (0..5) |_| {
        var config = try otter.loadFromSlice(BenchConfig, allocator, content);
        otter.freeConfig(BenchConfig, allocator, &config);
    }

    // Actual benchmark
    for (0..iterations) |_| {
        const timer = Timer.begin();
        var config = try otter.loadFromSlice(BenchConfig, allocator, content);
        const ns = timer.elapsed();

        otter.freeConfig(BenchConfig, allocator, &config);

        total_ns += ns;
        min_ns = @min(min_ns, ns);
        max_ns = @max(max_ns, ns);
    }

    return .{
        .name = "slice (no I/O)",
        .iterations = iterations,
        .total_ns = total_ns,
        .min_ns = min_ns,
        .max_ns = max_ns,
    };
}

fn printResult(result: BenchResult, size_bytes: usize) void {
    const throughput = @as(f64, @floatFromInt(size_bytes)) / (@as(f64, @floatFromInt(result.avgNs())) / 1_000_000_000.0) / (1024.0 * 1024.0);

    std.debug.print("  {s:<15} avg: {d:>8.3} ms  min: {d:>8.3} ms  max: {d:>8.3} ms  {d:>10.0} ops/s  {d:>6.1} MB/s\n", .{
        result.name,
        result.avgMs(),
        @as(f64, @floatFromInt(result.min_ns)) / 1_000_000.0,
        @as(f64, @floatFromInt(result.max_ns)) / 1_000_000.0,
        result.opsPerSec(),
        throughput,
    });
}

pub fn main() !void {
    const allocator = std.heap.smp_allocator;

    std.debug.print("\n", .{});
    std.debug.print("╔══════════════════════════════════════════════════════════════════════════════╗\n", .{});
    std.debug.print("║                        otter-conf Performance Benchmark                      ║\n", .{});
    std.debug.print("╚══════════════════════════════════════════════════════════════════════════════╝\n", .{});
    std.debug.print("\n", .{});

    // Create temp directory
    const tmp_dir = "/tmp/otter-conf-bench";
    std.Io.Dir.createDirAbsolute(std.Options.debug_io, tmp_dir, .{}) catch {};

    const tmp_path = tmp_dir ++ "/bench.conf";
    defer std.Io.Dir.deleteFileAbsolute(std.Options.debug_io, tmp_path) catch {};

    const size_configs = .{
        .{ SizeCategory.small, "Small (~500B)", @as(usize, 10000) },
        .{ SizeCategory.medium, "Medium (~5KB)", @as(usize, 5000) },
        .{ SizeCategory.large, "Large (~50KB)", @as(usize, 1000) },
        .{ SizeCategory.huge, "Huge (~500KB)", @as(usize, 100) },
    };

    inline for (size_configs) |size_config| {
        const cat = size_config[0];
        const name = size_config[1];
        const iters = size_config[2];

        const content = try generateConfig(allocator, cat);
        defer allocator.free(content);

        std.debug.print("━━━ {s} ({d} bytes, {d} iterations) ━━━\n", .{ name, content.len, iters });

        const slice_result = try runSliceBenchmark(allocator, content, iters);
        printResult(slice_result, content.len);

        const mmap_result = try runMmapBenchmark(allocator, content, iters, tmp_path);
        printResult(mmap_result, content.len);

        // Show overhead from file I/O
        const overhead = @as(f64, @floatFromInt(mmap_result.avgNs())) / @as(f64, @floatFromInt(slice_result.avgNs()));
        std.debug.print("  I/O overhead: {d:.2}x\n", .{overhead});
        std.debug.print("\n", .{});
    }

    std.debug.print("╔══════════════════════════════════════════════════════════════════════════════╗\n", .{});
    std.debug.print("║                              Benchmark Complete                              ║\n", .{});
    std.debug.print("╚══════════════════════════════════════════════════════════════════════════════╝\n", .{});
}
