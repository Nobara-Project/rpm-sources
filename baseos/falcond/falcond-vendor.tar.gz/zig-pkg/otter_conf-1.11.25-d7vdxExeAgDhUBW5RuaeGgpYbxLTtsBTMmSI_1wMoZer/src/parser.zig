const std = @import("std");
const support = @import("parser_support.zig");

pub const ParseError = support.ParseError;
pub const max_dynamic_entries = support.max_dynamic_entries;
const hasParseFn = support.hasParseFn;
const isContainerStruct = support.isContainerStruct;
const freeOwnedFieldValue = support.freeOwnedFieldValue;

/// Comptime-generic configuration parser.
/// Supports:
///   - Flat fields: `key = value` maps to `config.key`
///   - Nested struct flattening: `prefix_field = value` maps to `config.prefix.field`
///   - Custom value types: structs with `pub fn parse([]const u8) !@This()` are parsed from strings
///   - All standard types: bool, int, float, enum, optional, string, arrays, slices
pub fn Parser(comptime T: type) type {
    comptime {
        @setEvalBranchQuota(20_000);
    }
    return struct {
        const Self = @This();

        content: []const u8,
        pos: usize = 0,
        allocator: std.mem.Allocator,

        pub fn init(allocator: std.mem.Allocator, content: []const u8) Self {
            return .{
                .content = content,
                .allocator = allocator,
            };
        }

        inline fn skipWhitespace(self: *Self) void {
            support.skipWhitespace(self);
        }

        inline fn parseString(self: *Self) ![]const u8 {
            if (self.pos >= self.content.len or self.content[self.pos] != '"') {
                return error.InvalidSyntax;
            }
            self.pos += 1;
            const start = self.pos;
            const remaining = self.content[start..];

            if (std.mem.indexOfScalar(u8, remaining, '"')) |quote_offset| {
                if (std.mem.indexOfScalar(u8, remaining[0..quote_offset], '\\')) |_| {
                    return self.parseStringWithEscapes();
                }
                const slice = remaining[0..quote_offset];
                self.pos = start + quote_offset + 1;
                const result = try self.allocator.alloc(u8, slice.len);
                @memcpy(result, slice);
                return result;
            }
            return error.UnterminatedString;
        }

        fn parseStringWithEscapes(self: *Self) ![]const u8 {
            var result: std.ArrayListUnmanaged(u8) = .empty;
            errdefer result.deinit(self.allocator);

            while (self.pos < self.content.len) {
                const c = self.content[self.pos];
                self.pos += 1;

                switch (c) {
                    '"' => return try result.toOwnedSlice(self.allocator),
                    '\\' => {
                        if (self.pos >= self.content.len) return error.UnterminatedString;
                        const esc = self.content[self.pos];
                        self.pos += 1;
                        const replacement: u8 = switch (esc) {
                            '"' => '"',
                            '\\' => '\\',
                            'n' => '\n',
                            'r' => '\r',
                            't' => '\t',
                            '0' => 0,
                            else => return error.InvalidSyntax,
                        };
                        try result.append(self.allocator, replacement);
                    },
                    else => try result.append(self.allocator, c),
                }
            }
            return error.UnterminatedString;
        }

        inline fn parseNumber(self: *Self) !i64 {
            return support.parseNumber(self);
        }

        inline fn parseNumberAs(self: *Self, comptime IntType: type) !IntType {
            return support.parseNumberAs(self, IntType);
        }

        inline fn parseFloat(self: *Self) !f64 {
            return support.parseFloat(self);
        }

        fn parseListElem(self: *Self, comptime Elem: type) !Elem {
            if (comptime Elem == i64) return try self.parseNumber();
            if (comptime Elem == f64) return try self.parseFloat();
            if (comptime Elem == bool) return try self.parseBool();
            if (comptime Elem == []const u8) return try self.parseString();
            @compileError("unsupported config list element type");
        }

        fn parseList(self: *Self, comptime Elem: type) ![]const Elem {
            if (self.pos >= self.content.len or self.content[self.pos] != '[')
                return error.InvalidSyntax;

            self.pos += 1;
            var values: std.ArrayListUnmanaged(Elem) = .empty;
            errdefer {
                if (comptime Elem == []const u8) {
                    for (values.items) |str| self.allocator.free(str);
                }
                values.deinit(self.allocator);
            }

            while (self.pos < self.content.len) {
                self.skipWhitespace();
                if (self.pos >= self.content.len) return error.InvalidSyntax;

                if (self.content[self.pos] == ']') {
                    self.pos += 1;
                    return values.toOwnedSlice(self.allocator);
                }

                if (values.items.len >= max_dynamic_entries) return error.ListTooLong;

                const value = try self.parseListElem(Elem);
                if (comptime Elem == []const u8) {
                    var appended = false;
                    errdefer if (!appended) self.allocator.free(value);
                    try values.append(self.allocator, value);
                    appended = true;
                } else {
                    try values.append(self.allocator, value);
                }

                self.skipWhitespace();
                if (self.pos >= self.content.len) return error.InvalidSyntax;

                if (self.content[self.pos] == ',') {
                    self.pos += 1;
                    continue;
                }
                if (self.content[self.pos] == ']') {
                    self.pos += 1;
                    return values.toOwnedSlice(self.allocator);
                }
                return error.InvalidSyntax;
            }
            return error.InvalidSyntax;
        }

        inline fn parseArray(self: *Self) ![]const i64 {
            return self.parseList(i64);
        }

        fn parseFloatArray(self: *Self) ![]const f64 {
            return self.parseList(f64);
        }

        fn parseBoolArray(self: *Self) ![]const bool {
            return self.parseList(bool);
        }

        fn parseStringArray(self: *Self) ![]const []const u8 {
            return self.parseList([]const u8);
        }

        inline fn parseIdentifier(self: *Self) ![]const u8 {
            return support.parseIdentifier(self);
        }

        inline fn parseBool(self: *Self) !bool {
            return support.parseBool(self);
        }

        /// Skip past the value on the current line (unknown field handling).
        /// Handles quoted strings with escapes, bare values, and inline comments.
        fn skipValue(self: *Self) void {
            support.skipValue(self);
        }

        fn fieldIndex(name: []const u8) ?usize {
            const fields = std.meta.fields(T);
            inline for (fields, 0..) |field, i| {
                if (std.mem.eql(u8, name, field.name)) {
                    return i;
                }
            }
            return null;
        }

        inline fn setEnumValue(self: *Self, comptime EnumType: type, ptr: *EnumType) !void {
            const ident = try self.parseIdentifier();
            var found = false;
            inline for (std.meta.fields(EnumType)) |enum_field| {
                if (!found and std.mem.eql(u8, ident, enum_field.name)) {
                    ptr.* = @field(EnumType, enum_field.name);
                    found = true;
                }
            }
            if (!found) return error.InvalidEnum;
        }

        inline fn setRequiredFieldValue(self: *Self, comptime FieldType: type, ptr: *FieldType) !void {
            comptime {
                @setEvalBranchQuota(20_000);
            }
            switch (@typeInfo(FieldType)) {
                .bool => {
                    ptr.* = try self.parseBool();
                },
                .int => {
                    ptr.* = try self.parseNumberAs(FieldType);
                },
                .float => {
                    ptr.* = @floatCast(try self.parseFloat());
                },
                .@"struct" => {
                    if (comptime hasParseFn(FieldType)) {
                        const str = try self.parseString();
                        defer self.allocator.free(str);
                        ptr.* = FieldType.parse(str) catch return;
                    } else {
                        return error.InvalidSyntax;
                    }
                },
                .@"enum" => {
                    try self.setEnumValue(FieldType, ptr);
                },
                .pointer => |ptr_info| {
                    if (ptr_info.size != .slice) {
                        return error.InvalidSyntax;
                    }

                    if (ptr_info.child == []const u8) {
                        ptr.* = try self.parseStringArray();
                    } else switch (ptr_info.child) {
                        u8 => {
                            ptr.* = try self.parseString();
                        },
                        i64 => {
                            ptr.* = try self.parseArray();
                        },
                        f64 => {
                            ptr.* = try self.parseFloatArray();
                        },
                        else => {
                            return error.InvalidSyntax;
                        },
                    }
                },
                .array => |array_info| {
                    if (array_info.child == u8) {
                        const str = try self.parseString();
                        defer self.allocator.free(str);
                        const copy_len = @min(str.len, array_info.len);
                        @memset(ptr, 0);
                        @memcpy(ptr[0..copy_len], str[0..copy_len]);
                    } else if (array_info.child == i64 or @typeInfo(array_info.child) == .int) {
                        const array = try self.parseArray();
                        defer self.allocator.free(array);
                        const copy_len = @min(array.len, array_info.len);
                        for (0..copy_len) |i| {
                            ptr[i] = @intCast(array[i]);
                        }
                    } else if (array_info.child == f64 or @typeInfo(array_info.child) == .float) {
                        const array = try self.parseFloatArray();
                        defer self.allocator.free(array);
                        const copy_len = @min(array.len, array_info.len);
                        for (0..copy_len) |i| {
                            ptr[i] = @floatCast(array[i]);
                        }
                    } else if (array_info.child == bool) {
                        const array = try self.parseBoolArray();
                        defer self.allocator.free(array);
                        const copy_len = @min(array.len, array_info.len);
                        for (0..copy_len) |i| {
                            ptr[i] = array[i];
                        }
                    } else {
                        return error.InvalidSyntax;
                    }
                },
                else => return error.InvalidSyntax,
            }
        }

        inline fn setOptionalFieldValue(self: *Self, comptime Child: type, ptr: *?Child) !void {
            switch (@typeInfo(Child)) {
                .@"struct" => {
                    if (comptime hasParseFn(Child)) {
                        const str = try self.parseString();
                        defer self.allocator.free(str);
                        if (str.len == 0) return;
                        ptr.* = Child.parse(str) catch return;
                    } else {
                        return error.InvalidSyntax;
                    }
                },
                .@"enum" => {
                    var value: Child = undefined;
                    try self.setEnumValue(Child, &value);
                    ptr.* = value;
                },
                .pointer => |ptr_info| {
                    if (ptr_info.size == .slice and ptr_info.child == u8) {
                        const str = try self.parseString();
                        if (str.len == 0) {
                            self.allocator.free(str);
                            return;
                        }
                        ptr.* = str;
                    } else {
                        return error.InvalidSyntax;
                    }
                },
                .int, .float, .bool => {
                    var value: Child = undefined;
                    try self.setRequiredFieldValue(Child, &value);
                    ptr.* = value;
                },
                else => return error.InvalidSyntax,
            }
        }

        /// Parse a config value into the given field pointer based on comptime type.
        /// Handles all supported types including custom parse types and optionals.
        inline fn setFieldValue(self: *Self, comptime FieldType: type, ptr: *FieldType) !void {
            comptime {
                @setEvalBranchQuota(20_000);
            }
            switch (@typeInfo(FieldType)) {
                .optional => |opt_info| {
                    try self.setOptionalFieldValue(opt_info.child, ptr);
                },
                else => try self.setRequiredFieldValue(FieldType, ptr),
            }
        }

        /// Comptime tuple of staging slots, one per Dynamic field in T.
        const StagingTuple = blk: {
            var dynamic_field_count: usize = 0;
            for (std.meta.fields(T)) |f| {
                if (@import("dynamic.zig").isDynamic(f.type)) {
                    dynamic_field_count += 1;
                }
            }
            var field_names: [dynamic_field_count][]const u8 = undefined;
            var field_types: [dynamic_field_count]type = undefined;
            var field_attrs: [dynamic_field_count]std.builtin.Type.StructField.Attributes = undefined;
            var i: usize = 0;
            for (std.meta.fields(T)) |f| {
                if (@import("dynamic.zig").isDynamic(f.type)) {
                    const Staging = struct {
                        arena_ptr: *std.heap.ArenaAllocator,
                        arena_alloc: std.mem.Allocator,
                        entries: std.ArrayListUnmanaged(f.type.Elem),
                        initialized: bool,

                        fn ensureLen(self: *@This(), n: usize) !void {
                            while (self.entries.items.len < n) {
                                try self.entries.append(self.arena_alloc, .{});
                            }
                        }
                    };
                    field_names[i] = f.name;
                    field_types[i] = Staging;
                    field_attrs[i] = .{
                        .default_value_ptr = null,
                        .@"comptime" = false,
                        .@"align" = @alignOf(Staging),
                    };
                    i += 1;
                }
            }
            break :blk @Struct(.auto, null, &field_names, &field_types, &field_attrs);
        };

        fn ensureDynStaging(
            self: *Self,
            comptime DynField: type,
            st: anytype,
        ) !void {
            if (st.initialized) return;
            const arena = try self.allocator.create(std.heap.ArenaAllocator);
            arena.* = std.heap.ArenaAllocator.init(self.allocator);
            st.arena_ptr = arena;
            st.arena_alloc = arena.allocator();
            st.initialized = true;
            _ = DynField;
        }

        fn consumeDynamicBare(
            self: *Self,
            comptime DynField: type,
            st: anytype,
        ) !void {
            try self.ensureDynStaging(DynField, st);
            const Elem = DynField.Elem;
            var entry: Elem = .{};
            try self.consumeDynamicElemValue(Elem, &entry, st.arena_alloc);
            try st.entries.append(st.arena_alloc, entry);
        }

        fn consumeDynamicElemValue(
            self: *Self,
            comptime Elem: type,
            out: *Elem,
            arena_alloc: std.mem.Allocator,
        ) !void {
            if (comptime hasParseFn(Elem)) {
                const str = try self.parseString();
                defer self.allocator.free(str);
                const str_in_arena = try arena_alloc.dupe(u8, str);
                out.* = Elem.parse(str_in_arena) catch return;
                return;
            }
            if (comptime @typeInfo(Elem) == .@"struct") {
                const fs = std.meta.fields(Elem);
                if (fs.len == 1 and @typeInfo(fs[0].type) == .pointer) {
                    const prev = self.allocator;
                    defer self.allocator = prev;
                    self.allocator = arena_alloc;
                    @field(out.*, fs[0].name) = try self.parseString();
                    return;
                }
            }
            return error.InvalidSyntax;
        }

        fn setDynamicSubField(
            self: *Self,
            comptime Elem: type,
            out: *Elem,
            sub_name: []const u8,
            arena_alloc: std.mem.Allocator,
        ) !void {
            const fs = std.meta.fields(Elem);
            inline for (fs) |sf| {
                if (std.mem.eql(u8, sub_name, sf.name)) {
                    if (comptime @typeInfo(sf.type) == .array and @typeInfo(sf.type).array.child == u8) {
                        const str = try self.parseString();
                        defer self.allocator.free(str);
                        const copy_len = @min(str.len, @typeInfo(sf.type).array.len);
                        @memset(&@field(out.*, sf.name), 0);
                        @memcpy(@field(out.*, sf.name)[0..copy_len], str[0..copy_len]);

                        const len_field_name = comptime sf.name ++ "_len";
                        inline for (fs) |len_field| {
                            if (comptime std.mem.eql(u8, len_field_name, len_field.name)) {
                                if (@typeInfo(len_field.type) == .int) {
                                    @field(out.*, len_field.name) = @intCast(copy_len);
                                }
                            }
                        }
                        return;
                    }
                    const prev = self.allocator;
                    defer self.allocator = prev;
                    self.allocator = arena_alloc;
                    try self.setFieldValue(sf.type, &@field(out.*, sf.name));
                    return;
                }
            }
            self.skipValue();
        }

        pub fn parse(self: *Self) !T {
            comptime {
                @setEvalBranchQuota(20_000);
            }
            const dynamic = @import("dynamic.zig");

            var result: T = .{};
            const defaults: T = .{};
            const fields = std.meta.fields(T);

            var staging: StagingTuple = undefined;
            inline for (fields) |f| {
                if (comptime dynamic.isDynamic(f.type)) {
                    @field(staging, f.name) = .{
                        .arena_ptr = undefined,
                        .arena_alloc = undefined,
                        .entries = .empty,
                        .initialized = false,
                    };
                }
            }

            errdefer {
                inline for (fields) |f| {
                    if (comptime dynamic.isDynamic(f.type)) {
                        if (@field(staging, f.name).initialized) {
                            @field(staging, f.name).arena_ptr.deinit();
                            self.allocator.destroy(@field(staging, f.name).arena_ptr);
                        }
                    }
                }
            }

            while (self.pos < self.content.len) {
                self.skipWhitespace();
                if (self.pos >= self.content.len) break;

                const field_name = try self.parseIdentifier();
                self.skipWhitespace();

                if (self.pos >= self.content.len or self.content[self.pos] != '=')
                    return error.InvalidSyntax;
                self.pos += 1;

                self.skipWhitespace();

                if (fieldIndex(field_name)) |field_idx| {
                    switch (field_idx) {
                        inline 0...fields.len - 1 => |idx| {
                            const field = fields[idx];
                            if (comptime dynamic.isDynamic(field.type)) {
                                try self.consumeDynamicBare(
                                    field.type,
                                    &@field(staging, field.name),
                                );
                            } else {
                                freeOwnedFieldValue(
                                    field.type,
                                    self.allocator,
                                    &@field(result, field.name),
                                    &@field(defaults, field.name),
                                );
                                errdefer @field(result, field.name) = @field(defaults, field.name);
                                try self.setFieldValue(
                                    field.type,
                                    &@field(result, field.name),
                                );
                            }
                        },
                        else => unreachable,
                    }
                    continue;
                }

                var matched = false;
                inline for (fields) |outer_field| {
                    if (comptime isContainerStruct(outer_field.type)) {
                        if (!matched and
                            field_name.len > outer_field.name.len and
                            field_name[outer_field.name.len] == '_' and
                            std.mem.eql(u8, field_name[0..outer_field.name.len], outer_field.name))
                        {
                            const inner_name = field_name[outer_field.name.len + 1 ..];
                            inline for (std.meta.fields(outer_field.type)) |inner_field| {
                                if (!matched and std.mem.eql(u8, inner_name, inner_field.name)) {
                                    const default_outer = @field(defaults, outer_field.name);
                                    freeOwnedFieldValue(
                                        inner_field.type,
                                        self.allocator,
                                        &@field(@field(result, outer_field.name), inner_field.name),
                                        &@field(default_outer, inner_field.name),
                                    );
                                    errdefer @field(
                                        @field(result, outer_field.name),
                                        inner_field.name,
                                    ) = @field(default_outer, inner_field.name);
                                    try self.setFieldValue(
                                        inner_field.type,
                                        &@field(@field(result, outer_field.name), inner_field.name),
                                    );
                                    matched = true;
                                }
                            }
                        }
                    }
                }

                if (!matched) {
                    inline for (fields) |dyn_field| {
                        if (comptime dynamic.isDynamic(dyn_field.type)) {
                            const dp = dyn_field.type.prefix;
                            if (!matched and std.mem.eql(u8, field_name, dp)) {
                                try self.consumeDynamicBare(
                                    dyn_field.type,
                                    &@field(staging, dyn_field.name),
                                );
                                matched = true;
                            }
                            if (!matched and
                                field_name.len > dp.len and
                                field_name[dp.len] == '_' and
                                std.mem.eql(u8, field_name[0..dp.len], dp))
                            {
                                const after_prefix = field_name[dp.len + 1 ..];
                                const underscore = std.mem.indexOfScalar(u8, after_prefix, '_');
                                const idx_str = if (underscore) |u| after_prefix[0..u] else after_prefix;
                                if (std.fmt.parseInt(usize, idx_str, 10)) |idx| {
                                    if (idx >= max_dynamic_entries) return error.ArrayTooLarge;
                                    try self.ensureDynStaging(dyn_field.type, &@field(staging, dyn_field.name));
                                    try @field(staging, dyn_field.name).ensureLen(idx + 1);
                                    const entry_ptr = &@field(staging, dyn_field.name).entries.items[idx];
                                    if (underscore) |u| {
                                        const sub_name = after_prefix[u + 1 ..];
                                        try self.setDynamicSubField(
                                            dyn_field.type.Elem,
                                            entry_ptr,
                                            sub_name,
                                            @field(staging, dyn_field.name).arena_alloc,
                                        );
                                    } else {
                                        try self.consumeDynamicElemValue(
                                            dyn_field.type.Elem,
                                            entry_ptr,
                                            @field(staging, dyn_field.name).arena_alloc,
                                        );
                                    }
                                    matched = true;
                                } else |_| {}
                            }
                        }
                    }
                }

                if (!matched) {
                    self.skipValue();
                }
            }

            inline for (fields) |f| {
                if (comptime dynamic.isDynamic(f.type)) {
                    const st = &@field(staging, f.name);
                    if (st.initialized) {
                        const owned = try st.arena_alloc.alloc(f.type.Elem, st.entries.items.len);
                        @memcpy(owned, st.entries.items);
                        @field(result, f.name) = .{
                            .arena = st.arena_ptr,
                            .items = owned,
                        };
                    }
                }
            }

            return result;
        }
    };
}

// ============================================================================
