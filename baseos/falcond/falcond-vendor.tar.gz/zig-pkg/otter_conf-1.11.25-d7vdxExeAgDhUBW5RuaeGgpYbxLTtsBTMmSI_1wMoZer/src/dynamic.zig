//! Dynamic(T, prefix) — an unbounded, prefix-addressed slice of T.
//!
//! The parser detects fields of this type via a comptime marker and absorbs
//! any key matching `prefix`, `prefix_<N>`, or `prefix_<N>_<field>` into the
//! slice. Ownership: the Dynamic arena owns the backing slice and any strings
//! allocated by `T.parse` or nested struct field parsing.
//!
//! Usage:
//!     const Bind = struct {
//!         mods: u32 = 0,
//!         key: []const u8 = "",
//!         action: []const u8 = "",
//!     };
//!
//!     const Config = struct {
//!         binds: otter_conf.Dynamic(Bind, "bind") = .{},
//!     };
const std = @import("std");

pub fn Dynamic(comptime Elem_: type, comptime prefix_: []const u8) type {
    return struct {
        const Self = @This();

        /// Marker declaration. The parser and serializer detect Dynamic fields
        /// by `@hasDecl(FieldType, "__otter_conf_dynamic_marker")`.
        pub const __otter_conf_dynamic_marker = {};
        pub const Elem: type = Elem_;
        pub const prefix: []const u8 = prefix_;

        /// Arena backing the `items` slice and any strings inside them.
        /// `null` means the Dynamic is empty and owns nothing (default).
        arena: ?*std.heap.ArenaAllocator = null,
        items: []Elem_ = &.{},

        pub fn deinit(self: *Self, gpa: std.mem.Allocator) void {
            if (self.arena) |arena_ptr| {
                arena_ptr.deinit();
                gpa.destroy(arena_ptr);
            }
            self.* = .{};
        }

        pub fn len(self: Self) usize {
            return self.items.len;
        }

        pub fn slice(self: Self) []const Elem_ {
            return self.items;
        }
    };
}

/// Comptime predicate: is `T` a `Dynamic(_, _)` instantiation?
pub fn isDynamic(comptime T: type) bool {
    if (@typeInfo(T) != .@"struct") return false;
    return @hasDecl(T, "__otter_conf_dynamic_marker");
}

test "isDynamic true for Dynamic instantiation" {
    const Bind = struct { mods: u32 = 0, key: []const u8 = "" };
    const D = Dynamic(Bind, "bind");
    try std.testing.expect(isDynamic(D));
}

test "isDynamic false for regular struct" {
    const Plain = struct { x: u32 = 0 };
    try std.testing.expect(!isDynamic(Plain));
}

test "Dynamic default-initializes empty" {
    const Bind = struct { key: []const u8 = "" };
    var d: Dynamic(Bind, "bind") = .{};
    try std.testing.expectEqual(@as(usize, 0), d.len());
    try std.testing.expectEqual(@as(?*std.heap.ArenaAllocator, null), d.arena);
}
