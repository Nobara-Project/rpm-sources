const std = @import("std");
const Parser = @import("parser.zig").Parser;
const support = @import("parser_support.zig");
const hasParseFn = support.hasParseFn;
const isContainerStruct = support.isContainerStruct;

// Tests
// ============================================================================

const TestConfig = struct {
    // Boolean tests
    bool_true: bool = false,
    bool_false: bool = true,

    // Integer tests
    int_val: i64 = 0,

    // Float tests
    float_val: f64 = 0.0,

    // Array tests
    array_val: [4]i64 = .{ 0, 0, 0, 0 },

    // Enum tests
    enum_val: enum { First, Second, Third } = .Second,

    // String tests
    string_val: []const u8 = "",

    // Optional tests
    opt_int: ?i64 = null,

    // Slice tests
    int_slice: []const i64 = &[_]i64{},
    string_array: []const []const u8 = &[_][]const u8{},
};

test "parse all types" {
    const content =
        \\# This is a comment
        \\bool_true = true
        \\bool_false = false
        \\int_val = 42
        \\float_val = 3.14
        \\array_val = [1, 2, 3, 4]
        \\enum_val = First
        \\string_val = "hello world"
        \\opt_int = 999
        \\int_slice = [10, 20, 30]
        \\string_array = ["a", "b", "c"]
    ;

    var parser = Parser(TestConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer {
        std.testing.allocator.free(config.string_val);
        std.testing.allocator.free(config.int_slice);
        for (config.string_array) |s| std.testing.allocator.free(s);
        std.testing.allocator.free(config.string_array);
    }

    // Boolean tests
    try std.testing.expect(config.bool_true == true);
    try std.testing.expect(config.bool_false == false);

    // Integer tests
    try std.testing.expectEqual(@as(i64, 42), config.int_val);

    // Float tests
    try std.testing.expectApproxEqAbs(@as(f64, 3.14), config.float_val, 0.0001);

    // Array tests
    try std.testing.expectEqualSlices(i64, &[_]i64{ 1, 2, 3, 4 }, &config.array_val);

    // Enum tests
    try std.testing.expectEqual(@as(@TypeOf(config.enum_val), .First), config.enum_val);

    // String tests
    try std.testing.expectEqualStrings("hello world", config.string_val);

    // Optional tests
    try std.testing.expectEqual(@as(?i64, 999), config.opt_int);

    // Slice tests
    try std.testing.expectEqualSlices(i64, &[_]i64{ 10, 20, 30 }, config.int_slice);
    try std.testing.expectEqual(@as(usize, 3), config.string_array.len);
}

test "parse with defaults" {
    const SimpleConfig = struct {
        name: []const u8 = "default_name",
        count: u32 = 42,
        enabled: bool = true,
        ratio: f64 = 1.5,
    };

    const content =
        \\name = "custom"
    ;

    var parser = Parser(SimpleConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer std.testing.allocator.free(config.name);

    try std.testing.expectEqualStrings("custom", config.name);
    try std.testing.expectEqual(@as(u32, 42), config.count);
    try std.testing.expect(config.enabled == true);
    try std.testing.expectApproxEqAbs(@as(f64, 1.5), config.ratio, 0.0001);
}

test "parse empty content" {
    const SimpleConfig = struct {
        value: i64 = 100,
    };

    const content = "";

    var parser = Parser(SimpleConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(i64, 100), config.value);
}

test "parse with comments only" {
    const SimpleConfig = struct {
        value: i64 = 100,
    };

    const content =
        \\# Comment line 1
        \\# Comment line 2
        \\
        \\  # Indented comment
    ;

    var parser = Parser(SimpleConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(i64, 100), config.value);
}

test "parse string escapes" {
    const StringConfig = struct {
        text: []const u8 = "",
    };

    const content =
        \\text = "hello \"world\" and\\backslash"
    ;

    var parser = Parser(StringConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer std.testing.allocator.free(config.text);

    try std.testing.expectEqualStrings("hello \"world\" and\\backslash", config.text);
}

test "parse floats" {
    const FloatConfig = struct {
        val1: f64 = 0.0,
        val2: f32 = 0.0,
    };

    const content =
        \\val1 = 3.14159
        \\val2 = -2.5
    ;

    var parser = Parser(FloatConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectApproxEqAbs(@as(f64, 3.14159), config.val1, 0.0001);
    try std.testing.expectApproxEqAbs(@as(f32, -2.5), config.val2, 0.0001);
}

test "parse arrays" {
    const ArrayConfig = struct {
        ints: [3]i64 = .{ 0, 0, 0 },
        floats: [2]f64 = .{ 0.0, 0.0 },
    };

    const content =
        \\ints = [1, 2, 3]
        \\floats = [1.5, 2.5]
    ;

    var parser = Parser(ArrayConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqualSlices(i64, &[_]i64{ 1, 2, 3 }, &config.ints);
    try std.testing.expectApproxEqAbs(@as(f64, 1.5), config.floats[0], 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, 2.5), config.floats[1], 0.0001);
}

test "parse slices" {
    const SliceConfig = struct {
        int_slice: []const i64 = &[_]i64{},
        string_array: []const []const u8 = &[_][]const u8{},
    };

    const content =
        \\int_slice = [10, 20, 30]
        \\string_array = ["a", "b"]
    ;

    var parser = Parser(SliceConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer {
        std.testing.allocator.free(config.int_slice);
        for (config.string_array) |s| std.testing.allocator.free(s);
        std.testing.allocator.free(config.string_array);
    }

    try std.testing.expectEqualSlices(i64, &[_]i64{ 10, 20, 30 }, config.int_slice);
    try std.testing.expectEqual(@as(usize, 2), config.string_array.len);
}

test "parse integer sizes" {
    const IntConfig = struct {
        i8_val: i8 = 0,
        i16_val: i16 = 0,
        i32_val: i32 = 0,
        i64_val: i64 = 0,
        u8_val: u8 = 0,
        u16_val: u16 = 0,
        u32_val: u32 = 0,
        u64_val: u64 = 0,
    };

    const content =
        \\i8_val = 127
        \\i16_val = 32767
        \\i32_val = 2147483647
        \\i64_val = 9223372036854775807
        \\u8_val = 255
        \\u16_val = 65535
        \\u32_val = 4294967295
        \\u64_val = 18446744073709551615
    ;

    var parser = Parser(IntConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(i8, 127), config.i8_val);
    try std.testing.expectEqual(@as(i16, 32767), config.i16_val);
    try std.testing.expectEqual(@as(i32, 2147483647), config.i32_val);
    try std.testing.expectEqual(@as(i64, 9223372036854775807), config.i64_val);
    try std.testing.expectEqual(@as(u8, 255), config.u8_val);
    try std.testing.expectEqual(@as(u16, 65535), config.u16_val);
    try std.testing.expectEqual(@as(u32, 4294967295), config.u32_val);
    try std.testing.expectEqual(@as(u64, 18446744073709551615), config.u64_val);
}

test "parse negative integers" {
    const NegIntConfig = struct {
        neg_i8: i8 = 0,
        neg_i16: i16 = 0,
        neg_i32: i32 = 0,
        neg_i64: i64 = 0,
    };

    const content =
        \\neg_i8 = -128
        \\neg_i16 = -32768
        \\neg_i32 = -2147483648
        \\neg_i64 = -9223372036854775808
    ;

    var parser = Parser(NegIntConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(i8, -128), config.neg_i8);
    try std.testing.expectEqual(@as(i16, -32768), config.neg_i16);
    try std.testing.expectEqual(@as(i32, -2147483648), config.neg_i32);
    try std.testing.expectEqual(@as(i64, -9223372036854775808), config.neg_i64);
}

test "parse optional types" {
    const OptConfig = struct {
        opt_int: ?i64 = null,
        opt_float: ?f64 = null,
        opt_bool: ?bool = null,
        opt_string: ?[]const u8 = null,
        opt_enum: ?enum { A, B, C } = null,
    };

    const content =
        \\opt_int = 42
        \\opt_float = 3.14
        \\opt_bool = true
        \\opt_string = "hello"
        \\opt_enum = B
    ;

    var parser = Parser(OptConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer if (config.opt_string) |s| std.testing.allocator.free(s);

    try std.testing.expectEqual(@as(?i64, 42), config.opt_int);
    try std.testing.expectApproxEqAbs(@as(f64, 3.14), config.opt_float.?, 0.0001);
    try std.testing.expectEqual(@as(?bool, true), config.opt_bool);
    try std.testing.expectEqualStrings("hello", config.opt_string.?);
    try std.testing.expectEqual(@as(@TypeOf(config.opt_enum), .B), config.opt_enum);
}

test "parse optional defaults" {
    const OptDefaultConfig = struct {
        opt_int: ?i64 = null,
        opt_string: ?[]const u8 = null,
    };

    const content = "";

    var parser = Parser(OptDefaultConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(?i64, null), config.opt_int);
    try std.testing.expectEqual(@as(?[]const u8, null), config.opt_string);
}

test "parse optional string with non-null default override" {
    const Config = struct {
        command: ?[]const u8 = "default-command",
    };

    const content =
        \\command = "custom-command"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer if (config.command) |s| std.testing.allocator.free(s);

    try std.testing.expectEqualStrings("custom-command", config.command.?);
}

test "parse float variations" {
    const FloatVarConfig = struct {
        positive: f64 = 0.0,
        negative: f64 = 0.0,
        small: f64 = 0.0,
        whole: f64 = 0.0,
        f32_val: f32 = 0.0,
    };

    const content =
        \\positive = 123.456
        \\negative = -987.654
        \\small = 0.001
        \\whole = 42.0
        \\f32_val = 1.5
    ;

    var parser = Parser(FloatVarConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectApproxEqAbs(@as(f64, 123.456), config.positive, 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, -987.654), config.negative, 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, 0.001), config.small, 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, 42.0), config.whole, 0.0001);
    try std.testing.expectApproxEqAbs(@as(f32, 1.5), config.f32_val, 0.0001);
}

test "parse enum variations" {
    const EnumConfig = struct {
        level: enum { Debug, Info, Warn, Error } = .Info,
        mode: enum { Auto, Manual, Off } = .Auto,
        scheduler: enum { none, bpfland, rusty, lavd, flash } = .none,
    };

    const content =
        \\level = Error
        \\mode = Manual
        \\scheduler = flash
    ;

    var parser = Parser(EnumConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(@TypeOf(config.level), .Error), config.level);
    try std.testing.expectEqual(@as(@TypeOf(config.mode), .Manual), config.mode);
    try std.testing.expectEqual(@as(@TypeOf(config.scheduler), .flash), config.scheduler);
}

test "parse empty arrays" {
    const EmptyArrayConfig = struct {
        int_slice: []const i64 = &[_]i64{},
        string_array: []const []const u8 = &[_][]const u8{},
    };

    const content =
        \\int_slice = []
        \\string_array = []
    ;

    var parser = Parser(EmptyArrayConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer {
        std.testing.allocator.free(config.int_slice);
        std.testing.allocator.free(config.string_array);
    }

    try std.testing.expectEqual(@as(usize, 0), config.int_slice.len);
    try std.testing.expectEqual(@as(usize, 0), config.string_array.len);
}

test "parse empty string" {
    const EmptyStringConfig = struct {
        empty: []const u8 = "default",
        nonempty: []const u8 = "default",
    };

    const content =
        \\empty = ""
        \\nonempty = "hello"
    ;

    var parser = Parser(EmptyStringConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer {
        std.testing.allocator.free(config.empty);
        std.testing.allocator.free(config.nonempty);
    }

    try std.testing.expectEqualStrings("", config.empty);
    try std.testing.expectEqualStrings("hello", config.nonempty);
}

test "parse whitespace handling" {
    const WsConfig = struct {
        a: i64 = 0,
        b: i64 = 0,
        c: i64 = 0,
    };

    const content = "  a  =  1\n\tb\t=\t2\n\nc = 3";

    var parser = Parser(WsConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(i64, 1), config.a);
    try std.testing.expectEqual(@as(i64, 2), config.b);
    try std.testing.expectEqual(@as(i64, 3), config.c);
}

test "parse mixed comments" {
    const MixedConfig = struct {
        first: i64 = 0,
        second: i64 = 0,
        third: i64 = 0,
    };

    const content =
        \\# Header comment
        \\first = 1
        \\# Middle comment
        \\# Another comment
        \\second = 2
        \\third = 3 # inline style not supported, whole line is parsed
    ;

    var parser = Parser(MixedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(i64, 1), config.first);
    try std.testing.expectEqual(@as(i64, 2), config.second);
    // third = 3 # inline... - the # would be seen as start of field name, causing error
    // Actually let's check if this parses correctly
}

test "parse float arrays" {
    const FloatArrayConfig = struct {
        floats: []const f64 = &[_]f64{},
    };

    const content =
        \\floats = [1.1, 2.2, 3.3, -4.4]
    ;

    var parser = Parser(FloatArrayConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer std.testing.allocator.free(config.floats);

    try std.testing.expectEqual(@as(usize, 4), config.floats.len);
    try std.testing.expectApproxEqAbs(@as(f64, 1.1), config.floats[0], 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, 2.2), config.floats[1], 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, 3.3), config.floats[2], 0.0001);
    try std.testing.expectApproxEqAbs(@as(f64, -4.4), config.floats[3], 0.0001);
}

test "parse fixed size arrays" {
    const FixedArrayConfig = struct {
        ints: [5]i32 = .{ 0, 0, 0, 0, 0 },
        floats: [3]f32 = .{ 0.0, 0.0, 0.0 },
        bools: [2]bool = .{ false, false },
    };

    const content =
        \\ints = [1, 2, 3, 4, 5]
        \\floats = [1.5, 2.5, 3.5]
        \\bools = [true, false]
    ;

    var parser = Parser(FixedArrayConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqualSlices(i32, &[_]i32{ 1, 2, 3, 4, 5 }, &config.ints);
    try std.testing.expectApproxEqAbs(@as(f32, 1.5), config.floats[0], 0.0001);
    try std.testing.expectApproxEqAbs(@as(f32, 2.5), config.floats[1], 0.0001);
    try std.testing.expectApproxEqAbs(@as(f32, 3.5), config.floats[2], 0.0001);
    try std.testing.expectEqual(true, config.bools[0]);
    try std.testing.expectEqual(false, config.bools[1]);
}

test "parse string with special chars" {
    const SpecialCharConfig = struct {
        path: []const u8 = "",
        multiline: []const u8 = "",
    };

    const content =
        \\path = "/home/user/scripts/game_start.sh"
        \\multiline = "line1\nline2\ttabbed"
    ;

    var parser = Parser(SpecialCharConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer {
        std.testing.allocator.free(config.path);
        std.testing.allocator.free(config.multiline);
    }

    try std.testing.expectEqualStrings("/home/user/scripts/game_start.sh", config.path);
    try std.testing.expectEqualStrings("line1\nline2\ttabbed", config.multiline);
}

// ============================================================================
// Nested struct and custom type tests
// ============================================================================

const MockColor = packed struct(u32) {
    b: u8,
    g: u8,
    r: u8,
    a: u8,

    pub fn parse(str: []const u8) error{InvalidColor}!MockColor {
        if (str.len == 0) return error.InvalidColor;
        if (str[0] != '#' or str.len != 7) return error.InvalidColor;
        return .{
            .r = std.fmt.parseInt(u8, str[1..3], 16) catch return error.InvalidColor,
            .g = std.fmt.parseInt(u8, str[3..5], 16) catch return error.InvalidColor,
            .b = std.fmt.parseInt(u8, str[5..7], 16) catch return error.InvalidColor,
            .a = 0xFF,
        };
    }

    pub fn toStr(self: MockColor) [9]u8 {
        const hex = "0123456789ABCDEF";
        return .{ '#', hex[self.r >> 4], hex[self.r & 0xF], hex[self.g >> 4], hex[self.g & 0xF], hex[self.b >> 4], hex[self.b & 0xF], hex[self.a >> 4], hex[self.a & 0xF] };
    }
};

test "parse nested struct" {
    const Inner = struct {
        enabled: bool = false,
        count: u32 = 0,
    };
    const NestedConfig = struct {
        section: Inner = .{},
        other: i64 = 0,
    };

    const content =
        \\section_enabled = true
        \\section_count = 42
        \\other = 99
    ;

    var parser = Parser(NestedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expect(config.section.enabled);
    try std.testing.expectEqual(@as(u32, 42), config.section.count);
    try std.testing.expectEqual(@as(i64, 99), config.other);
}

test "parse custom type with parse fn" {
    const CustomConfig = struct {
        color: MockColor = .{ .r = 0, .g = 0, .b = 0, .a = 0xFF },
    };

    const content =
        \\color = "#FF8800"
    ;

    var parser = Parser(CustomConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(u8, 0xFF), config.color.r);
    try std.testing.expectEqual(@as(u8, 0x88), config.color.g);
    try std.testing.expectEqual(@as(u8, 0x00), config.color.b);
}

test "parse nested struct containing custom type" {
    const Inner = struct {
        text_color: MockColor = .{ .r = 0xFF, .g = 0xFF, .b = 0xFF, .a = 0xFF },
        enabled: bool = true,
    };
    const MixedConfig = struct {
        section: Inner = .{},
    };

    const content =
        \\section_text_color = "#00FF00"
        \\section_enabled = false
    ;

    var parser = Parser(MixedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqual(@as(u8, 0x00), config.section.text_color.r);
    try std.testing.expectEqual(@as(u8, 0xFF), config.section.text_color.g);
    try std.testing.expectEqual(@as(u8, 0x00), config.section.text_color.b);
    try std.testing.expect(!config.section.enabled);
}

test "direct field takes priority over nested prefix match" {
    const Inner = struct {
        b: i64 = 0,
    };
    const PriorityConfig = struct {
        a_b: i64 = 0,
        a: Inner = .{},
    };

    const content =
        \\a_b = 42
    ;

    var parser = Parser(PriorityConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    // Direct match a_b should win over nested a.b
    try std.testing.expectEqual(@as(i64, 42), config.a_b);
    try std.testing.expectEqual(@as(i64, 0), config.a.b);
}

test "nested defaults preserved when field not in config" {
    const Inner = struct {
        enabled: bool = true,
        count: u32 = 10,
    };
    const DefaultsConfig = struct {
        section: Inner = .{},
    };

    const content =
        \\section_count = 5
    ;

    var parser = Parser(DefaultsConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expect(config.section.enabled); // default preserved
    try std.testing.expectEqual(@as(u32, 5), config.section.count);
}

test "optional string empty becomes null" {
    const OptStringConfig = struct {
        name: ?[]const u8 = null,
        other: ?[]const u8 = null,
    };

    const content =
        \\name = ""
        \\other = "hello"
    ;

    var parser = Parser(OptStringConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer if (config.other) |s| std.testing.allocator.free(s);

    try std.testing.expectEqual(@as(?[]const u8, null), config.name);
    try std.testing.expectEqualStrings("hello", config.other.?);
}

test "custom type parse error keeps default" {
    const CustomConfig = struct {
        color: MockColor = .{ .r = 0xFF, .g = 0, .b = 0, .a = 0xFF },
    };

    const content =
        \\color = "not_a_color"
    ;

    var parser = Parser(CustomConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    // Default should be preserved on parse error
    try std.testing.expectEqual(@as(u8, 0xFF), config.color.r);
    try std.testing.expectEqual(@as(u8, 0), config.color.g);
}

test "nested struct with optional custom type" {
    const Inner = struct {
        color: ?MockColor = null,
        name: ?[]const u8 = null,
    };
    const OptNestedConfig = struct {
        section: Inner = .{},
    };

    const content =
        \\section_color = "#AABBCC"
        \\section_name = "test"
    ;

    var parser = Parser(OptNestedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer if (config.section.name) |s| std.testing.allocator.free(s);

    try std.testing.expect(config.section.color != null);
    try std.testing.expectEqual(@as(u8, 0xAA), config.section.color.?.r);
    try std.testing.expectEqualStrings("test", config.section.name.?);
}

test "nested struct with string fields" {
    const Inner = struct {
        icon: []const u8 = "default",
        label: []const u8 = "label",
    };
    const StringNestedConfig = struct {
        widget: Inner = .{},
    };

    const content =
        \\widget_icon = "custom_icon"
    ;

    var parser = Parser(StringNestedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer std.testing.allocator.free(config.widget.icon);

    try std.testing.expectEqualStrings("custom_icon", config.widget.icon);
    try std.testing.expectEqualStrings("label", config.widget.label); // default preserved
}

test "hasParseFn detects parse function" {
    try std.testing.expect(hasParseFn(MockColor));
    try std.testing.expect(!hasParseFn(bool));
    try std.testing.expect(!hasParseFn(u32));
}

test "isContainerStruct detects container structs" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Container = struct { x: i32 = 0 };
    const DynElem = struct { x: u32 = 0 };
    try std.testing.expect(isContainerStruct(Container));
    try std.testing.expect(!isContainerStruct(MockColor)); // has parse fn
    try std.testing.expect(!isContainerStruct(bool));
    try std.testing.expect(!isContainerStruct(Dynamic(DynElem, "dyn"))); // Dynamic is not nested-flattened
}

// ============================================================================
// Unknown field skip tests
// ============================================================================

test "skip unknown fields" {
    const SimpleConfig = struct {
        name: []const u8 = "default",
        count: u32 = 0,
        enabled: bool = false,
    };

    const content =
        \\name = "hello"
        \\unknown_bare = 42
        \\count = 7
        \\unknown_string = "ignored"
        \\unknown_array = [1, 2, 3]
        \\enabled = true
    ;

    var parser = Parser(SimpleConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer std.testing.allocator.free(config.name);

    try std.testing.expectEqualStrings("hello", config.name);
    try std.testing.expectEqual(@as(u32, 7), config.count);
    try std.testing.expect(config.enabled);
}

test "skip unknown fields with nested structs" {
    const Inner = struct {
        enabled: bool = false,
        count: u32 = 0,
    };
    const NestedConfig = struct {
        section: Inner = .{},
        other: i64 = 0,
    };

    const content =
        \\garbage_key = "skip me"
        \\section_enabled = true
        \\totally_fake = 999
        \\section_count = 42
        \\other = 99
        \\another_unknown = false
    ;

    var parser = Parser(NestedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expect(config.section.enabled);
    try std.testing.expectEqual(@as(u32, 42), config.section.count);
    try std.testing.expectEqual(@as(i64, 99), config.other);
}

test "skip unknown with custom type" {
    const Inner = struct {
        color: ?MockColor = null,
        name: []const u8 = "default",
    };
    const MixedConfig = struct {
        section: Inner = .{},
    };

    const content =
        \\removed_old_field = "whatever"
        \\section_color = "#AABBCC"
        \\section_name = "test"
        \\another_removed = 123
    ;

    var parser = Parser(MixedConfig).init(std.testing.allocator, content);
    const config = try parser.parse();
    defer std.testing.allocator.free(config.section.name);

    try std.testing.expect(config.section.color != null);
    try std.testing.expectEqual(@as(u8, 0xAA), config.section.color.?.r);
    try std.testing.expectEqualStrings("test", config.section.name);
}

test "skip unknown preserves defaults" {
    const SimpleConfig = struct {
        name: []const u8 = "default_name",
        count: u32 = 42,
        enabled: bool = true,
    };

    const content =
        \\unknown_a = "foo"
        \\unknown_b = 999
        \\unknown_c = false
    ;

    var parser = Parser(SimpleConfig).init(std.testing.allocator, content);
    const config = try parser.parse();

    try std.testing.expectEqualStrings("default_name", config.name);
    try std.testing.expectEqual(@as(u32, 42), config.count);
    try std.testing.expect(config.enabled);
}

test "Dynamic parse: prefix_N_field form" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Bind = struct {
        mods: u32 = 0,
        key: []const u8 = "",
        action: []const u8 = "",
    };
    const Config = struct {
        name: []const u8 = "",
        binds: Dynamic(Bind, "bind") = .{},
    };

    const content =
        \\name = "test"
        \\bind_0_mods = 1
        \\bind_0_key = "Return"
        \\bind_0_action = "spawn kitty"
        \\bind_1_mods = 4
        \\bind_1_key = "q"
        \\bind_1_action = "killclient"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    var cfg = try parser.parse();
    defer std.testing.allocator.free(cfg.name);
    defer cfg.binds.deinit(std.testing.allocator);

    try std.testing.expectEqualStrings("test", cfg.name);
    try std.testing.expectEqual(@as(usize, 2), cfg.binds.len());
    try std.testing.expectEqual(@as(u32, 1), cfg.binds.items[0].mods);
    try std.testing.expectEqualStrings("Return", cfg.binds.items[0].key);
    try std.testing.expectEqualStrings("spawn kitty", cfg.binds.items[0].action);
    try std.testing.expectEqual(@as(u32, 4), cfg.binds.items[1].mods);
    try std.testing.expectEqualStrings("q", cfg.binds.items[1].key);
    try std.testing.expectEqualStrings("killclient", cfg.binds.items[1].action);
}

test "Dynamic parse: bare prefix form appends in order" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Rule = struct {
        raw: []const u8 = "",
        pub fn parse(s: []const u8) !@This() {
            return .{ .raw = s };
        }
    };
    const Config = struct {
        binds: Dynamic(Rule, "bind") = .{},
    };

    const content =
        \\bind = "first"
        \\bind = "second"
        \\bind = "third"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    var cfg = try parser.parse();
    defer cfg.binds.deinit(std.testing.allocator);

    try std.testing.expectEqual(@as(usize, 3), cfg.binds.len());
    try std.testing.expectEqualStrings("first", cfg.binds.items[0].raw);
    try std.testing.expectEqualStrings("second", cfg.binds.items[1].raw);
    try std.testing.expectEqualStrings("third", cfg.binds.items[2].raw);
}

test "Dynamic parse: prefix_N bare value with T.parse" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const KeyBind = struct {
        raw: []const u8 = "",
        pub fn parse(s: []const u8) !@This() {
            return .{ .raw = s };
        }
    };
    const Config = struct {
        keybinds: Dynamic(KeyBind, "bind") = .{},
    };

    const content =
        \\bind_0 = "SUPER+Return,spawn,kitty"
        \\bind_1 = "SUPER+q,killclient"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    var cfg = try parser.parse();
    defer cfg.keybinds.deinit(std.testing.allocator);

    try std.testing.expectEqual(@as(usize, 2), cfg.keybinds.len());
    try std.testing.expectEqualStrings("SUPER+Return,spawn,kitty", cfg.keybinds.items[0].raw);
    try std.testing.expectEqualStrings("SUPER+q,killclient", cfg.keybinds.items[1].raw);
}

test "Dynamic parse rejects sparse index beyond cap" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Bind = struct {
        key: []const u8 = "",
    };
    const Config = struct {
        binds: Dynamic(Bind, "bind") = .{},
    };

    const content =
        \\bind_4096_key = "Return"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    try std.testing.expectError(error.ArrayTooLarge, parser.parse());
}

test "Dynamic parse rejects overflowing index" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Bind = struct {
        key: []const u8 = "",
    };
    const Config = struct {
        binds: Dynamic(Bind, "bind") = .{},
    };

    const content =
        \\bind_18446744073709551615_key = "Return"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    try std.testing.expectError(error.ArrayTooLarge, parser.parse());
}

test "parse duplicate string frees overwritten allocation" {
    const Config = struct {
        name: []const u8 = "",
    };

    const content =
        \\name = "first"
        \\name = "second"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    const cfg = try parser.parse();
    defer std.testing.allocator.free(cfg.name);

    try std.testing.expectEqualStrings("second", cfg.name);
}

test "Dynamic parse: fixed string buffers populate paired len fields" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Rule = struct {
        title_len: u8 = 0,
        title: [16]u8 = @splat(0),
        monitor_name_len: u8 = 0,
        monitor_name: [16]u8 = @splat(0),
        floating: bool = false,
    };
    const Config = struct {
        window_rule: Dynamic(Rule, "window_rule") = .{},
        tag_rule: Dynamic(Rule, "tag_rule") = .{},
    };

    const content =
        \\window_rule_0_title = "Dialog"
        \\window_rule_0_floating = true
        \\tag_rule_0_monitor_name = "DP-3"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    var cfg = try parser.parse();
    defer cfg.window_rule.deinit(std.testing.allocator);
    defer cfg.tag_rule.deinit(std.testing.allocator);

    try std.testing.expectEqual(@as(usize, 1), cfg.window_rule.items.len);
    try std.testing.expectEqual(@as(u8, 6), cfg.window_rule.items[0].title_len);
    try std.testing.expectEqualStrings("Dialog", cfg.window_rule.items[0].title[0..cfg.window_rule.items[0].title_len]);
    try std.testing.expect(cfg.window_rule.items[0].floating);

    try std.testing.expectEqual(@as(usize, 1), cfg.tag_rule.items.len);
    try std.testing.expectEqual(@as(u8, 4), cfg.tag_rule.items[0].monitor_name_len);
    try std.testing.expectEqualStrings("DP-3", cfg.tag_rule.items[0].monitor_name[0..cfg.tag_rule.items[0].monitor_name_len]);
}
