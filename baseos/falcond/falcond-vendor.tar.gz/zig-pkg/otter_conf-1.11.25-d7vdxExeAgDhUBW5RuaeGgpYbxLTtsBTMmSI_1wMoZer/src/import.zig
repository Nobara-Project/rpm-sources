//! Recursive `import = "path"` preprocessing: imported bodies first (in order),
//! then the remainder of each file with import lines stripped. Cycle detection
//! uses canonical paths on a resolution stack.

const std = @import("std");
const otter_utils = @import("otter_utils");
/// Cached reference to the app-installed `std.Io`. Fetched lazily to avoid
/// evaluating before `otter_utils.io.install(...)` runs in `main()`.
inline fn io_global() std.Io {
    return otter_utils.io.get();
}

pub const ResolveError = error{
    CircularImport,
    ImportTooDeep,
} || std.mem.Allocator.Error || std.Io.File.OpenError || std.Io.File.StatError || std.Io.Reader.LimitedAllocError || std.Io.Dir.RealPathFileAllocError || error{FileTooLarge};

pub const ImportError = ResolveError;
pub const max_import_depth: usize = 128;

pub const Resolved = struct {
    content: []u8,
    paths: [][]u8,

    pub fn deinit(self: *Resolved, allocator: std.mem.Allocator) void {
        allocator.free(self.content);
        for (self.paths) |p| allocator.free(p);
        allocator.free(self.paths);
    }
};

fn trimStart(line: []const u8) []const u8 {
    var i: usize = 0;
    while (i < line.len and (line[i] == ' ' or line[i] == '\t')) i += 1;
    return line[i..];
}

fn trimEndCr(line: []const u8) []const u8 {
    if (line.len > 0 and line[line.len - 1] == '\r') return line[0 .. line.len - 1];
    return line;
}

/// If the line is `import = "path"` (optional whitespace; `#` comment after the string), returns an owned copy of the path. Otherwise null.
fn parseImportPath(allocator: std.mem.Allocator, line: []const u8) std.mem.Allocator.Error!?[]const u8 {
    const s0 = trimEndCr(trimStart(line));
    if (s0.len == 0) return null;
    if (s0[0] == '#') return null;

    const kw = "import";
    if (s0.len < kw.len or !std.mem.startsWith(u8, s0, kw)) return null;
    const after_kw = s0[kw.len..];
    if (after_kw.len == 0) return null;
    switch (after_kw[0]) {
        ' ', '\t', '=' => {},
        else => return null,
    }

    var rest = after_kw;
    while (rest.len > 0 and (rest[0] == ' ' or rest[0] == '\t')) rest = rest[1..];
    if (rest.len == 0 or rest[0] != '=') return null;
    rest = rest[1..];
    while (rest.len > 0 and (rest[0] == ' ' or rest[0] == '\t')) rest = rest[1..];
    if (rest.len == 0 or rest[0] != '"') return null;
    rest = rest[1..];

    const q = std.mem.indexOfScalar(u8, rest, '"') orelse return null;
    const inner = rest[0..q];
    var tail = rest[q + 1 ..];
    while (tail.len > 0 and (tail[0] == ' ' or tail[0] == '\t')) tail = tail[1..];
    if (tail.len > 0 and tail[0] == '#') return try allocator.dupe(u8, inner);
    if (tail.len != 0) return null;

    return try allocator.dupe(u8, inner);
}

fn readFileLimited(allocator: std.mem.Allocator, abs_path: []const u8, max_file_size: usize) ResolveError![]const u8 {
    const io = io_global();
    const file = std.Io.Dir.openFileAbsolute(io, abs_path, .{ .mode = .read_only }) catch |err| switch (err) {
        error.FileNotFound => return err,
        error.AccessDenied => return err,
        else => return err,
    };
    defer file.close(io);

    const stat = try file.stat(io);
    const size: usize = @intCast(stat.size);
    if (size > max_file_size) return error.FileTooLarge;
    if (size == 0) return try allocator.dupe(u8, "");

    var reader_buffer: [4096]u8 = undefined;
    var reader = file.reader(io, &reader_buffer);
    const buf = try reader.interface.allocRemaining(allocator, .limited(max_file_size));
    if (buf.len > max_file_size) {
        allocator.free(buf);
        return error.FileTooLarge;
    }
    return buf;
}

fn resolveImportTarget(allocator: std.mem.Allocator, current_file_canon: []const u8, target: []const u8) ResolveError![]const u8 {
    if (std.fs.path.isAbsolute(target)) {
        return std.fs.path.resolve(allocator, &.{target}) catch |err| return err;
    }
    const dir = std.fs.path.dirname(current_file_canon) orelse ".";
    return std.fs.path.resolve(allocator, &.{ dir, target }) catch |err| return err;
}

fn wouldExceedLimit(current: usize, added: usize, limit: usize) bool {
    return added > limit or current > limit - added;
}

fn canonicalPath(allocator: std.mem.Allocator, path: []const u8) ResolveError![:0]u8 {
    const abs = try std.fs.path.resolve(allocator, &.{path});
    defer allocator.free(abs);
    return std.Io.Dir.realPathFileAbsoluteAlloc(io_global(), abs, allocator);
}

fn resolveFromCanonical(
    allocator: std.mem.Allocator,
    canon: []const u8,
    max_file_size: usize,
    stack: *std.ArrayListUnmanaged([]const u8),
    paths_list: ?*std.ArrayListUnmanaged([]u8),
) ResolveError![]u8 {
    if (stack.items.len >= max_import_depth) return error.ImportTooDeep;

    for (stack.items) |c| {
        if (std.mem.eql(u8, c, canon)) return error.CircularImport;
    }

    const stack_entry = try allocator.dupe(u8, canon);
    var stack_entry_owned: bool = true;
    errdefer if (stack_entry_owned) allocator.free(stack_entry);
    try stack.append(allocator, stack_entry);
    stack_entry_owned = false;
    defer {
        const popped = stack.pop().?;
        allocator.free(popped);
    }

    const content = try readFileLimited(allocator, canon, max_file_size);
    defer allocator.free(content);

    var import_targets: std.ArrayListUnmanaged([]const u8) = .empty;
    defer {
        for (import_targets.items) |p| allocator.free(p);
        import_targets.deinit(allocator);
    }

    var local: std.ArrayListUnmanaged(u8) = .empty;
    defer local.deinit(allocator);

    var rest = content;
    while (rest.len > 0) {
        const nl = std.mem.indexOfScalar(u8, rest, '\n');
        const line_full = if (nl) |n| rest[0..n] else rest;
        const after_nl = if (nl) |n| rest[n + 1 ..] else &[_]u8{};

        if (try parseImportPath(allocator, line_full)) |p| {
            defer allocator.free(p);
            const abs_tgt = try resolveImportTarget(allocator, canon, p);
            var abs_tgt_owned: bool = true;
            errdefer if (abs_tgt_owned) allocator.free(abs_tgt);
            try import_targets.append(allocator, abs_tgt);
            abs_tgt_owned = false;
        } else {
            try local.appendSlice(allocator, line_full);
            try local.append(allocator, '\n');
        }

        rest = after_nl;
    }

    var out: std.ArrayListUnmanaged(u8) = .empty;
    errdefer out.deinit(allocator);

    for (import_targets.items) |abs_tgt| {
        const child_canon = try std.Io.Dir.realPathFileAbsoluteAlloc(io_global(), abs_tgt, allocator);
        defer allocator.free(child_canon);
        const piece = try resolveFromCanonical(allocator, child_canon, max_file_size, stack, paths_list);
        defer allocator.free(piece);
        if (wouldExceedLimit(out.items.len, piece.len, max_file_size)) {
            return error.FileTooLarge;
        }
        try out.appendSlice(allocator, piece);
    }

    if (wouldExceedLimit(out.items.len, local.items.len, max_file_size)) {
        return error.FileTooLarge;
    }
    try out.appendSlice(allocator, local.items);
    if (paths_list) |list| {
        {
            const path_copy = try allocator.dupe(u8, canon);
            errdefer allocator.free(path_copy);
            try list.append(allocator, path_copy);
        }
    }
    return try out.toOwnedSlice(allocator);
}

/// Expand `import = "..."` recursively. Imported bodies come first; import lines are omitted from the merged text.
pub fn resolveWithImports(
    allocator: std.mem.Allocator,
    path: []const u8,
    max_file_size: usize,
) ResolveError![]u8 {
    var stack: std.ArrayListUnmanaged([]const u8) = .empty;
    defer stack.deinit(allocator);

    const canon = try canonicalPath(allocator, path);
    defer allocator.free(canon);

    return resolveFromCanonical(allocator, canon, max_file_size, &stack, null);
}

pub fn resolve(allocator: std.mem.Allocator, path: []const u8) ResolveError!Resolved {
    return resolveWithLimit(allocator, path, 64 * 1024 * 1024);
}

pub fn resolveWithLimit(
    allocator: std.mem.Allocator,
    path: []const u8,
    max_file_size: usize,
) ResolveError!Resolved {
    var stack: std.ArrayListUnmanaged([]const u8) = .empty;
    defer stack.deinit(allocator);
    var paths: std.ArrayListUnmanaged([]u8) = .empty;
    errdefer {
        for (paths.items) |p| allocator.free(p);
        paths.deinit(allocator);
    }

    const canon = try canonicalPath(allocator, path);
    defer allocator.free(canon);

    const content = try resolveFromCanonical(allocator, canon, max_file_size, &stack, &paths);
    errdefer allocator.free(content);
    return .{
        .content = content,
        .paths = try paths.toOwnedSlice(allocator),
    };
}

// ============================================================================
// Tests
// ============================================================================

test "resolve with no imports" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(io_global(), .{ .sub_path = "only.conf", .data = "a = 1\nb = 2\n" });
    const abs = try tmp.dir.realPathFileAlloc(std.testing.io, "only.conf", std.testing.allocator);
    defer std.testing.allocator.free(abs);

    const merged = try resolveWithImports(std.testing.allocator, abs, 64 * 1024 * 1024);
    defer std.testing.allocator.free(merged);

    try std.testing.expectEqualStrings("a = 1\nb = 2\n", merged);
}

test "resolve with single import (imports-first order)" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(io_global(), .{ .sub_path = "base.conf", .data = "a = 1\n" });
    try tmp.dir.writeFile(io_global(), .{ .sub_path = "main.conf", .data = "import = \"base.conf\"\na = 2\n" });

    const abs_main = try tmp.dir.realPathFileAlloc(std.testing.io, "main.conf", std.testing.allocator);
    defer std.testing.allocator.free(abs_main);

    const merged = try resolveWithImports(std.testing.allocator, abs_main, 64 * 1024 * 1024);
    defer std.testing.allocator.free(merged);

    try std.testing.expectEqualStrings("a = 1\na = 2\n", merged);
}

test "resolve API returns path list" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(io_global(), .{ .sub_path = "base.conf", .data = "a = 1\n" });
    try tmp.dir.writeFile(io_global(), .{ .sub_path = "main.conf", .data = "import = \"base.conf\"\na = 2\n" });

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path_len = try tmp.dir.realPathFile(std.testing.io, "main.conf", &path_buf);
    const path = path_buf[0..path_len];

    var resolved = try resolve(std.testing.allocator, path);
    defer resolved.deinit(std.testing.allocator);

    try std.testing.expectEqual(@as(usize, 2), resolved.paths.len);
    try std.testing.expect(std.mem.endsWith(u8, resolved.paths[0], "base.conf"));
    try std.testing.expect(std.mem.endsWith(u8, resolved.paths[1], "main.conf"));
}

test "circular import detected" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(io_global(), .{ .sub_path = "a.conf", .data = "import = \"b.conf\"\n" });
    try tmp.dir.writeFile(io_global(), .{ .sub_path = "b.conf", .data = "import = \"a.conf\"\n" });

    const abs_a = try tmp.dir.realPathFileAlloc(std.testing.io, "a.conf", std.testing.allocator);
    defer std.testing.allocator.free(abs_a);

    try std.testing.expectError(error.CircularImport, resolveWithImports(std.testing.allocator, abs_a, 64 * 1024 * 1024));
}

test "missing import file" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(io_global(), .{ .sub_path = "root.conf", .data = "import = \"nope.conf\"\n" });

    const abs = try tmp.dir.realPathFileAlloc(std.testing.io, "root.conf", std.testing.allocator);
    defer std.testing.allocator.free(abs);

    try std.testing.expectError(error.FileNotFound, resolveWithImports(std.testing.allocator, abs, 64 * 1024 * 1024));
}

test "resolve rejects import chains beyond depth cap" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    inline for (0..130) |i| {
        var name_buf: [32]u8 = undefined;
        const name = try std.fmt.bufPrint(&name_buf, "file_{d}.conf", .{i});
        var next_buf: [64]u8 = undefined;
        const data = if (i == 129)
            "value = 1\n"
        else
            try std.fmt.bufPrint(&next_buf, "import = \"file_{d}.conf\"\n", .{i + 1});
        try tmp.dir.writeFile(io_global(), .{ .sub_path = name, .data = data });
    }

    const abs = try tmp.dir.realPathFileAlloc(std.testing.io, "file_0.conf", std.testing.allocator);
    defer std.testing.allocator.free(abs);

    try std.testing.expectError(error.ImportTooDeep, resolveWithImports(std.testing.allocator, abs, 1024));
}

test "resolve rejects merged imports beyond total size cap" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    try tmp.dir.writeFile(io_global(), .{ .sub_path = "a.conf", .data = "value_a = 1111111111\n" });
    try tmp.dir.writeFile(io_global(), .{ .sub_path = "b.conf", .data = "value_b = 2222222222\n" });
    try tmp.dir.writeFile(io_global(), .{
        .sub_path = "main.conf",
        .data =
        \\import = "a.conf"
        \\import = "b.conf"
        \\
        ,
    });

    const abs = try tmp.dir.realPathFileAlloc(std.testing.io, "main.conf", std.testing.allocator);
    defer std.testing.allocator.free(abs);

    try std.testing.expectError(error.FileTooLarge, resolveWithImports(std.testing.allocator, abs, 32));
}
