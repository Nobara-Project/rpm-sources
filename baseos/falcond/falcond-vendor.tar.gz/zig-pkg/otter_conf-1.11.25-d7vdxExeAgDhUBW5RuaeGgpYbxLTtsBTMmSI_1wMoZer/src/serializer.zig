//! Serialization of config structs to otter-conf format.

const std = @import("std");
const support = @import("parser_support.zig");
const hasToStrFn = support.hasToStrFn;
const isContainerStruct = support.isContainerStruct;

/// Options for serializing a config to text.
pub const SerializeOptions = struct {
    /// Include a comment header.
    header_comment: ?[]const u8 = null,

    /// Add blank lines between fields.
    spacing: bool = true,

    /// Include type comments above each field.
    include_type_comments: bool = false,
};

/// Serialize a config struct to the otter-conf format.
pub fn serialize(
    comptime T: type,
    allocator: std.mem.Allocator,
    config: T,
    options: SerializeOptions,
) ![]const u8 {
    var aw: std.Io.Writer.Allocating = .init(allocator);
    errdefer aw.deinit();
    const writer = &aw.writer;

    if (options.header_comment) |header| {
        var lines = std.mem.splitScalar(u8, header, '\n');
        while (lines.next()) |line| {
            try writer.print("# {s}\n", .{line});
        }
        try writer.writeByte('\n');
    }

    const top_fields = std.meta.fields(T);
    inline for (top_fields, 0..) |field, i| {
        if (comptime @import("dynamic.zig").isDynamic(field.type)) {
            const dyn_val = @field(config, field.name);
            const Elem = field.type.Elem;
            const dp = field.type.prefix;
            var index: usize = 0;
            while (index < dyn_val.items.len) : (index += 1) {
                const entry = dyn_val.items[index];
                if (comptime hasToStrFn(Elem)) {
                    if (options.include_type_comments) {
                        try writer.print("# type: {s}\n", .{@typeName(Elem)});
                    }
                    try writer.print("{s}_{d} = ", .{ dp, index });
                    const str = entry.toStr();
                    try serializeCustomToStr(writer, str);
                } else if (comptime @typeInfo(Elem) == .@"struct") {
                    inline for (std.meta.fields(Elem)) |sub| {
                        if (options.include_type_comments) {
                            try writer.print("# type: {s}\n", .{@typeName(sub.type)});
                        }
                        var name_buf: [256]u8 = undefined;
                        const sub_name = try std.fmt.bufPrint(
                            &name_buf,
                            "{s}_{d}_{s}",
                            .{ dp, index, sub.name },
                        );
                        const sub_val = @field(entry, sub.name);
                        try serializeField(writer, sub_name, sub.type, sub_val);
                    }
                } else {
                    return error.UnsupportedDynamicElemSerialization;
                }
            }
        } else if (comptime isContainerStruct(field.type)) {
            // Nested struct: serialize sub-fields with prefix
            const inner_value = @field(config, field.name);
            inline for (std.meta.fields(field.type)) |inner_field| {
                if (options.include_type_comments) {
                    try writer.print("# type: {s}\n", .{@typeName(inner_field.type)});
                }
                const inner_val = @field(inner_value, inner_field.name);
                const prefix = comptime field.name ++ "_" ++ inner_field.name;
                try serializeField(writer, prefix, inner_field.type, inner_val);
            }
        } else {
            if (options.include_type_comments) {
                try writer.print("# type: {s}\n", .{@typeName(field.type)});
            }
            const value = @field(config, field.name);
            try serializeField(writer, field.name, field.type, value);
        }

        if (options.spacing and i < top_fields.len - 1) {
            try writer.writeByte('\n');
        }
    }

    return aw.toOwnedSlice();
}

/// Custom `toStr` returns `[N]u8`; emit only bytes before the first `0` so
/// variable-length values (e.g. comma lists) serialize correctly.
fn serializeCustomToStr(writer: anytype, str: anytype) !void {
    const T = @TypeOf(str);
    const slice: []const u8 = switch (@typeInfo(T)) {
        .array => |info| blk: {
            if (info.child != u8) @compileError("custom toStr must return [N]u8");
            const end = std.mem.indexOfScalar(u8, &str, 0) orelse str.len;
            break :blk str[0..end];
        },
        else => @compileError("unsupported custom toStr return type"),
    };
    try serializeString(writer, slice);
}

fn serializeField(
    writer: anytype,
    name: []const u8,
    comptime FieldType: type,
    value: FieldType,
) !void {
    switch (@typeInfo(FieldType)) {
        .@"struct" => {
            if (comptime hasToStrFn(FieldType)) {
                try writer.print("{s} = ", .{name});
                const str = value.toStr();
                try serializeCustomToStr(writer, str);
            } else {
                try writer.print("{s} = \"\"\n", .{name});
            }
            return;
        },
        .optional => |opt_info| {
            if (value) |v| {
                try writer.print("{s} = ", .{name});
                if (comptime @typeInfo(opt_info.child) == .@"struct" and hasToStrFn(opt_info.child)) {
                    const str = v.toStr();
                    try serializeCustomToStr(writer, str);
                } else {
                    try serializeValue(writer, opt_info.child, v);
                }
            } else {
                // Skip null optionals for non-string types; emit "" for string types
                if (comptime @typeInfo(opt_info.child) == .pointer) {
                    try writer.print("{s} = \"\"\n", .{name});
                }
                // Non-string null optionals: skip entirely
            }
            return;
        },
        else => {},
    }

    try writer.print("{s} = ", .{name});

    switch (@typeInfo(FieldType)) {
        .bool => {
            try writer.print("{s}\n", .{if (value) "true" else "false"});
        },
        .int => {
            try writer.print("{d}\n", .{value});
        },
        .float => {
            try writer.print("{d}\n", .{value});
        },
        .@"enum" => {
            try writer.print("{s}\n", .{@tagName(value)});
        },
        .pointer => |ptr_info| {
            if (ptr_info.size == .slice) {
                try serializeSlice(writer, ptr_info.child, value);
            } else {
                try writer.writeAll("\"\"\n");
            }
        },
        .array => |array_info| {
            try serializeArray(writer, array_info.child, array_info.len, &value);
        },
        else => {
            try writer.writeAll("\"\"\n");
        },
    }
}

fn serializeValue(
    writer: anytype,
    comptime T: type,
    value: T,
) !void {
    switch (@typeInfo(T)) {
        .bool => try writer.print("{s}\n", .{if (value) "true" else "false"}),
        .int => try writer.print("{d}\n", .{value}),
        .float => try writer.print("{d}\n", .{value}),
        .@"enum" => try writer.print("{s}\n", .{@tagName(value)}),
        .pointer => |ptr_info| {
            if (ptr_info.size == .slice and ptr_info.child == u8) {
                try serializeString(writer, value);
            } else {
                try serializeSlice(writer, ptr_info.child, value);
            }
        },
        else => try writer.writeAll("\"\"\n"),
    }
}

fn serializeString(writer: anytype, str: []const u8) !void {
    try writer.writeByte('"');
    for (str) |c| {
        switch (c) {
            '"' => try writer.writeAll("\\\""),
            '\\' => try writer.writeAll("\\\\"),
            '\n' => try writer.writeAll("\\n"),
            '\r' => try writer.writeAll("\\r"),
            '\t' => try writer.writeAll("\\t"),
            0 => try writer.writeAll("\\0"),
            else => try writer.writeByte(c),
        }
    }
    try writer.writeAll("\"\n");
}

fn serializeSlice(writer: anytype, comptime Child: type, slice: anytype) !void {
    if (Child == u8) {
        try serializeString(writer, slice);
    } else if (Child == []const u8) {
        try writer.writeByte('[');
        for (slice, 0..) |s, i| {
            try writer.writeByte('"');
            for (s) |c| {
                switch (c) {
                    '"' => try writer.writeAll("\\\""),
                    '\\' => try writer.writeAll("\\\\"),
                    else => try writer.writeByte(c),
                }
            }
            try writer.writeByte('"');
            if (i < slice.len - 1) try writer.writeAll(", ");
        }
        try writer.writeAll("]\n");
    } else {
        try writer.writeByte('[');
        for (slice, 0..) |v, i| {
            try writer.print("{d}", .{v});
            if (i < slice.len - 1) try writer.writeAll(", ");
        }
        try writer.writeAll("]\n");
    }
}

fn serializeArray(
    writer: anytype,
    comptime Child: type,
    comptime len: usize,
    array: *const [len]Child,
) !void {
    try writer.writeByte('[');
    for (array, 0..) |v, i| {
        try writer.print("{d}", .{v});
        if (i < len - 1) try writer.writeAll(", ");
    }
    try writer.writeAll("]\n");
}

/// Serialize a default config (using struct default values).
pub fn serializeDefaults(
    comptime T: type,
    allocator: std.mem.Allocator,
    options: SerializeOptions,
) ![]const u8 {
    const defaults: T = .{};
    return serialize(T, allocator, defaults, options);
}

// ============================================================================
// Tests
// ============================================================================

test "serialize basic config" {
    const TestConfig = struct {
        name: []const u8 = "test",
        count: i32 = 42,
        enabled: bool = true,
        ratio: f64 = 3.14,
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "name = \"test\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "count = 42") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "enabled = true") != null);
}

test "serialize with header" {
    const TestConfig = struct {
        value: i32 = 1,
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{
        .header_comment = "My Config\nVersion 1.0",
        .spacing = false,
    });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "# My Config") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "# Version 1.0") != null);
}

test "serialize string escaping" {
    const TestConfig = struct {
        text: []const u8 = "hello \"world\"\nnewline",
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "\\\"world\\\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "\\n") != null);
}

test "serialize enum" {
    const Mode = enum { Debug, Release, Test };
    const TestConfig = struct {
        mode: Mode = .Release,
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "mode = Release") != null);
}

test "serialize array" {
    const TestConfig = struct {
        values: [3]i64 = .{ 1, 2, 3 },
    };

    const config = TestConfig{};
    const output = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "values = [1, 2, 3]") != null);
}

test "serialize nested struct" {
    const Inner = struct {
        enabled: bool = true,
        count: u32 = 10,
    };
    const NestedConfig = struct {
        section: Inner = .{},
        other: i64 = 5,
    };

    const config = NestedConfig{};
    const output = try serialize(NestedConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "section_enabled = true") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "section_count = 10") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "other = 5") != null);
}

test "serialize custom type with toStr" {
    const MockColor = struct {
        r: u8,
        g: u8,

        pub fn toStr(self: @This()) [5]u8 {
            const hex = "0123456789ABCDEF";
            return .{ '#', hex[self.r >> 4], hex[self.r & 0xF], hex[self.g >> 4], hex[self.g & 0xF] };
        }

        pub fn parse(_: []const u8) !@This() {
            return .{ .r = 0, .g = 0 };
        }
    };
    const CustomConfig = struct {
        color: MockColor = .{ .r = 0xFF, .g = 0xAB },
    };

    const config = CustomConfig{};
    const output = try serialize(CustomConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "color = \"#FFAB\"") != null);
}

test "serialize nested struct with custom type" {
    const MockColor = struct {
        val: u8,

        pub fn toStr(self: @This()) [3]u8 {
            const hex = "0123456789ABCDEF";
            return .{ '#', hex[self.val >> 4], hex[self.val & 0xF] };
        }

        pub fn parse(_: []const u8) !@This() {
            return .{ .val = 0 };
        }
    };
    const Inner = struct {
        text_color: MockColor = .{ .val = 0xAA },
        enabled: bool = false,
    };
    const Config = struct {
        widget: Inner = .{},
    };

    const config = Config{};
    const output = try serialize(Config, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    try std.testing.expect(std.mem.indexOf(u8, output, "widget_text_color = \"#AA\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, output, "widget_enabled = false") != null);
}

test "serialize optional null skipped for non-string" {
    const Config = struct {
        opt_int: ?i32 = null,
        name: []const u8 = "test",
    };

    const config = Config{};
    const output = try serialize(Config, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(output);

    // null optional int should not appear in output
    try std.testing.expect(std.mem.indexOf(u8, output, "opt_int") == null);
    try std.testing.expect(std.mem.indexOf(u8, output, "name = \"test\"") != null);
}

test "serialize round-trip nested with custom type" {
    const parser_mod = @import("parser.zig");

    const MockColor = struct {
        r: u8,
        g: u8,
        b: u8,
        a: u8 = 0xFF,

        pub fn parse(str: []const u8) error{InvalidColor}!@This() {
            if (str.len < 7 or str[0] != '#') return error.InvalidColor;
            return .{
                .r = std.fmt.parseInt(u8, str[1..3], 16) catch return error.InvalidColor,
                .g = std.fmt.parseInt(u8, str[3..5], 16) catch return error.InvalidColor,
                .b = std.fmt.parseInt(u8, str[5..7], 16) catch return error.InvalidColor,
            };
        }

        pub fn toStr(self: @This()) [9]u8 {
            const hex = "0123456789ABCDEF";
            return .{ '#', hex[self.r >> 4], hex[self.r & 0xF], hex[self.g >> 4], hex[self.g & 0xF], hex[self.b >> 4], hex[self.b & 0xF], hex[self.a >> 4], hex[self.a & 0xF] };
        }
    };
    const Inner = struct {
        color: MockColor = .{ .r = 0xAA, .g = 0xBB, .b = 0xCC },
        enabled: bool = true,
    };
    const Config = struct {
        widget: Inner = .{},
    };

    // Serialize
    const original = Config{};
    const text = try serialize(Config, std.testing.allocator, original, .{ .spacing = false });
    defer std.testing.allocator.free(text);

    // Parse back
    var p = parser_mod.Parser(Config).init(std.testing.allocator, text);
    const parsed = try p.parse();

    try std.testing.expectEqual(original.widget.color.r, parsed.widget.color.r);
    try std.testing.expectEqual(original.widget.color.g, parsed.widget.color.g);
    try std.testing.expectEqual(original.widget.color.b, parsed.widget.color.b);
    try std.testing.expectEqual(original.widget.enabled, parsed.widget.enabled);
}

test "Dynamic serialize: struct fields" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Parser = @import("parser.zig").Parser;
    const Bind = struct {
        mods: u32 = 0,
        key: []const u8 = "",
    };
    const Config = struct {
        name: []const u8 = "cfg",
        binds: Dynamic(Bind, "bind") = .{},
    };

    const content =
        \\name = "cfg"
        \\bind_0_mods = 1
        \\bind_0_key = "Return"
        \\bind_1_mods = 4
        \\bind_1_key = "q"
    ;

    var parser = Parser(Config).init(std.testing.allocator, content);
    var cfg = try parser.parse();
    defer std.testing.allocator.free(cfg.name);
    defer cfg.binds.deinit(std.testing.allocator);

    const out = try serialize(Config, std.testing.allocator, cfg, .{ .spacing = false });
    defer std.testing.allocator.free(out);

    try std.testing.expect(std.mem.indexOf(u8, out, "bind_0_mods = 1") != null);
    try std.testing.expect(std.mem.indexOf(u8, out, "bind_0_key = \"Return\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, out, "bind_1_mods = 4") != null);
    try std.testing.expect(std.mem.indexOf(u8, out, "bind_1_key = \"q\"") != null);
}

test "Dynamic round-trip" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Parser = @import("parser.zig").Parser;
    const Rule = struct {
        raw: [5]u8 = .{ 0, 0, 0, 0, 0 },
        pub fn parse(s: []const u8) !@This() {
            if (s.len != 5) return error.InvalidRule;
            var raw: [5]u8 = undefined;
            @memcpy(raw[0..5], s[0..5]);
            return .{ .raw = raw };
        }

        pub fn toStr(self: @This()) [5]u8 {
            return self.raw;
        }
    };
    const Config = struct {
        rules: Dynamic(Rule, "rule") = .{},
    };

    const original =
        \\rule_0 = "alpha"
        \\rule_1 = "bravo"
    ;

    var parser1 = Parser(Config).init(std.testing.allocator, original);
    var cfg1 = try parser1.parse();
    defer cfg1.rules.deinit(std.testing.allocator);

    const text = try serialize(Config, std.testing.allocator, cfg1, .{ .spacing = false });
    defer std.testing.allocator.free(text);

    var parser2 = Parser(Config).init(std.testing.allocator, text);
    var cfg2 = try parser2.parse();
    defer cfg2.rules.deinit(std.testing.allocator);

    try std.testing.expectEqual(@as(usize, 2), cfg2.rules.len());
    try std.testing.expectEqualSlices(u8, "alpha", &cfg2.rules.items[0].raw);
    try std.testing.expectEqualSlices(u8, "bravo", &cfg2.rules.items[1].raw);
}

test "Dynamic serialize: unsupported element type errors" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Config = struct {
        values: Dynamic(i32, "value") = .{},
    };

    var cfg: Config = .{};
    cfg.values.arena = try std.testing.allocator.create(std.heap.ArenaAllocator);
    cfg.values.arena.?.* = std.heap.ArenaAllocator.init(std.testing.allocator);
    const dyn_alloc = cfg.values.arena.?.allocator();
    cfg.values.items = try dyn_alloc.alloc(i32, 1);
    cfg.values.items[0] = 42;
    defer cfg.values.deinit(std.testing.allocator);
    try std.testing.expectError(
        error.UnsupportedDynamicElemSerialization,
        serialize(Config, std.testing.allocator, cfg, .{ .spacing = false }),
    );
}
