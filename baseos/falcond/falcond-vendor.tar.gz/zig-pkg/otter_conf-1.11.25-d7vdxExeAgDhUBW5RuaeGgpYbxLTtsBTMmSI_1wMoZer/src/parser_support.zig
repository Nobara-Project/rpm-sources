const std = @import("std");

pub const ParseError = error{
    InvalidSyntax,
    UnexpectedCharacter,
    UnterminatedString,
    InvalidNumber,
    InvalidFloat,
    InvalidIdentifier,
    InvalidEnum,
    ArrayTooLarge,
    ListTooLong,
    OutOfMemory,
};

pub const max_dynamic_entries: usize = 4096;

pub fn hasParseFn(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    return @hasDecl(FieldType, "parse");
}

pub fn hasToStrFn(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    return @hasDecl(FieldType, "toStr");
}

pub fn isContainerStruct(comptime FieldType: type) bool {
    if (@typeInfo(FieldType) != .@"struct") return false;
    if (@hasDecl(FieldType, "parse")) return false;
    if (@import("dynamic.zig").isDynamic(FieldType)) return false;
    return std.meta.fields(FieldType).len > 0;
}

pub fn freeOwnedFieldValue(
    comptime FieldType: type,
    allocator: std.mem.Allocator,
    ptr: *FieldType,
    default_ptr: *const FieldType,
) void {
    switch (@typeInfo(FieldType)) {
        .pointer => |ptr_info| {
            if (ptr_info.size != .slice) return;
            if (ptr.*.ptr == default_ptr.*.ptr) return;

            if (ptr_info.child == u8) {
                allocator.free(ptr.*);
            } else if (ptr_info.child == []const u8) {
                for (ptr.*) |str| allocator.free(str);
                allocator.free(ptr.*);
            } else if (ptr_info.child == i64 or ptr_info.child == f64) {
                allocator.free(ptr.*);
            }
            ptr.* = default_ptr.*;
        },
        .optional => |opt_info| {
            switch (@typeInfo(opt_info.child)) {
                .pointer => |ptr_info| {
                    if (ptr_info.size == .slice and ptr_info.child == u8) {
                        if (ptr.*) |str| {
                            const is_default = if (default_ptr.*) |default|
                                str.ptr == default.ptr
                            else
                                false;
                            if (!is_default) allocator.free(str);
                        }
                        ptr.* = null;
                    }
                },
                else => {},
            }
        },
        else => {},
    }
}

pub fn skipWhitespace(self: anytype) void {
    while (self.pos < self.content.len) {
        switch (self.content[self.pos]) {
            ' ', '\t', '\n', '\r' => self.pos += 1,
            '#' => {
                if (std.mem.indexOfScalarPos(u8, self.content, self.pos, '\n')) |nl| {
                    self.pos = nl + 1;
                } else {
                    self.pos = self.content.len;
                    return;
                }
            },
            else => return,
        }
    }
}

pub fn parseIdentifier(self: anytype) ![]const u8 {
    const start = self.pos;

    while (self.pos < self.content.len) {
        switch (self.content[self.pos]) {
            'a'...'z', 'A'...'Z', '0'...'9', '_', '-' => self.pos += 1,
            else => break,
        }
    }

    if (start == self.pos) return error.InvalidIdentifier;
    return self.content[start..self.pos];
}

pub fn parseBool(self: anytype) !bool {
    if (self.pos >= self.content.len) return error.InvalidSyntax;

    switch (self.content[self.pos]) {
        't' => {
            if (self.pos + 4 <= self.content.len and
                std.mem.eql(u8, self.content[self.pos..][0..4], "true"))
            {
                self.pos += 4;
                return true;
            }
        },
        'f' => {
            if (self.pos + 5 <= self.content.len and
                std.mem.eql(u8, self.content[self.pos..][0..5], "false"))
            {
                self.pos += 5;
                return false;
            }
        },
        else => {},
    }
    return error.InvalidSyntax;
}

pub fn parseNumber(self: anytype) !i64 {
    skipWhitespace(self);
    const start = self.pos;

    if (self.pos < self.content.len and self.content[self.pos] == '-') {
        self.pos += 1;
    }

    while (self.pos < self.content.len) {
        switch (self.content[self.pos]) {
            '0'...'9' => self.pos += 1,
            else => break,
        }
    }

    if (self.pos == start or (self.content[start] == '-' and self.pos == start + 1)) {
        return error.InvalidNumber;
    }

    return std.fmt.parseInt(i64, self.content[start..self.pos], 10) catch return error.InvalidNumber;
}

pub fn parseNumberAs(self: anytype, comptime IntType: type) !IntType {
    skipWhitespace(self);
    const start = self.pos;

    if (@typeInfo(IntType).int.signedness == .signed) {
        if (self.pos < self.content.len and self.content[self.pos] == '-') {
            self.pos += 1;
        }
    }

    while (self.pos < self.content.len) {
        switch (self.content[self.pos]) {
            '0'...'9' => self.pos += 1,
            else => break,
        }
    }

    if (self.pos == start) return error.InvalidNumber;

    return std.fmt.parseInt(IntType, self.content[start..self.pos], 10) catch return error.InvalidNumber;
}

pub fn parseFloat(self: anytype) !f64 {
    skipWhitespace(self);
    const start = self.pos;

    while (self.pos < self.content.len) {
        switch (self.content[self.pos]) {
            '0'...'9', '.', 'e', 'E', '+', '-' => self.pos += 1,
            else => break,
        }
    }

    if (start == self.pos) return error.InvalidFloat;
    return std.fmt.parseFloat(f64, self.content[start..self.pos]) catch return error.InvalidFloat;
}

pub fn skipValue(self: anytype) void {
    while (self.pos < self.content.len and self.content[self.pos] != '\n') {
        switch (self.content[self.pos]) {
            '"' => {
                self.pos += 1;
                while (self.pos < self.content.len and self.content[self.pos] != '\n') {
                    if (self.content[self.pos] == '\\') {
                        self.pos += 1;
                        if (self.pos < self.content.len) self.pos += 1;
                    } else if (self.content[self.pos] == '"') {
                        self.pos += 1;
                        break;
                    } else {
                        self.pos += 1;
                    }
                }
            },
            '#' => break,
            else => self.pos += 1,
        }
    }
}
