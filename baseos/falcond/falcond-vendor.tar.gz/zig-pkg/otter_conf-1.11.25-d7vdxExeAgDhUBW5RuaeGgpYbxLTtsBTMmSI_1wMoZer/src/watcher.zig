//! File watching via inotify for config hot-reload
//!
//! Usage:
//!   var watcher = try Watcher.init(allocator);
//!   defer watcher.deinit();
//!   try watcher.addWatch(allocator, "/path/to/config.conf");
//!
//!   // In event loop, poll watcher.fd then:
//!   while (watcher.nextEvent()) |event| {
//!       if (event.isModified()) { ... }
//!   }

const std = @import("std");
const posix = std.posix;
const otter_utils = @import("otter_utils");

const InotifyWatcher = otter_utils.inotify.Watcher;

pub const Watcher = struct {
    inner: InotifyWatcher,

    pub const Event = InotifyWatcher.Event;
    pub const InitError = InotifyWatcher.InitError;
    pub const AddWatchError = InotifyWatcher.WatchError;

    pub fn init(allocator: std.mem.Allocator) InitError!Watcher {
        return .{ .inner = try InotifyWatcher.init(allocator) };
    }

    pub fn deinit(self: *Watcher) void {
        self.inner.deinit();
    }

    /// Add a file to watch. Returns watch descriptor.
    pub fn addWatch(self: *Watcher, allocator: std.mem.Allocator, path: []const u8) AddWatchError!i32 {
        _ = allocator;
        return self.inner.addWatch(path, InotifyWatcher.Mask.file_changes);
    }

    /// Register an inotify watch for each path. Returns an owned slice of
    /// watch descriptors (same order as `paths`). Caller frees the slice.
    pub fn addWatchesForImports(
        self: *Watcher,
        allocator: std.mem.Allocator,
        paths: []const []const u8,
    ) ![]i32 {
        const wds = try allocator.alloc(i32, paths.len);
        errdefer allocator.free(wds);
        for (paths, 0..) |p, i| {
            wds[i] = try self.addWatch(allocator, p);
        }
        return wds;
    }

    /// Remove a watch by descriptor.
    pub fn removeWatch(self: *Watcher, wd: i32) void {
        self.inner.removeWatch(wd);
    }

    /// Get the file descriptor for polling.
    pub fn getFd(self: *const Watcher) posix.fd_t {
        return self.inner.getFd();
    }

    /// Get the path associated with a watch descriptor.
    pub fn getPath(self: *const Watcher, wd: i32) ?[]const u8 {
        return self.inner.getPath(wd);
    }

    /// Read and iterate over pending events.
    pub fn nextEvent(self: *Watcher) ?Event {
        return self.inner.nextEvent();
    }

    /// Check if there are pending events (non-blocking).
    pub fn hasPendingEvents(self: *const Watcher) bool {
        return self.inner.hasPendingEvents();
    }
};

test "watcher init and deinit" {
    var watcher = try Watcher.init(std.testing.allocator);
    defer watcher.deinit();
    try std.testing.expect(watcher.getFd() >= 0);
}

test "event flags" {
    const event = Watcher.Event{
        .wd = 1,
        .mask = std.os.linux.IN.CLOSE_WRITE,
        .cookie = 0,
        .name = null,
    };
    try std.testing.expect(event.isModified());
    try std.testing.expect(!event.isDeleted());
    try std.testing.expect(!event.isCreated());
}

test "Watcher.addWatchesForImports registers every path" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    try tmp.dir.writeFile(std.testing.io, .{ .sub_path = "a.conf", .data = "" });
    try tmp.dir.writeFile(std.testing.io, .{ .sub_path = "b.conf", .data = "" });

    var buf_a: [std.fs.max_path_bytes]u8 = undefined;
    var buf_b: [std.fs.max_path_bytes]u8 = undefined;
    const path_a_len = try tmp.dir.realPathFile(std.testing.io, "a.conf", &buf_a);
    const path_a = buf_a[0..path_a_len];
    const path_b_len = try tmp.dir.realPathFile(std.testing.io, "b.conf", &buf_b);
    const path_b = buf_b[0..path_b_len];

    const paths: []const []const u8 = &.{ path_a, path_b };

    var w = try Watcher.init(std.testing.allocator);
    defer w.deinit();

    const wds = try w.addWatchesForImports(std.testing.allocator, paths);
    defer std.testing.allocator.free(wds);

    try std.testing.expectEqual(@as(usize, 2), wds.len);
    try std.testing.expect(wds[0] >= 0);
    try std.testing.expect(wds[1] >= 0);
}
