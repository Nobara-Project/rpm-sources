const std = @import("std");
const otter_utils = @import("otter_utils");
/// Cached reference to the app-installed `std.Io`. Fetched lazily to avoid
/// evaluating before `otter_utils.io.install(...)` runs in `main()`.
inline fn io_global() std.Io {
    return otter_utils.io.get();
}

const posix = std.posix;
const Parser = @import("parser.zig").Parser;
const import_mod = @import("import.zig");

pub const LoadError = error{
    FileTooLarge,
    FileNotFound,
    AccessDenied,
    InvalidPath,
    MmapFailed,
} || std.Io.File.OpenError || std.Io.File.StatError || std.Io.File.LockError || std.posix.MMapError || @import("parser.zig").ParseError;

/// Error set for `loadWithImports` (resolve + parse + root file stat).
pub const LoadWithImportsError = import_mod.ResolveError || @import("parser.zig").ParseError || std.Io.File.StatError;

/// Configuration options for loading.
pub const LoadOptions = struct {
    /// Maximum file size to load (default 64MB).
    max_file_size: usize = 64 * 1024 * 1024,
};

/// Result containing the parsed config and metadata about the load.
pub fn LoadResult(comptime T: type) type {
    return struct {
        config: T,
        /// File size in bytes.
        file_size: usize,
        /// Modification time in nanoseconds since epoch.
        mtime_ns: i128,
    };
}

/// Result of `loadWithImports`: merged parse result plus metadata for the root file.
pub fn ImportedLoadResult(comptime T: type) type {
    return struct {
        config: T,
        /// Absolute normalized paths of every file loaded (imports first, root last).
        paths: [][]u8,
        /// Size in bytes of the root config file (not the merged text).
        file_size: usize,
        /// Modification time of the root file.
        mtime_ns: i128,

        pub fn deinit(self: *@This(), allocator: std.mem.Allocator) void {
            for (self.paths) |p| allocator.free(p);
            allocator.free(self.paths);
        }
    };
}

/// Load and parse a configuration file using memory-mapped I/O.
pub fn load(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!T {
    const result = try loadWithMetadata(T, allocator, path, options);
    return result.config;
}

/// Load and parse a configuration file, returning metadata about the load.
pub fn loadWithMetadata(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!LoadResult(T) {
    const io = io_global();
    const file = std.Io.Dir.openFileAbsolute(io, path, .{ .mode = .read_only }) catch |err| {
        return switch (err) {
            error.FileNotFound => error.FileNotFound,
            error.AccessDenied => error.AccessDenied,
            else => err,
        };
    };
    defer file.close(io);

    // Shared lock prevents concurrent truncation during mmap (avoids SIGBUS
    // when another otter-shell app normalizes the same config/theme file).
    try file.lock(io, .shared);

    const stat = try file.stat(io);
    const size: usize = @intCast(stat.size);

    if (size > options.max_file_size) return error.FileTooLarge;

    const config = if (size == 0) blk: {
        // Handle empty file - return default-initialized struct
        var parser = Parser(T).init(allocator, "");
        break :blk try parser.parse();
    } else blk: {
        const mapped = posix.mmap(
            null,
            size,
            .{ .READ = true },
            .{ .TYPE = .PRIVATE },
            file.handle,
            0,
        ) catch return error.MmapFailed;
        defer posix.munmap(mapped);

        const content = mapped[0..size];
        var parser = Parser(T).init(allocator, content);
        break :blk try parser.parse();
    };

    return .{
        .config = config,
        .file_size = size,
        .mtime_ns = stat.mtime.nanoseconds,
    };
}

/// Load from a byte slice directly (useful for embedded configs or testing).
pub fn loadFromSlice(
    comptime T: type,
    allocator: std.mem.Allocator,
    content: []const u8,
) @import("parser.zig").ParseError!T {
    var parser = Parser(T).init(allocator, content);
    return parser.parse();
}

/// Load a config file, recursively resolving `import = "..."` directives.
/// Typed fields follow last-write-wins (main file overrides imports).
/// Dynamic fields append in load order (imports first, then main).
pub fn loadWithImports(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadWithImportsError!ImportedLoadResult(T) {
    const resolved = try import_mod.resolveWithLimit(allocator, path, options.max_file_size);
    defer allocator.free(resolved.content);
    errdefer {
        for (resolved.paths) |p| allocator.free(p);
        allocator.free(resolved.paths);
    }

    var parser = Parser(T).init(allocator, resolved.content);
    const cfg = try parser.parse();

    const root_path = resolved.paths[resolved.paths.len - 1];
    const file = std.Io.Dir.openFileAbsolute(io_global(), root_path, .{ .mode = .read_only }) catch |err| switch (err) {
        error.FileNotFound => return error.FileNotFound,
        error.AccessDenied => return error.AccessDenied,
        else => return err,
    };
    defer file.close(io_global());

    const stat = try file.stat(io_global());
    return .{
        .config = cfg,
        .paths = resolved.paths,
        .file_size = @intCast(stat.size),
        .mtime_ns = stat.mtime.nanoseconds,
    };
}

/// Check if a config file has been modified since the given mtime.
pub fn hasChanged(path: []const u8, last_mtime_ns: i128) !bool {
    const file = try std.Io.Dir.openFileAbsolute(io_global(), path, .{ .mode = .read_only });
    defer file.close(io_global());

    const stat = try file.stat(io_global());
    return stat.mtime.nanoseconds != last_mtime_ns;
}

/// Get the modification time of a config file.
pub fn getMtime(path: []const u8) !i128 {
    const file = try std.Io.Dir.openFileAbsolute(io_global(), path, .{ .mode = .read_only });
    defer file.close(io_global());

    const stat = try file.stat(io_global());
    return stat.mtime.nanoseconds;
}

// ============================================================================
// Tests
// ============================================================================

test "loadFromSlice basic" {
    const TestConfig = struct {
        name: []const u8 = "default",
        count: i64 = 0,
    };

    const content =
        \\name = "test"
        \\count = 42
    ;

    const config = try loadFromSlice(TestConfig, std.testing.allocator, content);
    defer std.testing.allocator.free(config.name);

    try std.testing.expectEqualStrings("test", config.name);
    try std.testing.expectEqual(@as(i64, 42), config.count);
}

test "loadFromSlice empty" {
    const TestConfig = struct {
        value: i64 = 100,
    };

    const config = try loadFromSlice(TestConfig, std.testing.allocator, "");
    try std.testing.expectEqual(@as(i64, 100), config.value);
}

test "load options default" {
    const opts = LoadOptions{};
    try std.testing.expectEqual(@as(usize, 64 * 1024 * 1024), opts.max_file_size);
}

test "loadWithImports: typed last-write-wins, Dynamic appends" {
    const Dynamic = @import("dynamic.zig").Dynamic;
    const Rule = struct {
        raw: [11]u8 = .{ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 },
        pub fn parse(s: []const u8) !@This() {
            if (s.len != 11) return error.InvalidRule;
            var raw: [11]u8 = undefined;
            @memcpy(raw[0..11], s[0..11]);
            return .{ .raw = raw };
        }
    };
    const Config = struct {
        name: []const u8 = "",
        count: i64 = 0,
        rules: Dynamic(Rule, "rule") = .{},
    };

    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    try tmp.dir.writeFile(io_global(), .{
        .sub_path = "rules.conf",
        .data = "rule_0 = \"from-import\"\ncount = 100\n",
    });
    try tmp.dir.writeFile(io_global(), .{
        .sub_path = "main.conf",
        .data =
        \\import = "rules.conf"
        \\name = "main"
        \\count = 42
        \\rule_1 = "from-main!!"
        \\
        ,
    });

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path_len = try tmp.dir.realPathFile(std.testing.io, "main.conf", &path_buf);
    const path = path_buf[0..path_len];

    var result = try loadWithImports(Config, std.testing.allocator, path, .{});
    defer result.deinit(std.testing.allocator);
    defer std.testing.allocator.free(result.config.name);
    defer result.config.rules.deinit(std.testing.allocator);

    try std.testing.expectEqualStrings("main", result.config.name);
    try std.testing.expectEqual(@as(i64, 42), result.config.count);
    try std.testing.expectEqual(@as(usize, 2), result.config.rules.len());
    try std.testing.expectEqualSlices(u8, "from-import", &result.config.rules.items[0].raw);
    try std.testing.expectEqualSlices(u8, "from-main!!", &result.config.rules.items[1].raw);
    try std.testing.expectEqual(@as(usize, 2), result.paths.len);
    try std.testing.expect(result.file_size > 0);
}
