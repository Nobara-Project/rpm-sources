//! otter-conf: Comptime-generic configuration library for Zig.
//!
//! Features:
//! - Comptime-generic parser works with any struct type
//! - Booleans, integers, floats, strings, enums, arrays, and optionals
//! - Memory-mapped file loading
//! - Directory loading with override support
//! - Serialization back to config format
//!
//! ## Basic Usage
//!
//! ```zig
//! const otter = @import("otter_conf");
//!
//! const Config = struct {
//!     name: []const u8 = "default",
//!     port: u16 = 8080,
//!     debug: bool = false,
//!     timeout: f64 = 30.0,
//! };
//!
//! // Load from file
//! const config = try otter.load(Config, allocator, "/etc/myapp/config.conf", .{});
//!
//! // Or parse from string
//! const config2 = try otter.loadFromSlice(Config, allocator, "name = \"test\"\nport = 9000");
//! ```

const std = @import("std");
const otter_utils = @import("otter_utils");
/// Cached reference to the app-installed `std.Io`. Fetched lazily to avoid
/// evaluating before `otter_utils.io.install(...)` runs in `main()`.
inline fn io_global() std.Io {
    return otter_utils.io.get();
}

// Re-export parser
pub const Parser = @import("parser.zig").Parser;
pub const ParseError = @import("parser.zig").ParseError;

// Re-export loader
pub const LoadOptions = @import("loader.zig").LoadOptions;
pub const LoadResult = @import("loader.zig").LoadResult;
pub const ImportedLoadResult = @import("loader.zig").ImportedLoadResult;
pub const LoadError = @import("loader.zig").LoadError;

// Re-export directory loader
pub const DirLoadOptions = @import("dir_loader.zig").DirLoadOptions;
pub const DirEntry = @import("dir_loader.zig").DirEntry;
pub const DirLoadResult = @import("dir_loader.zig").DirLoadResult;
pub const DirLoadError = @import("dir_loader.zig").DirLoadError;

// Re-export serializer
pub const SerializeOptions = @import("serializer.zig").SerializeOptions;
pub const serialize = @import("serializer.zig").serialize;
pub const serializeDefaults = @import("serializer.zig").serializeDefaults;

// Re-export file watcher
pub const Watcher = @import("watcher.zig").Watcher;
pub const WatchEvent = Watcher.Event;

pub const Dynamic = @import("dynamic.zig").Dynamic;
pub const isDynamic = @import("dynamic.zig").isDynamic;
pub const hasParseFn = @import("parser_support.zig").hasParseFn;
pub const hasToStrFn = @import("parser_support.zig").hasToStrFn;
pub const isContainerStruct = @import("parser_support.zig").isContainerStruct;
pub const ImportError = @import("import.zig").ImportError;
pub const ResolvedImports = @import("import.zig").Resolved;
pub const ResolveError = @import("import.zig").ResolveError;
pub const resolveImports = @import("import.zig").resolve;
pub const resolveImportsWithLimit = @import("import.zig").resolveWithLimit;
pub const resolveWithImports = @import("import.zig").resolveWithImports;

pub const LoadWithImportsError = @import("loader.zig").LoadWithImportsError;

// ============================================================================
// Loading
// ============================================================================

/// Load and parse a configuration file.
pub fn load(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!T {
    return @import("loader.zig").load(T, allocator, path, options);
}

/// Load and parse a configuration file, returning metadata.
pub fn loadWithMetadata(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadError!LoadResult(T) {
    return @import("loader.zig").loadWithMetadata(T, allocator, path, options);
}

/// Parse configuration from a byte slice.
pub fn loadFromSlice(
    comptime T: type,
    allocator: std.mem.Allocator,
    content: []const u8,
) ParseError!T {
    return @import("loader.zig").loadFromSlice(T, allocator, content);
}

/// Load a config file, recursively resolving imports.
pub fn loadWithImports(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: LoadOptions,
) LoadWithImportsError!ImportedLoadResult(T) {
    return @import("loader.zig").loadWithImports(T, allocator, path, options);
}

/// Load all config files from a directory.
pub fn loadDir(
    comptime T: type,
    allocator: std.mem.Allocator,
    dir_path: []const u8,
    options: DirLoadOptions,
) DirLoadError!DirLoadResult(T) {
    return @import("dir_loader.zig").loadDir(T, allocator, dir_path, options);
}

/// Load configs with user override support.
pub fn loadWithOverrides(
    comptime T: type,
    allocator: std.mem.Allocator,
    base_dir: []const u8,
    override_dir: ?[]const u8,
    options: DirLoadOptions,
) DirLoadError!DirLoadResult(T) {
    return @import("dir_loader.zig").loadWithOverrides(T, allocator, base_dir, override_dir, options);
}

/// Check if a config file has been modified.
pub fn hasChanged(path: []const u8, last_mtime_ns: i128) !bool {
    return @import("loader.zig").hasChanged(path, last_mtime_ns);
}

/// Get the modification time of a config file.
pub fn getMtime(path: []const u8) !i128 {
    return @import("loader.zig").getMtime(path);
}

// ============================================================================
// Saving
// ============================================================================

/// Save a config struct to a file.
pub fn save(
    comptime T: type,
    allocator: std.mem.Allocator,
    config: T,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const content = try serialize(T, allocator, config, options);
    defer allocator.free(content);

    const file = try std.Io.Dir.createFileAbsolute(io_global(), path, .{ .truncate = true });
    defer file.close(io_global());

    try file.lock(io_global(), .exclusive);
    try file.writeStreamingAll(io_global(), content);
}

/// Save a config struct to a relative path.
pub fn saveRelative(
    comptime T: type,
    allocator: std.mem.Allocator,
    config: T,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const content = try serialize(T, allocator, config, options);
    defer allocator.free(content);

    const file = try std.Io.Dir.cwd().createFile(io_global(), path, .{});
    defer file.close(io_global());

    try file.writeStreamingAll(io_global(), content);
}

/// Save a default config file (using struct default values).
pub fn saveDefaults(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const defaults: T = .{};
    try save(T, allocator, defaults, path, options);
}

/// Save a default config file to a relative path.
pub fn saveDefaultsRelative(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: SerializeOptions,
) !void {
    const defaults: T = .{};
    try saveRelative(T, allocator, defaults, path, options);
}

/// Create a config file if it doesn't exist, using defaults.
pub fn ensureConfigExists(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    options: SerializeOptions,
) !bool {
    std.Io.Dir.accessAbsolute(io_global(), path, .{}) catch {
        try saveDefaults(T, allocator, path, options);
        return true;
    };
    return false;
}

/// Load a config, creating it with defaults if it doesn't exist.
pub fn loadOrCreate(
    comptime T: type,
    allocator: std.mem.Allocator,
    path: []const u8,
    load_options: LoadOptions,
    save_options: SerializeOptions,
) !T {
    if (std.fs.path.dirname(path)) |dir| {
        std.Io.Dir.createDirAbsolute(io_global(), dir, .{}, .default_dir) catch |err| {
            if (err != error.PathAlreadyExists) {}
        };
    }

    return load(T, allocator, path, load_options) catch |err| {
        if (err == error.FileNotFound) {
            try saveDefaults(T, allocator, path, save_options);
            return T{};
        }
        return err;
    };
}

// ============================================================================
// Memory management
// ============================================================================

/// Free all allocated strings in a config struct.
pub fn freeConfig(comptime T: type, allocator: std.mem.Allocator, config: *T) void {
    @import("dir_loader.zig").freeConfigStrings(T, allocator, config);
}

// ============================================================================
// Tests
// ============================================================================

test "round-trip parse and serialize" {
    const TestConfig = struct {
        name: []const u8 = "",
        count: i64 = 0,
        enabled: bool = false,
    };

    const original =
        \\name = "round-trip"
        \\count = 123
        \\enabled = true
    ;

    const config = try loadFromSlice(TestConfig, std.testing.allocator, original);
    defer std.testing.allocator.free(config.name);

    const serialized = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(serialized);

    const config2 = try loadFromSlice(TestConfig, std.testing.allocator, serialized);
    defer std.testing.allocator.free(config2.name);

    try std.testing.expectEqualStrings("round-trip", config2.name);
    try std.testing.expectEqual(@as(i64, 123), config2.count);
    try std.testing.expect(config2.enabled);
}

test "round-trip with unknown fields" {
    const TestConfig = struct {
        name: []const u8 = "default",
        count: i64 = 0,
        enabled: bool = false,
    };

    const content_with_unknowns =
        \\name = "hello"
        \\removed_field = "should be stripped"
        \\count = 42
        \\old_setting = true
        \\enabled = true
    ;

    // Parse with unknown fields (should succeed, unknowns skipped)
    const config = try loadFromSlice(TestConfig, std.testing.allocator, content_with_unknowns);
    defer std.testing.allocator.free(config.name);

    try std.testing.expectEqualStrings("hello", config.name);
    try std.testing.expectEqual(@as(i64, 42), config.count);
    try std.testing.expect(config.enabled);

    // Serialize (unknown fields gone)
    const serialized = try serialize(TestConfig, std.testing.allocator, config, .{ .spacing = false });
    defer std.testing.allocator.free(serialized);

    // Re-parse serialized output
    const config2 = try loadFromSlice(TestConfig, std.testing.allocator, serialized);
    defer std.testing.allocator.free(config2.name);

    try std.testing.expectEqualStrings("hello", config2.name);
    try std.testing.expectEqual(@as(i64, 42), config2.count);
    try std.testing.expect(config2.enabled);
}

test "integration: imports + Dynamic + round-trip" {
    const Bind = struct {
        mods: u32 = 0,
        key: []const u8 = "",
    };
    const Config = struct {
        name: []const u8 = "",
        binds: Dynamic(Bind, "bind") = .{},
    };

    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    try tmp.dir.writeFile(io_global(), .{
        .sub_path = "binds.conf",
        .data = "bind_0_mods = 1\nbind_0_key = \"Return\"\n",
    });
    try tmp.dir.writeFile(io_global(), .{
        .sub_path = "main.conf",
        .data =
        \\import = "binds.conf"
        \\name = "cfg"
        \\bind_1_mods = 4
        \\bind_1_key = "q"
        \\
        ,
    });

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path_len = try tmp.dir.realPathFile(std.testing.io, "main.conf", &path_buf);
    const path = path_buf[0..path_len];

    var res = try loadWithImports(Config, std.testing.allocator, path, .{});
    defer res.deinit(std.testing.allocator);
    defer std.testing.allocator.free(res.config.name);
    defer res.config.binds.deinit(std.testing.allocator);

    try std.testing.expectEqualStrings("cfg", res.config.name);
    try std.testing.expectEqual(@as(usize, 2), res.config.binds.len());
    try std.testing.expectEqualStrings("Return", res.config.binds.items[0].key);
    try std.testing.expectEqualStrings("q", res.config.binds.items[1].key);

    const text = try serialize(Config, std.testing.allocator, res.config, .{ .spacing = false });
    defer std.testing.allocator.free(text);
    try std.testing.expect(std.mem.indexOf(u8, text, "bind_0_key = \"Return\"") != null);
    try std.testing.expect(std.mem.indexOf(u8, text, "bind_1_key = \"q\"") != null);
}

test "save truncates stale trailing bytes" {
    const Config = struct {
        name: []const u8 = "",
    };

    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path_len = try tmp.dir.realPath(std.testing.io, &path_buf);
    const dir_path = path_buf[0..path_len];
    var file_path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const file_path = try std.fmt.bufPrint(&file_path_buf, "{s}/short.conf", .{dir_path});

    try save(Config, std.testing.allocator, .{ .name = "long-long-long" }, file_path, .{ .spacing = false });
    try save(Config, std.testing.allocator, .{ .name = "x" }, file_path, .{ .spacing = false });

    const content = try tmp.dir.readFileAlloc(
        std.testing.io,
        "short.conf",
        std.testing.allocator,
        .limited(1024),
    );
    defer std.testing.allocator.free(content);

    try std.testing.expectEqualStrings("name = \"x\"\n", content);
}

test {
    _ = @import("parser.zig");
    _ = @import("parser_tests.zig");
    _ = @import("loader.zig");
    _ = @import("dir_loader.zig");
    _ = @import("serializer.zig");
    _ = @import("watcher.zig");
    _ = @import("dynamic.zig");
    _ = @import("import.zig");
}
