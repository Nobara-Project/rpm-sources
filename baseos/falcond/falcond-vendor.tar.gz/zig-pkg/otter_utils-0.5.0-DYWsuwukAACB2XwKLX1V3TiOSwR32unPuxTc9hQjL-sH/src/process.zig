//! Process spawning utilities for fire-and-forget commands.
//!
//! All Otter Shell apps that spawn external commands (bar buttons, network
//! widget, launcher) must go through these helpers to ensure child processes
//! are properly reaped and never left as zombies.

const std = @import("std");
const posix = std.posix;

const log = @import("log.zig").Scoped("process");

/// Spawn a shell command via `/bin/sh -c` and reap the child asynchronously.
/// A detached thread calls waitpid to prevent zombies — same principle as
/// falcond's screensaver.zig but non-blocking so the event loop isn't stalled.
pub fn spawnCommand(io: std.Io, cmd: []const u8) void {
    const argv = [_][]const u8{ "/bin/sh", "-c", cmd };

    const child = std.process.spawn(io, .{
        .argv = &argv,
        .stdin = .ignore,
        .stdout = .ignore,
        .stderr = .ignore,
    }) catch |err| {
        log.err("Failed to spawn command '{s}': {s}", .{ cmd, @errorName(err) });
        return;
    };

    if (child.id) |pid| reapChild(pid);
}

/// Spawn an argv command and reap the child asynchronously.
pub fn spawnArgv(io: std.Io, argv: []const []const u8) void {
    const child = std.process.spawn(io, .{
        .argv = argv,
        .stdin = .ignore,
        .stdout = .ignore,
        .stderr = .ignore,
    }) catch |err| {
        log.err("Failed to spawn process: {s}", .{@errorName(err)});
        return;
    };

    if (child.id) |pid| reapChild(pid);
}

/// Detached thread that calls waitpid(pid, 0) to reap the child.
fn reapChild(pid: posix.pid_t) void {
    const thread = std.Thread.spawn(.{}, struct {
        fn run(child_pid: posix.pid_t) void {
            var status: c_int = 0;
            // std.posix.waitpid was removed in 0.16; use the cross-platform libc call directly.
            _ = std.posix.system.waitpid(child_pid, &status, 0);
        }
    }.run, .{pid}) catch |err| {
        log.err("Failed to spawn reaper thread for pid {d}: {s}", .{ pid, @errorName(err) });
        return;
    };
    thread.detach();
}
