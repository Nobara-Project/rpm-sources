const std = @import("std");
const dbus = @import("dbus/connection.zig");
const Message = @import("dbus/message.zig").Message;

pub const Seat = struct {
    name: []const u8,
    path: []const u8 = "",
    graphical: bool,
    vtnr: ?u16,

    pub fn fromProperties(name: []const u8, graphical: bool, vtnr: ?u16) Seat {
        return .{ .name = name, .graphical = graphical, .vtnr = vtnr };
    }
};

pub const SeatEvent = union(enum) { added: Seat, removed: []const u8 };

pub const LogindSeats = struct {
    allocator: std.mem.Allocator,
    connection: dbus.Connection,
    callback: ?*const fn (SeatEvent, ?*anyopaque) void = null,
    callback_ctx: ?*anyopaque = null,

    pub fn init(allocator: std.mem.Allocator) !LogindSeats {
        return .{
            .allocator = allocator,
            .connection = try dbus.Connection.open(allocator, .system),
        };
    }

    pub fn list(self: *LogindSeats, allocator: std.mem.Allocator) ![]Seat {
        var reply = try self.connection.callMethod(
            "org.freedesktop.login1",
            "/org/freedesktop/login1",
            "org.freedesktop.login1.Manager",
            "ListSeats",
        );
        defer reply.unref();

        var seats = std.ArrayList(Seat).empty;
        errdefer freeList(allocator, seats.items);
        _ = try reply.enterArray("(so)");
        while (!reply.atEnd()) {
            if (!try reply.enterStruct("so")) break;
            const name = try reply.readString();
            const path = try reply.readObjectPath();
            try reply.exitContainer();
            try seats.append(allocator, .{
                .name = try allocator.dupe(u8, name),
                .path = try allocator.dupe(u8, path),
                .graphical = true,
                .vtnr = null,
            });
        }
        try reply.exitContainer();
        return seats.toOwnedSlice(allocator);
    }

    pub fn freeList(allocator: std.mem.Allocator, seats: []Seat) void {
        for (seats) |seat| {
            allocator.free(seat.name);
            allocator.free(seat.path);
        }
        allocator.free(seats);
    }

    pub fn subscribe(self: *LogindSeats, callback: *const fn (SeatEvent, ?*anyopaque) void, ctx: ?*anyopaque) !void {
        self.callback = callback;
        self.callback_ctx = ctx;
        try self.connection.subscribeSignal(
            "org.freedesktop.login1.Manager",
            "SeatNew",
            onSeatNew,
            self,
        );
        try self.connection.subscribeSignal(
            "org.freedesktop.login1.Manager",
            "SeatRemoved",
            onSeatRemoved,
            self,
        );
    }

    pub fn getFd(self: *const LogindSeats) std.posix.fd_t {
        return self.connection.getFd();
    }

    pub fn process(self: *LogindSeats) bool {
        return self.connection.process();
    }

    pub fn deinit(self: *LogindSeats) void {
        self.connection.deinit();
    }
};

fn onSeatNew(msg: Message, ctx: ?*anyopaque) void {
    const self: *LogindSeats = @ptrCast(@alignCast(ctx.?));
    if (self.callback == null) return;
    var mutable = msg;
    const name = mutable.readString() catch return;
    const path = mutable.readObjectPath() catch return;
    self.callback.?(SeatEvent{ .added = .{
        .name = name,
        .path = path,
        .graphical = true,
        .vtnr = null,
    } }, self.callback_ctx);
}

fn onSeatRemoved(msg: Message, ctx: ?*anyopaque) void {
    const self: *LogindSeats = @ptrCast(@alignCast(ctx.?));
    if (self.callback == null) return;
    var mutable = msg;
    const name = mutable.readString() catch return;
    self.callback.?(SeatEvent{ .removed = name }, self.callback_ctx);
}

test "seat record marks graphical seats" {
    const seat = Seat.fromProperties("seat1", true, @as(?u16, 2));
    try std.testing.expect(seat.graphical);
    try std.testing.expectEqualStrings("seat1", seat.name);
    try std.testing.expectEqual(@as(?u16, 2), seat.vtnr);
}
