const std = @import("std");
const c = @cImport({
    @cInclude("security/pam_appl.h");
});

pub const PromptStyle = enum { echo_on, echo_off, info, error_msg };
pub const Result = enum { success, auth_error, account_error, new_auth_token_required, service_error };

pub const Prompt = struct {
    style: PromptStyle,
    message: []const u8,
};

pub const Response = struct {
    text: []const u8,
};

pub const Conversation = struct {
    context: ?*anyopaque = null,
    on_prompt: *const fn (Prompt, ?*anyopaque) anyerror!Response,
    on_message: *const fn (Prompt, ?*anyopaque) void,
};

pub const Metadata = struct {
    service: []const u8,
    username: []const u8,
    seat: []const u8,
    vtnr: ?u16 = null,
    session_type: []const u8 = "wayland",
    session_class: []const u8 = "user",
    session_desktop: []const u8 = "",
};

pub fn Session(comptime Backend: type) type {
    return struct {
        backend: *Backend,
        metadata: Metadata,

        pub fn init(backend: *Backend, metadata: Metadata) @This() {
            return .{ .backend = backend, .metadata = metadata };
        }

        pub fn authenticate(self: *@This(), conversation: Conversation) !void {
            return self.backend.authenticate(self.metadata, conversation);
        }

        pub fn begin(self: *@This(), conversation: Conversation) !void {
            return self.backend.begin(self.metadata, conversation);
        }

        pub fn account(self: *@This()) !Result {
            return self.backend.account();
        }

        pub fn changeToken(self: *@This(), conversation: Conversation) !void {
            return self.backend.changeToken(conversation);
        }

        pub fn establishCredentials(self: *@This()) !void {
            return self.backend.establishCredentials();
        }

        pub fn open(self: *@This()) !void {
            return self.backend.open();
        }

        pub fn envList(self: *@This(), allocator: std.mem.Allocator) ![]const []const u8 {
            return self.backend.envList(allocator);
        }

        pub fn close(self: *@This()) !void {
            return self.backend.close();
        }

        pub fn deleteCredentials(self: *@This()) !void {
            return self.backend.deleteCredentials();
        }
    };
}

pub const PamBackend = struct {
    handle: ?*c.pam_handle_t = null,
    metadata: Metadata,
    opened: bool = false,
    conv_context: ConvContext = .{ .conversation = noopConversation() },

    pub fn init(metadata: Metadata) PamBackend {
        return .{ .metadata = metadata };
    }

    pub fn authenticate(self: *PamBackend, metadata: Metadata, conversation: Conversation) !void {
        try self.begin(metadata, conversation);
        const rc = c.pam_authenticate(self.handle.?, 0);
        if (rc != c.PAM_SUCCESS) return error.PamAuthFailed;
    }

    pub fn begin(self: *PamBackend, metadata: Metadata, conversation: Conversation) !void {
        self.metadata = metadata;
        self.conv_context = .{ .conversation = conversation };
        var conv = c.pam_conv{ .conv = pamConversation, .appdata_ptr = &self.conv_context };
        const service_z = try std.heap.page_allocator.dupeZ(u8, metadata.service);
        defer std.heap.page_allocator.free(service_z);
        const user_z = try std.heap.page_allocator.dupeZ(u8, metadata.username);
        defer std.heap.page_allocator.free(user_z);

        if (self.handle == null) {
            const rc = c.pam_start(service_z.ptr, user_z.ptr, &conv, &self.handle);
            if (rc != c.PAM_SUCCESS) return error.PamStartFailed;
            try self.setMetadata();
        } else {
            if (c.pam_set_item(self.handle.?, c.PAM_CONV, &conv) != c.PAM_SUCCESS) return error.PamConversationFailed;
        }
    }

    pub fn account(self: *PamBackend) !Result {
        const handle = self.handle orelse return .service_error;
        return mapPamResult(c.pam_acct_mgmt(handle, 0), true);
    }

    pub fn changeToken(self: *PamBackend, conversation: Conversation) !void {
        const handle = self.handle orelse return error.PamNotStarted;
        self.conv_context = .{ .conversation = conversation };
        var conv = c.pam_conv{ .conv = pamConversation, .appdata_ptr = &self.conv_context };
        if (c.pam_set_item(handle, c.PAM_CONV, &conv) != c.PAM_SUCCESS) return error.PamConversationFailed;
        if (c.pam_chauthtok(handle, 0) != c.PAM_SUCCESS) return error.PamChangeTokenFailed;
    }

    pub fn establishCredentials(self: *PamBackend) !void {
        const handle = self.handle orelse return error.PamNotStarted;
        if (c.pam_setcred(handle, c.PAM_ESTABLISH_CRED) != c.PAM_SUCCESS) return error.PamCredentialFailed;
    }

    pub fn open(self: *PamBackend) !void {
        const handle = self.handle orelse return error.PamNotStarted;
        if (c.pam_open_session(handle, 0) != c.PAM_SUCCESS) return error.PamOpenSessionFailed;
        self.opened = true;
    }

    pub fn envList(self: *PamBackend, allocator: std.mem.Allocator) ![]const []const u8 {
        const handle = self.handle orelse return allocator.alloc([]const u8, 0);
        const raw = c.pam_getenvlist(handle);
        if (raw == null) return allocator.alloc([]const u8, 0);
        defer freePamEnv(raw);
        var count: usize = 0;
        while (raw[count] != null) : (count += 1) {}
        const out = try allocator.alloc([]const u8, count);
        for (0..count) |i| out[i] = try allocator.dupe(u8, std.mem.span(raw[i]));
        return out;
    }

    pub fn putEnvEntry(self: *PamBackend, entry: []const u8) !void {
        const handle = self.handle orelse return error.PamNotStarted;
        const entry_z = try std.heap.page_allocator.dupeZ(u8, entry);
        defer std.heap.page_allocator.free(entry_z);
        if (c.pam_putenv(handle, entry_z.ptr) != c.PAM_SUCCESS) return error.PamEnvFailed;
    }

    pub fn close(self: *PamBackend) !void {
        if (self.handle) |handle| {
            if (self.opened) _ = c.pam_close_session(handle, 0);
        }
        self.opened = false;
    }

    pub fn deleteCredentials(self: *PamBackend) !void {
        if (self.handle) |handle| _ = c.pam_setcred(handle, c.PAM_DELETE_CRED);
    }

    pub fn end(self: *PamBackend) void {
        if (self.handle) |handle| {
            _ = c.pam_end(handle, c.PAM_SUCCESS);
            self.handle = null;
        }
    }

    fn setMetadata(self: *PamBackend) !void {
        const handle = self.handle orelse return error.PamNotStarted;
        try setEnv(handle, "XDG_SESSION_TYPE", self.metadata.session_type);
        try setEnv(handle, "XDG_SESSION_CLASS", self.metadata.session_class);
        try setEnv(handle, "XDG_SEAT", self.metadata.seat);
        if (self.metadata.session_desktop.len != 0) try setEnv(handle, "XDG_SESSION_DESKTOP", self.metadata.session_desktop);
        if (self.metadata.vtnr) |vtnr| {
            var buf: [16]u8 = undefined;
            const vtnr_text = try std.fmt.bufPrint(&buf, "{d}", .{vtnr});
            try setEnv(handle, "XDG_VTNR", vtnr_text);
            var tty_buf: [16]u8 = undefined;
            if (c.pam_set_item(handle, c.PAM_TTY, (try std.fmt.bufPrintZ(&tty_buf, "tty{s}", .{vtnr_text})).ptr) != c.PAM_SUCCESS) return error.PamTtyFailed;
        }
    }
};

pub const PamSession = Session(PamBackend);

const ConvContext = struct {
    conversation: Conversation,
};

fn noopConversation() Conversation {
    return .{ .on_prompt = noopPrompt, .on_message = noopMessage };
}

fn noopPrompt(_: Prompt, _: ?*anyopaque) anyerror!Response {
    return error.PamConversationUnavailable;
}

fn noopMessage(_: Prompt, _: ?*anyopaque) void {}

fn pamConversation(num_msg: c_int, msg: [*c][*c]const c.pam_message, resp: [*c][*c]c.pam_response, appdata_ptr: ?*anyopaque) callconv(.c) c_int {
    const ctx: *ConvContext = @ptrCast(@alignCast(appdata_ptr orelse return c.PAM_CONV_ERR));
    const count: usize = if (num_msg > 0) @intCast(num_msg) else return c.PAM_CONV_ERR;
    const responses: [*c]c.pam_response = @ptrCast(@alignCast(std.c.malloc(count * @sizeOf(c.pam_response)) orelse return c.PAM_BUF_ERR));
    for (0..count) |i| {
        responses[i] = .{ .resp = null, .resp_retcode = 0 };
        const m = msg[i].*;
        const text = if (m.msg) |p| std.mem.span(p) else "";
        const style: PromptStyle = switch (m.msg_style) {
            c.PAM_PROMPT_ECHO_ON => .echo_on,
            c.PAM_PROMPT_ECHO_OFF => .echo_off,
            c.PAM_TEXT_INFO => .info,
            c.PAM_ERROR_MSG => .error_msg,
            else => {
                freeResponses(responses, i);
                return c.PAM_CONV_ERR;
            },
        };
        if (style == .info or style == .error_msg) {
            ctx.conversation.on_message(.{ .style = style, .message = text }, ctx.conversation.context);
            continue;
        }
        const answer = ctx.conversation.on_prompt(.{ .style = style, .message = text }, ctx.conversation.context) catch {
            freeResponses(responses, i);
            return c.PAM_CONV_ERR;
        };
        const buf: [*c]u8 = @ptrCast(std.c.malloc(answer.text.len + 1) orelse {
            freeResponses(responses, i);
            return c.PAM_BUF_ERR;
        });
        @memcpy(buf[0..answer.text.len], answer.text);
        buf[answer.text.len] = 0;
        responses[i].resp = buf;
    }
    resp[0] = responses;
    return c.PAM_SUCCESS;
}

fn freeResponses(responses: [*c]c.pam_response, count: usize) void {
    for (0..count) |i| {
        if (responses[i].resp) |raw| {
            const ptr: [*]u8 = @ptrCast(raw);
            var len: usize = 0;
            while (ptr[len] != 0) : (len += 1) {}
            @memset(ptr[0..len], 0);
            std.c.free(raw);
        }
    }
    std.c.free(responses);
}

fn setEnv(handle: *c.pam_handle_t, key: []const u8, value: []const u8) !void {
    const entry = try std.fmt.allocPrintSentinel(std.heap.page_allocator, "{s}={s}", .{ key, value }, 0);
    defer std.heap.page_allocator.free(entry);
    if (c.pam_putenv(handle, entry.ptr) != c.PAM_SUCCESS) return error.PamEnvFailed;
}

fn mapPamResult(rc: c_int, account: bool) Result {
    if (rc == c.PAM_SUCCESS) return .success;
    if (account and rc == c.PAM_NEW_AUTHTOK_REQD) return .new_auth_token_required;
    if (account) return .account_error;
    return .auth_error;
}

fn freePamEnv(raw: [*c][*c]u8) void {
    var i: usize = 0;
    while (raw[i] != null) : (i += 1) std.c.free(raw[i]);
    std.c.free(@ptrCast(raw));
}

const FakeBackend = struct {
    result: Result,
    closed: bool = false,
    began: bool = false,
    authenticated: bool = false,

    fn init(result: Result) FakeBackend {
        return .{ .result = result };
    }

    fn begin(self: *FakeBackend, _: Metadata, _: Conversation) !void {
        self.began = true;
    }

    fn authenticate(self: *FakeBackend, _: Metadata, conversation: Conversation) !void {
        self.authenticated = true;
        _ = try conversation.on_prompt(.{ .style = .echo_off, .message = "Password:" }, conversation.context);
    }

    fn account(self: *FakeBackend) !Result {
        return self.result;
    }

    fn changeToken(_: *FakeBackend, conversation: Conversation) !void {
        _ = try conversation.on_prompt(.{ .style = .echo_off, .message = "New password:" }, conversation.context);
    }

    fn establishCredentials(_: *FakeBackend) !void {}
    fn open(_: *FakeBackend) !void {}
    fn envList(_: *FakeBackend, allocator: std.mem.Allocator) ![]const []const u8 {
        return allocator.alloc([]const u8, 0);
    }

    fn close(self: *FakeBackend) !void {
        self.closed = true;
    }

    fn deleteCredentials(_: *FakeBackend) !void {}
};

fn promptOk(prompt: Prompt, ctx: ?*anyopaque) anyerror!Response {
    _ = prompt;
    _ = ctx;
    return .{ .text = "secret" };
}

fn messageNoop(prompt: Prompt, ctx: ?*anyopaque) void {
    _ = prompt;
    _ = ctx;
}

fn testConversation() Conversation {
    return .{ .on_prompt = promptOk, .on_message = messageNoop };
}

test "fake PAM flow handles password change requirement" {
    var fake = FakeBackend.init(.new_auth_token_required);
    var session = Session(FakeBackend).init(&fake, .{
        .service = "otter-greeter",
        .username = "ferreo",
        .seat = "seat0",
    });
    try session.authenticate(testConversation());
    try std.testing.expectEqual(Result.new_auth_token_required, try session.account());
    try session.changeToken(testConversation());
    try session.establishCredentials();
    try session.open();
    try session.close();
    try session.deleteCredentials();
    try std.testing.expect(fake.closed);
}

test "fake PAM flow can begin unauthenticated greeter session" {
    var fake = FakeBackend.init(.success);
    var session = Session(FakeBackend).init(&fake, .{
        .service = "otter-greeter-greeter",
        .username = "otter-greeter",
        .seat = "seat0",
        .session_class = "greeter",
    });
    try session.begin(testConversation());
    try std.testing.expect(fake.began);
    try std.testing.expect(!fake.authenticated);
    try std.testing.expectEqual(Result.success, try session.account());
    try session.establishCredentials();
    try session.open();
    try session.close();
    try session.deleteCredentials();
}
