//! System Information Service
//!
//! Provides access to system metrics including CPU usage, memory usage,
//! disk usage, and CPU temperature via sysinfo(2), /proc/stat, and /sys.
//!
//! Design principles:
//! - Data-driven: Lookup tables replace branching logic
//! - Branchless: SIMD and arithmetic operations minimize branching
//! - Zero-allocation: Stack buffers, no heap usage
//! - Pub/sub: Subscribe for state change notifications
//! - Minimal syscalls: sysinfo(2) replaces /proc/meminfo, /proc/loadavg, /proc/uptime
//!
//! Call `refresh()` periodically to update metrics and notify subscribers.

const std = @import("std");
const otter_utils = @import("otter_utils");
/// Cached reference to the app-installed `std.Io`. Fetched lazily to avoid
/// evaluating before `otter_utils.io.install(...)` runs in `main()`.
inline fn io_global() std.Io {
    return otter_utils.io.get();
}

const fs = std.Io;
const mem = std.mem;
const linux = std.os.linux;

const log = std.log.scoped(.sysinfo);

// ============================================================================
// Constants
// ============================================================================

const max_path_len: usize = 256;
const max_name_len: usize = 64;
const max_temp_sensors: usize = 8;
const max_subscribers: usize = 8;
const read_buf_size: usize = 4096;

const sysfs_hwmon_path = "/sys/class/hwmon";
const proc_stat_path = "/proc/stat";
const proc_meminfo_path = "/proc/meminfo";

/// Memory field indices for data-driven parsing
const MemField = enum(u8) {
    mem_total = 0,
    mem_available = 1,
    mem_free = 2,
    buffers = 3,
    cached = 4,
    swap_total = 5,
    swap_free = 6,

    const count = 7;
};

/// Memory field lookup table
const mem_field_names = [MemField.count][]const u8{
    "MemTotal:",
    "MemAvailable:",
    "MemFree:",
    "Buffers:",
    "Cached:",
    "SwapTotal:",
    "SwapFree:",
};

// ============================================================================
// Data-Driven Sensor Detection
// ============================================================================

/// Sensor configuration entry for data-driven detection
const SensorConfig = struct {
    name: []const u8,
    sensor_type: TempSensor.SensorType,
    /// Temperature input index to use (0 = temp1, 1 = temp2, etc.)
    primary_input: u8,
    /// Whether to average multiple inputs
    average_inputs: bool,
    /// Start index for averaging (0-based)
    avg_start: u8,
    /// End index for averaging (exclusive, 0-based)
    avg_end: u8,
};

/// Data-driven sensor lookup table - checked in order
const sensor_configs = [_]SensorConfig{
    .{ .name = "coretemp", .sensor_type = .coretemp, .primary_input = 0, .average_inputs = true, .avg_start = 1, .avg_end = 16 },
    .{ .name = "k10temp", .sensor_type = .k10temp, .primary_input = 0, .average_inputs = false, .avg_start = 0, .avg_end = 0 },
    .{ .name = "zenpower", .sensor_type = .k10temp, .primary_input = 0, .average_inputs = false, .avg_start = 0, .avg_end = 0 },
    .{ .name = "acpitz", .sensor_type = .acpitz, .primary_input = 0, .average_inputs = false, .avg_start = 0, .avg_end = 0 },
    .{ .name = "thinkpad", .sensor_type = .other, .primary_input = 0, .average_inputs = false, .avg_start = 0, .avg_end = 0 },
    .{ .name = "it87", .sensor_type = .other, .primary_input = 0, .average_inputs = false, .avg_start = 0, .avg_end = 0 },
    .{ .name = "nct", .sensor_type = .other, .primary_input = 0, .average_inputs = false, .avg_start = 0, .avg_end = 0 },
};

// ============================================================================
// Linux Syscall Types
// ============================================================================

const Statfs = extern struct {
    f_type: u64,
    f_bsize: u64,
    f_blocks: u64,
    f_bfree: u64,
    f_bavail: u64,
    f_files: u64,
    f_ffree: u64,
    f_fsid: [2]i32,
    f_namelen: u64,
    f_frsize: u64,
    f_flags: u64,
    f_spare: [4]u64,
};

// ============================================================================
// Public Types
// ============================================================================

/// Memory information in bytes and percentages
pub const MemoryInfo = struct {
    total: u64 = 0,
    available: u64 = 0,
    used: u64 = 0,
    percent_used: u8 = 0,
    swap_total: u64 = 0,
    swap_used: u64 = 0,
    swap_percent: u8 = 0,

    pub fn usedGiB(self: MemoryInfo) f32 {
        return toGiB(self.used);
    }

    pub fn totalGiB(self: MemoryInfo) f32 {
        return toGiB(self.total);
    }

    pub fn availableGiB(self: MemoryInfo) f32 {
        return toGiB(self.available);
    }

    pub fn swapUsedGiB(self: MemoryInfo) f32 {
        return toGiB(self.swap_used);
    }

    pub fn swapTotalGiB(self: MemoryInfo) f32 {
        return toGiB(self.swap_total);
    }
};

/// Disk usage information
pub const DiskInfo = struct {
    total: u64 = 0,
    free: u64 = 0,
    used: u64 = 0,
    percent_used: u8 = 0,

    pub fn usedGiB(self: DiskInfo) f32 {
        return toGiB(self.used);
    }

    pub fn totalGiB(self: DiskInfo) f32 {
        return toGiB(self.total);
    }

    pub fn freeGiB(self: DiskInfo) f32 {
        return toGiB(self.free);
    }
};

/// CPU time counters for usage calculation
pub const CpuTimes = struct {
    idle: u64 = 0,
    total: u64 = 0,
};

/// System load averages
pub const LoadAverage = struct {
    one: f32 = 0,
    five: f32 = 0,
    fifteen: f32 = 0,
};

/// Temperature sensor information
pub const TempSensor = struct {
    name: [max_name_len]u8 = undefined,
    name_len: usize = 0,
    hwmon_index: usize = 0,
    sensor_type: SensorType = .unknown,
    config_index: usize = 0,

    pub const SensorType = enum(u8) {
        unknown = 0,
        coretemp = 1,
        k10temp = 2,
        acpitz = 3,
        other = 4,
    };

    pub fn getName(self: *const TempSensor) []const u8 {
        return self.name[0..self.name_len];
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscription = struct {
    callback: StateChangeFn,
    context: ?*anyopaque,
};

pub const Error = error{
    ReadFailed,
    ParseFailed,
    PathTooLong,
    NotFound,
    StatFailed,
};

// ============================================================================
// SysInfo Service
// ============================================================================

pub const SysInfo = struct {
    // Internal buffers
    path_buf: [max_path_len]u8 = undefined,
    read_buf: [read_buf_size]u8 = undefined,

    // CPU tracking
    prev_cpu_times: CpuTimes = .{},
    has_prev_cpu: bool = false,

    // Temperature sensors
    temp_sensors: [max_temp_sensors]TempSensor = undefined,
    temp_sensor_count: usize = 0,
    temp_sensors_enumerated: bool = false,

    // Subscriptions
    subscriptions: [max_subscribers]Subscription = undefined,
    subscription_mask: u8 = 0,

    // Throttling
    last_refresh_ms: i64 = 0,
    refresh_interval_ms: i64 = 3000, // Default 3 seconds

    // Cached sysinfo(2) result
    cached_sysinfo: linux.Sysinfo = undefined,
    cached_sysinfo_valid: bool = false,

    // Cached metrics
    memory: MemoryInfo = .{},
    cpu_percent: u8 = 0,
    cpu_temp: ?i32 = null,
    disk: DiskInfo = .{},
    load: LoadAverage = .{},
    uptime_seconds: u64 = 0,

    pub fn init() SysInfo {
        return .{};
    }

    pub fn initWithInterval(interval_ms: i64) SysInfo {
        return .{ .refresh_interval_ms = interval_ms };
    }

    pub fn deinit(self: *SysInfo) void {
        self.subscription_mask = 0;
    }

    /// Subscribe to state changes (branchless slot finding)
    pub fn subscribe(self: *SysInfo, callback: StateChangeFn, context: ?*anyopaque) bool {
        const mask = self.subscription_mask;
        const free_slot = @ctz(~mask);
        if (free_slot >= max_subscribers) return false;

        self.subscriptions[free_slot] = .{ .callback = callback, .context = context };
        self.subscription_mask = mask | (@as(u8, 1) << @intCast(free_slot));
        return true;
    }

    /// Unsubscribe (branchless removal)
    pub fn unsubscribe(self: *SysInfo, callback: StateChangeFn, context: ?*anyopaque) void {
        var mask = self.subscription_mask;
        inline for (0..max_subscribers) |i| {
            const bit = @as(u8, 1) << i;
            const is_set = (mask & bit) != 0;
            const sub = self.subscriptions[i];
            const matches = is_set and sub.callback == callback and sub.context == context;
            mask &= ~(@as(u8, @intFromBool(matches)) << i);
        }
        self.subscription_mask = mask;
    }

    /// Poll for updates - only refreshes if interval has elapsed.
    /// Call this frequently (e.g., every frame or poll cycle).
    /// Returns true if a refresh occurred.
    pub fn poll(self: *SysInfo) bool {
        const now = @as(i64, @intCast(@divTrunc(std.Io.Clock.awake.now(io_global()).nanoseconds, std.time.ns_per_ms)));
        if (now - self.last_refresh_ms >= self.refresh_interval_ms) {
            self.refresh();
            return true;
        }
        return false;
    }

    /// Force refresh all metrics and notify subscribers.
    /// Use poll() for throttled updates.
    pub fn refresh(self: *SysInfo) void {
        self.last_refresh_ms = @as(i64, @intCast(@divTrunc(std.Io.Clock.awake.now(io_global()).nanoseconds, std.time.ns_per_ms)));
        self.cached_sysinfo_valid = (linux.sysinfo(&self.cached_sysinfo) == 0);

        self.memory = self.getMemoryInfo();
        self.cpu_percent = self.getCpuUsage() catch 0;
        self.cpu_temp = self.getCpuTemperature();
        self.disk = self.getRootDiskInfo() catch .{};
        self.load = self.getLoadAverage();
        self.uptime_seconds = self.getUptime();
        self.notify();
    }

    fn notify(self: *const SysInfo) void {
        var mask = self.subscription_mask;
        while (mask != 0) {
            const idx = @ctz(mask);
            self.subscriptions[idx].callback(self.subscriptions[idx].context);
            mask &= mask - 1;
        }
    }

    /// Get memory info via /proc/meminfo (MemAvailable requires page cache data
    /// not available from sysinfo(2)).
    pub fn getMemoryInfo(self: *SysInfo) MemoryInfo {
        const bytes_read = readFile(proc_meminfo_path, &self.read_buf) orelse return .{};
        const content = self.read_buf[0..bytes_read];

        var values: [MemField.count]u64 = .{0} ** MemField.count;
        parseMemInfo(content, &values);

        var info = MemoryInfo{
            .total = values[@intFromEnum(MemField.mem_total)],
            .swap_total = values[@intFromEnum(MemField.swap_total)],
        };

        // Use MemAvailable if present, otherwise calculate from free + buffers + cached
        const available = values[@intFromEnum(MemField.mem_available)];
        info.available = if (available > 0) available else values[@intFromEnum(MemField.mem_free)] +
            values[@intFromEnum(MemField.buffers)] + values[@intFromEnum(MemField.cached)];

        info.used = info.total -| info.available;
        info.percent_used = calcPercent(info.used, info.total);

        const swap_free = values[@intFromEnum(MemField.swap_free)];
        info.swap_used = info.swap_total -| swap_free;
        info.swap_percent = calcPercent(info.swap_used, info.swap_total);

        return info;
    }

    pub fn getDiskInfo(self: *SysInfo, path: []const u8) Error!DiskInfo {
        // Null-terminate path for syscall
        const path_z = std.fmt.bufPrint(&self.path_buf, "{s}\x00", .{path}) catch return Error.PathTooLong;

        var stat: Statfs = undefined;
        const rc = linux.syscall2(.statfs, @intFromPtr(path_z.ptr), @intFromPtr(&stat));
        if (rc != 0) return Error.StatFailed;

        // Branchless calculations
        const block_size = stat.f_bsize;
        const used = (stat.f_blocks -| stat.f_bfree) * block_size;
        const available = stat.f_bavail * block_size;
        const total = stat.f_blocks * block_size;
        const total_relevant = used + available;

        return .{
            .total = total,
            .free = available,
            .used = used,
            .percent_used = calcPercent(used, total_relevant),
        };
    }

    pub fn getRootDiskInfo(self: *SysInfo) Error!DiskInfo {
        return self.getDiskInfo("/");
    }

    pub fn getCpuUsage(self: *SysInfo) Error!u8 {
        const current = try self.readCpuTimes();

        const idle_delta = current.idle -| self.prev_cpu_times.idle;
        const total_delta = current.total -| self.prev_cpu_times.total;

        // Branchless: multiply result by has_prev to return 0 on first call
        const has_prev: u64 = @intFromBool(self.has_prev_cpu);

        self.prev_cpu_times = current;
        self.has_prev_cpu = true;

        // Branchless division with zero-check, then mask with has_prev
        const safe_total = total_delta + @intFromBool(total_delta == 0);
        const idle_pct = (idle_delta * 100 + safe_total / 2) / safe_total;
        const usage = (100 -| idle_pct) * has_prev;
        return @intCast(@min(100, usage));
    }

    /// Get load averages from sysinfo(2). loads[] are fixed-point with SI_LOAD_SHIFT=16.
    pub fn getLoadAverage(self: *SysInfo) LoadAverage {
        if (!self.cached_sysinfo_valid) return .{};
        const shift: f32 = 1.0 / 65536.0;
        return .{
            .one = @as(f32, @floatFromInt(self.cached_sysinfo.loads[0])) * shift,
            .five = @as(f32, @floatFromInt(self.cached_sysinfo.loads[1])) * shift,
            .fifteen = @as(f32, @floatFromInt(self.cached_sysinfo.loads[2])) * shift,
        };
    }

    /// Get uptime in seconds from sysinfo(2).
    pub fn getUptime(self: *SysInfo) u64 {
        if (!self.cached_sysinfo_valid) return 0;
        return @intCast(self.cached_sysinfo.uptime);
    }

    pub fn getCpuTemperature(self: *SysInfo) ?i32 {
        if (!self.temp_sensors_enumerated) {
            self.enumerateTempSensors();
        }
        if (self.temp_sensor_count == 0) return null;

        // Read first available sensor using data-driven config
        const sensor = &self.temp_sensors[0];
        return self.readTemperatureDataDriven(sensor);
    }

    pub fn enumerateTempSensors(self: *SysInfo) void {
        self.temp_sensors_enumerated = true;
        self.temp_sensor_count = 0;

        var dir = fs.Dir.cwd().openDir(io_global(), sysfs_hwmon_path, .{ .iterate = true }) catch return;
        defer dir.close(io_global());

        var iter = dir.iterate();
        while (iter.next(io_global()) catch null) |entry| {
            if (self.temp_sensor_count >= max_temp_sensors) break;
            if (entry.kind != .directory and entry.kind != .sym_link) continue;

            if (self.probeTempSensorDataDriven(entry.name)) |sensor| {
                self.temp_sensors[self.temp_sensor_count] = sensor;
                self.temp_sensor_count += 1;
                log.info("Found sensor: {s} (hwmon{s})", .{ sensor.getName(), entry.name });
            }
        }
    }

    pub fn getTempSensors(self: *SysInfo) []const TempSensor {
        if (!self.temp_sensors_enumerated) self.enumerateTempSensors();
        return self.temp_sensors[0..self.temp_sensor_count];
    }

    // --- Private Methods ---

    fn readCpuTimes(self: *SysInfo) Error!CpuTimes {
        const bytes_read = readFile(proc_stat_path, &self.read_buf) orelse return Error.ReadFailed;
        const content = self.read_buf[0..bytes_read];

        const newline_pos = mem.indexOf(u8, content, "\n") orelse content.len;
        const cpu_line = content[0..newline_pos];

        if (!mem.startsWith(u8, cpu_line, "cpu ")) return Error.ParseFailed;

        var times = CpuTimes{};
        var fields = mem.tokenizeScalar(u8, cpu_line, ' ');
        _ = fields.next(); // skip "cpu"

        var i: usize = 0;
        while (fields.next()) |field| : (i += 1) {
            const val = std.fmt.parseInt(u64, field, 10) catch continue;
            times.total += val;
            // idle is field index 3 (branchless accumulation)
            times.idle += val * @intFromBool(i == 3);
        }
        return times;
    }

    fn probeTempSensorDataDriven(self: *SysInfo, hwmon_name: []const u8) ?TempSensor {
        const name_path = std.fmt.bufPrint(&self.path_buf, "{s}/{s}/name", .{ sysfs_hwmon_path, hwmon_name }) catch return null;

        var name_buf: [64]u8 = undefined;
        const sensor_name = readFileStr(name_path, &name_buf) orelse return null;

        // Only accept known CPU temperature sensors
        var sensor_type: TempSensor.SensorType = .unknown;
        if (mem.eql(u8, sensor_name, "coretemp")) {
            sensor_type = .coretemp;
        } else if (mem.eql(u8, sensor_name, "k10temp")) {
            sensor_type = .k10temp;
        } else if (mem.eql(u8, sensor_name, "zenpower")) {
            sensor_type = .k10temp; // zenpower uses same logic as k10temp
        } else {
            // Not a CPU temperature sensor, skip it
            return null;
        }

        // Verify sensor has temp input
        const temp_path = std.fmt.bufPrint(&self.path_buf, "{s}/{s}/temp1_input", .{ sysfs_hwmon_path, hwmon_name }) catch return null;
        fs.Dir.cwd().access(io_global(), temp_path, .{}) catch return null;

        var sensor = TempSensor{
            .sensor_type = sensor_type,
            .config_index = 0,
        };

        const len = @min(sensor_name.len, max_name_len);
        @memcpy(sensor.name[0..len], sensor_name[0..len]);
        sensor.name_len = len;

        if (mem.startsWith(u8, hwmon_name, "hwmon")) {
            sensor.hwmon_index = std.fmt.parseInt(usize, hwmon_name[5..], 10) catch 0;
        }

        return sensor;
    }

    fn readTemperatureDataDriven(self: *SysInfo, sensor: *const TempSensor) ?i32 {
        return switch (sensor.sensor_type) {
            .k10temp => self.readK10Temp(sensor.hwmon_index),
            .coretemp => self.readCoreTemp(sensor.hwmon_index),
            else => self.readSingleTemp(sensor.hwmon_index, 1),
        };
    }

    /// Read AMD k10temp - prefer average CCD temps, fall back to Tctl
    fn readK10Temp(self: *SysInfo, hwmon_index: usize) ?i32 {
        const hwmon_path = std.fmt.bufPrint(&self.path_buf, "{s}/hwmon{d}", .{ sysfs_hwmon_path, hwmon_index }) catch return null;

        var dir = fs.Dir.cwd().openDir(io_global(), hwmon_path, .{ .iterate = true }) catch return null;
        defer dir.close(io_global());

        var tccd_total: i64 = 0;
        var tccd_count: i32 = 0;
        var tctl_temp: ?i32 = null;

        var iter = dir.iterate();
        while (iter.next(io_global()) catch null) |entry| {
            // Look for temp*_label files
            if (!mem.startsWith(u8, entry.name, "temp")) continue;
            if (!mem.endsWith(u8, entry.name, "_label")) continue;

            // Read the label content
            var label_buf: [64]u8 = undefined;
            const label_path = std.fmt.bufPrint(&self.path_buf, "{s}/hwmon{d}/{s}", .{ sysfs_hwmon_path, hwmon_index, entry.name }) catch continue;
            const label = readFileStr(label_path, &label_buf) orelse continue;

            const label_idx = mem.indexOf(u8, entry.name, "_label") orelse continue;
            const temp_prefix = entry.name[0..label_idx];
            const input_path = std.fmt.bufPrint(&self.path_buf, "{s}/hwmon{d}/{s}_input", .{ sysfs_hwmon_path, hwmon_index, temp_prefix }) catch continue;
            const temp = readSysfsInt(input_path) orelse continue;

            if (isTccdLabel(label)) {
                tccd_total += temp;
                tccd_count += 1;
            } else if (mem.eql(u8, label, "Tctl")) {
                tctl_temp = @intCast(@divTrunc(temp, 1000));
            }
        }

        if (tccd_count > 0) return @intCast(@divTrunc(@divTrunc(tccd_total, tccd_count), 1000));
        if (tctl_temp) |temp| return temp;

        // Fallback to temp1_input
        return self.readSingleTemp(hwmon_index, 1);
    }

    /// Read Intel coretemp - average all temp*_input files
    fn readCoreTemp(self: *SysInfo, hwmon_index: usize) ?i32 {
        const hwmon_path = std.fmt.bufPrint(&self.path_buf, "{s}/hwmon{d}", .{ sysfs_hwmon_path, hwmon_index }) catch return null;

        var dir = fs.Dir.cwd().openDir(io_global(), hwmon_path, .{ .iterate = true }) catch return null;
        defer dir.close(io_global());

        var total: i64 = 0;
        var count: i32 = 0;

        var iter = dir.iterate();
        while (iter.next(io_global()) catch null) |entry| {
            // Look for temp*_input files
            if (!mem.startsWith(u8, entry.name, "temp")) continue;
            if (!mem.endsWith(u8, entry.name, "_input")) continue;

            const input_path = std.fmt.bufPrint(&self.path_buf, "{s}/hwmon{d}/{s}", .{ sysfs_hwmon_path, hwmon_index, entry.name }) catch continue;
            const temp = readSysfsInt(input_path) orelse continue;
            total += temp;
            count += 1;
        }

        if (count == 0) {
            return self.readSingleTemp(hwmon_index, 1);
        }

        return @intCast(@divTrunc(@divTrunc(total, count), 1000));
    }

    fn readSingleTemp(self: *SysInfo, hwmon_index: usize, temp_index: usize) ?i32 {
        const temp_path = std.fmt.bufPrint(&self.path_buf, "{s}/hwmon{d}/temp{d}_input", .{ sysfs_hwmon_path, hwmon_index, temp_index }) catch return null;
        const temp = readSysfsInt(temp_path) orelse return null;
        return @intCast(@divTrunc(temp, 1000));
    }
};

// ============================================================================
// Data-Driven Parsing Helpers
// ============================================================================

fn parseMemInfo(content: []const u8, values: *[MemField.count]u64) void {
    var lines = mem.splitScalar(u8, content, '\n');
    while (lines.next()) |line| {
        inline for (mem_field_names, 0..) |field_name, i| {
            if (mem.startsWith(u8, line, field_name)) {
                values[i] = parseKbValue(line) orelse 0;
                break;
            }
        }
    }
}

fn parseKbValue(line: []const u8) ?u64 {
    var parts = mem.tokenizeScalar(u8, line, ' ');
    _ = parts.next(); // skip label
    const val_str = parts.next() orelse return null;
    const kb = std.fmt.parseInt(u64, val_str, 10) catch return null;
    return kb * 1024;
}

fn isTccdLabel(label: []const u8) bool {
    if (!mem.startsWith(u8, label, "Tccd")) return false;
    return label.len > 4 and std.ascii.isDigit(label[4]);
}

// ============================================================================
// Branchless Utility Functions
// ============================================================================

inline fn toGiB(bytes: u64) f32 {
    return @as(f32, @floatFromInt(bytes)) * (1.0 / (1024.0 * 1024.0 * 1024.0));
}

inline fn calcPercent(used: u64, total: u64) u8 {
    const safe_total = total + @intFromBool(total == 0);
    return @intCast(@min(100, (used * 100) / safe_total));
}

fn readFile(path: []const u8, buf: []u8) ?usize {
    const file = fs.Dir.cwd().openFile(io_global(), path, .{}) catch return null;
    defer file.close(io_global());
    var reader_buf: [4096]u8 = undefined;
    var reader = file.reader(io_global(), &reader_buf);
    return reader.interface.readSliceShort(buf) catch null;
}

fn readFileStr(path: []const u8, buf: []u8) ?[]const u8 {
    const len = readFile(path, buf) orelse return null;
    if (len == 0) return null;
    return mem.trimEnd(u8, buf[0..len], &[_]u8{ '\n', '\r', ' ' });
}

fn readSysfsInt(path: []const u8) ?i64 {
    var buf: [32]u8 = undefined;
    const s = readFileStr(path, &buf) orelse return null;
    return std.fmt.parseInt(i64, s, 10) catch null;
}

// ============================================================================
// Tests
// ============================================================================

test "SysInfo types compile" {
    _ = SysInfo;
    _ = MemoryInfo;
    _ = DiskInfo;
    _ = CpuTimes;
    _ = TempSensor;
    _ = LoadAverage;
    _ = StateChangeFn;
    _ = Subscription;
    _ = Error;
}

test "MemoryInfo calculations" {
    const testing = std.testing;

    const info = MemoryInfo{
        .total = 16 * 1024 * 1024 * 1024,
        .available = 8 * 1024 * 1024 * 1024,
        .used = 8 * 1024 * 1024 * 1024,
        .percent_used = 50,
    };

    try testing.expectApproxEqAbs(@as(f32, 16.0), info.totalGiB(), 0.01);
    try testing.expectApproxEqAbs(@as(f32, 8.0), info.usedGiB(), 0.01);
    try testing.expectApproxEqAbs(@as(f32, 8.0), info.availableGiB(), 0.01);
}

test "DiskInfo calculations" {
    const testing = std.testing;

    const info = DiskInfo{
        .total = 500 * 1024 * 1024 * 1024,
        .used = 250 * 1024 * 1024 * 1024,
        .free = 250 * 1024 * 1024 * 1024,
        .percent_used = 50,
    };

    try testing.expectApproxEqAbs(@as(f32, 500.0), info.totalGiB(), 0.01);
    try testing.expectApproxEqAbs(@as(f32, 250.0), info.usedGiB(), 0.01);
}

test "calcPercent branchless" {
    const testing = std.testing;

    try testing.expectEqual(@as(u8, 50), calcPercent(50, 100));
    try testing.expectEqual(@as(u8, 0), calcPercent(0, 100));
    try testing.expectEqual(@as(u8, 100), calcPercent(100, 100));
    try testing.expectEqual(@as(u8, 0), calcPercent(0, 0)); // Edge case: no division by zero
    try testing.expectEqual(@as(u8, 100), calcPercent(200, 100)); // Clamped to 100
}

test "toGiB" {
    const testing = std.testing;

    try testing.expectApproxEqAbs(@as(f32, 1.0), toGiB(1024 * 1024 * 1024), 0.001);
    try testing.expectApproxEqAbs(@as(f32, 0.0), toGiB(0), 0.001);
}

test "subscription branchless operations" {
    const testing = std.testing;

    var sys = SysInfo.init();
    defer sys.deinit();

    var call_count: usize = 0;
    const callback = struct {
        fn cb(ctx: ?*anyopaque) void {
            const count: *usize = @ptrCast(@alignCast(ctx));
            count.* += 1;
        }
    }.cb;

    // Subscribe
    try testing.expect(sys.subscribe(callback, &call_count));
    try testing.expectEqual(@as(u8, 1), sys.subscription_mask);

    // Add more subscriptions
    try testing.expect(sys.subscribe(callback, null));
    try testing.expectEqual(@as(u8, 3), sys.subscription_mask);

    // Unsubscribe first
    sys.unsubscribe(callback, &call_count);
    try testing.expectEqual(@as(u8, 2), sys.subscription_mask);

    // Fill all slots
    sys.subscription_mask = 0;
    for (0..max_subscribers) |_| {
        try testing.expect(sys.subscribe(callback, null));
    }
    try testing.expectEqual(@as(u8, 0xFF), sys.subscription_mask);

    // Should fail when full
    try testing.expect(!sys.subscribe(callback, null));
}

test "sensor config lookup" {
    const testing = std.testing;

    // Verify data-driven config
    try testing.expectEqualStrings("coretemp", sensor_configs[0].name);
    try testing.expect(sensor_configs[0].average_inputs);
    try testing.expectEqual(@as(u8, 1), sensor_configs[0].avg_start);

    try testing.expectEqualStrings("k10temp", sensor_configs[1].name);
    try testing.expect(!sensor_configs[1].average_inputs);
}

test "k10temp CCD label matching" {
    try std.testing.expect(isTccdLabel("Tccd1"));
    try std.testing.expect(isTccdLabel("Tccd2"));
    try std.testing.expect(isTccdLabel("Tccd12"));
    try std.testing.expect(!isTccdLabel("Tctl"));
    try std.testing.expect(!isTccdLabel("Tccd"));
    try std.testing.expect(!isTccdLabel("Tccd "));
}

test "memory field names alignment" {
    const testing = std.testing;

    try testing.expectEqual(@as(usize, MemField.count), mem_field_names.len);
    try testing.expectEqualStrings("MemTotal:", mem_field_names[@intFromEnum(MemField.mem_total)]);
    try testing.expectEqualStrings("SwapFree:", mem_field_names[@intFromEnum(MemField.swap_free)]);
}

test "parseMemInfo data-driven" {
    const testing = std.testing;

    const content =
        \\MemTotal:       16384000 kB
        \\MemFree:         1000000 kB
        \\MemAvailable:    8000000 kB
        \\Buffers:          500000 kB
        \\Cached:          2000000 kB
        \\SwapTotal:       4000000 kB
        \\SwapFree:        3000000 kB
    ;

    var values: [MemField.count]u64 = .{0} ** MemField.count;
    parseMemInfo(content, &values);

    try testing.expectEqual(@as(u64, 16384000 * 1024), values[@intFromEnum(MemField.mem_total)]);
    try testing.expectEqual(@as(u64, 8000000 * 1024), values[@intFromEnum(MemField.mem_available)]);
    try testing.expectEqual(@as(u64, 4000000 * 1024), values[@intFromEnum(MemField.swap_total)]);
    try testing.expectEqual(@as(u64, 3000000 * 1024), values[@intFromEnum(MemField.swap_free)]);
}

test "parseKbValue" {
    const testing = std.testing;

    const result = parseKbValue("MemTotal:       16384000 kB");
    try testing.expect(result != null);
    try testing.expectEqual(@as(u64, 16384000 * 1024), result.?);

    try testing.expect(parseKbValue("Invalid") == null);
    try testing.expect(parseKbValue("") == null);
}

test "SysInfo init and deinit" {
    var sys = SysInfo.init();
    defer sys.deinit();

    try std.testing.expectEqual(@as(u8, 0), sys.subscription_mask);
    try std.testing.expect(!sys.has_prev_cpu);
}

test "live system memory read" {
    // This test reads actual system memory info via /proc/meminfo
    var sys = SysInfo.init();
    defer sys.deinit();

    const info = sys.getMemoryInfo();

    // Basic sanity checks (may be zero in sandboxed environments)
    if (info.total > 0) {
        std.testing.expect(info.available <= info.total) catch return;
        std.testing.expect(info.percent_used <= 100) catch return;
    }
}

test "live system disk read" {
    var sys = SysInfo.init();
    defer sys.deinit();

    if (sys.getRootDiskInfo()) |info| {
        std.testing.expect(info.total > 0) catch return;
        std.testing.expect(info.percent_used <= 100) catch return;
    } else |_| {}
}

test "live system cpu read" {
    var sys = SysInfo.init();
    defer sys.deinit();

    // First read initializes
    const first = sys.getCpuUsage() catch return;
    std.testing.expectEqual(@as(u8, 0), first) catch return;

    // Second read should work
    std.Io.sleep(io_global(), .fromNanoseconds(10 * std.time.ns_per_ms), .awake) catch {};
    if (sys.getCpuUsage()) |usage| {
        std.testing.expect(usage <= 100) catch return;
    } else |_| {}
}

test "live system load average" {
    var sys = SysInfo.init();
    defer sys.deinit();

    sys.cached_sysinfo_valid = (linux.sysinfo(&sys.cached_sysinfo) == 0);
    const load = sys.getLoadAverage();

    if (sys.cached_sysinfo_valid) {
        std.testing.expect(load.one >= 0) catch return;
        std.testing.expect(load.five >= 0) catch return;
        std.testing.expect(load.fifteen >= 0) catch return;
    }
}

test "live system uptime" {
    var sys = SysInfo.init();
    defer sys.deinit();

    sys.cached_sysinfo_valid = (linux.sysinfo(&sys.cached_sysinfo) == 0);
    const uptime = sys.getUptime();

    if (sys.cached_sysinfo_valid) {
        std.testing.expect(uptime > 0) catch return;
    }
}

test "refresh updates all metrics" {
    var sys = SysInfo.init();
    defer sys.deinit();

    sys.refresh();

    // After refresh, cached values should be populated
    // (may be zero in sandboxed environments, but shouldn't crash)
    _ = sys.memory;
    _ = sys.cpu_percent;
    _ = sys.disk;
    _ = sys.load;
    _ = sys.uptime_seconds;
}
