//! Application Launcher
//!
//! Handles expanding Exec field codes and spawning applications,
//! including terminal application support.

const std = @import("std");
const otter_utils_io = @import("otter_utils");
inline fn io_global() std.Io { return otter_utils_io.io.get(); }
const mem = std.mem;
const Allocator = std.mem.Allocator;

const DesktopEntry = @import("desktop_entry.zig").DesktopEntry;
const process = @import("otter_utils").process;

const log = std.log.scoped(.Launcher);

pub const LaunchError = error{
    OutOfMemory,
    SpawnFailed,
};

/// Terminal emulator configuration: command name and the flag/subcommand
/// used to pass a command for execution.
pub const TerminalConfig = struct {
    cmd: []const u8,
    /// Flag or subcommand placed between the terminal and the app command.
    /// e.g. "-e", "--", "start --", or "" (for xdg-terminal-exec which takes args directly).
    exec_flag: []const u8,
};

/// Known terminal emulators in priority order (Wayland-native first).
const known_terminals = [_]TerminalConfig{
    .{ .cmd = "xdg-terminal-exec", .exec_flag = "" },
    .{ .cmd = "foot", .exec_flag = "-e" },
    .{ .cmd = "otter-term", .exec_flag = "-e" },
    .{ .cmd = "ghostty", .exec_flag = "-e" },
    .{ .cmd = "kitty", .exec_flag = "-e" },
    .{ .cmd = "alacritty", .exec_flag = "-e" },
    .{ .cmd = "wezterm", .exec_flag = "start --" },
    .{ .cmd = "rio", .exec_flag = "-e" },
    .{ .cmd = "contour", .exec_flag = "execute" },
    .{ .cmd = "gnome-terminal", .exec_flag = "--" },
    .{ .cmd = "konsole", .exec_flag = "-e" },
    .{ .cmd = "xfce4-terminal", .exec_flag = "-e" },
    .{ .cmd = "mate-terminal", .exec_flag = "-e" },
    .{ .cmd = "tilix", .exec_flag = "-e" },
    .{ .cmd = "xterm", .exec_flag = "-e" },
};

const fallback_terminal = TerminalConfig{ .cmd = "xterm", .exec_flag = "-e" };

/// Detect an available terminal emulator.
/// Priority: $TERMINAL env var > probing known terminals in PATH.
pub fn detectTerminal() TerminalConfig {
    // 1. Check $TERMINAL environment variable
    if (blk: { if (std.c.getenv("TERMINAL")) |raw| break :blk std.mem.span(raw); break :blk @as(?[]const u8, null); }) |term| {
        if (term.len > 0) {
            // Match against known terminals for correct exec flag
            for (known_terminals) |def| {
                if (mem.eql(u8, term, def.cmd)) return def;
            }
            // Unknown terminal - assume -e convention
            return .{ .cmd = term, .exec_flag = "-e" };
        }
    }

    // 2. Probe known terminals in PATH
    const path_env = blk: { if (std.c.getenv("PATH")) |raw| break :blk std.mem.span(raw); break :blk @as(?[]const u8, null); } orelse "/usr/local/bin:/usr/bin:/bin";
    for (known_terminals) |def| {
        if (existsInPath(def.cmd, path_env)) {
            log.info("Detected terminal: {s}", .{def.cmd});
            return def;
        }
    }

    return fallback_terminal;
}

/// Check whether a binary name exists in any PATH directory.
fn existsInPath(name: []const u8, path_env: []const u8) bool {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    var iter = mem.splitScalar(u8, path_env, ':');
    while (iter.next()) |dir| {
        if (dir.len == 0) continue;
        const full = std.fmt.bufPrint(&path_buf, "{s}/{s}", .{ dir, name }) catch continue;
        std.Io.Dir.cwd().access(io_global(), full, .{}) catch continue;
        return true;
    }
    return false;
}

/// Launch an application from its desktop entry.
/// Auto-detects a terminal emulator for Terminal=true entries.
pub fn launch(allocator: Allocator, entry: *const DesktopEntry) LaunchError!void {
    return launchWithTerminal(allocator, entry, detectTerminal());
}

/// Launch an application with a specific terminal emulator config.
pub fn launchWithTerminal(
    allocator: Allocator,
    entry: *const DesktopEntry,
    terminal: TerminalConfig,
) LaunchError!void {
    // Expand Exec field codes
    const expanded = expandExec(allocator, entry) catch return LaunchError.OutOfMemory;
    defer allocator.free(expanded);

    // Build the actual command
    var cmd: []const u8 = undefined;
    var needs_free = false;

    if (entry.terminal) {
        cmd = if (terminal.exec_flag.len > 0)
            std.fmt.allocPrint(allocator, "{s} {s} {s}", .{ terminal.cmd, terminal.exec_flag, expanded }) catch return LaunchError.OutOfMemory
        else
            std.fmt.allocPrint(allocator, "{s} {s}", .{ terminal.cmd, expanded }) catch return LaunchError.OutOfMemory;
        needs_free = true;
    } else {
        cmd = expanded;
    }
    defer if (needs_free) allocator.free(cmd);

    log.info("Launching: {s}", .{cmd});

    process.spawnCommand(io_global(), cmd);
}

/// Expand Exec field codes according to the Desktop Entry Specification.
/// Handles: %f, %F, %u, %U (stripped), %i, %c, %k, %%
pub fn expandExec(allocator: Allocator, entry: *const DesktopEntry) Allocator.Error![]const u8 {
    const exec = entry.exec;

    // First pass: calculate required size
    var size: usize = 0;
    var i: usize = 0;
    while (i < exec.len) {
        if (exec[i] == '%' and i + 1 < exec.len) {
            const code = exec[i + 1];
            switch (code) {
                'f', 'F', 'u', 'U' => {
                    // Strip file/URL codes (no args provided)
                    i += 2;
                },
                'i' => {
                    // --icon <icon>
                    if (entry.icon) |icon| {
                        size += "--icon ".len + icon.len;
                    }
                    i += 2;
                },
                'c' => {
                    // Application name
                    size += entry.name.len;
                    i += 2;
                },
                'k' => {
                    // Desktop file path
                    size += entry.path.len;
                    i += 2;
                },
                '%' => {
                    // Literal %
                    size += 1;
                    i += 2;
                },
                else => {
                    // Unknown code, keep as-is
                    size += 2;
                    i += 2;
                },
            }
        } else {
            size += 1;
            i += 1;
        }
    }

    // Second pass: build result
    var result = try allocator.alloc(u8, size);
    var pos: usize = 0;
    i = 0;

    while (i < exec.len) {
        if (exec[i] == '%' and i + 1 < exec.len) {
            const code = exec[i + 1];
            switch (code) {
                'f', 'F', 'u', 'U' => {
                    // Strip file/URL codes
                    i += 2;
                    // Also skip any trailing space
                    while (i < exec.len and exec[i] == ' ') i += 1;
                },
                'i' => {
                    if (entry.icon) |icon| {
                        @memcpy(result[pos..][0.."--icon ".len], "--icon ");
                        pos += "--icon ".len;
                        @memcpy(result[pos..][0..icon.len], icon);
                        pos += icon.len;
                    }
                    i += 2;
                },
                'c' => {
                    @memcpy(result[pos..][0..entry.name.len], entry.name);
                    pos += entry.name.len;
                    i += 2;
                },
                'k' => {
                    @memcpy(result[pos..][0..entry.path.len], entry.path);
                    pos += entry.path.len;
                    i += 2;
                },
                '%' => {
                    result[pos] = '%';
                    pos += 1;
                    i += 2;
                },
                else => {
                    result[pos] = '%';
                    result[pos + 1] = code;
                    pos += 2;
                    i += 2;
                },
            }
        } else {
            result[pos] = exec[i];
            pos += 1;
            i += 1;
        }
    }

    // Trim trailing whitespace
    while (pos > 0 and result[pos - 1] == ' ') {
        pos -= 1;
    }

    // Return trimmed slice
    if (pos < result.len) {
        const trimmed = try allocator.realloc(result, pos);
        return trimmed;
    }

    return result;
}

/// Strip quotes from a command string.
pub fn stripQuotes(cmd: []const u8) []const u8 {
    if (cmd.len >= 2) {
        if ((cmd[0] == '"' and cmd[cmd.len - 1] == '"') or
            (cmd[0] == '\'' and cmd[cmd.len - 1] == '\''))
        {
            return cmd[1 .. cmd.len - 1];
        }
    }
    return cmd;
}

// Tests

test "expand %c to app name" {
    const allocator = std.testing.allocator;

    const entry = DesktopEntry{
        .id = "test",
        .name = "Test App",
        .comment = null,
        .exec = "myapp --title %c",
        .icon = null,
        .terminal = false,
        .categories = &.{},
        .keywords = &.{},
        .no_display = false,
        .hidden = false,
        .path = "/test.desktop",
        .allocator = allocator,
    };

    const expanded = try expandExec(allocator, &entry);
    defer allocator.free(expanded);

    try std.testing.expectEqualStrings("myapp --title Test App", expanded);
}

test "expand %k to desktop path" {
    const allocator = std.testing.allocator;

    const entry = DesktopEntry{
        .id = "test",
        .name = "Test",
        .comment = null,
        .exec = "myapp --desktop %k",
        .icon = null,
        .terminal = false,
        .categories = &.{},
        .keywords = &.{},
        .no_display = false,
        .hidden = false,
        .path = "/usr/share/applications/test.desktop",
        .allocator = allocator,
    };

    const expanded = try expandExec(allocator, &entry);
    defer allocator.free(expanded);

    try std.testing.expectEqualStrings("myapp --desktop /usr/share/applications/test.desktop", expanded);
}

test "expand %i to --icon arg" {
    const allocator = std.testing.allocator;

    const entry = DesktopEntry{
        .id = "test",
        .name = "Test",
        .comment = null,
        .exec = "myapp %i",
        .icon = "my-icon",
        .terminal = false,
        .categories = &.{},
        .keywords = &.{},
        .no_display = false,
        .hidden = false,
        .path = "/test.desktop",
        .allocator = allocator,
    };

    const expanded = try expandExec(allocator, &entry);
    defer allocator.free(expanded);

    try std.testing.expectEqualStrings("myapp --icon my-icon", expanded);
}

test "expand %% to literal percent" {
    const allocator = std.testing.allocator;

    const entry = DesktopEntry{
        .id = "test",
        .name = "Test",
        .comment = null,
        .exec = "myapp --value 50%%",
        .icon = null,
        .terminal = false,
        .categories = &.{},
        .keywords = &.{},
        .no_display = false,
        .hidden = false,
        .path = "/test.desktop",
        .allocator = allocator,
    };

    const expanded = try expandExec(allocator, &entry);
    defer allocator.free(expanded);

    try std.testing.expectEqualStrings("myapp --value 50%", expanded);
}

test "strip %f %F %u %U when no args" {
    const allocator = std.testing.allocator;

    const entry = DesktopEntry{
        .id = "test",
        .name = "Test",
        .comment = null,
        .exec = "firefox %u",
        .icon = null,
        .terminal = false,
        .categories = &.{},
        .keywords = &.{},
        .no_display = false,
        .hidden = false,
        .path = "/test.desktop",
        .allocator = allocator,
    };

    const expanded = try expandExec(allocator, &entry);
    defer allocator.free(expanded);

    try std.testing.expectEqualStrings("firefox", expanded);
}

test "strip quotes from exec" {
    try std.testing.expectEqualStrings("hello", stripQuotes("\"hello\""));
    try std.testing.expectEqualStrings("hello", stripQuotes("'hello'"));
    try std.testing.expectEqualStrings("hello", stripQuotes("hello"));
    try std.testing.expectEqualStrings("\"hello", stripQuotes("\"hello"));
}
