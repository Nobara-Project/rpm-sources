const std = @import("std");

pub fn build(b: *std.Build) void {
    const target = b.standardTargetOptions(.{});
    const optimize = b.standardOptimizeOption(.{});

    // Feature options (default enabled for backward compatibility)
    const enable_dbus = b.option(bool, "enable_dbus", "Enable D-Bus support (basu/sd-bus)") orelse true;
    const enable_pipewire = b.option(bool, "enable_pipewire", "Enable PipeWire audio support") orelse true;
    const enable_pam = b.option(bool, "enable_pam", "Enable PAM authentication support") orelse false;
    const c_allocator = b.option(CAllocator, "c_allocator", "C allocator for linked libraries (jemalloc, mimalloc)") orelse .libc;

    // Build options module (shared by main module and tests)
    const build_options = b.addOptions();
    build_options.addOption(bool, "has_dbus", enable_dbus);
    build_options.addOption(bool, "has_pipewire", enable_pipewire);
    build_options.addOption(bool, "has_pam", enable_pam);

    const session_launcher_c = b.addTranslateC(.{
        .root_source_file = b.path("src/session_launcher_c.h"),
        .target = target,
        .optimize = optimize,
    });

    const dbus_c = if (enable_dbus) blk: {
        const translate_c = b.addTranslateC(.{
            .root_source_file = b.path("src/dbus/types_c.h"),
            .target = target,
            .optimize = optimize,
        });
        translate_c.addIncludePath(b.path("vendor/basu/src"));
        break :blk translate_c.createModule();
    } else null;

    const pam_c = if (enable_pam) blk: {
        const translate_c = b.addTranslateC(.{
            .root_source_file = b.path("src/pam_c.h"),
            .target = target,
            .optimize = optimize,
        });
        translate_c.linkSystemLibrary("pam", .{});
        break :blk translate_c.createModule();
    } else null;

    // Dependencies
    const otter_utils = b.dependency("otter_utils", .{
        .target = target,
        .optimize = optimize,
    }).module("otter_utils");

    // Library module
    const mod = b.addModule("otter_desktop", .{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    configureDesktopModule(mod, otter_utils, build_options, c_allocator, session_launcher_c.createModule(), dbus_c, pam_c);

    const portal_screencast_mod = if (enable_dbus) blk: {
        const portal = b.addModule("otter_desktop_portal_screencast", .{
            .root_source_file = b.path("src/portal_screencast.zig"),
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        });
        portal.addImport("dbus_c", dbus_c.?);
        switch (c_allocator) {
            .jemalloc => portal.linkSystemLibrary("jemalloc", .{}),
            .mimalloc => portal.linkSystemLibrary("mimalloc", .{}),
            .libc => {},
        }
        break :blk portal;
    } else null;

    // Tests
    const test_mod = b.createModule(.{
        .root_source_file = b.path("src/root.zig"),
        .target = target,
        .optimize = optimize,
        .link_libc = true,
    });
    configureDesktopModule(test_mod, otter_utils, build_options, c_allocator, session_launcher_c.createModule(), dbus_c, pam_c);

    // Conditionally build and link basu (sd-bus)
    if (enable_dbus) {
        const basu = buildBasu(b, target, optimize);
        linkBasuModule(b, mod, basu);
        linkBasuModule(b, test_mod, basu);
        linkBasuModule(b, portal_screencast_mod.?, basu);
    }

    // Conditionally link PAM
    if (enable_pam) {
        linkPamModule(mod);
        linkPamModule(test_mod);
    }

    // Resolve and link PipeWire via the Cornspies/pipewire#main branch (PR #20)
    // which supports the `use_translate_c` option for 0.16 compatibility.
    if (enable_pipewire) {
        const pipewire = b.lazyDependency("pipewire", .{
            .optimize = optimize,
            .target = target,
            .use_translate_c = true,
        });
        if (pipewire) |pw| {
            // The pipewire module links its own static artifact; adding
            // linkLibrary here causes duplicate symbols across consumers.
            addPipeWireModule(mod, pw.module("pipewire"));
            addPipeWireModule(test_mod, pw.module("pipewire"));
        }
    }

    const lib_tests = b.addTest(.{
        .root_module = test_mod,
    });

    const run_lib_tests = b.addRunArtifact(lib_tests);
    const test_step = b.step("test", "Run unit tests");
    test_step.dependOn(&run_lib_tests.step);
}

const CAllocator = enum { libc, jemalloc, mimalloc };

fn configureDesktopModule(
    mod: *std.Build.Module,
    otter_utils: *std.Build.Module,
    build_options: *std.Build.Step.Options,
    c_allocator: CAllocator,
    session_launcher_c: *std.Build.Module,
    dbus_c: ?*std.Build.Module,
    pam_c: ?*std.Build.Module,
) void {
    mod.addImport("otter_utils", otter_utils);
    mod.addOptions("build_options", build_options);
    mod.addImport("session_launcher_c", session_launcher_c);
    if (dbus_c) |c_mod| mod.addImport("dbus_c", c_mod);
    if (pam_c) |c_mod| mod.addImport("pam_c", c_mod);
    switch (c_allocator) {
        .jemalloc => mod.linkSystemLibrary("jemalloc", .{}),
        .mimalloc => mod.linkSystemLibrary("mimalloc", .{}),
        .libc => {},
    }
}

fn linkBasuModule(b: *std.Build, mod: *std.Build.Module, basu: *std.Build.Step.Compile) void {
    mod.linkLibrary(basu);
    mod.addIncludePath(b.path("vendor/basu/src")); // for "systemd/sd-bus.h"
}

fn linkPamModule(mod: *std.Build.Module) void {
    mod.linkSystemLibrary("pam", .{});
}

fn addPipeWireModule(mod: *std.Build.Module, pipewire: *std.Build.Module) void {
    mod.addImport("pipewire", pipewire);
}

fn buildBasu(b: *std.Build, target: std.Build.ResolvedTarget, optimize: std.builtin.OptimizeMode) *std.Build.Step.Compile {
    // Create the basu static library using Zig 0.15 API
    const basu = b.addLibrary(.{
        .linkage = .static,
        .name = "basu",
        .root_module = b.createModule(.{
            .target = target,
            .optimize = optimize,
            .link_libc = true,
        }),
    });

    const root = basu.root_module;

    // Get absolute path for config.h include
    const config_path = b.path("vendor/basu/generated/config.h").getPath(b);

    // C compiler flags matching meson build
    const cflags: []const []const u8 = &.{
        "-std=gnu99",
        "-fvisibility=default",
        "-fno-strict-aliasing",
        "-include",
        config_path,
        // Warnings we need to suppress for basu code
        "-Wno-unused-parameter",
        "-Wno-missing-field-initializers",
        "-Wno-unused-result",
    };

    // Include paths
    root.addIncludePath(b.path("vendor/basu/generated")); // config.h, errno headers
    root.addIncludePath(b.path("vendor/basu/src/basic"));
    root.addIncludePath(b.path("vendor/basu/src/systemd"));
    root.addIncludePath(b.path("vendor/basu/src/libsystemd/sd-bus"));
    root.addIncludePath(b.path("vendor/basu/src/libsystemd/sd-daemon"));
    root.addIncludePath(b.path("vendor/basu/src/libsystemd/sd-id128"));

    // Basic utility sources
    const basic_sources: []const []const u8 = &.{
        "vendor/basu/src/basic/alloc-util.c",
        "vendor/basu/src/basic/audit-util.c",
        "vendor/basu/src/basic/bus-label.c",
        "vendor/basu/src/basic/env-util.c",
        "vendor/basu/src/basic/errno-list.c",
        "vendor/basu/src/basic/escape.c",
        "vendor/basu/src/basic/fd-util.c",
        "vendor/basu/src/basic/fileio.c",
        "vendor/basu/src/basic/fs-util.c",
        "vendor/basu/src/basic/gunicode.c",
        "vendor/basu/src/basic/hash-funcs.c",
        "vendor/basu/src/basic/hashmap.c",
        "vendor/basu/src/basic/hexdecoct.c",
        "vendor/basu/src/basic/io-util.c",
        "vendor/basu/src/basic/json.c",
        "vendor/basu/src/basic/locale-util.c",
        "vendor/basu/src/basic/log.c",
        "vendor/basu/src/basic/memfd-util.c",
        "vendor/basu/src/basic/parse-util.c",
        "vendor/basu/src/basic/path-util.c",
        "vendor/basu/src/basic/prioq.c",
        "vendor/basu/src/basic/process-util.c",
        "vendor/basu/src/basic/random-util.c",
        "vendor/basu/src/basic/siphash24.c",
        "vendor/basu/src/basic/socket-util.c",
        "vendor/basu/src/basic/string-util.c",
        "vendor/basu/src/basic/strv.c",
        "vendor/basu/src/basic/syslog-util.c",
        "vendor/basu/src/basic/terminal-util.c",
        "vendor/basu/src/basic/time-util.c",
        "vendor/basu/src/basic/user-util.c",
        "vendor/basu/src/basic/utf8.c",
        "vendor/basu/src/basic/util.c",
        "vendor/basu/src/basic/verbs.c",
        "vendor/basu/src/basic/xml.c",
    };

    // sd-bus sources
    const sdbus_sources: []const []const u8 = &.{
        "vendor/basu/src/libsystemd/sd-bus/bus-common-errors.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-control.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-convenience.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-creds.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-dump.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-error.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-gvariant.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-internal.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-introspect.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-kernel.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-match.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-message.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-objects.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-signature.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-slot.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-socket.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-track.c",
        "vendor/basu/src/libsystemd/sd-bus/bus-type.c",
        "vendor/basu/src/libsystemd/sd-bus/sd-bus.c",
    };

    // sd-id128 sources
    const id128_sources: []const []const u8 = &.{
        "vendor/basu/src/libsystemd/sd-id128/id128-util.c",
        "vendor/basu/src/libsystemd/sd-id128/sd-id128.c",
    };

    // sd-daemon sources
    const daemon_sources: []const []const u8 = &.{
        "vendor/basu/src/libsystemd/sd-daemon/sd-daemon.c",
    };

    // Add all source files
    for (basic_sources) |src| {
        root.addCSourceFile(.{ .file = b.path(src), .flags = cflags });
    }
    for (sdbus_sources) |src| {
        root.addCSourceFile(.{ .file = b.path(src), .flags = cflags });
    }
    for (id128_sources) |src| {
        root.addCSourceFile(.{ .file = b.path(src), .flags = cflags });
    }
    for (daemon_sources) |src| {
        root.addCSourceFile(.{ .file = b.path(src), .flags = cflags });
    }

    // Link required system libraries
    root.linkSystemLibrary("rt", .{}); // librt for clock_gettime, etc.
    root.linkSystemLibrary("pthread", .{}); // threading

    return basu;
}
