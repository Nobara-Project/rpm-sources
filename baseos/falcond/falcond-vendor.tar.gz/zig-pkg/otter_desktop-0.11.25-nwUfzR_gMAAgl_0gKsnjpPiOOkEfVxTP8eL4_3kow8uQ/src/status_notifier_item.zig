//! StatusNotifierItem D-Bus Client
//!
//! Reads properties and invokes actions on StatusNotifierItem instances.
//! Each tray application exposes this interface for icon, title, status, etc.
//!
//! D-Bus Interface: org.kde.StatusNotifierItem
//!
//! Reference: https://www.freedesktop.org/wiki/Specifications/StatusNotifierItem/

const std = @import("std");
const mem = std.mem;
const Allocator = std.mem.Allocator;
const FixedString = @import("otter_utils").FixedString;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.sni);

/// D-Bus constants
const sni_interface = "org.kde.StatusNotifierItem";

/// Maximum string field length
const max_string_len = 256;

/// Maximum icon pixmap dimension
const max_icon_dim = 256;

/// Item category
pub const Category = enum {
    application_status,
    communications,
    system_services,
    hardware,
    unknown,

    pub fn fromString(s: []const u8) Category {
        if (mem.eql(u8, s, "ApplicationStatus")) return .application_status;
        if (mem.eql(u8, s, "Communications")) return .communications;
        if (mem.eql(u8, s, "SystemServices")) return .system_services;
        if (mem.eql(u8, s, "Hardware")) return .hardware;
        return .unknown;
    }
};

/// Item status
pub const Status = enum {
    passive,
    active,
    needs_attention,
    unknown,

    pub fn fromString(s: []const u8) Status {
        if (mem.eql(u8, s, "Passive")) return .passive;
        if (mem.eql(u8, s, "Active")) return .active;
        if (mem.eql(u8, s, "NeedsAttention")) return .needs_attention;
        return .unknown;
    }
};

/// Icon pixmap data (ARGB32, heap-allocated)
pub const IconPixmap = struct {
    width: i32 = 0,
    height: i32 = 0,
    data: ?[]u8 = null,
    allocator: ?Allocator = null,

    pub fn deinit(self: *IconPixmap) void {
        if (self.data) |d| {
            if (self.allocator) |a| {
                a.free(d);
            }
        }
        self.* = .{};
    }

    pub fn hasData(self: *const IconPixmap) bool {
        return self.data != null and self.width > 0 and self.height > 0;
    }
};

/// Tooltip information
pub const ToolTip = struct {
    icon_name: FixedString(max_string_len) = .{},
    title: FixedString(max_string_len) = .{},
    description: FixedString(max_string_len) = .{},
};

/// All cached properties for a StatusNotifierItem
pub const ItemProperties = struct {
    id: FixedString(max_string_len) = .{},
    category: Category = .unknown,
    title: FixedString(max_string_len) = .{},
    status: Status = .unknown,
    icon_name: FixedString(max_string_len) = .{},
    icon_pixmap: IconPixmap = .{},
    overlay_icon_name: FixedString(max_string_len) = .{},
    attention_icon_name: FixedString(max_string_len) = .{},
    item_is_menu: bool = false,
    menu_path: FixedString(max_string_len) = .{},
    tooltip: ToolTip = .{},

    pub fn deinit(self: *ItemProperties) void {
        self.icon_pixmap.deinit();
    }

    /// Check if the item has a named icon (prefer over pixmap).
    pub fn hasIconName(self: *const ItemProperties) bool {
        return !self.icon_name.isEmpty();
    }
};

/// Read all properties for a StatusNotifierItem.
pub fn readItemProperties(
    conn: *dbus.Connection,
    allocator: Allocator,
    service: [:0]const u8,
    path: [:0]const u8,
) ItemProperties {
    var props = ItemProperties{};

    readPropertyString(conn, service, path, "Id", &props.id);
    readPropertyCategory(conn, service, path, &props.category);
    readPropertyString(conn, service, path, "Title", &props.title);
    readPropertyStatus(conn, service, path, &props.status);
    readPropertyString(conn, service, path, "IconName", &props.icon_name);
    readPropertyString(conn, service, path, "OverlayIconName", &props.overlay_icon_name);
    readPropertyString(conn, service, path, "AttentionIconName", &props.attention_icon_name);
    readPropertyBool(conn, service, path, "ItemIsMenu", &props.item_is_menu);
    readPropertyObjectPath(conn, service, path, "Menu", &props.menu_path);

    // Only read pixmap if no icon name
    if (props.icon_name.isEmpty()) {
        readIconPixmap(conn, allocator, service, path, &props.icon_pixmap);
    }

    readToolTip(conn, service, path, &props.tooltip);

    return props;
}

/// Call Activate(ii) on the item.
pub fn activate(conn: *dbus.Connection, service: [:0]const u8, path: [:0]const u8, x: i32, y: i32) void {
    var msg = conn.callMethodWithTwoInt32(service, path, sni_interface, "Activate", x, y) catch |err| {
        log.debug("Activate failed: {s}", .{@errorName(err)});
        return;
    };
    msg.unref();
}

/// Call SecondaryActivate(ii) on the item.
pub fn secondaryActivate(conn: *dbus.Connection, service: [:0]const u8, path: [:0]const u8, x: i32, y: i32) void {
    var msg = conn.callMethodWithTwoInt32(service, path, sni_interface, "SecondaryActivate", x, y) catch |err| {
        log.debug("SecondaryActivate failed: {s}", .{@errorName(err)});
        return;
    };
    msg.unref();
}

/// Call ContextMenu(ii) on the item.
pub fn contextMenu(conn: *dbus.Connection, service: [:0]const u8, path: [:0]const u8, x: i32, y: i32) void {
    var msg = conn.callMethodWithTwoInt32(service, path, sni_interface, "ContextMenu", x, y) catch |err| {
        log.debug("ContextMenu failed: {s}", .{@errorName(err)});
        return;
    };
    msg.unref();
}

// --- Internal property readers ---

fn readPropertyString(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    prop: [:0]const u8,
    out: anytype,
) void {
    var msg = conn.getProperty(service, path, sni_interface, prop) catch return;
    defer msg.unref();
    if (msg.enterVariant("s") catch false) {
        if (msg.readString()) |val| out.set(val) else |_| {}
        msg.exitContainer() catch {};
    }
}

fn readPropertyObjectPath(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    prop: [:0]const u8,
    out: anytype,
) void {
    var msg = conn.getProperty(service, path, sni_interface, prop) catch return;
    defer msg.unref();
    if (msg.enterVariant("o") catch false) {
        if (msg.readObjectPath()) |val| out.set(val) else |_| {}
        msg.exitContainer() catch {};
    }
}

fn readPropertyBool(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    prop: [:0]const u8,
    out: *bool,
) void {
    var msg = conn.getProperty(service, path, sni_interface, prop) catch return;
    defer msg.unref();
    if (msg.enterVariant("b") catch false) {
        out.* = msg.readBool() catch false;
        msg.exitContainer() catch {};
    }
}

fn readPropertyCategory(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    out: *Category,
) void {
    var msg = conn.getProperty(service, path, sni_interface, "Category") catch return;
    defer msg.unref();
    if (msg.enterVariant("s") catch false) {
        if (msg.readString()) |val| {
            out.* = Category.fromString(val);
        } else |_| {}
        msg.exitContainer() catch {};
    }
}

fn readPropertyStatus(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    out: *Status,
) void {
    var msg = conn.getProperty(service, path, sni_interface, "Status") catch return;
    defer msg.unref();
    if (msg.enterVariant("s") catch false) {
        if (msg.readString()) |val| {
            out.* = Status.fromString(val);
        } else |_| {}
        msg.exitContainer() catch {};
    }
}

/// Read IconPixmap property: a(iiay) — pick the largest icon ≤ max_icon_dim.
fn readIconPixmap(
    conn: *dbus.Connection,
    allocator: Allocator,
    service: [:0]const u8,
    path: [:0]const u8,
    out: *IconPixmap,
) void {
    var msg = conn.getProperty(service, path, sni_interface, "IconPixmap") catch return;
    defer msg.unref();

    if (!(msg.enterVariant("a(iiay)") catch false)) return;
    if (!(msg.enterArray("(iiay)") catch false)) {
        msg.exitContainer() catch {};
        return;
    }

    var best_w: i32 = 0;
    var best_h: i32 = 0;
    var best_data: ?[]const u8 = null;

    while (!msg.atEnd()) {
        if (!(msg.enterStruct("iiay") catch false)) break;

        const w = msg.readInt32() catch {
            msg.exitContainer() catch {};
            continue;
        };
        const h = msg.readInt32() catch {
            msg.exitContainer() catch {};
            continue;
        };
        const data = msg.readByteArray() catch {
            msg.exitContainer() catch {};
            continue;
        };

        // Pick the largest icon that fits within max_icon_dim
        if (w > 0 and h > 0 and w <= max_icon_dim and h <= max_icon_dim) {
            if (w > best_w or h > best_h) {
                best_w = w;
                best_h = h;
                best_data = data;
            }
        }

        msg.exitContainer() catch {};
    }

    msg.exitContainer() catch {}; // exit array
    msg.exitContainer() catch {}; // exit variant

    // Copy best pixmap to heap
    if (best_data) |data| {
        const heap_data = allocator.alloc(u8, data.len) catch return;
        @memcpy(heap_data, data);
        out.* = .{
            .width = best_w,
            .height = best_h,
            .data = heap_data,
            .allocator = allocator,
        };
    }
}

/// Read ToolTip property: (sa(iiay)ss)
fn readToolTip(
    conn: *dbus.Connection,
    service: [:0]const u8,
    path: [:0]const u8,
    out: *ToolTip,
) void {
    var msg = conn.getProperty(service, path, sni_interface, "ToolTip") catch return;
    defer msg.unref();

    if (!(msg.enterVariant("(sa(iiay)ss)") catch false)) return;
    if (!(msg.enterStruct("sa(iiay)ss") catch false)) {
        msg.exitContainer() catch {};
        return;
    }

    // icon_name (s)
    if (msg.readString()) |val| out.icon_name.set(val) else |_| {}

    // icon pixmap array — skip it (we only want text fields)
    msg.skip("a(iiay)") catch {};

    // title (s)
    if (msg.readString()) |val| out.title.set(val) else |_| {}

    // description (s)
    if (msg.readString()) |val| out.description.set(val) else |_| {}

    msg.exitContainer() catch {}; // exit struct
    msg.exitContainer() catch {}; // exit variant
}

// Tests

test "StatusNotifierItem types compile" {
    _ = ItemProperties;
    _ = IconPixmap;
    _ = ToolTip;
    _ = Category;
    _ = Status;
}

test "Category fromString" {
    const testing = std.testing;

    try testing.expectEqual(Category.application_status, Category.fromString("ApplicationStatus"));
    try testing.expectEqual(Category.communications, Category.fromString("Communications"));
    try testing.expectEqual(Category.system_services, Category.fromString("SystemServices"));
    try testing.expectEqual(Category.hardware, Category.fromString("Hardware"));
    try testing.expectEqual(Category.unknown, Category.fromString("Other"));
}

test "Status fromString" {
    const testing = std.testing;

    try testing.expectEqual(Status.passive, Status.fromString("Passive"));
    try testing.expectEqual(Status.active, Status.fromString("Active"));
    try testing.expectEqual(Status.needs_attention, Status.fromString("NeedsAttention"));
    try testing.expectEqual(Status.unknown, Status.fromString("Other"));
}

test "ItemProperties default state" {
    const testing = std.testing;

    var props = ItemProperties{};
    try testing.expect(props.id.isEmpty());
    try testing.expectEqual(Category.unknown, props.category);
    try testing.expectEqual(Status.unknown, props.status);
    try testing.expect(!props.hasIconName());
    try testing.expect(!props.item_is_menu);
    try testing.expect(!props.icon_pixmap.hasData());
    props.deinit();
}

test "IconPixmap default and deinit" {
    const testing = std.testing;

    var pixmap = IconPixmap{};
    try testing.expect(!pixmap.hasData());
    try testing.expectEqual(@as(i32, 0), pixmap.width);
    pixmap.deinit(); // Should be safe on default
}

test "FixedString operations" {
    const testing = std.testing;

    var s = FixedString(64){};
    try testing.expect(s.isEmpty());

    s.set("hello");
    try testing.expectEqualStrings("hello", s.get());
    try testing.expect(!s.isEmpty());

    s.clear();
    try testing.expect(s.isEmpty());
}
