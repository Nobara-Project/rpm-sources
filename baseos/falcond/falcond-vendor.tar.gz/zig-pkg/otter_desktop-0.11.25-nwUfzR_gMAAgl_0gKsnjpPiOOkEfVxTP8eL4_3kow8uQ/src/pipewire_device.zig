//! PipeWire device/default mutation helpers.

const std = @import("std");
const mem = std.mem;
const pipewire = @import("pipewire");
const c = pipewire.c;
const types = @import("pipewire_types.zig");

const DeviceType = types.DeviceType;
const AudioDevice = types.AudioDevice;
const max_devices = 16;
const max_string_len = 256;
const log = std.log.scoped(.pipewire);

const Error = error{
    NotInitialized,
    NoDevice,
    OperationFailed,
    ConnectionFailed,
};

const MetadataMethods = extern struct {
    version: u32 = 0,
    add_listener: ?*const fn (?*anyopaque, [*c]c.spa_hook, ?*const anyopaque, ?*anyopaque) callconv(.c) c_int = null,
    set_property: ?*const fn (?*anyopaque, u32, [*c]const u8, [*c]const u8, [*c]const u8) callconv(.c) c_int = null,
    clear: ?*const fn (?*anyopaque) callconv(.c) c_int = null,
};

fn spa_dict_lookup(dict: ?*const c.spa_dict, key: [*:0]const u8) ?[*:0]const u8 {
    if (dict == null) return null;
    return c.spa_dict_lookup(dict, key);
}

pub fn getDefaultSinkMut(self: anytype) ?*AudioDevice {
    if (self.default_sink_id) |id| {
        for (&self.sinks) |*slot| {
            if (slot.*) |*device| {
                if (device.id == id) return device;
            }
        }
    }
    if (self.sink_count > 0) {
        if (self.sinks[0]) |*device| return device;
    }
    return null;
}

pub fn getDefaultSourceMut(self: anytype) ?*AudioDevice {
    if (self.default_source_id) |id| {
        for (&self.sources) |*slot| {
            if (slot.*) |*device| {
                if (device.id == id) return device;
            }
        }
    }
    if (self.source_count > 0) {
        if (self.sources[0]) |*device| return device;
    }
    return null;
}

pub fn setDeviceVolume(self: anytype, device: *AudioDevice, volume: f32) Error!void {
    // Lazily bind proxy if not yet bound (handles metadata default changes
    // that arrive after bindDefaultProxies but before proxy swap completes)
    if (self.findNodeSlot(device.id) == null) {
        self.bindNodeProxy(device.id);
    }
    const slot = self.findNodeSlot(device.id) orelse return Error.NoDevice;
    const proxy = slot.proxy orelse return Error.NoDevice;

    var buffer: [1024]u8 = undefined;
    var builder: c.struct_spa_pod_builder = .{
        .data = &buffer,
        .size = buffer.len,
    };

    var frame: c.struct_spa_pod_frame = std.mem.zeroes(c.struct_spa_pod_frame);
    _ = c.spa_pod_builder_push_object(&builder, &frame, @bitCast(c.SPA_TYPE_OBJECT_Props), @bitCast(c.SPA_PARAM_Props));

    _ = c.spa_pod_builder_prop(&builder, @bitCast(c.SPA_PROP_channelVolumes), 0);

    var array_frame: c.struct_spa_pod_frame = std.mem.zeroes(c.struct_spa_pod_frame);
    _ = c.spa_pod_builder_push_array(&builder, &array_frame);

    const channels = @max(device.channels, 1);
    for (0..channels) |_| {
        _ = c.spa_pod_builder_float(&builder, volume);
    }

    _ = c.spa_pod_builder_pop(&builder, &array_frame);
    const pod: [*c]const c.struct_spa_pod = @ptrCast(@alignCast(c.spa_pod_builder_pop(&builder, &frame)));

    const result = c.pw_node_set_param(proxy, @bitCast(c.SPA_PARAM_Props), 0, pod);
    if (result < 0) {
        log.warn("pw_node_set_param(volume) failed: {d}", .{result});
        return Error.OperationFailed;
    }

    device.volume = volume;
    self.notify();
    log.debug("Volume set to {d:.2} for device {d}", .{ volume, device.id });
}

pub fn setDeviceMute(self: anytype, device: *AudioDevice, muted: bool) Error!void {
    if (self.findNodeSlot(device.id) == null) {
        self.bindNodeProxy(device.id);
    }
    const slot = self.findNodeSlot(device.id) orelse return Error.NoDevice;
    const proxy = slot.proxy orelse return Error.NoDevice;

    var buffer: [256]u8 = undefined;
    var builder: c.struct_spa_pod_builder = .{
        .data = &buffer,
        .size = buffer.len,
    };

    var frame: c.struct_spa_pod_frame = std.mem.zeroes(c.struct_spa_pod_frame);
    _ = c.spa_pod_builder_push_object(&builder, &frame, @bitCast(c.SPA_TYPE_OBJECT_Props), @bitCast(c.SPA_PARAM_Props));
    _ = c.spa_pod_builder_prop(&builder, @bitCast(c.SPA_PROP_mute), 0);
    _ = c.spa_pod_builder_bool(&builder, muted);
    const pod: [*c]const c.struct_spa_pod = @ptrCast(@alignCast(c.spa_pod_builder_pop(&builder, &frame)));

    const result = c.pw_node_set_param(proxy, @bitCast(c.SPA_PARAM_Props), 0, pod);
    if (result < 0) {
        log.warn("pw_node_set_param(mute) failed: {d}", .{result});
        return Error.OperationFailed;
    }

    device.muted = muted;
    self.notify();
    log.debug("Mute set to {any} for device {d}", .{ muted, device.id });
}

pub fn addDevice(self: anytype, id: u32, props: ?*const c.spa_dict) void {
    if (props == null) return;

    const media_class = spa_dict_lookup(props, "media.class") orelse return;

    var device = AudioDevice{ .id = id };

    // Get device properties
    if (spa_dict_lookup(props, "node.name")) |name| {
        device.name.setFromC(name);
    }
    if (spa_dict_lookup(props, "node.description")) |desc| {
        device.description.setFromC(desc);
    } else if (spa_dict_lookup(props, "node.nick")) |nick| {
        device.description.setFromC(nick);
    }
    device.media_class.setFromC(media_class);

    // Determine device type
    const class_str = mem.span(media_class);
    var became_default = false;
    if (mem.eql(u8, class_str, "Audio/Sink")) {
        device.device_type = .sink;
        if (self.sink_count < max_devices) {
            self.sinks[self.sink_count] = device;
            self.sink_count += 1;
            if (self.default_sink_id == null) {
                self.default_sink_id = id;
                self.sinks[self.sink_count - 1].?.is_default = true;
                became_default = true;
            }
            log.debug("Added sink: {s} (id={d})", .{ device.name.get(), id });
        }
    } else if (mem.eql(u8, class_str, "Audio/Source")) {
        device.device_type = .source;
        if (self.source_count < max_devices) {
            self.sources[self.source_count] = device;
            self.source_count += 1;
            if (self.default_source_id == null) {
                self.default_source_id = id;
                self.sources[self.source_count - 1].?.is_default = true;
                became_default = true;
            }
            log.debug("Added source: {s} (id={d})", .{ device.name.get(), id });
        }
    } else return;

    // Bind proxy immediately if this device became the new default
    // (e.g. after disconnect/reconnect when no other default existed).
    // Non-default proxies are bound on demand via bindAllProxies().
    if (became_default and self.initialized) {
        self.bindNodeProxy(id);
    }
}
pub fn bindDefaultProxies(self: anytype) void {
    if (self.default_sink_id) |id| {
        if (self.findNodeSlot(id) == null) {
            self.bindNodeProxy(id);
        }
    }
    if (self.default_source_id) |id| {
        if (self.findNodeSlot(id) == null) {
            self.bindNodeProxy(id);
        }
    }
}

/// Bind proxies for all known devices (for popup showing per-device controls).
pub fn bindAllProxies(self: anytype) void {
    for (&self.sinks) |*slot| {
        if (slot.*) |device| {
            if (self.findNodeSlot(device.id) == null) self.bindNodeProxy(device.id);
        }
    }
    for (&self.sources) |*slot| {
        if (slot.*) |device| {
            if (self.findNodeSlot(device.id) == null) self.bindNodeProxy(device.id);
        }
    }
}

/// Unbind proxies for all non-default devices (cleanup after popup closes).
pub fn unbindNonDefaultProxies(self: anytype) void {
    for (&self.node_slots) |*ns| {
        if (!ns.active) continue;
        const id = ns.node_id;
        const is_default_sink = if (self.default_sink_id) |sid| id == sid else false;
        const is_default_source = if (self.default_source_id) |sid| id == sid else false;
        if (!is_default_sink and !is_default_source) {
            ns.deinit();
        }
    }
}

pub fn removeDevice(self: anytype, id: u32) void {
    // Clean up node proxy slot
    for (&self.node_slots) |*ns| {
        if (ns.active and ns.node_id == id) {
            ns.deinit();
            break;
        }
    }

    // Remove from sinks
    for (&self.sinks, 0..) |*slot, i| {
        if (slot.*) |device| {
            if (device.id == id) {
                slot.* = null;
                if (i < self.sink_count - 1) {
                    var j = i;
                    while (j < self.sink_count - 1) : (j += 1) {
                        self.sinks[j] = self.sinks[j + 1];
                    }
                    self.sinks[self.sink_count - 1] = null;
                }
                self.sink_count -|= 1;
                if (self.default_sink_id == id) {
                    const new_default = if (self.sink_count > 0 and self.sinks[0] != null)
                        self.sinks[0].?.id
                    else
                        null;
                    self.default_sink_id = new_default;
                    // Bind proxy for the new fallback default
                    if (new_default) |new_id| {
                        if (self.findNodeSlot(new_id) == null) self.bindNodeProxy(new_id);
                    }
                }
                log.debug("Removed sink: id={d}", .{id});
                return;
            }
        }
    }

    // Remove from sources
    for (&self.sources, 0..) |*slot, i| {
        if (slot.*) |device| {
            if (device.id == id) {
                slot.* = null;
                if (i < self.source_count - 1) {
                    var j = i;
                    while (j < self.source_count - 1) : (j += 1) {
                        self.sources[j] = self.sources[j + 1];
                    }
                    self.sources[self.source_count - 1] = null;
                }
                self.source_count -|= 1;
                if (self.default_source_id == id) {
                    const new_default = if (self.source_count > 0 and self.sources[0] != null)
                        self.sources[0].?.id
                    else
                        null;
                    self.default_source_id = new_default;
                    // Bind proxy for the new fallback default
                    if (new_default) |new_id| {
                        if (self.findNodeSlot(new_id) == null) self.bindNodeProxy(new_id);
                    }
                }
                log.debug("Removed source: id={d}", .{id});
                return;
            }
        }
    }
}
pub fn findDeviceMut(self: anytype, node_id: u32) ?*AudioDevice {
    for (&self.sinks) |*slot| {
        if (slot.*) |*device| {
            if (device.id == node_id) return device;
        }
    }
    for (&self.sources) |*slot| {
        if (slot.*) |*device| {
            if (device.id == node_id) return device;
        }
    }
    return null;
}
pub fn setMetadataDefault(self: anytype, key: [*:0]const u8, device: *const AudioDevice) Error!void {
    const proxy = self.metadata_proxy orelse return Error.OperationFailed;

    // Build JSON value: {"name":"<device_name>"}
    const name = device.name.get();
    if (name.len == 0) return Error.NoDevice;

    var buf: [max_string_len + 32]u8 = undefined;
    const json = std.fmt.bufPrint(&buf, "{{\"name\":\"{s}\"}}", .{name}) catch return Error.OperationFailed;
    buf[json.len] = 0;

    // Call set_property through the vtable (same pattern as pw_node_set_param)
    const iface: *c.struct_spa_interface = @ptrCast(@alignCast(proxy));
    const methods: ?*const MetadataMethods = @ptrCast(@alignCast(iface.cb.funcs));
    if (methods) |m| {
        if (m.set_property) |set_prop| {
            const result = set_prop(iface.cb.data, 0, key, "Spa:String:JSON", @ptrCast(buf[0..json.len :0]));
            if (result < 0) {
                log.warn("metadata set_property failed: {d}", .{result});
                return Error.OperationFailed;
            }
        } else return Error.OperationFailed;
    } else return Error.OperationFailed;

    log.debug("Set {s} to {s}", .{ mem.span(key), name });
}

pub fn updateDefaultByName(self: anytype, name: []const u8, device_type: DeviceType) void {
    const devices = switch (device_type) {
        .sink => &self.sinks,
        .source => &self.sources,
    };

    const old_default_id: ?u32 = switch (device_type) {
        .sink => self.default_sink_id,
        .source => self.default_source_id,
    };

    var found_id: ?u32 = null;
    for (devices) |*slot| {
        if (slot.*) |*device| {
            const is_match: bool = mem.eql(u8, device.name.get(), name);
            device.is_default = is_match;
            if (is_match) found_id = device.id;
        }
    }

    const new_id = found_id orelse switch (device_type) {
        .sink => self.default_sink_id,
        .source => self.default_source_id,
    };

    switch (device_type) {
        .sink => self.default_sink_id = new_id,
        .source => self.default_source_id = new_id,
    }

    // Swap proxy from old default to new default
    if (new_id != old_default_id) {
        // Unbind old default proxy
        if (old_default_id) |old_id| {
            for (&self.node_slots) |*ns| {
                if (ns.active and ns.node_id == old_id) {
                    ns.deinit();
                    break;
                }
            }
        }
    }
    // Ensure proxy is bound for current default (covers both swap and
    // race where default_sink_id was set before updateDefaultByName ran)
    if (new_id) |id| {
        if (self.findNodeSlot(id) == null) {
            self.bindNodeProxy(id);
        }
    }
}

pub fn notify(self: anytype) void {
    self.subscriptions.notify();
}
