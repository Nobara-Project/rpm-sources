const std = @import("std");

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};
const c = dbus.types.c;

pub const Error = dbus.types.Error || error{
    PortalFailed,
    PortalCanceled,
    NoUri,
    UnsupportedUri,
};

pub fn openFile(allocator: std.mem.Allocator, title: []const u8) Error![]u8 {
    return openFileWithParent(allocator, title, "");
}

pub fn openFileWithParent(allocator: std.mem.Allocator, title: []const u8, parent_window: []const u8) Error![]u8 {
    return chooseFile(allocator, .open, title, null, parent_window);
}

pub fn saveFile(allocator: std.mem.Allocator, title: []const u8, current_name: []const u8) Error![]u8 {
    return saveFileWithParent(allocator, title, current_name, "");
}

pub fn saveFileWithParent(allocator: std.mem.Allocator, title: []const u8, current_name: []const u8, parent_window: []const u8) Error![]u8 {
    return chooseFile(allocator, .save, title, current_name, parent_window);
}

const Mode = enum { open, save };
var portal_token_counter: u32 = 0;

fn chooseFile(allocator: std.mem.Allocator, mode: Mode, title: []const u8, current_name: ?[]const u8, parent_window: []const u8) Error![]u8 {
    var conn = try dbus.Connection.open(allocator, .session);
    defer conn.deinit();

    var token_buf: [32]u8 = undefined;
    const handle_token = nextHandleToken(&token_buf);
    var response = Response{ .allocator = allocator };
    defer response.deinit();

    var match_buf: [512]u8 = undefined;
    var request_path_buf: [256]u8 = undefined;
    const unique_name = conn.getUniqueName() orelse return Error.PortalFailed;
    const request_path = requestPathFor(&request_path_buf, unique_name, handle_token) catch return Error.PortalFailed;
    const match = responseMatchRule(&match_buf, request_path) catch return Error.PortalFailed;
    try conn.subscribeMatch(match, handleResponse, &response);
    try conn.flush();

    var msg: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    defer c.sd_bus_error_free(&err);

    const member: [*:0]const u8 = switch (mode) {
        .open => "OpenFile",
        .save => "SaveFile",
    };
    if (c.sd_bus_message_new_method_call(
        conn.bus,
        &msg,
        "org.freedesktop.portal.Desktop",
        "/org/freedesktop/portal/desktop",
        "org.freedesktop.portal.FileChooser",
        member,
    ) < 0) return Error.PortalFailed;
    defer _ = c.sd_bus_message_unref(msg.?);

    try appendStringSlice(msg.?, parent_window);
    try appendStringSlice(msg.?, title);
    try appendOptions(msg.?, mode, current_name, handle_token);

    var reply: ?*c.sd_bus_message = null;
    const call_ret = c.sd_bus_call(conn.bus, msg.?, 0, &err, &reply);
    if (call_ret < 0) return Error.PortalFailed;
    defer {
        if (reply) |r| _ = c.sd_bus_message_unref(r);
    }

    const reply_msg = reply orelse return Error.PortalFailed;
    var wrapped = dbus.Message.wrap(reply_msg);
    _ = try wrapped.readObjectPath();

    while (!response.done) {
        while (conn.process()) {}
        if (response.done) break;
        var fds = [_]std.posix.pollfd{.{ .fd = conn.getFd(), .events = std.posix.POLL.IN, .revents = 0 }};
        _ = std.posix.poll(&fds, -1) catch return Error.PortalFailed;
    }

    if (response.path) |path| {
        response.path = null;
        return path;
    }
    return Error.PortalCanceled;
}

fn nextHandleToken(buf: *[32]u8) []const u8 {
    portal_token_counter +%= 1;
    return std.fmt.bufPrint(buf, "otter_shot_{d}", .{portal_token_counter}) catch "otter_shot";
}

const Response = struct {
    allocator: std.mem.Allocator,
    done: bool = false,
    path: ?[]u8 = null,

    fn deinit(self: *Response) void {
        if (self.path) |path| self.allocator.free(path);
    }
};

fn appendOptions(msg: *c.sd_bus_message, mode: Mode, current_name: ?[]const u8, handle_token: []const u8) Error!void {
    if (c.sd_bus_message_open_container(msg, 'a', "{sv}") < 0) return Error.PortalFailed;
    try appendStringOption(msg, "handle_token", handle_token);
    try appendBoolOption(msg, "modal", true);
    if (mode == .open) try appendBoolOption(msg, "multiple", false);
    if (current_name) |name| try appendStringOption(msg, "current_name", name);
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendBoolOption(msg: *c.sd_bus_message, key: [:0]const u8, value: bool) Error!void {
    if (c.sd_bus_message_open_container(msg, 'e', "sv") < 0) return Error.PortalFailed;
    try appendString(msg, key);
    if (c.sd_bus_message_open_container(msg, 'v', "b") < 0) return Error.PortalFailed;
    var raw: c_int = @intFromBool(value);
    if (c.sd_bus_message_append_basic(msg, 'b', @ptrCast(&raw)) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendStringOption(msg: *c.sd_bus_message, key: [:0]const u8, value: []const u8) Error!void {
    if (c.sd_bus_message_open_container(msg, 'e', "sv") < 0) return Error.PortalFailed;
    try appendString(msg, key);
    if (c.sd_bus_message_open_container(msg, 'v', "s") < 0) return Error.PortalFailed;
    try appendStringSlice(msg, value);
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendString(msg: *c.sd_bus_message, value: [:0]const u8) Error!void {
    if (c.sd_bus_message_append_basic(msg, 's', @ptrCast(value.ptr)) < 0) return Error.PortalFailed;
}

fn appendStringSlice(msg: *c.sd_bus_message, value: []const u8) Error!void {
    var buf: [512:0]u8 = undefined;
    const len = @min(value.len, buf.len - 1);
    @memcpy(buf[0..len], value[0..len]);
    buf[len] = 0;
    try appendString(msg, buf[0..len :0]);
}

fn handleResponse(message: dbus.Message, ctx: ?*anyopaque) void {
    const response: *Response = @ptrCast(@alignCast(ctx.?));
    var msg = message;
    const code = msg.readUint32() catch {
        response.done = true;
        return;
    };
    if (code != 0) {
        response.done = true;
        return;
    }
    response.path = readUriResult(response.allocator, &msg) catch null;
    response.done = true;
}

fn readUriResult(allocator: std.mem.Allocator, msg: *dbus.Message) Error![]u8 {
    if (!try msg.enterArray("{sv}")) return Error.NoUri;
    defer msg.exitContainer() catch {};
    while (!msg.atEnd()) {
        if (!try msg.enterDictEntry("sv")) break;
        const key = try msg.readString();
        if (std.mem.eql(u8, key, "uris")) {
            if (!try msg.enterVariant("as")) return Error.NoUri;
            defer msg.exitContainer() catch {};
            if (!try msg.enterArray("s")) return Error.NoUri;
            defer msg.exitContainer() catch {};
            if (msg.atEnd()) return Error.NoUri;
            const uri = try msg.readString();
            return uriToPath(allocator, uri);
        }
        try msg.skip("v");
        try msg.exitContainer();
    }
    return Error.NoUri;
}

fn uriToPath(allocator: std.mem.Allocator, uri: []const u8) Error![]u8 {
    const prefix = "file://";
    if (!std.mem.startsWith(u8, uri, prefix)) return Error.UnsupportedUri;
    var out = std.ArrayList(u8).empty;
    errdefer out.deinit(allocator);
    var i: usize = prefix.len;
    while (i < uri.len) {
        if (uri[i] == '%' and i + 2 < uri.len) {
            const byte = std.fmt.parseInt(u8, uri[i + 1 .. i + 3], 16) catch return Error.UnsupportedUri;
            out.append(allocator, byte) catch return Error.NoMemory;
            i += 3;
        } else {
            out.append(allocator, uri[i]) catch return Error.NoMemory;
            i += 1;
        }
    }
    return out.toOwnedSlice(allocator) catch Error.NoMemory;
}

fn requestPathFor(buf: []u8, unique_name: []const u8, handle_token: []const u8) Error![]const u8 {
    var sender_buf: [96]u8 = undefined;
    const sender = senderSegment(&sender_buf, unique_name);
    return std.fmt.bufPrint(buf, "/org/freedesktop/portal/desktop/request/{s}/{s}", .{ sender, handle_token }) catch Error.PortalFailed;
}

fn responseMatchRule(buf: *[512]u8, request_path: []const u8) ![:0]const u8 {
    return std.fmt.bufPrintZ(buf, "type='signal',sender='org.freedesktop.portal.Desktop',path='{s}',interface='org.freedesktop.portal.Request',member='Response'", .{request_path});
}

fn senderSegment(buf: *[96]u8, unique_name: []const u8) []const u8 {
    const start: usize = if (unique_name.len != 0 and unique_name[0] == ':') 1 else 0;
    var len: usize = 0;
    for (unique_name[start..]) |ch| {
        if (len == buf.len) break;
        buf[len] = if (ch == '.') '_' else ch;
        len += 1;
    }
    return buf[0..len];
}

test "uriToPath decodes file URI" {
    const path = try uriToPath(std.testing.allocator, "file:///tmp/a%20b.png");
    defer std.testing.allocator.free(path);
    try std.testing.expectEqualStrings("/tmp/a b.png", path);
}

test "requestPathFor normalizes bus name and token" {
    var buf: [128]u8 = undefined;
    const path = try requestPathFor(&buf, ":1.234", "otter_shot_7");
    try std.testing.expectEqualStrings("/org/freedesktop/portal/desktop/request/1_234/otter_shot_7", path);
}

test "responseMatchRule uses exact request path" {
    var buf: [512]u8 = undefined;
    const rule = try responseMatchRule(&buf, "/org/freedesktop/portal/desktop/request/1_234/otter_shot_7");
    try std.testing.expect(std.mem.indexOf(u8, rule, "path='/org/freedesktop/portal/desktop/request/1_234/otter_shot_7'") != null);
    try std.testing.expect(std.mem.indexOf(u8, rule, "member='Response'") != null);
}

test "cancel response completes without URI parsing" {
    var conn = dbus.Connection.open(std.testing.allocator, .session) catch return error.SkipZigTest;
    defer conn.deinit();

    var msg: ?*c.sd_bus_message = null;
    if (c.sd_bus_message_new_signal(
        conn.bus,
        &msg,
        "/org/freedesktop/portal/desktop/request/1_234/otter_shot_test",
        "org.freedesktop.portal.Request",
        "Response",
    ) < 0) return error.SkipZigTest;
    defer _ = c.sd_bus_message_unref(msg.?);

    var code: u32 = 1;
    if (c.sd_bus_message_append_basic(msg.?, 'u', @ptrCast(&code)) < 0) return error.PortalFailed;
    if (c.sd_bus_message_seal(msg.?, 1, 0) < 0) return error.PortalFailed;
    if (c.sd_bus_message_rewind(msg.?, 1) < 0) return error.PortalFailed;

    var response = Response{ .allocator = std.testing.allocator };
    handleResponse(dbus.Message.wrap(msg.?), &response);
    try std.testing.expect(response.done);
    try std.testing.expect(response.path == null);
}

test "portal request message stores string values" {
    var conn = dbus.Connection.open(std.testing.allocator, .session) catch return error.SkipZigTest;
    defer conn.deinit();

    var msg: ?*c.sd_bus_message = null;
    if (c.sd_bus_message_new_method_call(
        conn.bus,
        &msg,
        "org.freedesktop.portal.Desktop",
        "/org/freedesktop/portal/desktop",
        "org.freedesktop.portal.FileChooser",
        "OpenFile",
    ) < 0) return error.SkipZigTest;
    defer _ = c.sd_bus_message_unref(msg.?);

    try appendStringSlice(msg.?, "wayland:parent-token");
    try appendStringSlice(msg.?, "Select wallpaper");
    try appendOptions(msg.?, .open, null, "otter_shot_test");

    if (c.sd_bus_message_seal(msg.?, 1, 0) < 0) return error.PortalFailed;
    if (c.sd_bus_message_rewind(msg.?, 1) < 0) return error.PortalFailed;
    var wrapped = dbus.Message.wrap(msg.?);
    try std.testing.expectEqualStrings("wayland:parent-token", try wrapped.readString());
    try std.testing.expectEqualStrings("Select wallpaper", try wrapped.readString());
}
