//! D-Bus introspection XML for org.freedesktop.Notifications.

pub const xml: [*:0]const u8 =
    \\<!DOCTYPE node PUBLIC "-//freedesktop//DTD D-BUS Object Introspection 1.0//EN"
    \\"http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd">
    \\<node>
    \\  <interface name="org.freedesktop.Notifications">
    \\    <method name="Notify">
    \\      <arg direction="in"  type="s" name="app_name"/>
    \\      <arg direction="in"  type="u" name="replaces_id"/>
    \\      <arg direction="in"  type="s" name="app_icon"/>
    \\      <arg direction="in"  type="s" name="summary"/>
    \\      <arg direction="in"  type="s" name="body"/>
    \\      <arg direction="in"  type="as" name="actions"/>
    \\      <arg direction="in"  type="a{sv}" name="hints"/>
    \\      <arg direction="in"  type="i" name="expire_timeout"/>
    \\      <arg direction="out" type="u" name="id"/>
    \\    </method>
    \\    <method name="CloseNotification">
    \\      <arg direction="in"  type="u" name="id"/>
    \\    </method>
    \\    <method name="GetCapabilities">
    \\      <arg direction="out" type="as" name="capabilities"/>
    \\    </method>
    \\    <method name="GetServerInformation">
    \\      <arg direction="out" type="s" name="name"/>
    \\      <arg direction="out" type="s" name="vendor"/>
    \\      <arg direction="out" type="s" name="version"/>
    \\      <arg direction="out" type="s" name="spec_version"/>
    \\    </method>
    \\    <signal name="NotificationClosed">
    \\      <arg type="u" name="id"/>
    \\      <arg type="u" name="reason"/>
    \\    </signal>
    \\    <signal name="ActionInvoked">
    \\      <arg type="u" name="id"/>
    \\      <arg type="s" name="action_key"/>
    \\    </signal>
    \\  </interface>
    \\  <interface name="org.freedesktop.DBus.Introspectable">
    \\    <method name="Introspect">
    \\      <arg direction="out" type="s" name="xml_data"/>
    \\    </method>
    \\  </interface>
    \\  <interface name="org.freedesktop.DBus.Properties">
    \\    <method name="GetAll">
    \\      <arg direction="in"  type="s" name="interface_name"/>
    \\      <arg direction="out" type="a{sv}" name="properties"/>
    \\    </method>
    \\  </interface>
    \\</node>
    \\
;
