const std = @import("std");

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};
const c = dbus.types.c;

const portal_bus = "org.freedesktop.portal.Desktop";
const portal_path = "/org/freedesktop/portal/desktop";
const screencast_iface = "org.freedesktop.portal.ScreenCast";
const session_iface = "org.freedesktop.portal.Session";

pub const SourceTypes = packed struct(u32) {
    monitor: bool = true,
    window: bool = false,
    virtual: bool = false,
    _pad: u29 = 0,
};

pub const CursorMode = enum(u32) {
    hidden = 1,
    embedded = 2,
    metadata = 4,
};

pub const Error = dbus.types.Error || error{
    PortalFailed,
    PortalCanceled,
    NoSessionHandle,
    NoStream,
    NoPipeWireFd,
};

pub const Session = struct {
    allocator: std.mem.Allocator,
    connection: dbus.Connection,
    session_handle: []u8,
    pipewire_fd: std.posix.fd_t,
    node_id: u32,
    pipewire_serial: ?u64 = null,

    pub fn deinit(self: *Session) void {
        if (self.session_handle.len > 0) {
            var path_buf: [256:0]u8 = undefined;
            if (copyZ(path_buf[0..], self.session_handle)) |path| {
                _ = self.connection.callMethod(
                    portal_bus,
                    path,
                    session_iface,
                    "Close",
                ) catch {};
            }
        }
        if (self.pipewire_fd >= 0) _ = std.posix.system.close(self.pipewire_fd);
        self.allocator.free(self.session_handle);
        self.connection.deinit();
        self.* = undefined;
    }
};

var token_counter: u32 = 0;

pub fn available(allocator: std.mem.Allocator) bool {
    var conn = dbus.Connection.open(allocator, .session) catch return false;
    defer conn.deinit();

    var msg = conn.getProperty(
        portal_bus,
        portal_path,
        screencast_iface,
        "version",
    ) catch return false;
    defer msg.unref();

    _ = msg.readVariantUint32() catch return false;
    return true;
}

pub fn openMonitorSession(allocator: std.mem.Allocator) Error!Session {
    return openSession(allocator, .{ .monitor = true }, .embedded);
}

pub fn openSession(allocator: std.mem.Allocator, sources: SourceTypes, cursor_mode: CursorMode) Error!Session {
    var conn = try dbus.Connection.open(allocator, .session);

    var session = Session{
        .allocator = allocator,
        .connection = conn,
        .session_handle = &.{},
        .pipewire_fd = -1,
        .node_id = 0,
    };
    errdefer {
        session.connection = conn;
        session.deinit();
    }

    session.session_handle = try createSession(allocator, &conn);
    try selectSources(&conn, session.session_handle, sources, cursor_mode);
    const stream = try startSession(&conn, session.session_handle);
    session.node_id = stream.node_id;
    session.pipewire_serial = stream.pipewire_serial;
    session.pipewire_fd = try openPipeWireRemote(&conn, session.session_handle);
    session.connection = conn;
    return session;
}

const Stream = struct {
    node_id: u32,
    pipewire_serial: ?u64 = null,
};

const Response = struct {
    allocator: std.mem.Allocator,
    done: bool = false,
    canceled: bool = false,
    session_handle: ?[]u8 = null,
    stream: ?Stream = null,

    fn deinit(self: *Response) void {
        if (self.session_handle) |handle| self.allocator.free(handle);
    }
};

fn createSession(allocator: std.mem.Allocator, conn: *dbus.Connection) Error![]u8 {
    var token_buf: [40]u8 = undefined;
    const handle_token = nextToken(&token_buf, "otter_rec_req");
    var session_token_buf: [40]u8 = undefined;
    const session_token = nextToken(&session_token_buf, "otter_rec_session");

    var response = Response{ .allocator = allocator };
    defer response.deinit();
    try subscribeFor(conn, handle_token, &response);

    const msg = try newPortalCall(conn, "CreateSession");
    defer _ = c.sd_bus_message_unref(msg);
    try appendCreateSessionOptions(msg, handle_token, session_token);
    try callAndReadHandle(conn, msg);
    try waitForResponse(conn, &response);

    const handle = response.session_handle orelse return Error.NoSessionHandle;
    response.session_handle = null;
    return handle;
}

fn selectSources(conn: *dbus.Connection, session_handle: []const u8, sources: SourceTypes, cursor_mode: CursorMode) Error!void {
    var token_buf: [40]u8 = undefined;
    const handle_token = nextToken(&token_buf, "otter_rec_select");

    var response = Response{ .allocator = conn.allocator };
    defer response.deinit();
    try subscribeFor(conn, handle_token, &response);

    const msg = try newPortalCall(conn, "SelectSources");
    defer _ = c.sd_bus_message_unref(msg);
    try appendObjectPathSlice(msg, session_handle);
    try appendSelectSourcesOptions(msg, handle_token, sources, cursor_mode);
    try callAndReadHandle(conn, msg);
    try waitForResponse(conn, &response);
}

fn startSession(conn: *dbus.Connection, session_handle: []const u8) Error!Stream {
    var token_buf: [40]u8 = undefined;
    const handle_token = nextToken(&token_buf, "otter_rec_start");

    var response = Response{ .allocator = conn.allocator };
    defer response.deinit();
    try subscribeFor(conn, handle_token, &response);

    const msg = try newPortalCall(conn, "Start");
    defer _ = c.sd_bus_message_unref(msg);
    try appendObjectPathSlice(msg, session_handle);
    try appendStringSlice(msg, "");
    try appendHandleOnlyOptions(msg, handle_token);
    try callAndReadHandle(conn, msg);
    try waitForResponse(conn, &response);
    return response.stream orelse Error.NoStream;
}

fn openPipeWireRemote(conn: *dbus.Connection, session_handle: []const u8) Error!std.posix.fd_t {
    const msg = try newPortalCall(conn, "OpenPipeWireRemote");
    defer _ = c.sd_bus_message_unref(msg);
    try appendObjectPathSlice(msg, session_handle);
    try appendEmptyOptions(msg);

    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    defer c.sd_bus_error_free(&err);
    if (c.sd_bus_call(conn.bus, msg, 0, &err, &reply) < 0) return Error.PortalFailed;
    defer {
        if (reply) |r| _ = c.sd_bus_message_unref(r);
    }

    var fd: std.posix.fd_t = -1;
    if (reply == null or c.sd_bus_message_read_basic(reply.?, 'h', @ptrCast(&fd)) < 0 or fd < 0) {
        return Error.NoPipeWireFd;
    }
    const dup_rc = std.os.linux.dup(fd);
    return switch (std.posix.errno(dup_rc)) {
        .SUCCESS => @intCast(dup_rc),
        else => Error.NoPipeWireFd,
    };
}

fn newPortalCall(conn: *dbus.Connection, member: [*:0]const u8) Error!*c.sd_bus_message {
    var msg: ?*c.sd_bus_message = null;
    if (c.sd_bus_message_new_method_call(
        conn.bus,
        &msg,
        portal_bus,
        portal_path,
        screencast_iface,
        member,
    ) < 0) return Error.PortalFailed;
    return msg orelse Error.PortalFailed;
}

fn callAndReadHandle(conn: *dbus.Connection, msg: *c.sd_bus_message) Error!void {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    defer c.sd_bus_error_free(&err);
    if (c.sd_bus_call(conn.bus, msg, 0, &err, &reply) < 0) return Error.PortalFailed;
    defer {
        if (reply) |r| _ = c.sd_bus_message_unref(r);
    }
    var wrapped = dbus.Message.wrap(reply orelse return Error.PortalFailed);
    _ = try wrapped.readObjectPath();
}

fn subscribeFor(conn: *dbus.Connection, handle_token: []const u8, response: *Response) Error!void {
    const unique_name = conn.getUniqueName() orelse return Error.PortalFailed;
    var path_buf: [256]u8 = undefined;
    const request_path = requestPathFor(&path_buf, unique_name, handle_token) catch return Error.PortalFailed;
    var match_buf: [512]u8 = undefined;
    const rule = responseMatchRule(&match_buf, request_path) catch return Error.PortalFailed;
    try conn.subscribeMatch(rule, handleResponse, response);
    try conn.flush();
}

fn waitForResponse(conn: *dbus.Connection, response: *Response) Error!void {
    while (!response.done) {
        while (conn.process()) {}
        if (response.done) break;
        var fds = [_]std.posix.pollfd{.{ .fd = conn.getFd(), .events = std.posix.POLL.IN, .revents = 0 }};
        _ = std.posix.poll(&fds, -1) catch return Error.PortalFailed;
    }
    if (response.canceled) return Error.PortalCanceled;
}

fn handleResponse(message: dbus.Message, ctx: ?*anyopaque) void {
    const response: *Response = @ptrCast(@alignCast(ctx.?));
    var msg = message;
    const code = msg.readUint32() catch {
        response.done = true;
        response.canceled = true;
        return;
    };
    if (code != 0) {
        response.done = true;
        response.canceled = true;
        return;
    }
    readResult(response, &msg) catch {};
    response.done = true;
}

fn readResult(response: *Response, msg: *dbus.Message) Error!void {
    if (!try msg.enterArray("{sv}")) return;
    defer msg.exitContainer() catch {};
    while (!msg.atEnd()) {
        if (!try msg.enterDictEntry("sv")) break;
        defer msg.exitContainer() catch {};
        const key = try msg.readString();
        if (std.mem.eql(u8, key, "session_handle")) {
            if (!try msg.enterVariant("s")) return Error.NoSessionHandle;
            defer msg.exitContainer() catch {};
            response.session_handle = response.allocator.dupe(u8, try msg.readString()) catch return Error.NoMemory;
        } else if (std.mem.eql(u8, key, "streams")) {
            response.stream = try readFirstStream(msg);
        } else {
            try msg.skip("v");
        }
    }
}

fn readFirstStream(msg: *dbus.Message) Error!Stream {
    if (!try msg.enterVariant("a(ua{sv})")) return Error.NoStream;
    defer msg.exitContainer() catch {};
    if (!try msg.enterArray("(ua{sv})")) return Error.NoStream;
    defer msg.exitContainer() catch {};
    if (msg.atEnd()) return Error.NoStream;
    if (!try msg.enterStruct("ua{sv}")) return Error.NoStream;
    defer msg.exitContainer() catch {};

    var stream = Stream{ .node_id = try msg.readUint32() };
    if (try msg.enterArray("{sv}")) {
        defer msg.exitContainer() catch {};
        while (!msg.atEnd()) {
            if (!try msg.enterDictEntry("sv")) break;
            defer msg.exitContainer() catch {};
            const key = try msg.readString();
            if (std.mem.eql(u8, key, "pipewire-serial")) {
                stream.pipewire_serial = try msg.readVariantUint64();
            } else {
                try msg.skip("v");
            }
        }
    }
    return stream;
}

fn appendCreateSessionOptions(msg: *c.sd_bus_message, handle_token: []const u8, session_token: []const u8) Error!void {
    if (c.sd_bus_message_open_container(msg, 'a', "{sv}") < 0) return Error.PortalFailed;
    try appendStringOption(msg, "handle_token", handle_token);
    try appendStringOption(msg, "session_handle_token", session_token);
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendSelectSourcesOptions(msg: *c.sd_bus_message, handle_token: []const u8, sources: SourceTypes, cursor_mode: CursorMode) Error!void {
    if (c.sd_bus_message_open_container(msg, 'a', "{sv}") < 0) return Error.PortalFailed;
    try appendStringOption(msg, "handle_token", handle_token);
    try appendUint32Option(msg, "types", @bitCast(sources));
    try appendBoolOption(msg, "multiple", false);
    try appendUint32Option(msg, "cursor_mode", @intFromEnum(cursor_mode));
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendHandleOnlyOptions(msg: *c.sd_bus_message, handle_token: []const u8) Error!void {
    if (c.sd_bus_message_open_container(msg, 'a', "{sv}") < 0) return Error.PortalFailed;
    try appendStringOption(msg, "handle_token", handle_token);
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendEmptyOptions(msg: *c.sd_bus_message) Error!void {
    if (c.sd_bus_message_open_container(msg, 'a', "{sv}") < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendBoolOption(msg: *c.sd_bus_message, key: [:0]const u8, value: bool) Error!void {
    if (c.sd_bus_message_open_container(msg, 'e', "sv") < 0) return Error.PortalFailed;
    try appendString(msg, key);
    if (c.sd_bus_message_open_container(msg, 'v', "b") < 0) return Error.PortalFailed;
    var raw: c_int = @intFromBool(value);
    if (c.sd_bus_message_append_basic(msg, 'b', @ptrCast(&raw)) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendUint32Option(msg: *c.sd_bus_message, key: [:0]const u8, value: u32) Error!void {
    if (c.sd_bus_message_open_container(msg, 'e', "sv") < 0) return Error.PortalFailed;
    try appendString(msg, key);
    if (c.sd_bus_message_open_container(msg, 'v', "u") < 0) return Error.PortalFailed;
    var raw = value;
    if (c.sd_bus_message_append_basic(msg, 'u', @ptrCast(&raw)) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendStringOption(msg: *c.sd_bus_message, key: [:0]const u8, value: []const u8) Error!void {
    if (c.sd_bus_message_open_container(msg, 'e', "sv") < 0) return Error.PortalFailed;
    try appendString(msg, key);
    if (c.sd_bus_message_open_container(msg, 'v', "s") < 0) return Error.PortalFailed;
    try appendStringSlice(msg, value);
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
    if (c.sd_bus_message_close_container(msg) < 0) return Error.PortalFailed;
}

fn appendString(msg: *c.sd_bus_message, value: [:0]const u8) Error!void {
    if (c.sd_bus_message_append_basic(msg, 's', @ptrCast(value.ptr)) < 0) return Error.PortalFailed;
}

fn appendStringSlice(msg: *c.sd_bus_message, value: []const u8) Error!void {
    var buf: [512:0]u8 = undefined;
    const z = copyZ(buf[0..], value) orelse return Error.PortalFailed;
    try appendString(msg, z);
}

fn appendObjectPathSlice(msg: *c.sd_bus_message, value: []const u8) Error!void {
    var buf: [256:0]u8 = undefined;
    const z = copyZ(buf[0..], value) orelse return Error.PortalFailed;
    if (c.sd_bus_message_append_basic(msg, 'o', @ptrCast(z.ptr)) < 0) return Error.PortalFailed;
}

fn copyZ(buf: []u8, value: []const u8) ?[:0]const u8 {
    if (value.len >= buf.len) return null;
    @memcpy(buf[0..value.len], value);
    buf[value.len] = 0;
    return buf[0..value.len :0];
}

fn nextToken(buf: []u8, prefix: []const u8) []const u8 {
    token_counter +%= 1;
    return std.fmt.bufPrint(buf, "{s}_{d}", .{ prefix, token_counter }) catch prefix;
}

fn requestPathFor(buf: []u8, unique_name: []const u8, handle_token: []const u8) Error![]const u8 {
    var sender_buf: [96]u8 = undefined;
    const sender = senderSegment(&sender_buf, unique_name);
    return std.fmt.bufPrint(buf, "/org/freedesktop/portal/desktop/request/{s}/{s}", .{ sender, handle_token }) catch Error.PortalFailed;
}

fn responseMatchRule(buf: *[512]u8, request_path: []const u8) ![:0]const u8 {
    return std.fmt.bufPrintZ(buf, "type='signal',sender='org.freedesktop.portal.Desktop',path='{s}',interface='org.freedesktop.portal.Request',member='Response'", .{request_path});
}

fn senderSegment(buf: *[96]u8, unique_name: []const u8) []const u8 {
    const start: usize = if (unique_name.len != 0 and unique_name[0] == ':') 1 else 0;
    var len: usize = 0;
    for (unique_name[start..]) |ch| {
        if (len == buf.len) break;
        buf[len] = if (ch == '.') '_' else ch;
        len += 1;
    }
    return buf[0..len];
}

test "screencast portal availability check is safe without a portal" {
    _ = available(std.testing.allocator);
}

test "screencast request path normalizes sender" {
    var buf: [128]u8 = undefined;
    const path = try requestPathFor(&buf, ":1.234", "otter_rec_start_3");
    try std.testing.expectEqualStrings("/org/freedesktop/portal/desktop/request/1_234/otter_rec_start_3", path);
}

test "screencast source bitmask matches portal API" {
    const monitors: u32 = @bitCast(SourceTypes{ .monitor = true });
    const windows: u32 = @bitCast(SourceTypes{ .monitor = false, .window = true });
    try std.testing.expectEqual(@as(u32, 1), monitors);
    try std.testing.expectEqual(@as(u32, 2), windows);
}
