const std = @import("std");
const dbus = @import("dbus/connection.zig");
const types = @import("dbus/types.zig");
const c = types.c;

pub const PowerAction = enum { shutdown, reboot, @"suspend" };

pub fn requestPowerAction(action: PowerAction) !void {
    var connection = try dbus.Connection.open(std.heap.page_allocator, .system);
    defer connection.deinit();
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{ .name = null, .message = null, ._need_free = 0 };
    defer c.sd_bus_error_free(&err);
    const method: [*:0]const u8 = switch (action) {
        .shutdown => "PowerOff",
        .reboot => "Reboot",
        .@"suspend" => "Suspend",
    };
    const ret = c.sd_bus_call_method(
        connection.bus,
        "org.freedesktop.login1",
        "/org/freedesktop/login1",
        "org.freedesktop.login1.Manager",
        method,
        &err,
        &reply,
        "b",
        @as(c_int, 1),
    );
    if (reply) |r| _ = c.sd_bus_message_unref(r);
    if (ret < 0) return error.PowerActionFailed;
}
