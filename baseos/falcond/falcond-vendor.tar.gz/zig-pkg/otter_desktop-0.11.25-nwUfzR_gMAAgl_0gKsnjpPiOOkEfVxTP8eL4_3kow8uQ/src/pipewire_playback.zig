const std = @import("std");
const pipewire = @import("pipewire.zig");
const c = pipewire.c;

pub const Error = error{
    InitFailed,
    StreamFailed,
    PlaybackFailed,
};

const Context = struct {
    loop: ?*c.pw_main_loop = null,
    stream: ?*c.pw_stream = null,
    samples: []const f32,
    sample_rate: u32,
    channels: u16,
    cursor: usize = 0,
    drain_frames: usize = 0,
    failed: bool = false,
};

pub fn playF32Mono(samples: []const f32, sample_rate: u32) Error!void {
    try playF32(samples, sample_rate, 1);
}

pub fn playF32(samples: []const f32, sample_rate: u32, channels: u16) Error!void {
    if (samples.len == 0 or channels == 0) return;

    c.pw_init(null, null);
    defer c.pw_deinit();

    var ctx = Context{
        .samples = samples,
        .sample_rate = sample_rate,
        .channels = channels,
        .drain_frames = sample_rate / 5,
    };

    ctx.loop = c.pw_main_loop_new(null) orelse return Error.InitFailed;
    defer c.pw_main_loop_destroy(ctx.loop);

    const props = c.pw_properties_new(
        c.PW_KEY_MEDIA_TYPE,
        "Audio",
        c.PW_KEY_MEDIA_CATEGORY,
        "Playback",
        c.PW_KEY_MEDIA_ROLE,
        "Music",
        c.PW_KEY_APP_NAME,
        "otter-vox",
        @as(?*anyopaque, null),
    ) orelse return Error.InitFailed;

    ctx.stream = c.pw_stream_new_simple(
        c.pw_main_loop_get_loop(ctx.loop),
        "otter-vox",
        props,
        &.{
            .version = c.PW_VERSION_STREAM_EVENTS,
            .process = onProcess,
        },
        &ctx,
    ) orelse return Error.StreamFailed;
    defer c.pw_stream_destroy(ctx.stream);

    var storage: [1024]u8 align(@alignOf(u32)) = undefined;
    var builder = std.mem.zeroInit(c.spa_pod_builder, .{
        .data = &storage,
        .size = storage.len,
    });

    var params: [1]?*const c.spa_pod = undefined;
    var frame: c.spa_pod_frame = undefined;
    check(c.spa_pod_builder_push_object(&builder, &frame, c.SPA_TYPE_OBJECT_Format, c.SPA_PARAM_EnumFormat)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_prop(&builder, c.SPA_FORMAT_mediaType, 0)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_id(&builder, c.SPA_MEDIA_TYPE_audio)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_prop(&builder, c.SPA_FORMAT_mediaSubtype, 0)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_id(&builder, c.SPA_MEDIA_SUBTYPE_raw)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_prop(&builder, c.SPA_FORMAT_AUDIO_format, 0)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_id(&builder, c.SPA_AUDIO_FORMAT_F32)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_prop(&builder, c.SPA_FORMAT_AUDIO_rate, 0)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_int(&builder, @intCast(sample_rate))) catch return Error.StreamFailed;
    check(c.spa_pod_builder_prop(&builder, c.SPA_FORMAT_AUDIO_channels, 0)) catch return Error.StreamFailed;
    check(c.spa_pod_builder_int(&builder, channels)) catch return Error.StreamFailed;

    params[0] = @ptrCast(@alignCast(c.spa_pod_builder_pop(&builder, &frame)));
    check(c.pw_stream_connect(
        ctx.stream,
        c.PW_DIRECTION_OUTPUT,
        c.PW_ID_ANY,
        c.PW_STREAM_FLAG_AUTOCONNECT | c.PW_STREAM_FLAG_MAP_BUFFERS | c.PW_STREAM_FLAG_RT_PROCESS,
        &params,
        1,
    )) catch return Error.StreamFailed;

    check(c.pw_main_loop_run(ctx.loop)) catch return Error.PlaybackFailed;
    if (ctx.failed) return Error.PlaybackFailed;
}

fn onProcess(data: ?*anyopaque) callconv(.c) void {
    const ctx: *Context = @ptrCast(@alignCast(data orelse return));

    var maybe_buffer: ?*c.pw_buffer = null;
    while (true) {
        const next = c.pw_stream_dequeue_buffer(ctx.stream) orelse break;
        if (maybe_buffer) |queued| {
            check(c.pw_stream_queue_buffer(ctx.stream, queued)) catch {
                ctx.failed = true;
            };
        }
        maybe_buffer = next;
    }

    const buffer = maybe_buffer orelse {
        ctx.failed = true;
        _ = c.pw_main_loop_quit(ctx.loop);
        return;
    };
    defer check(c.pw_stream_queue_buffer(ctx.stream, buffer)) catch {
        ctx.failed = true;
    };

    const spa_buffer: *c.spa_buffer = buffer.buffer;
    const data_ptr = spa_buffer.datas[0].data orelse return;
    var dst: [*]f32 = @ptrCast(@alignCast(data_ptr));
    const stride = @sizeOf(f32) * ctx.channels;
    var frames = spa_buffer.datas[0].maxsize / stride;
    if (buffer.requested != 0) frames = @min(buffer.requested, frames);

    var written: usize = 0;
    while (written < frames) : (written += 1) {
        if (ctx.cursor < ctx.samples.len) {
            const sample = ctx.samples[ctx.cursor];
            ctx.cursor += 1;
            for (0..ctx.channels) |_| {
                dst[0] = sample;
                dst += 1;
            }
        } else if (ctx.drain_frames > 0) {
            ctx.drain_frames -= 1;
            for (0..ctx.channels) |_| {
                dst[0] = 0;
                dst += 1;
            }
        } else {
            break;
        }
    }

    spa_buffer.datas[0].chunk.*.offset = 0;
    spa_buffer.datas[0].chunk.*.stride = @intCast(stride);
    spa_buffer.datas[0].chunk.*.size = @intCast(written * stride);

    if (ctx.cursor >= ctx.samples.len and ctx.drain_frames == 0) {
        _ = c.pw_main_loop_quit(ctx.loop);
    }
}

fn check(result: c_int) Error!void {
    if (result != 0) return Error.StreamFailed;
}
