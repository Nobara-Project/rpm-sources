//! D-Bus Notification Service
//!
//! Implements the org.freedesktop.Notifications specification.
//! Hosts a D-Bus service that receives notification requests from applications.
//! Uses sd_bus_add_object for pure-Zig message dispatch (no C vtable).
//!
//! Provides notification data types, a fixed-capacity notification store,
//! and the D-Bus service that bridges external applications to the store.
//!
//! D-Bus Service: org.freedesktop.Notifications
//! Object Path: /org/freedesktop/Notifications

const std = @import("std");
const mem = std.mem;
const posix = std.posix;
pub const FixedString = @import("otter_utils").FixedString;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const c = dbus.types.c;

const log = std.log.scoped(.dbus_notifications);

// ============================================================================
// Notification types
// ============================================================================

const max_string_len = 512;
const max_image_dim: u32 = 512;
const max_image_rgba_bytes: usize = 1024 * 1024;
const max_body_len = 4096;
const max_actions = 16;

pub const Urgency = enum(u8) {
    low = 0,
    normal = 1,
    critical = 2,
};

pub const CloseReason = enum(u32) {
    expired = 1,
    dismissed = 2,
    closed_by_call = 3,
    undefined = 4,
};

pub const Action = struct {
    key: FixedString(128) = .{},
    label: FixedString(256) = .{},
};

/// Raw pixel data from D-Bus image-data hint (RGBA format, heap-allocated).
pub const ImageData = struct {
    width: u32,
    height: u32,
    pixels: []u8, // RGBA format
    allocator: std.mem.Allocator,

    pub fn deinit(self: *ImageData) void {
        self.allocator.free(self.pixels);
    }
};

pub const Notification = struct {
    id: u32 = 0,
    app_name: FixedString(max_string_len) = .{},
    app_icon: FixedString(max_string_len) = .{},
    summary: FixedString(max_string_len) = .{},
    body: FixedString(max_body_len) = .{},
    image_path: FixedString(max_string_len) = .{},
    image_data: ?*ImageData = null, // Heap-allocated, owned
    urgency: Urgency = .normal,
    expire_timeout_ms: i32 = -1,
    actions: [max_actions]?Action = .{null} ** max_actions,
    action_count: u8 = 0,
    created_at_ms: i64 = 0,
    expires_at_ms: i64 = 0,
    visible: bool = false,

    pub fn addAction(self: *Notification, key: []const u8, label: []const u8) void {
        if (self.action_count >= max_actions) return;
        for (&self.actions) |*slot| {
            if (slot.* == null) {
                var action = Action{};
                action.key.set(key);
                action.label.set(label);
                slot.* = action;
                self.action_count += 1;
                return;
            }
        }
    }

    pub fn hasDefaultAction(self: *const Notification) bool {
        for (self.actions) |maybe_action| {
            if (maybe_action) |action| {
                if (mem.eql(u8, action.key.get(), "default")) return true;
            }
        }
        return false;
    }

    pub fn isExpired(self: *const Notification, now_ms: i64) bool {
        // expires_at_ms == 0 means never expires
        return self.expires_at_ms != 0 and now_ms >= self.expires_at_ms;
    }

    /// Free heap-allocated image data if present.
    pub fn deinitImageData(self: *Notification) void {
        if (self.image_data) |data| {
            const alloc = data.allocator;
            data.deinit();
            alloc.destroy(data);
            self.image_data = null;
        }
    }
};

// ============================================================================
// Notification Store
// ============================================================================

pub const max_capacity = 64;
const max_visible_results = max_capacity;

pub const Store = struct {
    slots: [max_capacity]?Notification = .{null} ** max_capacity,
    count: u32 = 0,
    next_id: u32 = 1,
    max_visible: u8 = 5,

    /// Visible notification pointers returned by getVisible().
    /// Stored here to avoid per-call stack allocation.
    visible_buf: [max_visible_results]*const Notification = undefined,

    pub fn init(max_visible: u8) Store {
        return .{ .max_visible = max_visible };
    }

    /// Add a notification to the store. Assigns an auto-incremented ID.
    /// Returns the assigned ID, or null if the store is full.
    pub fn add(self: *Store, notif: Notification) ?u32 {
        const slot_idx = self.findFreeSlot() orelse return null;
        const id = self.next_id;
        self.advanceId();

        var n = notif;
        n.id = id;
        self.slots[slot_idx] = n;
        self.count += 1;
        self.updateVisibility();
        return id;
    }

    /// Replace a notification in-place, preserving its visibility state.
    /// Returns true if the notification was found and replaced.
    pub fn replace(self: *Store, id: u32, notif: Notification) bool {
        const slot_idx = self.findSlotById(id) orelse return false;
        const was_visible = self.slots[slot_idx].?.visible;
        // Clean up old image data before overwriting
        if (self.slots[slot_idx]) |*old| {
            old.deinitImageData();
        }
        var n = notif;
        n.id = id;
        n.visible = was_visible;
        self.slots[slot_idx] = n;
        self.updateVisibility();
        return true;
    }

    /// Remove a notification by ID. Returns the close reason (.closed_by_call)
    /// or null if the ID was not found.
    pub fn remove(self: *Store, id: u32) ?CloseReason {
        const slot_idx = self.findSlotById(id) orelse return null;
        if (self.slots[slot_idx]) |*n| {
            n.deinitImageData();
        }
        self.slots[slot_idx] = null;
        self.count -= 1;
        self.updateVisibility();
        return .closed_by_call;
    }

    /// Remove all expired notifications. Returns the number removed.
    pub fn removeExpired(self: *Store, now_ms: i64) u32 {
        var removed: u32 = 0;
        for (&self.slots) |*slot| {
            if (slot.*) |*n| {
                if (n.isExpired(now_ms)) {
                    n.deinitImageData();
                    slot.* = null;
                    self.count -= 1;
                    removed += 1;
                }
            }
        }
        if (removed > 0) self.updateVisibility();
        return removed;
    }

    /// Get a notification by ID.
    pub fn get(self: *const Store, id: u32) ?*const Notification {
        for (&self.slots) |*slot| {
            if (slot.*) |*n| {
                if (n.id == id) return n;
            }
        }
        return null;
    }

    /// Returns a slice of pointers to visible notifications.
    /// Critical notifications appear first, then others in slot order.
    pub fn getVisible(self: *Store) []*const Notification {
        var idx: usize = 0;

        // Critical first
        for (&self.slots) |*slot| {
            if (slot.*) |*n| {
                if (n.visible and n.urgency == .critical) {
                    self.visible_buf[idx] = n;
                    idx += 1;
                }
            }
        }

        // Then non-critical
        for (&self.slots) |*slot| {
            if (slot.*) |*n| {
                if (n.visible and n.urgency != .critical) {
                    self.visible_buf[idx] = n;
                    idx += 1;
                }
            }
        }

        return self.visible_buf[0..idx];
    }

    /// Count of currently visible notifications.
    pub fn visibleCount(self: *const Store) u32 {
        var vc: u32 = 0;
        for (self.slots) |maybe| {
            if (maybe) |n| {
                vc += @intFromBool(n.visible);
            }
        }
        return vc;
    }

    /// Earliest expiry time across all notifications, or null if none expire.
    pub fn nextExpiryMs(self: *const Store) ?i64 {
        var earliest: i64 = std.math.maxInt(i64);
        var found = false;
        for (self.slots) |maybe| {
            if (maybe) |n| {
                // Skip non-expiring notifications (expires_at_ms == 0)
                const has_expiry = n.expires_at_ms != 0;
                found = found or has_expiry;
                if (has_expiry) {
                    earliest = @min(earliest, n.expires_at_ms);
                }
            }
        }
        return if (found) earliest else null;
    }

    /// Update visibility flags. Critical notifications always get priority,
    /// then remaining slots filled by other notifications in slot order.
    pub fn updateVisibility(self: *Store) void {
        // First pass: clear all visibility
        for (&self.slots) |*slot| {
            if (slot.*) |*n| {
                n.visible = false;
            }
        }

        var remaining: u8 = self.max_visible;

        // Second pass: mark critical notifications visible first
        for (&self.slots) |*slot| {
            if (remaining == 0) break;
            if (slot.*) |*n| {
                if (n.urgency == .critical) {
                    n.visible = true;
                    remaining -= 1;
                }
            }
        }

        // Third pass: fill remaining slots with non-critical notifications
        for (&self.slots) |*slot| {
            if (remaining == 0) break;
            if (slot.*) |*n| {
                if (n.urgency != .critical and !n.visible) {
                    n.visible = true;
                    remaining -= 1;
                }
            }
        }
    }

    // --- Internal helpers ---

    fn findFreeSlot(self: *const Store) ?usize {
        for (self.slots, 0..) |slot, i| {
            if (slot == null) return i;
        }
        return null;
    }

    fn findSlotById(self: *const Store, id: u32) ?usize {
        for (self.slots, 0..) |slot, i| {
            if (slot) |n| {
                if (n.id == id) return i;
            }
        }
        return null;
    }

    fn advanceId(self: *Store) void {
        self.next_id +%= 1;
        // ID 0 is reserved (means "assign new"), so skip past it on wrap
        self.next_id +|= @intFromBool(self.next_id == 0);
    }
};

// ============================================================================
// D-Bus Service
// ============================================================================

/// D-Bus constants
pub const service_name = "org.freedesktop.Notifications";
pub const object_path = "/org/freedesktop/Notifications";
pub const notifications_interface = "org.freedesktop.Notifications";
const properties_interface = "org.freedesktop.DBus.Properties";
const introspect_interface = "org.freedesktop.DBus.Introspectable";
const introspection_xml = @import("notification_introspection.zig").xml;

/// Callback type invoked when a notification is added or replaced.
pub const NotifyCallback = *const fn (ctx: ?*anyopaque, notif: *const Notification) void;

/// Callback type invoked when a notification is closed.
pub const CloseCallback = *const fn (ctx: ?*anyopaque, id: u32, reason: CloseReason) void;

/// Get monotonic time in milliseconds.
pub fn getMonotonicMs() i64 {
    var ts: std.posix.timespec = undefined;
    const rc = std.posix.system.clock_gettime(.MONOTONIC, &ts);
    if (std.posix.errno(rc) != .SUCCESS) return 0;
    return @as(i64, ts.sec) * 1000 + @divTrunc(ts.nsec, std.time.ns_per_ms);
}

pub const NotificationService = struct {
    connection: dbus.Connection,
    store: *Store,
    allocator: std.mem.Allocator,
    default_timeout: u32,
    low_timeout: u32,
    critical_timeout: u32,
    on_notify: ?NotifyCallback = null,
    on_close: ?CloseCallback = null,
    callback_ctx: ?*anyopaque = null,

    pub const Error = dbus.types.Error;

    /// Initialize the D-Bus notification service.
    /// Connects to the session bus. Call `start()` AFTER the struct is in its
    /// final memory location.
    pub fn init(
        allocator: std.mem.Allocator,
        store: *Store,
        default_timeout: u32,
        low_timeout: u32,
        critical_timeout: u32,
    ) Error!NotificationService {
        var conn = try dbus.Connection.open(allocator, .session);
        errdefer conn.deinit();

        return NotificationService{
            .connection = conn,
            .store = store,
            .allocator = allocator,
            .default_timeout = default_timeout,
            .low_timeout = low_timeout,
            .critical_timeout = critical_timeout,
        };
    }

    /// Start the service -- register the object handler and request the well-known name.
    /// MUST be called after the struct is in its final memory location.
    /// Uses REPLACE_EXISTING to take over from any existing notification daemon.
    pub fn start(self: *NotificationService) Error!void {
        self.connection.addObject(object_path, handleMessage, self) catch |err| {
            log.err("Failed to register notification object: {s}", .{@errorName(err)});
            return err;
        };

        // SD_BUS_NAME_REPLACE_EXISTING (1) - take over from existing owner
        // SD_BUS_NAME_ALLOW_REPLACEMENT (2) - allow others to replace us
        self.connection.requestNameFlags(service_name, 1 | 2) catch |err| {
            log.err("Failed to request name {s}: {s}", .{ service_name, @errorName(err) });
            return err;
        };

        log.info("Notification service started on {s}", .{service_name});
    }

    pub fn deinit(self: *NotificationService) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const NotificationService) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    pub fn process(self: *NotificationService) bool {
        return self.connection.process();
    }

    pub fn drain(self: *NotificationService) void {
        self.connection.drain();
    }

    /// Emit the NotificationClosed signal.
    pub fn emitNotificationClosed(self: *NotificationService, id: u32, reason: CloseReason) void {
        _ = c.sd_bus_emit_signal(
            self.connection.bus,
            object_path,
            notifications_interface,
            "NotificationClosed",
            "uu",
            id,
            @intFromEnum(reason),
        );
    }

    /// Emit the ActionInvoked signal.
    pub fn emitActionInvoked(self: *NotificationService, id: u32, action_key: [*:0]const u8) void {
        _ = c.sd_bus_emit_signal(
            self.connection.bus,
            object_path,
            notifications_interface,
            "ActionInvoked",
            "us",
            id,
            action_key,
        );
    }

    // --- Message dispatch ---

    fn handleMessage(
        msg: ?*c.sd_bus_message,
        userdata: ?*anyopaque,
        _: [*c]c.sd_bus_error,
    ) callconv(.c) c_int {
        const raw = msg orelse return 0;
        const self: *NotificationService = @ptrCast(@alignCast(userdata orelse return 0));
        var wrapped = dbus.Message.wrap(raw);
        const iface = wrapped.getInterface() orelse return 0;
        const member_name = wrapped.getMember() orelse return 0;

        if (mem.eql(u8, iface, notifications_interface)) {
            if (mem.eql(u8, member_name, "Notify"))
                return self.handleNotify(raw, &wrapped);
            if (mem.eql(u8, member_name, "CloseNotification"))
                return self.handleCloseNotification(raw, &wrapped);
            if (mem.eql(u8, member_name, "GetCapabilities"))
                return handleGetCapabilities(raw);
            if (mem.eql(u8, member_name, "GetServerInformation"))
                return handleGetServerInformation(raw);
        } else if (mem.eql(u8, iface, introspect_interface)) {
            if (mem.eql(u8, member_name, "Introspect"))
                return handleIntrospect(raw);
        } else if (mem.eql(u8, iface, properties_interface)) {
            if (mem.eql(u8, member_name, "GetAll"))
                return handlePropertyGetAll(raw);
        }

        return 0; // Not handled
    }

    fn handleNotify(self: *NotificationService, raw: *c.sd_bus_message, msg: *dbus.Message) c_int {
        // Read: app_name(s), replaces_id(u), app_icon(s), summary(s), body(s),
        //        actions(as), hints(a{sv}), expire_timeout(i)
        const app_name = msg.readString() catch return -1;
        const replaces_id = msg.readUint32() catch return -1;
        const app_icon = msg.readString() catch return -1;
        const summary = msg.readString() catch return -1;
        const body = msg.readString() catch return -1;

        var notif = Notification{};
        notif.app_name.set(app_name);
        notif.app_icon.set(app_icon);
        notif.summary.set(summary);
        notif.body.set(body);

        // Parse actions: array of strings, pairs of (key, label)
        if (msg.enterArray("s") catch null) |entered| {
            if (entered) {
                var action_key: ?[]const u8 = null;
                while (!msg.atEnd()) {
                    const val = msg.readString() catch break;
                    if (action_key) |key| {
                        notif.addAction(key, val);
                        action_key = null;
                    } else {
                        action_key = val;
                    }
                }
            }
            msg.exitContainer() catch {};
        }

        // Parse hints: a{sv} -- extract "urgency" byte
        var urgency = Urgency.normal;
        if (msg.enterArray("{sv}") catch null) |entered| {
            if (entered) {
                while (!msg.atEnd()) {
                    const dict_entered = msg.enterDictEntry("sv") catch break;
                    if (!dict_entered) break;

                    const hint_key = msg.readString() catch {
                        msg.exitContainer() catch {};
                        break;
                    };

                    if (mem.eql(u8, hint_key, "urgency")) {
                        if (msg.enterVariant("y") catch null) |v_entered| {
                            if (v_entered) {
                                if (msg.readByte() catch null) |byte_val| {
                                    // Table lookup: 0=low, 1=normal, 2=critical; clamp out-of-range to normal
                                    const urgency_table = [_]Urgency{ .low, .normal, .critical };
                                    const idx: usize = if (byte_val < urgency_table.len) byte_val else 1;
                                    urgency = urgency_table[idx];
                                }
                            }
                            msg.exitContainer() catch {};
                        }
                    } else if (mem.eql(u8, hint_key, "image-data")) {
                        if (msg.enterVariant("(iiibiiay)") catch null) |v_entered| {
                            if (v_entered) {
                                self.parseImageData(msg, &notif);
                            }
                            msg.exitContainer() catch {};
                        }
                    } else if (mem.eql(u8, hint_key, "image-path")) {
                        if (msg.enterVariant("s") catch null) |v_entered| {
                            if (v_entered) {
                                if (msg.readString() catch null) |path| {
                                    notif.image_path.set(path);
                                }
                            }
                            msg.exitContainer() catch {};
                        }
                    } else {
                        msg.skip("v") catch {};
                    }

                    msg.exitContainer() catch {};
                }
            }
            msg.exitContainer() catch {};
        }

        notif.urgency = urgency;

        // Read expire_timeout
        const expire_timeout = msg.readInt32() catch return -1;
        notif.expire_timeout_ms = expire_timeout;

        // Compute actual timeout and expiry
        const now_ms = getMonotonicMs();
        notif.created_at_ms = now_ms;

        // Table lookup for default timeout by urgency (indexed by enum value)
        const timeout_table = [_]u32{ self.low_timeout, self.default_timeout, self.critical_timeout };
        const effective_timeout: u32 = if (expire_timeout > 0)
            @intCast(expire_timeout)
        else
            timeout_table[@intFromEnum(urgency)];

        // 0 means never expire
        notif.expires_at_ms = if (effective_timeout == 0) 0 else now_ms + @as(i64, effective_timeout);

        // Add or replace
        var assigned_id: u32 = 0;

        if (replaces_id > 0 and self.store.replace(replaces_id, notif)) {
            assigned_id = replaces_id;
        } else {
            assigned_id = self.store.add(notif) orelse {
                log.warn("Notification store full, dropping notification", .{});
                return c.sd_bus_reply_method_return(raw, "u", @as(u32, 0));
            };
        }

        // Reply with the assigned ID
        const ret = c.sd_bus_reply_method_return(raw, "u", assigned_id);
        if (ret < 0) return ret;

        // Invoke callback
        if (self.on_notify) |cb| {
            if (self.store.get(assigned_id)) |stored_notif| {
                cb(self.callback_ctx, stored_notif);
            }
        }

        return 1;
    }

    fn handleCloseNotification(self: *NotificationService, raw: *c.sd_bus_message, msg: *dbus.Message) c_int {
        const id = msg.readUint32() catch return -1;

        const reason = self.store.remove(id) orelse CloseReason.undefined;

        // Emit NotificationClosed signal
        self.emitNotificationClosed(id, reason);

        // Invoke callback
        if (self.on_close) |cb| {
            cb(self.callback_ctx, id, reason);
        }

        return c.sd_bus_reply_method_return(raw, null);
    }

    fn handleGetCapabilities(raw: *c.sd_bus_message) c_int {
        return c.sd_bus_reply_method_return(
            raw,
            "as",
            @as(c_int, 4),
            @as([*:0]const u8, "body"),
            @as([*:0]const u8, "icon-static"),
            @as([*:0]const u8, "actions"),
            @as([*:0]const u8, "persistence"),
        );
    }

    fn handleGetServerInformation(raw: *c.sd_bus_message) c_int {
        return c.sd_bus_reply_method_return(
            raw,
            "ssss",
            @as([*:0]const u8, "otter-notifications"),
            @as([*:0]const u8, "otter-shell"),
            @as([*:0]const u8, "0.1.0"),
            @as([*:0]const u8, "1.2"),
        );
    }

    fn handleIntrospect(raw: *c.sd_bus_message) c_int {
        return c.sd_bus_reply_method_return(raw, "s", introspection_xml);
    }

    fn handlePropertyGetAll(raw: *c.sd_bus_message) c_int {
        // Empty a{sv} — 0 entries
        return c.sd_bus_reply_method_return(raw, "a{sv}", @as(c_int, 0));
    }

    /// Parse the image-data hint: (iiibiiay) struct containing raw pixel data.
    /// Converts from source format (RGB/RGBA) to RGBA and stores on the notification.
    fn parseImageData(self: *NotificationService, msg: *dbus.Message, notif: *Notification) void {
        const entered = msg.enterStruct("iiibiiay") catch return;
        if (!entered) return;
        defer msg.exitContainer() catch {};

        const width = msg.readInt32() catch return;
        const height = msg.readInt32() catch return;
        const rowstride = msg.readInt32() catch return;
        const has_alpha = msg.readBool() catch return;
        const bits_per_sample = msg.readInt32() catch return;
        const channels = msg.readInt32() catch return;
        const pixel_data = msg.readByteArray() catch return;

        if (width <= 0 or height <= 0 or bits_per_sample != 8) return;
        if (channels != 3 and channels != 4) return;

        const w: u32 = @intCast(width);
        const h: u32 = @intCast(height);
        if (w > max_image_dim or h > max_image_dim) return;
        const stride: u32 = @intCast(rowstride);
        const pixel_count = w * h * 4;
        if (pixel_count > max_image_rgba_bytes) return;
        if (stride < w * @as(u32, @intCast(channels))) return;
        const min_src_bytes = @as(usize, h) * @as(usize, stride);
        if (min_src_bytes > pixel_data.len) return;

        // Allocate RGBA buffer
        const rgba = self.allocator.alloc(u8, pixel_count) catch return;
        errdefer self.allocator.free(rgba);

        // Convert from source format (RGB or RGBA) to RGBA.
        // Alpha source flag and default are hoisted out of the pixel loop.
        const ch: u32 = @intCast(channels);
        const use_src_alpha = has_alpha and channels == 4;
        const alpha_default: u8 = if (use_src_alpha) 0 else 0xFF;
        const alpha_src_flag: u32 = @intFromBool(use_src_alpha);

        var y: u32 = 0;
        while (y < h) : (y += 1) {
            const row_offset = y * stride;
            const dst_row = y * w;
            var x: u32 = 0;
            while (x < w) : (x += 1) {
                const src_offset = row_offset + x * ch;
                const dst_offset = (dst_row + x) * 4;
                if (src_offset + ch > pixel_data.len) break;
                if (dst_offset + 4 > pixel_count) break;

                rgba[dst_offset] = pixel_data[src_offset];
                rgba[dst_offset + 1] = pixel_data[src_offset + 1];
                rgba[dst_offset + 2] = pixel_data[src_offset + 2];
                // Select source alpha when present, else 0xFF via bitmask
                const src_alpha = pixel_data[src_offset + 3 * alpha_src_flag];
                const mask: u8 = @as(u8, 0) -% @as(u8, @intCast(alpha_src_flag));
                rgba[dst_offset + 3] = (src_alpha & mask) | (alpha_default & ~mask);
            }
        }

        const img_data = self.allocator.create(ImageData) catch {
            self.allocator.free(rgba);
            return;
        };
        img_data.* = .{ .width = w, .height = h, .pixels = rgba, .allocator = self.allocator };
        notif.image_data = img_data;
    }
};

test {
    _ = @import("notification_service_tests.zig");
}
