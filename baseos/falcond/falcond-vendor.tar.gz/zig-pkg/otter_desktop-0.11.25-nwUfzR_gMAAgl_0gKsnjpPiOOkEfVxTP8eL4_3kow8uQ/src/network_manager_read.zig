//! NetworkManager DBus property readers and discovery helpers.

const std = @import("std");

const log = std.log.scoped(.network_manager);

const nm_service = "org.freedesktop.NetworkManager";
const nm_path = "/org/freedesktop/NetworkManager";
const nm_interface = "org.freedesktop.NetworkManager";
const device_interface = "org.freedesktop.NetworkManager.Device";
const wireless_interface = "org.freedesktop.NetworkManager.Device.Wireless";
const ap_interface = "org.freedesktop.NetworkManager.AccessPoint";
const active_conn_interface = "org.freedesktop.NetworkManager.Connection.Active";
const ip4_interface = "org.freedesktop.NetworkManager.IP4Config";
const statistics_interface = "org.freedesktop.NetworkManager.Device.Statistics";
const settings_conn_interface = "org.freedesktop.NetworkManager.Settings.Connection";

fn copyFixedBuf(buf: []u8, len: *usize, src: []const u8) void {
    const n = @min(src.len, buf.len);
    @memcpy(buf[0..n], src[0..n]);
    len.* = n;
}

fn toSentinel(buf: *[256:0]u8, src: []const u8) ?[:0]const u8 {
    if (src.len >= 256) return null;
    @memcpy(buf[0..src.len], src);
    buf[src.len] = 0;
    return buf[0..src.len :0];
}

pub fn readActiveConnectionProperties(self: anytype, conn_path: []const u8, info: anytype) void {
    var path_buf: [256:0]u8 = undefined;
    const path_z = toSentinel(&path_buf, conn_path) orelse return;

    // Id (connection name)
    readPropString(self, path_z, active_conn_interface, "Id", &info.name, &info.name_len);

    // Vpn
    readPropBool(self, path_z, active_conn_interface, "Vpn", &info.is_vpn);

    // Devices — array of object paths
    var dev_msg = self.connection.getProperty(nm_service, path_z, active_conn_interface, "Devices") catch return;
    defer dev_msg.unref();

    if (dev_msg.enterVariant("ao") catch false) {
        if (dev_msg.enterArray("o") catch false) {
            if (!dev_msg.atEnd()) {
                const dev_path = dev_msg.readObjectPath() catch {
                    dev_msg.exitContainer() catch {};
                    dev_msg.exitContainer() catch {};
                    return;
                };
                copyFixedBuf(&info.device_path, &info.device_path_len, dev_path);
                self.readDeviceProperties(dev_path, info);
            }
            dev_msg.exitContainer() catch {};
        }
        dev_msg.exitContainer() catch {};
    }
}

pub fn readDeviceProperties(self: anytype, dev_path: []const u8, info: anytype) void {
    var path_buf: [256:0]u8 = undefined;
    const path_z = toSentinel(&path_buf, dev_path) orelse return;

    // DeviceType
    {
        var msg = self.connection.getProperty(nm_service, path_z, device_interface, "DeviceType") catch return;
        defer msg.unref();
        info.device_type = @enumFromInt(msg.readVariantUint32() catch 0);
    }

    // State
    {
        var msg = self.connection.getProperty(nm_service, path_z, device_interface, "State") catch return;
        defer msg.unref();
        info.device_state = @enumFromInt(msg.readVariantUint32() catch 0);
    }

    // Interface name
    readPropString(self, path_z, device_interface, "Interface", &info.iface_name, &info.iface_name_len);

    // WiFi-specific properties
    if (info.device_type == .wifi) {
        self.readWifiProperties(path_z, info);
    }

    // IP address
    self.readIpAddress(path_z, info);

    // Device.Statistics — RxBytes/TxBytes
    self.readDeviceStatistics(path_z, info);
}

pub fn readDeviceStatistics(self: anytype, device_path_z: [:0]const u8, info: anytype) void {
    // Enable statistics refresh (1000ms = 1 second polling)
    self.enableDeviceStatistics(device_path_z);

    // RxBytes (u64)
    {
        var msg = self.connection.getProperty(nm_service, device_path_z, statistics_interface, "RxBytes") catch return;
        defer msg.unref();
        info.rx_bytes = msg.readVariantUint64() catch 0;
    }

    // TxBytes (u64)
    {
        var msg = self.connection.getProperty(nm_service, device_path_z, statistics_interface, "TxBytes") catch return;
        defer msg.unref();
        info.tx_bytes = msg.readVariantUint64() catch 0;
    }
}

pub fn enableDeviceStatistics(self: anytype, device_path_z: [:0]const u8) void {
    // Set RefreshRateMs to 1000ms to enable statistics tracking
    self.connection.setPropertyUint32(
        nm_service,
        device_path_z,
        statistics_interface,
        "RefreshRateMs",
        1000,
    ) catch {
        // Not critical — statistics just won't auto-update
        log.debug("Failed to enable device statistics refresh", .{});
    };
}

pub fn readWifiProperties(self: anytype, device_path_z: [:0]const u8, info: anytype) void {
    // ActiveAccessPoint
    var ap_msg = self.connection.getProperty(nm_service, device_path_z, wireless_interface, "ActiveAccessPoint") catch return;
    defer ap_msg.unref();

    if (ap_msg.enterVariant("o") catch false) {
        const ap_path = ap_msg.readObjectPath() catch {
            ap_msg.exitContainer() catch {};
            return;
        };
        ap_msg.exitContainer() catch {};

        // Skip if no active AP (path is "/" or empty)
        if (ap_path.len <= 1) return;

        var ap_buf: [256:0]u8 = undefined;
        const ap_z = toSentinel(&ap_buf, ap_path) orelse return;

        // Strength (byte)
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Strength") catch return;
            defer msg.unref();
            info.wifi_strength = msg.readVariantByte() catch 0;
        }

        // Ssid (byte array)
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Ssid") catch return;
            defer msg.unref();
            if (msg.enterVariant("ay") catch false) {
                if (msg.enterArray("y") catch false) {
                    var i: usize = 0;
                    while (!msg.atEnd() and i < 32) {
                        info.ssid[i] = msg.readByte() catch break;
                        i += 1;
                    }
                    info.ssid_len = i;
                    msg.exitContainer() catch {};
                }
                msg.exitContainer() catch {};
            }
        }

        // Frequency
        {
            var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Frequency") catch return;
            defer msg.unref();
            info.wifi_freq = msg.readVariantUint32() catch 0;
        }
    }
}

pub fn readIpAddress(self: anytype, device_path_z: [:0]const u8, info: anytype) void {
    // Get Ip4Config object path
    var config_msg = self.connection.getProperty(nm_service, device_path_z, device_interface, "Ip4Config") catch return;
    defer config_msg.unref();

    if (config_msg.enterVariant("o") catch false) {
        const config_path = config_msg.readObjectPath() catch {
            config_msg.exitContainer() catch {};
            return;
        };
        config_msg.exitContainer() catch {};

        if (config_path.len <= 1) return;

        var cfg_buf: [256:0]u8 = undefined;
        const cfg_z = toSentinel(&cfg_buf, config_path) orelse return;

        // AddressData — a(a{sv})
        var addr_msg = self.connection.getProperty(nm_service, cfg_z, ip4_interface, "AddressData") catch return;
        defer addr_msg.unref();

        if (addr_msg.enterVariant("aa{sv}") catch false) {
            if (addr_msg.enterArray("a{sv}") catch false) {
                // Read first address entry
                if (!addr_msg.atEnd()) {
                    if (addr_msg.enterArray("{sv}") catch false) {
                        while (!addr_msg.atEnd()) {
                            if (addr_msg.enterDictEntry("sv") catch false) {
                                const key = addr_msg.readString() catch {
                                    addr_msg.exitContainer() catch {};
                                    continue;
                                };
                                if (std.mem.eql(u8, key, "address")) {
                                    if (addr_msg.enterVariant("s") catch false) {
                                        const addr = addr_msg.readString() catch {
                                            addr_msg.exitContainer() catch {};
                                            addr_msg.exitContainer() catch {};
                                            continue;
                                        };
                                        copyFixedBuf(&info.ip_address, &info.ip_address_len, addr);
                                        addr_msg.exitContainer() catch {};
                                    }
                                } else {
                                    addr_msg.skip("v") catch {};
                                }
                                addr_msg.exitContainer() catch {};
                            }
                        }
                        addr_msg.exitContainer() catch {};
                    }
                }
                addr_msg.exitContainer() catch {};
            }
            addr_msg.exitContainer() catch {};
        }
    }
}

pub fn readApProperties(self: anytype, ap_path: []const u8, net: anytype) void {
    var path_buf: [256:0]u8 = undefined;
    const ap_z = toSentinel(&path_buf, ap_path) orelse return;

    copyFixedBuf(&net.ap_path, &net.ap_path_len, ap_path);

    // Strength
    {
        var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Strength") catch return;
        defer msg.unref();
        net.strength = msg.readVariantByte() catch 0;
    }

    // Ssid
    {
        var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Ssid") catch return;
        defer msg.unref();
        if (msg.enterVariant("ay") catch false) {
            if (msg.enterArray("y") catch false) {
                var i: usize = 0;
                while (!msg.atEnd() and i < 32) {
                    net.ssid[i] = msg.readByte() catch break;
                    i += 1;
                }
                net.ssid_len = i;
                msg.exitContainer() catch {};
            }
            msg.exitContainer() catch {};
        }
    }

    // Frequency
    {
        var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Frequency") catch return;
        defer msg.unref();
        net.frequency = msg.readVariantUint32() catch 0;
    }

    // Flags (WPA flags indicate secured)
    {
        var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "WpaFlags") catch return;
        defer msg.unref();
        net.secured = (msg.readVariantUint32() catch 0) != 0;
    }

    // Also check RSN flags if WPA flags were zero
    if (!net.secured) {
        var msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "RsnFlags") catch return;
        defer msg.unref();
        net.secured = (msg.readVariantUint32() catch 0) != 0;
    }
}

pub fn readSavedConnectionSettings(self: anytype, conn_path: []const u8, saved: anytype) void {
    var path_buf: [256:0]u8 = undefined;
    const path_z = toSentinel(&path_buf, conn_path) orelse return;

    // GetSettings returns a{sa{sv}} — outer dict keyed by setting group
    var msg = self.connection.callMethod(nm_service, path_z, settings_conn_interface, "GetSettings") catch return;
    defer msg.unref();

    if (msg.enterArray("{sa{sv}}") catch false) {
        while (!msg.atEnd()) {
            if (msg.enterDictEntry("sa{sv}") catch false) {
                const section = msg.readString() catch {
                    msg.exitContainer() catch {};
                    continue;
                };

                if (std.mem.eql(u8, section, "connection")) {
                    if (msg.enterArray("{sv}") catch false) {
                        while (!msg.atEnd()) {
                            if (msg.enterDictEntry("sv") catch false) {
                                const key = msg.readString() catch {
                                    msg.exitContainer() catch {};
                                    continue;
                                };
                                if (std.mem.eql(u8, key, "id")) {
                                    if (msg.enterVariant("s") catch false) {
                                        const val = msg.readString() catch {
                                            msg.exitContainer() catch {};
                                            msg.exitContainer() catch {};
                                            continue;
                                        };
                                        copyFixedBuf(&saved.name, &saved.name_len, val);
                                        msg.exitContainer() catch {};
                                    }
                                } else if (std.mem.eql(u8, key, "type")) {
                                    if (msg.enterVariant("s") catch false) {
                                        const val = msg.readString() catch {
                                            msg.exitContainer() catch {};
                                            msg.exitContainer() catch {};
                                            continue;
                                        };
                                        copyFixedBuf(&saved.conn_type, &saved.conn_type_len, val);
                                        saved.is_vpn = std.mem.eql(u8, val, "vpn");
                                        msg.exitContainer() catch {};
                                    }
                                } else {
                                    msg.skip("v") catch {};
                                }
                                msg.exitContainer() catch {};
                            }
                        }
                        msg.exitContainer() catch {};
                    }
                } else {
                    msg.skip("a{sv}") catch {};
                }
                msg.exitContainer() catch {};
            }
        }
        msg.exitContainer() catch {};
    }
}

pub fn readPropString(self: anytype, path: [:0]const u8, iface: [:0]const u8, prop: [:0]const u8, out: []u8, out_len: *usize) void {
    var msg = self.connection.getProperty(nm_service, path, iface, prop) catch return;
    defer msg.unref();
    const str = msg.readVariantString() catch return;
    const len = @min(str.len, out.len);
    @memcpy(out[0..len], str[0..len]);
    out_len.* = len;
}

pub fn readPropBool(self: anytype, path: [:0]const u8, iface: [:0]const u8, prop: [:0]const u8, out: *bool) void {
    var msg = self.connection.getProperty(nm_service, path, iface, prop) catch return;
    defer msg.unref();
    out.* = msg.readVariantBool() catch return;
}

pub fn findWifiDevicePath(self: anytype) ?[:0]const u8 {
    // Check active connections first
    for (self.connections[0..self.connection_count]) |maybe_conn| {
        if (maybe_conn) |conn| {
            if (conn.device_type == .wifi and conn.device_path_len > 1) {
                return conn.device_path[0..conn.device_path_len :0];
            }
        }
    }

    // Return cached path if available
    if (self.wifi_device_path_len > 1) {
        return self.wifi_device_path[0..self.wifi_device_path_len :0];
    }

    // Enumerate all NM devices to find a WiFi adapter
    self.discoverWifiDevice();
    if (self.wifi_device_path_len > 1) {
        return self.wifi_device_path[0..self.wifi_device_path_len :0];
    }

    return null;
}

/// Query NM GetDevices() and find the first WiFi device, caching its path.
pub fn discoverWifiDevice(self: anytype) void {
    var msg = self.connection.callMethod(
        nm_service,
        nm_path,
        nm_interface,
        "GetDevices",
    ) catch return;
    defer msg.unref();

    if (msg.enterArray("o") catch false) {
        while (!msg.atEnd()) {
            const dev_path = msg.readObjectPath() catch continue;
            // Convert to sentinel-terminated for getProperty call
            var path_buf: [256:0]u8 = undefined;
            const dev_path_z = toSentinel(&path_buf, dev_path) orelse continue;
            // Read DeviceType property
            var prop_msg = self.connection.getProperty(
                nm_service,
                dev_path_z,
                device_interface,
                "DeviceType",
            ) catch continue;
            defer prop_msg.unref();
            if (prop_msg.enterVariant("u") catch false) {
                const dev_type_raw = prop_msg.readUint32() catch continue;
                prop_msg.exitContainer() catch {};
                if (dev_type_raw == 2) {
                    copyFixedBuf(&self.wifi_device_path, &self.wifi_device_path_len, dev_path);
                    // Null-terminate for sentinel slice
                    if (self.wifi_device_path_len < self.wifi_device_path.len) {
                        self.wifi_device_path[self.wifi_device_path_len] = 0;
                    }
                    msg.exitContainer() catch {};
                    return;
                }
            }
        }
        msg.exitContainer() catch {};
    }
}
