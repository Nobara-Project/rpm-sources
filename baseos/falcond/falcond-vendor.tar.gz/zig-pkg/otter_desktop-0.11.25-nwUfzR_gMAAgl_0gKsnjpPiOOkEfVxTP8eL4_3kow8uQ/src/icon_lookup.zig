//! XDG Icon Lookup
//!
//! Finds application icons based on app_id following the XDG icon theme specification.
//! Scans actual directories on disk for themes, sizes, and contexts rather than
//! relying on hardcoded lists. Preferred themes and larger sizes are checked first.
//! Search locations: user icons, /usr/share/icons, /usr/local/share/icons,
//! /usr/share/pixmaps, and .desktop files.

const std = @import("std");
const otter_utils = @import("otter_utils");
/// Cached reference to the app-installed `std.Io`. Fetched lazily to avoid
/// evaluating before `otter_utils.io.install(...)` runs in `main()`.
inline fn io_global() std.Io {
    return otter_utils.io.get();
}

const mem = std.mem;
const fs = std.Io;
const Allocator = std.mem.Allocator;
const xdg_paths = @import("xdg_paths.zig");
const desktop_entry = @import("applications/desktop_entry.zig");

const log = std.log.scoped(.IconLookup);

/// Preferred themes checked first (in order). Any other themes found on disk
/// are checked after these.
pub const preferred_themes = [_][]const u8{
    "steam",
    "Papirus-Colors-Dark",
    "Papirus-Dark",
    "Papirus-Colors",
    "Papirus",
    "Papirus-Light",
    "breeze-dark",
    "breeze",
    "Adwaita",
    "hicolor",
};

/// All supported icon file extensions, SVG preferred.
const all_extensions = [_][]const u8{
    ".svg",
    ".png",
    ".jpg",
    ".jpeg",
};

/// Caller owns the returned memory.
pub fn findIcon(allocator: Allocator, app_id: []const u8) ?[]const u8 {
    if (findIconDirect(allocator, app_id)) |path| {
        return path;
    }

    var lower_buf: [256]u8 = undefined;
    const lower_id = toLower(app_id, &lower_buf) orelse app_id;
    if (!mem.eql(u8, lower_id, app_id)) {
        if (findIconDirect(allocator, lower_id)) |path| {
            return path;
        }
    }

    // XDG symbolic fallback: try adding/removing "-symbolic" suffix
    if (findIconSymbolicFallback(allocator, app_id)) |path| {
        return path;
    }

    if (findIconFromDesktop(allocator, app_id)) |path| {
        return path;
    }

    return null;
}

const symbolic_suffix = "-symbolic";

/// Try symbolic variant fallback per XDG icon spec:
/// - If name doesn't end with "-symbolic", try "name-symbolic"
/// - If name ends with "-symbolic", try without it
fn findIconSymbolicFallback(allocator: Allocator, app_id: []const u8) ?[]const u8 {
    var buf: [256]u8 = undefined;

    if (mem.endsWith(u8, app_id, symbolic_suffix)) {
        // Strip "-symbolic" and try base name
        const base = app_id[0 .. app_id.len - symbolic_suffix.len];
        if (base.len > 0) {
            if (findIconDirect(allocator, base)) |path| return path;
        }
    } else {
        // Append "-symbolic" and try
        if (app_id.len + symbolic_suffix.len <= buf.len) {
            @memcpy(buf[0..app_id.len], app_id);
            @memcpy(buf[app_id.len..][0..symbolic_suffix.len], symbolic_suffix);
            const symbolic_name = buf[0 .. app_id.len + symbolic_suffix.len];
            if (findIconDirect(allocator, symbolic_name)) |path| return path;
        }
    }

    return null;
}

fn toLower(str: []const u8, buf: []u8) ?[]const u8 {
    if (str.len > buf.len) return null;
    for (str, 0..) |c, i| {
        buf[i] = std.ascii.toLower(c);
    }
    return buf[0..str.len];
}

fn findIconDirect(allocator: Allocator, icon_name: []const u8) ?[]const u8 {
    var path_buf: [std.fs.max_path_bytes]u8 = undefined;

    var base_paths = xdg_paths.PathList(16){};
    xdg_paths.collectIconDirs(&base_paths, xdg_paths.Env.fromProcess());

    // Pass 1: Preferred themes in priority order (SVG first, then raster)
    for (base_paths.items()) |base_path| {
        for (preferred_themes) |theme| {
            if (searchThemeDir(allocator, base_path, theme, icon_name, &path_buf)) |path| {
                return path;
            }
        }
    }

    // Pass 2: Scan all remaining themes on disk (discovers themes not in preferred list)
    for (base_paths.items()) |base_path| {
        var dir = fs.Dir.cwd().openDir(io_global(), base_path, .{ .iterate = true }) catch continue;
        defer dir.close(io_global());

        var iter = dir.iterate();
        while (iter.next(io_global()) catch null) |entry| {
            if (entry.kind != .directory and entry.kind != .sym_link) continue;
            // Skip themes already checked in pass 1
            if (isPreferredTheme(entry.name)) continue;

            if (searchThemeDir(allocator, base_path, entry.name, icon_name, &path_buf)) |path| {
                return path;
            }
        }
    }

    // Pass 3: Pixmaps fallback (all extensions including SVG)
    var pixmap_paths = xdg_paths.PathList(16){};
    xdg_paths.collectPixmapDirs(&pixmap_paths, xdg_paths.Env.fromProcess());
    for (pixmap_paths.items()) |pixmap_path| {
        for (all_extensions) |ext| {
            const path = std.fmt.bufPrint(&path_buf, "{s}/{s}{s}", .{ pixmap_path, icon_name, ext }) catch continue;
            if (fs.Dir.cwd().access(io_global(), path, .{})) |_| {
                return allocator.dupe(u8, path) catch null;
            } else |_| {}
        }
    }

    return null;
}

fn isPreferredTheme(name: []const u8) bool {
    for (preferred_themes) |pref| {
        if (mem.eql(u8, name, pref)) return true;
    }
    return false;
}

/// Search a single theme directory for the icon. Scans actual subdirectories
/// on disk rather than using hardcoded size/context lists.
/// Single pass: checks all extensions (SVG first) per subdir using dir-relative
/// faccessat for minimal syscall overhead. Only builds full path on hit.
fn searchThemeDir(
    allocator: Allocator,
    base_path: []const u8,
    theme: []const u8,
    icon_name: []const u8,
    path_buf: *[std.fs.max_path_bytes]u8,
) ?[]const u8 {
    var theme_path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const theme_path = std.fmt.bufPrint(&theme_path_buf, "{s}/{s}", .{ base_path, theme }) catch return null;

    var theme_dir = fs.Dir.cwd().openDir(io_global(), theme_path, .{ .iterate = true }) catch return null;
    defer theme_dir.close(io_global());

    // Pre-build candidate filenames once: "icon.svg", "icon.png", "icon.jpg", "icon.jpeg"
    // SVG first so vector format is preferred within each subdirectory.
    const max_name = 256 + 6;
    var candidates: [all_extensions.len][max_name]u8 = undefined;
    var candidate_lens: [all_extensions.len]usize = undefined;
    for (all_extensions, 0..) |ext, i| {
        const c = std.fmt.bufPrint(&candidates[i], "{s}{s}", .{ icon_name, ext }) catch return null;
        candidate_lens[i] = c.len;
    }

    var l1_iter = theme_dir.iterate();
    while (l1_iter.next(io_global()) catch null) |l1_entry| {
        if (l1_entry.kind != .directory and l1_entry.kind != .sym_link) continue;

        var l1_dir = theme_dir.openDir(io_global(), l1_entry.name, .{ .iterate = true }) catch continue;
        defer l1_dir.close(io_global());

        // Check L1 dir itself (some themes put icons directly in size dirs)
        for (&candidates, candidate_lens) |*cand, len| {
            if (l1_dir.access(io_global(), cand[0..len], .{})) |_| {
                const path = std.fmt.bufPrint(path_buf, "{s}/{s}/{s}", .{
                    theme_path, l1_entry.name, cand[0..len],
                }) catch continue;
                return allocator.dupe(u8, path) catch null;
            } else |_| {}
        }

        // Check L2 subdirs via relative paths from l1_dir (no L2 opendir needed)
        var rel_buf: [512]u8 = undefined;
        var l2_iter = l1_dir.iterate();
        while (l2_iter.next(io_global()) catch null) |l2_entry| {
            if (l2_entry.kind != .directory and l2_entry.kind != .sym_link) continue;

            for (&candidates, candidate_lens) |*cand, len| {
                const rel_path = std.fmt.bufPrint(&rel_buf, "{s}/{s}", .{
                    l2_entry.name, cand[0..len],
                }) catch continue;

                if (l1_dir.access(io_global(), rel_path, .{})) |_| {
                    const path = std.fmt.bufPrint(path_buf, "{s}/{s}/{s}", .{
                        theme_path, l1_entry.name, rel_path,
                    }) catch continue;
                    return allocator.dupe(u8, path) catch null;
                } else |_| {}
            }
        }
    }

    return null;
}

fn findIconFromDesktop(allocator: Allocator, app_id: []const u8) ?[]const u8 {
    var desktop_paths = xdg_paths.PathList(16){};
    xdg_paths.collectApplicationDirs(&desktop_paths, xdg_paths.Env.fromProcess());

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    var line_buf: [1024]u8 = undefined;

    // Pass 1: Exact filename match ({app_id}.desktop)
    for (desktop_paths.items()) |desktop_path| {
        const desktop_file_path = std.fmt.bufPrint(&path_buf, "{s}/{s}.desktop", .{ desktop_path, app_id }) catch continue;

        if (resolveDesktopIcon(allocator, desktop_file_path, &line_buf)) |icon_path| {
            return icon_path;
        }
    }

    // Pass 2: Scan directories for .desktop files whose Icon= field matches app_id.
    // Handles AppImages and other apps where the .desktop filename differs from the icon name.
    for (desktop_paths.items()) |desktop_path| {
        if (scanDesktopDirForIcon(allocator, desktop_path, app_id, &path_buf, &line_buf)) |icon_path| {
            return icon_path;
        }
    }

    return null;
}

/// Try to resolve an icon from a specific .desktop file path.
/// Returns an allocated icon path on success.
fn resolveDesktopIcon(allocator: Allocator, desktop_file_path: []const u8, line_buf: *[1024]u8) ?[]const u8 {
    const icon_name = parseDesktopIcon(desktop_file_path, line_buf) orelse return null;
    if (findIconDirect(allocator, icon_name)) |icon_path| {
        return icon_path;
    }
    // Absolute path in Icon= field — check it exists directly, then try common extensions
    if (icon_name.len > 0 and icon_name[0] == '/') {
        if (fs.Dir.cwd().access(io_global(), icon_name, .{})) |_| {
            return allocator.dupe(u8, icon_name) catch null;
        } else |_| {}
        // Try with common extensions (some .desktop files omit the extension)
        var ext_buf: [std.fs.max_path_bytes]u8 = undefined;
        for (all_extensions) |ext| {
            const with_ext = std.fmt.bufPrint(&ext_buf, "{s}{s}", .{ icon_name, ext }) catch continue;
            if (fs.Dir.cwd().access(io_global(), with_ext, .{})) |_| {
                return allocator.dupe(u8, with_ext) catch null;
            } else |_| {}
        }
    }
    return null;
}

/// Scan a directory of .desktop files for one whose Icon= field matches app_id.
/// This handles cases where the .desktop filename differs from the icon name
/// (common with AppImages, e.g., appimagekit_<hash>-<name>.desktop).
fn scanDesktopDirForIcon(
    allocator: Allocator,
    dir_path: []const u8,
    app_id: []const u8,
    path_buf: *[std.fs.max_path_bytes]u8,
    line_buf: *[1024]u8,
) ?[]const u8 {
    var dir = fs.Dir.cwd().openDir(io_global(), dir_path, .{ .iterate = true }) catch return null;
    defer dir.close(io_global());

    var iter = dir.iterate();
    while (iter.next(io_global()) catch null) |entry| {
        if (entry.kind != .file and entry.kind != .sym_link) continue;
        if (!mem.endsWith(u8, entry.name, ".desktop")) continue;

        const desktop_file_path = std.fmt.bufPrint(path_buf, "{s}/{s}", .{ dir_path, entry.name }) catch continue;
        const icon_value = parseDesktopIcon(desktop_file_path, line_buf) orelse continue;

        // Match: Icon= value is exactly app_id, or the basename stem matches
        const matches = mem.eql(u8, icon_value, app_id) or blk: {
            // Extract stem from absolute path: /path/to/icon.png -> icon
            if (icon_value.len > 0 and icon_value[0] == '/') {
                const basename = std.fs.path.basename(icon_value);
                const stem = if (mem.lastIndexOfScalar(u8, basename, '.')) |dot|
                    basename[0..dot]
                else
                    basename;
                break :blk mem.eql(u8, stem, app_id);
            }
            break :blk false;
        };

        if (matches) {
            return resolveDesktopIcon(allocator, desktop_file_path, line_buf);
        }
    }
    return null;
}

fn parseDesktopIcon(desktop_path: []const u8, line_buf: []u8) ?[]const u8 {
    return desktop_entry.readDesktopEntryKey(desktop_path, "Icon", line_buf);
}

pub const IconCache = struct {
    cache: std.StringHashMap(?[]const u8),
    allocator: Allocator,

    pub fn init(allocator: Allocator) IconCache {
        return .{
            .cache = std.StringHashMap(?[]const u8).init(allocator),
            .allocator = allocator,
        };
    }

    pub fn deinit(self: *IconCache) void {
        var iter = self.cache.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
            if (entry.value_ptr.*) |path| {
                self.allocator.free(path);
            }
        }
        self.cache.deinit();
    }

    pub fn lookup(self: *IconCache, app_id: []const u8) ?[]const u8 {
        if (self.cache.get(app_id)) |cached| {
            return cached;
        }

        const icon_path = findIcon(self.allocator, app_id);

        const key = self.allocator.dupe(u8, app_id) catch return icon_path;
        self.cache.put(key, icon_path) catch {
            self.allocator.free(key);
        };

        return icon_path;
    }

    pub fn clear(self: *IconCache) void {
        var iter = self.cache.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
            if (entry.value_ptr.*) |path| {
                self.allocator.free(path);
            }
        }
        self.cache.clearRetainingCapacity();
    }
};

test "IconCache init/deinit" {
    var cache = IconCache.init(std.testing.allocator);
    defer cache.deinit();
}

test "IconCache lookup caches null results" {
    var cache = IconCache.init(std.testing.allocator);
    defer cache.deinit();

    const result1 = cache.lookup("nonexistent_app_12345");
    try std.testing.expect(result1 == null);

    const result2 = cache.lookup("nonexistent_app_12345");
    try std.testing.expect(result2 == null);
}

test "IconCache clear" {
    var cache = IconCache.init(std.testing.allocator);
    defer cache.deinit();

    _ = cache.lookup("nonexistent_app_12345");
    cache.clear();

    try std.testing.expect(cache.cache.count() == 0);
}

test "toLower basic" {
    var buf: [256]u8 = undefined;
    const result = toLower("Firefox", &buf);
    try std.testing.expectEqualStrings("firefox", result.?);
}

test "toLower empty string" {
    var buf: [256]u8 = undefined;
    const result = toLower("", &buf);
    try std.testing.expectEqualStrings("", result.?);
}

test "toLower already lowercase" {
    var buf: [256]u8 = undefined;
    const result = toLower("firefox", &buf);
    try std.testing.expectEqualStrings("firefox", result.?);
}

test "toLower buffer too small" {
    var buf: [3]u8 = undefined;
    const result = toLower("Firefox", &buf);
    try std.testing.expect(result == null);
}

test "toLower mixed case" {
    var buf: [256]u8 = undefined;
    const result = toLower("FireFox_Browser", &buf);
    try std.testing.expectEqualStrings("firefox_browser", result.?);
}

test "findIcon returns null for nonexistent app" {
    const result = findIcon(std.testing.allocator, "nonexistent_app_xyz_12345");
    try std.testing.expect(result == null);
}

test "findIconSymbolicFallback returns null for nonexistent icons" {
    // Base name: tries appending "-symbolic", still not found
    try std.testing.expect(findIconSymbolicFallback(std.testing.allocator, "nonexistent_xyz_12345") == null);
    // Symbolic name: tries stripping "-symbolic" to get base, still not found
    try std.testing.expect(findIconSymbolicFallback(std.testing.allocator, "nonexistent_xyz_12345-symbolic") == null);
}

test "isPreferredTheme" {
    try std.testing.expect(isPreferredTheme("hicolor"));
    try std.testing.expect(isPreferredTheme("Adwaita"));
    try std.testing.expect(!isPreferredTheme("some-unknown-theme"));
}
