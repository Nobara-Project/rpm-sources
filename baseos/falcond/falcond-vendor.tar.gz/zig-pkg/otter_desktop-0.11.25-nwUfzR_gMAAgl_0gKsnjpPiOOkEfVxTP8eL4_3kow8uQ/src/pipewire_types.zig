//! PipeWire public audio data types.

const FixedString = @import("otter_utils").FixedString;

pub const DeviceType = enum {
    sink, // Output (speakers, headphones)
    source, // Input (microphone)
};

/// Audio device information
pub const AudioDevice = struct {
    /// PipeWire node ID
    id: u32 = 0,

    /// Device name (internal identifier)
    name: FixedString(256) = .{},

    /// Human-readable description
    description: FixedString(256) = .{},

    /// Device type (sink or source)
    device_type: DeviceType = .sink,

    /// Volume level (0.0 to 1.0+)
    volume: f32 = 1.0,

    /// Number of channels
    channels: u32 = 2,

    /// Muted state
    muted: bool = false,

    /// Whether this is the default device
    is_default: bool = false,

    /// Media class (e.g., "Audio/Sink")
    media_class: FixedString(64) = .{},

    /// Check if device is an output (sink)
    pub fn isSink(self: *const AudioDevice) bool {
        return self.device_type == .sink;
    }

    /// Check if device is an input (source)
    pub fn isSource(self: *const AudioDevice) bool {
        return self.device_type == .source;
    }

    /// Get volume as percentage (0-150, PipeWire allows overamplification up to 1.5)
    pub fn getVolumePercent(self: *const AudioDevice) u8 {
        return @intFromFloat(@min(150.0, @max(0.0, self.volume * 100.0)));
    }
};
