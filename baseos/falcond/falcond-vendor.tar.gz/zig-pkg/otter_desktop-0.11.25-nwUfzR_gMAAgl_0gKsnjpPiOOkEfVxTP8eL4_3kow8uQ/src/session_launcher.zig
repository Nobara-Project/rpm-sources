const std = @import("std");
const c = @import("session_launcher_c");

pub const UserEnv = struct { username: []const u8, home: []const u8, shell: []const u8, path: []const u8 };
pub const SessionEnv = struct { seat: []const u8, vtnr: ?u16, session_desktop: []const u8, current_desktop: []const u8 };

pub const EnvBuilder = struct {
    allocator: std.mem.Allocator,
    map: std.StringHashMap([]const u8),

    pub fn init(allocator: std.mem.Allocator) EnvBuilder {
        return .{ .allocator = allocator, .map = std.StringHashMap([]const u8).init(allocator) };
    }

    pub fn addUser(self: *EnvBuilder, user: UserEnv) !void {
        try self.put("HOME", user.home);
        try self.put("PWD", user.home);
        try self.put("SHELL", user.shell);
        try self.put("USER", user.username);
        try self.put("LOGNAME", user.username);
        try self.put("PATH", user.path);
    }

    pub fn addSession(self: *EnvBuilder, session: SessionEnv) !void {
        try self.put("XDG_SESSION_TYPE", "wayland");
        try self.put("XDG_SESSION_CLASS", "user");
        try self.put("XDG_SESSION_DESKTOP", session.session_desktop);
        try self.put("XDG_SEAT", session.seat);
        try self.put("XDG_CURRENT_DESKTOP", session.current_desktop);
        if (session.vtnr) |vtnr| {
            var buf: [16]u8 = undefined;
            try self.put("XDG_VTNR", try std.fmt.bufPrint(&buf, "{d}", .{vtnr}));
        }
    }

    pub fn addPamEnv(self: *EnvBuilder, entries: []const []const u8) !void {
        for (entries) |entry| {
            if (std.mem.indexOfScalar(u8, entry, '=')) |eq| {
                try self.put(entry[0..eq], entry[eq + 1 ..]);
            }
        }
    }

    pub fn requireRuntimeDir(self: *const EnvBuilder) !void {
        if (self.get("XDG_RUNTIME_DIR") == null) return error.MissingRuntimeDir;
    }

    pub fn toEnvp(self: *const EnvBuilder, allocator: std.mem.Allocator) ![:null]?[*:0]const u8 {
        var out = try allocator.allocSentinel(?[*:0]const u8, self.map.count(), null);
        var it = self.map.iterator();
        var i: usize = 0;
        while (it.next()) |entry| : (i += 1) {
            const item = try std.fmt.allocPrintSentinel(allocator, "{s}={s}", .{ entry.key_ptr.*, entry.value_ptr.* }, 0);
            out[i] = item.ptr;
        }
        return out;
    }

    pub fn get(self: *const EnvBuilder, key: []const u8) ?[]const u8 {
        return self.map.get(key);
    }

    pub fn deinit(self: *EnvBuilder) void {
        var it = self.map.iterator();
        while (it.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
            self.allocator.free(entry.value_ptr.*);
        }
        self.map.deinit();
    }

    pub fn put(self: *EnvBuilder, key: []const u8, value: []const u8) !void {
        if (self.map.fetchRemove(key)) |old| {
            self.allocator.free(old.key);
            self.allocator.free(old.value);
        }
        try self.map.put(try self.allocator.dupe(u8, key), try self.allocator.dupe(u8, value));
    }
};

pub fn validateShell(path: []const u8) !void {
    if (!std.fs.path.isAbsolute(path)) return error.InvalidShell;
    const z = try std.heap.page_allocator.dupeZ(u8, path);
    defer std.heap.page_allocator.free(z);
    if (c.access(z.ptr, c.X_OK) != 0) return error.InvalidShell;
}

pub fn buildShellArgv(allocator: std.mem.Allocator, shell: []const u8, exec: []const u8) ![:null]?[*:0]const u8 {
    var argv = try allocator.allocSentinel(?[*:0]const u8, 3, null);
    argv[0] = (try allocator.dupeZ(u8, shell)).ptr;
    argv[1] = (try allocator.dupeZ(u8, "-c")).ptr;
    argv[2] = (try allocator.dupeZ(u8, exec)).ptr;
    return argv;
}

pub fn dropPrivileges(username_z: [*:0]const u8, uid: std.posix.uid_t, gid: std.posix.gid_t) !void {
    if (c.initgroups(username_z, gid) != 0) return error.InitGroupsFailed;
    if (std.c.setgid(gid) != 0) return error.SetGidFailed;
    if (std.c.setuid(uid) != 0) return error.SetUidFailed;
}

test "env builder does not synthesize logind-owned variables" {
    var env = EnvBuilder.init(std.testing.allocator);
    defer env.deinit();
    try env.addUser(.{
        .username = "ferreo",
        .home = "/home/ferreo",
        .shell = "/bin/bash",
        .path = "/usr/bin:/bin",
    });
    try env.addSession(.{
        .seat = "seat1",
        .vtnr = null,
        .session_desktop = "otter",
        .current_desktop = "otter",
    });
    try std.testing.expect(env.get("XDG_RUNTIME_DIR") == null);
    try std.testing.expect(env.get("XDG_SESSION_ID") == null);
    try std.testing.expect(env.get("DISPLAY") == null);
    try std.testing.expectEqualStrings("wayland", env.get("XDG_SESSION_TYPE").?);
    try std.testing.expectEqualStrings("seat1", env.get("XDG_SEAT").?);
}
