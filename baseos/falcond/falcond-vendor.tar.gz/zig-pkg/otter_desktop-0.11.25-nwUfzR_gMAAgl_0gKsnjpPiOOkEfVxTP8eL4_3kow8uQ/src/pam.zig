//! PAM Authentication Module
//!
//! C interop wrapper for Linux PAM (Pluggable Authentication Modules).
//! Provides password-based authentication via the system PAM stack.

const std = @import("std");
const log = std.log.scoped(.pam);

const c = @import("pam_c");

pub const PamResult = enum {
    success,
    auth_error,
    account_error,
    service_error,
};

/// Context passed through PAM conversation callback via appdata_ptr.
const ConvContext = struct {
    password: []const u8,
};

pub const PamAuth = struct {
    /// Authenticate a user via PAM.
    ///
    /// service: PAM service name (e.g. "otter-lock")
    /// username: system username
    /// password: plaintext password (caller should zero after return)
    ///
    /// Returns the authentication result. The password copy used internally
    /// is zeroed before returning.
    pub fn authenticate(
        service: [*:0]const u8,
        username: [*:0]const u8,
        password: []const u8,
    ) PamResult {
        var ctx = ConvContext{ .password = password };

        const conv = c.pam_conv{
            .conv = &pamConversation,
            .appdata_ptr = @ptrCast(&ctx),
        };

        var handle: ?*c.pam_handle_t = null;
        var status = c.pam_start(service, username, &conv, &handle);
        if (status != c.PAM_SUCCESS) {
            log.warn("pam_start failed: {s}", .{pamStrerror(handle, status)});
            return .service_error;
        }

        status = c.pam_authenticate(handle.?, 0);
        if (status != c.PAM_SUCCESS) {
            log.info("pam_authenticate failed: {s}", .{pamStrerror(handle, status)});
            _ = c.pam_end(handle.?, status);
            return .auth_error;
        }

        status = c.pam_acct_mgmt(handle.?, 0);
        if (status != c.PAM_SUCCESS) {
            log.info("pam_acct_mgmt failed: {s}", .{pamStrerror(handle, status)});
            _ = c.pam_end(handle.?, status);
            return .account_error;
        }

        _ = c.pam_end(handle.?, c.PAM_SUCCESS);
        return .success;
    }
};

/// PAM conversation callback. Responds to PAM_PROMPT_ECHO_OFF with the password.
/// PAM requires responses allocated with malloc (it calls free internally).
fn pamConversation(
    num_msg: c_int,
    msg: [*c][*c]const c.pam_message,
    resp: [*c][*c]c.pam_response,
    appdata_ptr: ?*anyopaque,
) callconv(.c) c_int {
    const ctx: *ConvContext = @ptrCast(@alignCast(appdata_ptr orelse return c.PAM_CONV_ERR));

    const count: usize = if (num_msg > 0) @intCast(num_msg) else return c.PAM_CONV_ERR;

    // Allocate response array with C malloc (PAM frees it)
    const responses: [*c]c.pam_response = @ptrCast(@alignCast(
        std.c.malloc(count * @sizeOf(c.pam_response)) orelse return c.PAM_BUF_ERR,
    ));

    for (0..count) |i| {
        responses[i].resp = null;
        responses[i].resp_retcode = 0;

        const m = msg[i];
        switch (m.*.msg_style) {
            c.PAM_PROMPT_ECHO_OFF => {
                // Allocate password copy with C malloc (PAM frees it)
                const pwd_buf: [*c]u8 = @ptrCast(
                    std.c.malloc(ctx.password.len + 1) orelse {
                        freeResponses(responses, i);
                        return c.PAM_BUF_ERR;
                    },
                );
                @memcpy(pwd_buf[0..ctx.password.len], ctx.password);
                pwd_buf[ctx.password.len] = 0;
                responses[i].resp = pwd_buf;
            },
            c.PAM_PROMPT_ECHO_ON, c.PAM_ERROR_MSG, c.PAM_TEXT_INFO => {},
            else => {
                freeResponses(responses, i);
                return c.PAM_CONV_ERR;
            },
        }
    }

    resp[0] = responses;
    return c.PAM_SUCCESS;
}

fn freeResponses(responses: [*c]c.pam_response, count: usize) void {
    for (0..count) |i| {
        if (responses[i].resp) |r| {
            // Zero the password before freeing
            const ptr: [*]u8 = @ptrCast(r);
            var len: usize = 0;
            while (ptr[len] != 0) : (len += 1) {}
            @memset(ptr[0..len], 0);
            std.c.free(r);
        }
    }
    std.c.free(responses);
}

fn pamStrerror(handle: ?*c.pam_handle_t, status: c_int) [*:0]const u8 {
    if (handle) |h| {
        return c.pam_strerror(h, status);
    }
    return "unknown error";
}

// ============================================================================
// Tests
// ============================================================================

test "PamResult has expected variants" {
    const results = [_]PamResult{ .success, .auth_error, .account_error, .service_error };
    try std.testing.expectEqual(@as(usize, 4), results.len);
}

test "PamAuth type is a struct" {
    try std.testing.expect(@typeInfo(PamAuth) == .@"struct");
}
