const std = @import("std");
const dbus = @import("dbus/connection.zig");
const otter_utils = @import("otter_utils");
inline fn io_global() std.Io { return otter_utils.io.get(); }

pub const User = struct {
    username: []const u8,
    display_name: []const u8,
    icon_path: []const u8,
    uid: u32,
    locked: bool,
    system_account: bool,
    home: []const u8,
    shell: []const u8,
    allocator: std.mem.Allocator,

    pub fn deinit(self: *User) void {
        self.allocator.free(self.username);
        self.allocator.free(self.display_name);
        self.allocator.free(self.icon_path);
        self.allocator.free(self.home);
        self.allocator.free(self.shell);
    }
};

pub const PasswdUser = struct {
    username: []const u8,
    uid: u32,
    gid: u32,
    home: []const u8,
    shell: []const u8,
};

pub const UidRange = struct {
    uid_min: u32 = 1000,
    uid_max: u32 = 60000,
};

pub fn loadUsers(allocator: std.mem.Allocator, prefer_accountsservice: bool) ![]User {
    if (prefer_accountsservice) {
        const users = loadAccountsServiceUsers(allocator) catch null;
        if (users) |list| if (list.len != 0) return list else allocator.free(list);
    }
    return loadPasswdUsers(allocator);
}

fn loadAccountsServiceUsers(allocator: std.mem.Allocator) ![]User {
    var connection = try dbus.Connection.open(allocator, .system);
    defer connection.deinit();
    var reply = try connection.callMethod(
        "org.freedesktop.Accounts",
        "/org/freedesktop/Accounts",
        "org.freedesktop.Accounts",
        "ListCachedUsers",
    );
    defer reply.unref();
    var out = std.ArrayList(User).empty;
    errdefer {
        for (out.items) |*u| u.deinit();
        out.deinit(allocator);
    }
    _ = try reply.enterArray("o");
    while (!reply.atEnd()) {
        const path = try reply.readObjectPath();
        var user = readAccountsUser(allocator, &connection, path) catch continue;
        if (user.locked or user.system_account) {
            user.deinit();
            continue;
        }
        try out.append(allocator, user);
    }
    try reply.exitContainer();
    std.mem.sort(User, out.items, {}, lessUser);
    return out.toOwnedSlice(allocator);
}

fn loadPasswdUsers(allocator: std.mem.Allocator) ![]User {
    var out = std.ArrayList(User).empty;
    errdefer {
        for (out.items) |*u| u.deinit();
        out.deinit(allocator);
    }
    const file = std.Io.Dir.openFileAbsolute(io_global(), "/etc/passwd", .{}) catch return out.toOwnedSlice(allocator);
    defer file.close(io_global());
    const len: usize = @intCast(try file.length(io_global()));
    const bytes = try allocator.alloc(u8, @min(len, 1024 * 1024));
    const read_len = try file.readPositionalAll(io_global(), bytes, 0);
    const content = bytes[0..read_len];
    defer allocator.free(bytes);
    var parsed = std.ArrayList(PasswdUser).empty;
    defer parsed.deinit(allocator);
    var lines = std.mem.splitScalar(u8, content, '\n');
    while (lines.next()) |line| {
        if (line.len == 0) continue;
        var parts = std.mem.splitScalar(u8, line, ':');
        const username = parts.next() orelse continue;
        _ = parts.next() orelse continue;
        const uid_s = parts.next() orelse continue;
        const gid_s = parts.next() orelse continue;
        _ = parts.next() orelse continue;
        const home = parts.next() orelse continue;
        const shell = parts.next() orelse continue;
        try parsed.append(allocator, .{
            .username = username,
            .uid = std.fmt.parseInt(u32, uid_s, 10) catch continue,
            .gid = std.fmt.parseInt(u32, gid_s, 10) catch continue,
            .home = home,
            .shell = shell,
        });
    }
    try collectPasswdUsers(allocator, parsed.items, .{}, &out);
    return out.toOwnedSlice(allocator);
}

fn readAccountsUser(allocator: std.mem.Allocator, connection: *dbus.Connection, path: []const u8) !User {
    const path_z = try allocator.dupeZ(u8, path);
    defer allocator.free(path_z);
    const username = try readStringProperty(allocator, connection, path_z, "UserName");
    errdefer allocator.free(username);
    const real_name = readStringProperty(allocator, connection, path_z, "RealName") catch try allocator.dupe(u8, "");
    defer allocator.free(real_name);
    const display_name = if (real_name.len != 0) real_name else username;
    const icon_path = readStringProperty(allocator, connection, path_z, "IconFile") catch try allocator.dupe(u8, "");
    errdefer allocator.free(icon_path);
    const home = readStringProperty(allocator, connection, path_z, "HomeDirectory") catch try allocator.dupe(u8, "");
    errdefer allocator.free(home);
    const shell = readStringProperty(allocator, connection, path_z, "Shell") catch try allocator.dupe(u8, "");
    errdefer allocator.free(shell);
    return .{
        .username = username,
        .display_name = try allocator.dupe(u8, display_name),
        .icon_path = icon_path,
        .uid = readUidProperty(connection, path_z, "Uid") catch 0,
        .locked = readBoolProperty(connection, path_z, "Locked") catch false,
        .system_account = readBoolProperty(connection, path_z, "SystemAccount") catch false,
        .home = home,
        .shell = shell,
        .allocator = allocator,
    };
}

fn readStringProperty(allocator: std.mem.Allocator, connection: *dbus.Connection, path: [:0]const u8, property: [:0]const u8) ![]const u8 {
    var msg = try connection.getProperty("org.freedesktop.Accounts", path, "org.freedesktop.Accounts.User", property);
    defer msg.unref();
    if (!try msg.enterVariant("s")) return error.InvalidProperty;
    const value = try msg.readString();
    try msg.exitContainer();
    return allocator.dupe(u8, value);
}

fn readBoolProperty(connection: *dbus.Connection, path: [:0]const u8, property: [:0]const u8) !bool {
    var msg = try connection.getProperty("org.freedesktop.Accounts", path, "org.freedesktop.Accounts.User", property);
    defer msg.unref();
    if (!try msg.enterVariant("b")) return error.InvalidProperty;
    const value = try msg.readBool();
    try msg.exitContainer();
    return value;
}

fn readUidProperty(connection: *dbus.Connection, path: [:0]const u8, property: [:0]const u8) !u32 {
    var msg = try connection.getProperty("org.freedesktop.Accounts", path, "org.freedesktop.Accounts.User", property);
    defer msg.unref();
    if (msg.enterVariant("t") catch false) {
        const value = try msg.readUint64();
        try msg.exitContainer();
        return @intCast(value);
    }
    if (try msg.enterVariant("u")) {
        const value = try msg.readUint32();
        try msg.exitContainer();
        return value;
    }
    return error.InvalidProperty;
}

pub fn collectPasswdUsers(allocator: std.mem.Allocator, users: []const PasswdUser, range: UidRange, out: *std.ArrayList(User)) !void {
    for (users) |u| {
        if (isNonLoginShell(u.shell)) continue;
        const normal = u.uid >= range.uid_min and u.uid <= range.uid_max;
        const homed = u.uid >= 60001 and u.uid <= 60513;
        if (!normal and !homed) continue;
        try out.append(allocator, .{
            .username = try allocator.dupe(u8, u.username),
            .display_name = try allocator.dupe(u8, u.username),
            .icon_path = try allocator.dupe(u8, ""),
            .uid = u.uid,
            .locked = false,
            .system_account = false,
            .home = try allocator.dupe(u8, u.home),
            .shell = try allocator.dupe(u8, u.shell),
            .allocator = allocator,
        });
    }
    std.mem.sort(User, out.items, {}, lessUser);
}

fn isNonLoginShell(shell: []const u8) bool {
    return std.mem.endsWith(u8, shell, "/nologin") or std.mem.eql(u8, shell, "/bin/false");
}

fn lessUser(_: void, a: User, b: User) bool {
    const by_display = std.mem.order(u8, a.display_name, b.display_name);
    if (by_display != .eq) return by_display == .lt;
    return std.mem.lessThan(u8, a.username, b.username);
}

test "passwd fallback filters non-login shells" {
    const users = [_]PasswdUser{
        .{ .username = "daemon", .uid = 1, .gid = 1, .home = "/usr/sbin", .shell = "/usr/sbin/nologin" },
        .{ .username = "ferreo", .uid = 1000, .gid = 1000, .home = "/home/ferreo", .shell = "/bin/bash" },
        .{ .username = "homed", .uid = 60001, .gid = 60001, .home = "/home/homed", .shell = "/bin/zsh" },
    };
    var out = std.ArrayList(User).empty;
    defer {
        for (out.items) |*u| u.deinit();
        out.deinit(std.testing.allocator);
    }
    try collectPasswdUsers(std.testing.allocator, &users, .{ .uid_min = 1000, .uid_max = 60000 }, &out);
    try std.testing.expectEqual(@as(usize, 2), out.items.len);
    try std.testing.expectEqualStrings("ferreo", out.items[0].username);
    try std.testing.expectEqualStrings("homed", out.items[1].username);
}
