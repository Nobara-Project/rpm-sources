const std = @import("std");

pub const Env = struct {
    home: ?[]const u8 = null,
    xdg_data_home: ?[]const u8 = null,
    xdg_data_dirs: ?[]const u8 = null,

    pub fn fromProcess() Env {
        return .{
            .home = getenv("HOME"),
            .xdg_data_home = getenv("XDG_DATA_HOME"),
            .xdg_data_dirs = getenv("XDG_DATA_DIRS"),
        };
    }

    fn getenv(name: [:0]const u8) ?[]const u8 {
        return if (std.c.getenv(name)) |raw| std.mem.span(raw) else null;
    }
};

pub fn PathList(comptime capacity: usize) type {
    return struct {
        storage: [capacity][std.fs.max_path_bytes]u8 = undefined,
        paths: [capacity][]const u8 = undefined,
        count: usize = 0,

        const Self = @This();

        pub fn appendLiteral(self: *Self, path: []const u8) void {
            self.appendPath(path);
        }

        pub fn appendFmt(self: *Self, comptime fmt: []const u8, args: anytype) void {
            if (self.count >= capacity) return;
            const path = std.fmt.bufPrint(&self.storage[self.count], fmt, args) catch return;
            self.appendPath(path);
        }

        pub fn items(self: *const Self) []const []const u8 {
            return self.paths[0..self.count];
        }

        fn appendPath(self: *Self, path: []const u8) void {
            if (self.count >= capacity) return;
            const normalized = normalize(path);
            for (self.paths[0..self.count]) |existing| {
                if (std.mem.eql(u8, normalize(existing), normalized)) return;
            }
            self.paths[self.count] = normalized;
            self.count += 1;
        }
    };
}

pub fn collectApplicationDirs(list: anytype, env: Env) void {
    if (env.xdg_data_home) |data_home| {
        list.appendFmt("{s}/applications", .{data_home});
    } else if (env.home) |home| {
        list.appendFmt("{s}/.local/share/applications", .{home});
    }

    if (env.home) |home| {
        list.appendFmt("{s}/.local/share/flatpak/exports/share/applications", .{home});
    }

    appendXdgDataSubdir(list, env.xdg_data_dirs orelse "/usr/local/share:/usr/share", "applications");
    list.appendLiteral("/var/lib/flatpak/exports/share/applications");
}

pub fn collectIconDirs(list: anytype, env: Env) void {
    if (env.xdg_data_home) |data_home| {
        list.appendFmt("{s}/icons", .{data_home});
    } else if (env.home) |home| {
        list.appendFmt("{s}/.local/share/icons", .{home});
    }

    if (env.home) |home| {
        list.appendFmt("{s}/.local/share/flatpak/exports/share/icons", .{home});
    }

    appendXdgDataSubdir(list, env.xdg_data_dirs orelse "/usr/local/share:/usr/share", "icons");
    list.appendLiteral("/var/lib/flatpak/exports/share/icons");
}

pub fn collectPixmapDirs(list: anytype, env: Env) void {
    appendXdgDataSubdir(list, env.xdg_data_dirs orelse "/usr/local/share:/usr/share", "pixmaps");
    if (env.home) |home| {
        list.appendFmt("{s}/.local/share/flatpak/exports/share/pixmaps", .{home});
    }
    list.appendLiteral("/var/lib/flatpak/exports/share/pixmaps");
}

fn appendXdgDataSubdir(list: anytype, data_dirs: []const u8, subdir: []const u8) void {
    var iter = std.mem.splitScalar(u8, data_dirs, ':');
    while (iter.next()) |data_dir| {
        if (data_dir.len == 0) continue;
        list.appendFmt("{s}/{s}", .{ data_dir, subdir });
    }
}

fn normalize(path: []const u8) []const u8 {
    if (path.len > 1 and path[path.len - 1] == '/') return path[0 .. path.len - 1];
    return path;
}

test "collectApplicationDirs preserves priority and deduplicates" {
    var list = PathList(8){};
    collectApplicationDirs(&list, .{
        .home = "/home/test",
        .xdg_data_home = "/data/home",
        .xdg_data_dirs = "/usr/local/share:/usr/share:/var/lib/flatpak/exports/share",
    });

    const items = list.items();
    try std.testing.expectEqual(@as(usize, 5), items.len);
    try std.testing.expectEqualStrings("/data/home/applications", items[0]);
    try std.testing.expectEqualStrings("/home/test/.local/share/flatpak/exports/share/applications", items[1]);
    try std.testing.expectEqualStrings("/usr/local/share/applications", items[2]);
    try std.testing.expectEqualStrings("/usr/share/applications", items[3]);
    try std.testing.expectEqualStrings("/var/lib/flatpak/exports/share/applications", items[4]);
}

test "collectIconDirs falls back to HOME and XDG defaults" {
    var list = PathList(8){};
    collectIconDirs(&list, .{ .home = "/home/test" });

    const items = list.items();
    try std.testing.expectEqual(@as(usize, 5), items.len);
    try std.testing.expectEqualStrings("/home/test/.local/share/icons", items[0]);
    try std.testing.expectEqualStrings("/home/test/.local/share/flatpak/exports/share/icons", items[1]);
    try std.testing.expectEqualStrings("/usr/local/share/icons", items[2]);
    try std.testing.expectEqualStrings("/usr/share/icons", items[3]);
    try std.testing.expectEqualStrings("/var/lib/flatpak/exports/share/icons", items[4]);
}

test "collectPixmapDirs includes user flatpak after system data dirs" {
    var list = PathList(8){};
    collectPixmapDirs(&list, .{ .home = "/home/test", .xdg_data_dirs = "/opt/share:/usr/share" });

    const items = list.items();
    try std.testing.expectEqual(@as(usize, 4), items.len);
    try std.testing.expectEqualStrings("/opt/share/pixmaps", items[0]);
    try std.testing.expectEqualStrings("/usr/share/pixmaps", items[1]);
    try std.testing.expectEqualStrings("/home/test/.local/share/flatpak/exports/share/pixmaps", items[2]);
    try std.testing.expectEqualStrings("/var/lib/flatpak/exports/share/pixmaps", items[3]);
}
