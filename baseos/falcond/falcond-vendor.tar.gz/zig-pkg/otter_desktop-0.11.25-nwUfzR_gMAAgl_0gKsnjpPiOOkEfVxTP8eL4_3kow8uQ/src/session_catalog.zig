const std = @import("std");
const otter_utils = @import("otter_utils");
inline fn io_global() std.Io { return otter_utils.io.get(); }

pub const Session = struct {
    id: []const u8,
    name: []const u8,
    exec: []const u8,
    desktop_names: []const u8,
    session_desktop: []const u8,
    current_desktop: []const u8,
    path: []const u8,
    allocator: std.mem.Allocator,

    pub fn deinit(self: *Session) void {
        self.allocator.free(self.id);
        self.allocator.free(self.name);
        self.allocator.free(self.exec);
        self.allocator.free(self.desktop_names);
        self.allocator.free(self.session_desktop);
        self.allocator.free(self.current_desktop);
        self.allocator.free(self.path);
    }
};

pub const Catalog = struct {
    sessions: std.ArrayList(Session) = .empty,

    pub fn scan(allocator: std.mem.Allocator, dirs: []const u8) !Catalog {
        var catalog = Catalog{};
        errdefer catalog.deinit(allocator);
        var it = std.mem.splitScalar(u8, dirs, ':');
        while (it.next()) |dir_path| {
            if (dir_path.len == 0) continue;
            var dir = std.Io.Dir.openDirAbsolute(io_global(), dir_path, .{ .iterate = true }) catch continue;
            defer dir.close(io_global());
            var walker = try dir.walk(allocator);
            defer walker.deinit();
            while (try walker.next(io_global())) |entry| {
                if (entry.kind != .file or !std.mem.endsWith(u8, entry.basename, ".desktop")) continue;
                const full = try std.fs.path.join(allocator, &.{ dir_path, entry.path });
                defer allocator.free(full);
                const bytes = std.Io.Dir.cwd().readFileAlloc(io_global(), full, allocator, .limited(64 * 1024)) catch continue;
                defer allocator.free(bytes);
                if (try shouldSkip(bytes)) continue;
                var parsed = parseDesktopEntry(allocator, entry.basename, bytes) catch continue;
                parsed.path = try allocator.dupe(u8, full);
                try catalog.sessions.append(allocator, parsed);
            }
        }
        std.mem.sort(Session, catalog.sessions.items, {}, lessSession);
        return catalog;
    }

    pub fn findById(self: *const Catalog, id: []const u8) ?*const Session {
        for (self.sessions.items) |*session| {
            if (std.mem.eql(u8, session.id, id)) return session;
        }
        return null;
    }

    pub fn defaultSession(self: *const Catalog, remembered: []const u8, configured: []const u8) ?*const Session {
        if (remembered.len != 0) if (self.findById(remembered)) |s| return s;
        if (configured.len != 0) if (self.findById(configured)) |s| return s;
        if (self.findById("otter")) |s| return s;
        if (self.sessions.items.len == 0) return null;
        return &self.sessions.items[0];
    }

    pub fn deinit(self: *Catalog, allocator: std.mem.Allocator) void {
        for (self.sessions.items) |*session| session.deinit();
        self.sessions.deinit(allocator);
    }
};

fn lessSession(_: void, a: Session, b: Session) bool {
    const by_name = std.mem.order(u8, a.name, b.name);
    if (by_name != .eq) return by_name == .lt;
    return std.mem.lessThan(u8, a.id, b.id);
}

pub fn parseDesktopEntry(allocator: std.mem.Allocator, filename: []const u8, text: []const u8) !Session {
    var name: []const u8 = "";
    var exec: []const u8 = "";
    var desktop_names: []const u8 = "";
    var in_entry = false;
    var lines = std.mem.splitScalar(u8, text, '\n');
    while (lines.next()) |raw| {
        const line = std.mem.trim(u8, raw, " \t\r");
        if (line.len == 0 or line[0] == '#') continue;
        if (line[0] == '[') {
            in_entry = std.mem.eql(u8, line, "[Desktop Entry]");
            continue;
        }
        if (!in_entry) continue;
        if (std.mem.indexOfScalar(u8, line, '=')) |eq| {
            const key = line[0..eq];
            const value = line[eq + 1 ..];
            if (std.mem.eql(u8, key, "Name")) name = value;
            if (std.mem.eql(u8, key, "Exec")) exec = value;
            if (std.mem.eql(u8, key, "DesktopNames")) desktop_names = value;
        }
    }
    if (name.len == 0 or exec.len == 0) return error.InvalidDesktopEntry;
    const id = stem(filename);
    const session_desktop = if (desktop_names.len == 0) id else firstDesktopName(desktop_names);
    const current_desktop = if (desktop_names.len == 0) id else try semicolonsToColons(allocator, desktop_names);
    errdefer if (desktop_names.len != 0) allocator.free(current_desktop);
    return .{
        .id = try allocator.dupe(u8, id),
        .name = try allocator.dupe(u8, name),
        .exec = try allocator.dupe(u8, exec),
        .desktop_names = try allocator.dupe(u8, desktop_names),
        .session_desktop = try allocator.dupe(u8, session_desktop),
        .current_desktop = if (desktop_names.len == 0) try allocator.dupe(u8, current_desktop) else current_desktop,
        .path = try allocator.dupe(u8, ""),
        .allocator = allocator,
    };
}

pub fn shouldSkip(text: []const u8) !bool {
    var has_type = false;
    var type_ok = true;
    var hidden = false;
    var nodisplay = false;
    var terminal = false;
    var in_entry = false;
    var lines = std.mem.splitScalar(u8, text, '\n');
    while (lines.next()) |raw| {
        const line = std.mem.trim(u8, raw, " \t\r");
        if (line.len == 0 or line[0] == '#') continue;
        if (line[0] == '[') {
            in_entry = std.mem.eql(u8, line, "[Desktop Entry]");
            continue;
        }
        if (!in_entry) continue;
        if (std.mem.indexOfScalar(u8, line, '=')) |eq| {
            const key = line[0..eq];
            const value = line[eq + 1 ..];
            if (std.mem.eql(u8, key, "Type")) {
                has_type = true;
                type_ok = std.mem.eql(u8, value, "Application");
            }
            if (std.mem.eql(u8, key, "Hidden")) hidden = std.mem.eql(u8, value, "true");
            if (std.mem.eql(u8, key, "NoDisplay")) nodisplay = std.mem.eql(u8, value, "true");
            if (std.mem.eql(u8, key, "Terminal")) terminal = std.mem.eql(u8, value, "true");
        }
    }
    return (has_type and !type_ok) or hidden or nodisplay or terminal;
}

fn stem(filename: []const u8) []const u8 {
    const base = std.fs.path.basename(filename);
    if (std.mem.endsWith(u8, base, ".desktop")) return base[0 .. base.len - ".desktop".len];
    return base;
}

fn firstDesktopName(names: []const u8) []const u8 {
    if (std.mem.indexOfScalar(u8, names, ';')) |idx| return names[0..idx];
    return names;
}

fn semicolonsToColons(allocator: std.mem.Allocator, names: []const u8) ![]const u8 {
    const out = try allocator.dupe(u8, names);
    for (out) |*c| {
        if (c.* == ';') c.* = ':';
    }
    return out;
}

test "DesktopNames maps to XDG variables like LY" {
    var parsed = try parseDesktopEntry(std.testing.allocator, "sway.desktop",
        \\[Desktop Entry]
        \\Name=Sway
        \\Exec=sway
        \\Type=Application
        \\DesktopNames=sway;wlroots;
    );
    defer parsed.deinit();
    try std.testing.expectEqualStrings("sway", parsed.session_desktop);
    try std.testing.expectEqualStrings("sway:wlroots:", parsed.current_desktop);
}

test "missing DesktopNames falls back to file stem" {
    var parsed = try parseDesktopEntry(std.testing.allocator, "otter.desktop",
        \\[Desktop Entry]
        \\Name=Otter
        \\Exec=zango
        \\Type=Application
    );
    defer parsed.deinit();
    try std.testing.expectEqualStrings("otter", parsed.session_desktop);
}

test "hidden nodisplay and terminal entries are skipped" {
    try std.testing.expect(try shouldSkip(
        \\[Desktop Entry]
        \\Name=Hidden
        \\Exec=hidden
        \\Type=Application
        \\Hidden=true
    ));
    try std.testing.expect(try shouldSkip(
        \\[Desktop Entry]
        \\Name=Terminal
        \\Exec=foot
        \\Type=Application
        \\Terminal=true
    ));
}

test "Wayland session entries may omit Type" {
    try std.testing.expect(!try shouldSkip(
        \\[Desktop Entry]
        \\Exec=/usr/bin/startplasma-wayland
        \\TryExec=/usr/bin/startplasma-wayland
        \\DesktopNames=KDE
        \\Name=Plasma (Wayland)
    ));
}

test "non-application Type entries are skipped" {
    try std.testing.expect(try shouldSkip(
        \\[Desktop Entry]
        \\Name=Link
        \\Exec=ignored
        \\Type=Link
    ));
}

test "catalog scan includes Plasma-style session without Type" {
    var tmp = std.testing.tmpDir(.{});
    defer tmp.cleanup();
    try tmp.dir.writeFile(io_global(), .{
        .sub_path = "plasma.desktop",
        .data =
        \\[Desktop Entry]
        \\Exec=/usr/bin/startplasma-wayland
        \\TryExec=/usr/bin/startplasma-wayland
        \\DesktopNames=KDE
        \\Name=Plasma (Wayland)
        \\
        ,
    });

    var path_buf: [std.fs.max_path_bytes]u8 = undefined;
    const path_len = try tmp.dir.realPathFile(std.testing.io, "plasma.desktop", &path_buf);
    const session_path = path_buf[0..path_len];
    const dir_path = std.fs.path.dirname(session_path).?;

    var catalog = try Catalog.scan(std.testing.allocator, dir_path);
    defer catalog.deinit(std.testing.allocator);
    try std.testing.expectEqual(@as(usize, 1), catalog.sessions.items.len);
    try std.testing.expectEqualStrings("plasma", catalog.sessions.items[0].id);
    try std.testing.expectEqualStrings("Plasma (Wayland)", catalog.sessions.items[0].name);
    try std.testing.expectEqualStrings("KDE", catalog.sessions.items[0].session_desktop);
}
