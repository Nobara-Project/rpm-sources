//! MPRIS D-Bus Client
//!
//! Provides access to media players via the MPRIS2 D-Bus specification.
//! Supports multiple players, playback control, and metadata tracking.
//!
//! D-Bus Interface: org.mpris.MediaPlayer2.Player
//! Object Path: /org/mpris/MediaPlayer2
//!
//! Reference: https://specifications.freedesktop.org/mpris-spec/latest/

const std = @import("std");
const mem = std.mem;
const Allocator = std.mem.Allocator;
const posix = std.posix;
const FixedString = @import("otter_utils").FixedString;
const SubscriberList = @import("otter_utils").SubscriberList;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.mpris);

/// MPRIS D-Bus constants
const mpris_prefix = "org.mpris.MediaPlayer2.";
const mpris_path = "/org/mpris/MediaPlayer2";
const player_interface = "org.mpris.MediaPlayer2.Player";
const root_interface = "org.mpris.MediaPlayer2";
const dbus_interface = "org.freedesktop.DBus";
const dbus_path = "/org/freedesktop/DBus";
const properties_interface = "org.freedesktop.DBus.Properties";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// Maximum number of tracked players
const max_players = 8;

/// Maximum length for string fields
const max_string_len = 256;

/// Maximum length for service name
const max_service_len = 128;

/// Maximum length for URL fields
const max_url_len = 512;

/// Playback status
pub const PlaybackStatus = enum {
    playing,
    paused,
    stopped,
    unknown,

    pub fn fromString(s: []const u8) PlaybackStatus {
        if (mem.eql(u8, s, "Playing")) return .playing;
        if (mem.eql(u8, s, "Paused")) return .paused;
        if (mem.eql(u8, s, "Stopped")) return .stopped;
        return .unknown;
    }

    pub fn toString(self: PlaybackStatus) []const u8 {
        return switch (self) {
            .playing => "Playing",
            .paused => "Paused",
            .stopped => "Stopped",
            .unknown => "Unknown",
        };
    }
};

/// Loop status
pub const LoopStatus = enum {
    none,
    track,
    playlist,
    unknown,

    pub fn fromString(s: []const u8) LoopStatus {
        if (mem.eql(u8, s, "None")) return .none;
        if (mem.eql(u8, s, "Track")) return .track;
        if (mem.eql(u8, s, "Playlist")) return .playlist;
        return .unknown;
    }
};

/// Media player information
pub const PlayerInfo = struct {
    /// D-Bus service name (e.g., "org.mpris.MediaPlayer2.spotify")
    service: FixedString(max_service_len) = .{},

    /// Player identity (friendly name)
    identity: FixedString(max_string_len) = .{},

    /// Desktop entry name (for icon lookup)
    desktop_entry: FixedString(max_string_len) = .{},

    /// Current playback status
    status: PlaybackStatus = .unknown,

    /// Loop status
    loop_status: LoopStatus = .unknown,

    /// Shuffle enabled
    shuffle: bool = false,

    /// Current track metadata
    title: FixedString(max_string_len) = .{},
    artist: FixedString(max_string_len) = .{},
    album: FixedString(max_string_len) = .{},
    art_url: FixedString(max_url_len) = .{},
    track_id: FixedString(max_url_len) = .{},

    /// Track duration in microseconds
    duration: i64 = 0,

    /// Current position in microseconds
    position: i64 = 0,

    /// Volume (0.0 to 1.0+)
    volume: f64 = 1.0,

    /// Playback rate
    rate: f64 = 1.0,

    /// Player capabilities
    can_control: bool = false,
    can_play: bool = false,
    can_pause: bool = false,
    can_go_next: bool = false,
    can_go_previous: bool = false,
    can_seek: bool = false,

    /// Check if player is currently playing
    pub fn isPlaying(self: *const PlayerInfo) bool {
        return self.status == .playing;
    }

    /// Get short player name (without MPRIS prefix)
    pub fn getShortName(self: *const PlayerInfo) []const u8 {
        const service = self.service.get();
        if (mem.startsWith(u8, service, mpris_prefix)) {
            return service[mpris_prefix.len..];
        }
        return service;
    }

    /// Get duration in seconds
    pub fn getDurationSeconds(self: *const PlayerInfo) f64 {
        if (self.duration <= 0) return 0;
        return @as(f64, @floatFromInt(self.duration)) / 1_000_000.0;
    }

    /// Get position in seconds
    pub fn getPositionSeconds(self: *const PlayerInfo) f64 {
        if (self.position <= 0) return 0;
        return @as(f64, @floatFromInt(self.position)) / 1_000_000.0;
    }

    /// Get progress as percentage (0-100)
    pub fn getProgress(self: *const PlayerInfo) u8 {
        if (self.duration <= 0) return 0;
        const progress = (@as(f64, @floatFromInt(self.position)) / @as(f64, @floatFromInt(self.duration))) * 100.0;
        return @intFromFloat(@min(100.0, @max(0.0, progress)));
    }

    fn clear(self: *PlayerInfo) void {
        self.* = .{};
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscriptions = SubscriberList(StateChangeFn, max_subscribers);
pub const Subscription = Subscriptions.Subscription;

pub const Error = dbus.types.Error || error{
    NoPlayer,
    MethodFailed,
};

pub const Mpris = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    subscriptions: Subscriptions = .{},

    /// Tracked players
    players: [max_players]?PlayerInfo = .{null} ** max_players,
    player_count: usize = 0,

    /// Index of the active (focused) player
    active_player_index: ?usize = null,

    /// Whether initial enumeration has been done
    initialized: bool = false,

    /// Initialize the MPRIS client.
    /// Connects to the session D-Bus.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location
    /// to enable D-Bus signal handling.
    /// Player enumeration is deferred to first process() call to avoid blocking.
    pub fn init(allocator: Allocator) Error!Mpris {
        var conn = try dbus.Connection.open(allocator, .session);
        errdefer conn.deinit();

        return Mpris{
            .connection = conn,
            .allocator = allocator,
        };
    }

    /// Start monitoring for D-Bus signals.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *Mpris) void {
        self.subscribeToNameChanges() catch |err| {
            log.warn("Failed to subscribe to name changes: {s}", .{@errorName(err)});
        };

        self.subscribeToPropertyChanges() catch |err| {
            log.warn("Failed to subscribe to property changes: {s}", .{@errorName(err)});
        };

        self.subscribeToSeeked() catch |err| {
            log.warn("Failed to subscribe to Seeked signal: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *Mpris) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const Mpris) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if there are more messages to process.
    /// On first call, enumerates existing players.
    pub fn process(self: *Mpris) bool {
        // Deferred initialization - enumerate players on first process call
        if (!self.initialized) {
            self.initialized = true;
            self.enumeratePlayers() catch |err| {
                log.warn("Failed to enumerate players: {s}", .{@errorName(err)});
            };
            // Notify subscribers of initial state
            self.notify();
        }
        return self.connection.process();
    }

    pub fn drain(self: *Mpris) void {
        while (self.process()) {}
    }

    /// Get the currently active player.
    pub fn getActivePlayer(self: *const Mpris) ?*const PlayerInfo {
        if (self.active_player_index) |idx| {
            if (idx < max_players) {
                if (self.players[idx]) |*player| {
                    return player;
                }
            }
        }
        return null;
    }

    /// Get all tracked players.
    pub fn getPlayers(self: *const Mpris) []const ?PlayerInfo {
        return self.players[0..self.player_count];
    }

    /// Get player count.
    pub fn getPlayerCount(self: *const Mpris) usize {
        return self.player_count;
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *Mpris, callback: StateChangeFn, context: ?*anyopaque) bool {
        return self.subscriptions.subscribe(callback, context);
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *Mpris, callback: StateChangeFn, context: ?*anyopaque) void {
        self.subscriptions.unsubscribe(callback, context);
    }

    // Playback control methods

    /// Play/Pause toggle on active player.
    pub fn playPause(self: *Mpris) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        try self.callPlayerMethod(player, "PlayPause");
    }

    /// Start playback on active player.
    pub fn play(self: *Mpris) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        try self.callPlayerMethod(player, "Play");
    }

    /// Pause playback on active player.
    pub fn pause(self: *Mpris) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        try self.callPlayerMethod(player, "Pause");
    }

    /// Stop playback on active player.
    pub fn stop(self: *Mpris) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        try self.callPlayerMethod(player, "Stop");
    }

    /// Skip to next track on active player.
    pub fn next(self: *Mpris) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        try self.callPlayerMethod(player, "Next");
    }

    /// Skip to previous track on active player.
    pub fn previous(self: *Mpris) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        try self.callPlayerMethod(player, "Previous");
    }

    /// Seek by offset (microseconds) on active player.
    pub fn seek(self: *Mpris, offset_us: i64) Error!void {
        const player = self.getActivePlayerMut() orelse return Error.NoPlayer;
        _ = offset_us;
        // Note: Seek requires additional D-Bus method call with argument
        // For now, we just call the basic method infrastructure
        try self.callPlayerMethod(player, "Seek");
    }

    /// Set active player by index.
    pub fn setActivePlayer(self: *Mpris, index: usize) bool {
        if (index < self.player_count and self.players[index] != null) {
            self.active_player_index = index;
            return true;
        }
        return false;
    }

    /// Refresh player state from D-Bus.
    pub fn refresh(self: *Mpris) Error!void {
        try self.enumeratePlayers();
    }

    // Internal methods

    fn getActivePlayerMut(self: *Mpris) ?*PlayerInfo {
        if (self.active_player_index) |idx| {
            if (idx < max_players) {
                if (self.players[idx]) |*player| {
                    return player;
                }
            }
        }
        return null;
    }

    fn callPlayerMethod(self: *Mpris, player: *PlayerInfo, method: [:0]const u8) Error!void {
        const service = player.service.getZ();
        var msg = self.connection.callMethod(service, mpris_path, player_interface, method) catch |err| {
            log.warn("Failed to call {s}: {s}", .{ method, @errorName(err) });
            return Error.MethodFailed;
        };
        msg.unref();
    }

    fn enumeratePlayers(self: *Mpris) Error!void {
        // Clear all player slots (not just count) to avoid stale references
        for (&self.players) |*slot| {
            slot.* = null;
        }
        self.player_count = 0;
        self.active_player_index = null;

        // Call org.freedesktop.DBus.ListNames
        var msg = try self.connection.callMethod(dbus_interface, dbus_path, dbus_interface, "ListNames");
        defer msg.unref();

        // Parse array of strings
        if (try msg.enterArray("s")) {
            while (!msg.atEnd() and self.player_count < max_players) {
                const name = msg.readString() catch continue;

                if (mem.startsWith(u8, name, mpris_prefix)) {
                    var player = PlayerInfo{};
                    player.service.set(name);

                    // Get player identity and properties
                    self.refreshPlayerProperties(&player) catch |err| {
                        log.warn("Failed to get properties for {s}: {s}", .{ name, @errorName(err) });
                        continue;
                    };

                    self.players[self.player_count] = player;

                    // Set first playing player as active, or first player
                    if (self.active_player_index == null) {
                        self.active_player_index = self.player_count;
                    } else if (player.status == .playing) {
                        // Switch to this player if it's playing and current isn't
                        if (self.players[self.active_player_index.?]) |current| {
                            if (!current.isPlaying()) {
                                self.active_player_index = self.player_count;
                            }
                        } else {
                            self.active_player_index = self.player_count;
                        }
                    }

                    self.player_count += 1;
                    log.debug("Found player: {s} ({s})", .{ name, player.identity.get() });
                }
            }
            try msg.exitContainer();
        }

        log.info("Found {d} MPRIS player(s)", .{self.player_count});
    }

    fn refreshPlayerProperties(self: *Mpris, player: *PlayerInfo) Error!void {
        const service = player.service.getZ();

        // Get Identity from root interface
        self.readPropertyString(service, root_interface, "Identity", &player.identity);
        self.readPropertyString(service, root_interface, "DesktopEntry", &player.desktop_entry);

        // Get player properties
        self.readPlaybackStatus(service, player);
        self.readPropertyBool(service, player_interface, "CanControl", &player.can_control);
        self.readPropertyBool(service, player_interface, "CanPlay", &player.can_play);
        self.readPropertyBool(service, player_interface, "CanPause", &player.can_pause);
        self.readPropertyBool(service, player_interface, "CanGoNext", &player.can_go_next);
        self.readPropertyBool(service, player_interface, "CanGoPrevious", &player.can_go_previous);
        self.readPropertyBool(service, player_interface, "CanSeek", &player.can_seek);
        self.readPropertyBool(service, player_interface, "Shuffle", &player.shuffle);
        self.readPropertyDouble(service, player_interface, "Volume", &player.volume);
        self.readPropertyDouble(service, player_interface, "Rate", &player.rate);
        self.readPropertyInt64(service, player_interface, "Position", &player.position);

        // Get metadata
        self.readMetadata(service, player);
    }

    fn readPlaybackStatus(self: *Mpris, service: [:0]const u8, player: *PlayerInfo) void {
        var msg = self.connection.getProperty(service, mpris_path, player_interface, "PlaybackStatus") catch return;
        defer msg.unref();

        const status_str = msg.readVariantString() catch return;
        player.status = PlaybackStatus.fromString(status_str);
    }

    fn readMetadata(self: *Mpris, service: [:0]const u8, player: *PlayerInfo) void {
        var msg = self.connection.getProperty(service, mpris_path, player_interface, "Metadata") catch return;
        defer msg.unref();

        // Metadata is a{sv} wrapped in variant
        if (msg.enterVariant("a{sv}") catch false) {
            if (msg.enterArray("{sv}") catch false) {
                while (!msg.atEnd()) {
                    if (msg.enterDictEntry("sv") catch false) {
                        const key = msg.readString() catch {
                            msg.exitContainer() catch {};
                            continue;
                        };

                        self.parseMetadataEntry(&msg, key, player);
                        msg.exitContainer() catch {};
                    }
                }
                msg.exitContainer() catch {};
            }
            msg.exitContainer() catch {};
        }
    }

    fn parseMetadataEntry(self: *Mpris, msg: *dbus.Message, key: []const u8, player: *PlayerInfo) void {
        _ = self;

        // Always skip the variant at the end if we don't consume it
        var consumed = false;

        if (mem.eql(u8, key, "xesam:title")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| player.title.set(val) else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "xesam:artist")) {
            // Artist is array of strings, take first
            if (msg.enterVariant("as") catch false) {
                if (msg.enterArray("s") catch false) {
                    if (msg.readString()) |val| player.artist.set(val) else |_| {}
                    msg.exitContainer() catch {};
                }
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "xesam:album")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| player.album.set(val) else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "mpris:artUrl")) {
            if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| player.art_url.set(val) else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "mpris:trackid")) {
            if (msg.enterVariant("o") catch false) {
                if (msg.readObjectPath()) |val| player.track_id.set(val) else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            } else if (msg.enterVariant("s") catch false) {
                if (msg.readString()) |val| player.track_id.set(val) else |_| {}
                msg.exitContainer() catch {};
                consumed = true;
            }
        } else if (mem.eql(u8, key, "mpris:length")) {
            // Length can be x (int64) or t (uint64) depending on player
            if (msg.enterVariant("x") catch false) {
                player.duration = msg.readInt64() catch 0;
                msg.exitContainer() catch {};
                consumed = true;
            } else if (msg.enterVariant("t") catch false) {
                const val = msg.readUint64() catch 0;
                player.duration = @intCast(@min(val, @as(u64, @intCast(std.math.maxInt(i64)))));
                msg.exitContainer() catch {};
                consumed = true;
            }
        }

        // Skip the variant if we didn't consume it
        if (!consumed) {
            msg.skip("v") catch {};
        }
    }

    fn readPropertyString(self: *Mpris, service: [:0]const u8, interface: [:0]const u8, prop: [:0]const u8, out: anytype) void {
        var msg = self.connection.getProperty(service, mpris_path, interface, prop) catch return;
        defer msg.unref();

        if (msg.readVariantString()) |val| out.set(val) else |_| {}
    }

    fn readPropertyBool(self: *Mpris, service: [:0]const u8, interface: [:0]const u8, prop: [:0]const u8, out: *bool) void {
        var msg = self.connection.getProperty(service, mpris_path, interface, prop) catch return;
        defer msg.unref();

        out.* = msg.readVariantBool() catch false;
    }

    fn readPropertyDouble(self: *Mpris, service: [:0]const u8, interface: [:0]const u8, prop: [:0]const u8, out: *f64) void {
        var msg = self.connection.getProperty(service, mpris_path, interface, prop) catch return;
        defer msg.unref();

        out.* = msg.readVariantDouble() catch 1.0;
    }

    fn readPropertyInt64(self: *Mpris, service: [:0]const u8, interface: [:0]const u8, prop: [:0]const u8, out: *i64) void {
        var msg = self.connection.getProperty(service, mpris_path, interface, prop) catch return;
        defer msg.unref();

        out.* = msg.readVariantInt64() catch 0;
    }

    fn subscribeToNameChanges(self: *Mpris) Error!void {
        // Subscribe to NameOwnerChanged to detect player start/stop
        const match_rule =
            "type='signal'," ++
            "interface='org.freedesktop.DBus'," ++
            "member='NameOwnerChanged'," ++
            "arg0namespace='org.mpris.MediaPlayer2'";

        try self.connection.subscribeMatch(match_rule, handleNameOwnerChanged, self);
    }

    fn subscribeToPropertyChanges(self: *Mpris) Error!void {
        // Subscribe to PropertiesChanged on MPRIS player paths
        const match_rule =
            "type='signal'," ++
            "interface='org.freedesktop.DBus.Properties'," ++
            "member='PropertiesChanged'," ++
            "path='/org/mpris/MediaPlayer2'";

        try self.connection.subscribeMatch(match_rule, handlePropertyChanged, self);
    }

    fn subscribeToSeeked(self: *Mpris) Error!void {
        // Subscribe to Seeked signal
        const match_rule =
            "type='signal'," ++
            "interface='org.mpris.MediaPlayer2.Player'," ++
            "member='Seeked'";

        try self.connection.subscribeMatch(match_rule, handleSeeked, self);
    }

    fn handleNameOwnerChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *Mpris = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;

        // Player added or removed - re-enumerate
        self.enumeratePlayers() catch {};
        self.notify();
    }

    fn handlePropertyChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *Mpris = @ptrCast(@alignCast(ctx orelse return));

        // Get sender to find which player changed
        const sender = msg.getSender() orelse return;

        // Find player by checking which one's service name resolves to this sender
        // For simplicity, refresh all players on property change
        for (self.players[0..self.player_count]) |*slot| {
            if (slot.*) |*player| {
                self.refreshPlayerProperties(player) catch {};
            }
        }

        _ = sender;
        self.updateActivePlayer();
        self.notify();
    }

    fn handleSeeked(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *Mpris = @ptrCast(@alignCast(ctx orelse return));

        var mutable_msg = msg;
        const new_position = mutable_msg.readInt64() catch return;

        // Update position on active player
        if (self.getActivePlayerMut()) |player| {
            player.position = new_position;
        }

        self.notify();
    }

    fn updateActivePlayer(self: *Mpris) void {
        // If current active player is no longer playing, switch to one that is
        if (self.active_player_index) |idx| {
            if (self.players[idx]) |p| {
                if (p.status == .playing) return; // Keep current
            }
        }

        // Find a playing player
        for (self.players, 0..) |maybe_player, i| {
            if (maybe_player) |player| {
                if (player.status == .playing) {
                    self.active_player_index = i;
                    return;
                }
            }
        }
    }

    fn notify(self: *const Mpris) void {
        self.subscriptions.notify();
    }
};

// Tests

test "Mpris types compile" {
    _ = Mpris;
    _ = PlayerInfo;
    _ = PlaybackStatus;
    _ = LoopStatus;
    _ = StateChangeFn;
}

test "PlaybackStatus fromString" {
    const testing = std.testing;

    try testing.expectEqual(PlaybackStatus.playing, PlaybackStatus.fromString("Playing"));
    try testing.expectEqual(PlaybackStatus.paused, PlaybackStatus.fromString("Paused"));
    try testing.expectEqual(PlaybackStatus.stopped, PlaybackStatus.fromString("Stopped"));
    try testing.expectEqual(PlaybackStatus.unknown, PlaybackStatus.fromString("Other"));
}

test "LoopStatus fromString" {
    const testing = std.testing;

    try testing.expectEqual(LoopStatus.none, LoopStatus.fromString("None"));
    try testing.expectEqual(LoopStatus.track, LoopStatus.fromString("Track"));
    try testing.expectEqual(LoopStatus.playlist, LoopStatus.fromString("Playlist"));
    try testing.expectEqual(LoopStatus.unknown, LoopStatus.fromString("Other"));
}

test "PlayerInfo default values" {
    const testing = std.testing;

    const player = PlayerInfo{};
    try testing.expect(player.service.isEmpty());
    try testing.expectEqual(PlaybackStatus.unknown, player.status);
    try testing.expect(!player.isPlaying());
    try testing.expectEqual(@as(i64, 0), player.duration);
    try testing.expectEqual(@as(u8, 0), player.getProgress());
}

test "PlayerInfo progress calculation" {
    const testing = std.testing;

    var player = PlayerInfo{};
    player.duration = 300_000_000; // 300 seconds
    player.position = 150_000_000; // 150 seconds

    try testing.expectEqual(@as(u8, 50), player.getProgress());
    try testing.expectApproxEqAbs(@as(f64, 300.0), player.getDurationSeconds(), 0.001);
    try testing.expectApproxEqAbs(@as(f64, 150.0), player.getPositionSeconds(), 0.001);
}

test "PlayerInfo getShortName" {
    const testing = std.testing;

    var player = PlayerInfo{};
    player.service.set("org.mpris.MediaPlayer2.spotify");

    try testing.expectEqualStrings("spotify", player.getShortName());
}

test "FixedString operations" {
    const testing = std.testing;

    var s = FixedString(32){};
    try testing.expect(s.isEmpty());

    s.set("test value");
    try testing.expectEqualStrings("test value", s.get());
    try testing.expect(!s.isEmpty());

    s.clear();
    try testing.expect(s.isEmpty());
}
