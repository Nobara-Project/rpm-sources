//! StatusNotifierWatcher D-Bus Service
//!
//! Implements the org.kde.StatusNotifierWatcher specification.
//! Hosts a D-Bus service that tracks StatusNotifierItem registrations.
//! Uses sd_bus_add_object for pure-Zig message dispatch (no C vtable).
//!
//! D-Bus Service: org.kde.StatusNotifierWatcher
//! Object Path: /StatusNotifierWatcher

const std = @import("std");
const mem = std.mem;
const Allocator = std.mem.Allocator;
const posix = std.posix;
const SubscriberList = @import("otter_utils").SubscriberList;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
    const c = types.c;
};

const log = std.log.scoped(.snw);

/// D-Bus constants
const watcher_service = "org.kde.StatusNotifierWatcher";
const watcher_path = "/StatusNotifierWatcher";
const watcher_interface = "org.kde.StatusNotifierWatcher";
const properties_interface = "org.freedesktop.DBus.Properties";
const dbus_interface = "org.freedesktop.DBus";

/// Maximum tracked items
const max_items = 32;

/// Maximum length for service/path/id strings
const max_id_len = 256;

/// Maximum state change subscribers
const max_subscribers = 8;

/// A registered StatusNotifierItem
pub const RegisteredItem = struct {
    service: [max_id_len]u8 = undefined,
    service_len: usize = 0,
    path: [max_id_len]u8 = undefined,
    path_len: usize = 0,
    /// Combined "service/path" identifier
    id: [max_id_len * 2 + 1]u8 = undefined,
    id_len: usize = 0,

    pub fn getService(self: *const RegisteredItem) []const u8 {
        return self.service[0..self.service_len];
    }

    pub fn getPath(self: *const RegisteredItem) []const u8 {
        return self.path[0..self.path_len];
    }

    pub fn getId(self: *const RegisteredItem) []const u8 {
        return self.id[0..self.id_len];
    }

    /// Get null-terminated service name for D-Bus calls.
    pub fn getServiceZ(self: *RegisteredItem) [*:0]const u8 {
        if (self.service_len < max_id_len) {
            self.service[self.service_len] = 0;
            return self.service[0..self.service_len :0];
        }
        self.service[max_id_len - 1] = 0;
        return self.service[0 .. max_id_len - 1 :0];
    }

    /// Get null-terminated id for signal emission.
    pub fn getIdZ(self: *RegisteredItem) [*:0]const u8 {
        if (self.id_len < max_id_len * 2 + 1) {
            self.id[self.id_len] = 0;
            return self.id[0..self.id_len :0];
        }
        self.id[max_id_len * 2] = 0;
        return self.id[0 .. max_id_len * 2 :0];
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscriptions = SubscriberList(StateChangeFn, max_subscribers);
pub const Subscription = Subscriptions.Subscription;

pub const Error = dbus.types.Error || error{
    WatcherFull,
};

pub const StatusNotifierWatcher = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    items: [max_items]?RegisteredItem = .{null} ** max_items,
    item_count: usize = 0,
    subscriptions: Subscriptions = .{},
    initialized: bool = false,
    is_host: bool = false,

    /// Initialize the watcher.
    /// Connects to the session D-Bus and requests the well-known name.
    /// Call `startMonitoring()` AFTER the struct is in its final memory location.
    pub fn init(allocator: Allocator) Error!StatusNotifierWatcher {
        var conn = try dbus.Connection.open(allocator, .session);
        errdefer conn.deinit();

        return StatusNotifierWatcher{
            .connection = conn,
            .allocator = allocator,
        };
    }

    /// Start monitoring — register object, request name, subscribe to NameOwnerChanged.
    /// MUST be called after the struct is in its final memory location.
    /// If another process owns the watcher name, falls back to client mode.
    pub fn startMonitoring(self: *StatusNotifierWatcher) void {
        // Try to become the watcher host
        self.connection.requestName(watcher_service) catch {
            // Another process owns the name — fall back to client mode
            log.info("Another watcher owns {s}, using client mode", .{watcher_service});
            self.is_host = false;
            self.startClientMode();
            return;
        };

        // Host mode — we own the name
        self.is_host = true;

        // Register object handler for incoming method calls
        self.connection.addObject(watcher_path, handleMessage, self) catch |err| {
            log.err("Failed to register watcher object: {s}", .{@errorName(err)});
            return;
        };

        // Subscribe to NameOwnerChanged to detect item disappearance
        self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus'," ++
                "member='NameOwnerChanged'",
            handleNameOwnerChanged,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to NameOwnerChanged: {s}", .{@errorName(err)});
        };

        // Emit StatusNotifierHostRegistered to tell items we're ready
        self.connection.emitSignal(watcher_path, watcher_interface, "StatusNotifierHostRegistered") catch |err| {
            log.warn("Failed to emit StatusNotifierHostRegistered: {s}", .{@errorName(err)});
        };

        log.info("StatusNotifierWatcher started (host mode)", .{});
    }

    /// Client fallback mode — subscribe to the existing watcher's signals and query its items.
    fn startClientMode(self: *StatusNotifierWatcher) void {
        // Subscribe to NameOwnerChanged to detect item disappearance
        self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus'," ++
                "member='NameOwnerChanged'",
            handleNameOwnerChanged,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to NameOwnerChanged: {s}", .{@errorName(err)});
        };

        // Subscribe to StatusNotifierItemRegistered from the existing watcher
        self.connection.subscribeMatch(
            "type='signal'," ++
                "sender='org.kde.StatusNotifierWatcher'," ++
                "interface='org.kde.StatusNotifierWatcher'," ++
                "member='StatusNotifierItemRegistered'",
            handleExternalItemRegistered,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to ItemRegistered: {s}", .{@errorName(err)});
        };

        // Subscribe to StatusNotifierItemUnregistered from the existing watcher
        self.connection.subscribeMatch(
            "type='signal'," ++
                "sender='org.kde.StatusNotifierWatcher'," ++
                "interface='org.kde.StatusNotifierWatcher'," ++
                "member='StatusNotifierItemUnregistered'",
            handleExternalItemUnregistered,
            self,
        ) catch |err| {
            log.warn("Failed to subscribe to ItemUnregistered: {s}", .{@errorName(err)});
        };

        // Query existing items from the watcher
        self.queryExistingItems();

        log.info("StatusNotifierWatcher started (client mode)", .{});
    }

    /// Query the existing watcher for its RegisteredStatusNotifierItems property.
    fn queryExistingItems(self: *StatusNotifierWatcher) void {
        var reply = self.connection.getProperty(
            watcher_service,
            watcher_path,
            watcher_interface,
            "RegisteredStatusNotifierItems",
        ) catch |err| {
            log.warn("Failed to query existing items: {s}", .{@errorName(err)});
            return;
        };
        defer reply.unref();

        // Response: variant(array of string) -> v -> as -> s...
        if (!(reply.enterVariant("as") catch return)) return;
        if (!(reply.enterArray("s") catch return)) {
            reply.exitContainer() catch {};
            return;
        }

        while (!reply.atEnd()) {
            const item_id = reply.readString() catch break;
            self.addItemFromId(item_id);
        }

        reply.exitContainer() catch {};
        reply.exitContainer() catch {};
    }

    /// Parse an item ID string ("service/path" or plain bus name) and add it.
    fn addItemFromId(self: *StatusNotifierWatcher, item_id: []const u8) void {
        if (item_id.len == 0) return;

        var item = RegisteredItem{};

        // Parse "service/path" format — find first '/' after the bus name
        // Bus names start with ':' (unique) or a letter (well-known), paths start with '/'
        // So look for '/' that starts an object path
        if (mem.indexOfScalar(u8, item_id, '/')) |slash_pos| {
            const svc = item_id[0..slash_pos];
            const pth = item_id[slash_pos..];
            const s_len = @min(svc.len, max_id_len);
            @memcpy(item.service[0..s_len], svc[0..s_len]);
            item.service_len = s_len;
            const p_len = @min(pth.len, max_id_len);
            @memcpy(item.path[0..p_len], pth[0..p_len]);
            item.path_len = p_len;
        } else {
            // Just a bus name, use default path
            const sni_path = "/StatusNotifierItem";
            const s_len = @min(item_id.len, max_id_len);
            @memcpy(item.service[0..s_len], item_id[0..s_len]);
            item.service_len = s_len;
            @memcpy(item.path[0..sni_path.len], sni_path);
            item.path_len = sni_path.len;
        }

        // Build combined id: "service/path"
        const svc = item.getService();
        const pth = item.getPath();
        const total_len = @min(svc.len + 1 + pth.len, max_id_len * 2 + 1);
        @memcpy(item.id[0..svc.len], svc);
        if (svc.len < max_id_len * 2) {
            item.id[svc.len] = '/';
            const remaining = total_len -| (svc.len + 1);
            @memcpy(item.id[svc.len + 1 ..][0..remaining], pth[0..remaining]);
        }
        item.id_len = total_len;

        // Check for duplicate
        for (self.items) |maybe_item| {
            if (maybe_item) |existing| {
                if (mem.eql(u8, existing.getId(), item.getId())) return;
            }
        }

        // Find empty slot
        for (&self.items) |*slot| {
            if (slot.* == null) {
                slot.* = item;
                self.item_count += 1;
                log.info("Registered item (client): {s}", .{item.getId()});
                self.notify();
                return;
            }
        }

        log.warn("Watcher full, cannot register item", .{});
    }

    fn handleExternalItemRegistered(msg_wrapped: dbus.Message, ctx: ?*anyopaque) void {
        const self: *StatusNotifierWatcher = @ptrCast(@alignCast(ctx orelse return));
        var msg = msg_wrapped;
        const item_id = msg.readString() catch return;
        self.addItemFromId(item_id);
    }

    fn handleExternalItemUnregistered(msg_wrapped: dbus.Message, ctx: ?*anyopaque) void {
        const self: *StatusNotifierWatcher = @ptrCast(@alignCast(ctx orelse return));
        var msg = msg_wrapped;
        const item_id = msg.readString() catch return;

        if (item_id.len == 0) return;

        var removed = false;
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                if (mem.eql(u8, item.getId(), item_id) or
                    mem.eql(u8, item.getService(), item_id))
                {
                    log.info("Item unregistered (client): {s}", .{item.getId()});
                    slot.* = null;
                    self.item_count -|= 1;
                    removed = true;
                    break;
                }
            }
        }
        if (removed) self.notify();
    }

    pub fn deinit(self: *StatusNotifierWatcher) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const StatusNotifierWatcher) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    pub fn process(self: *StatusNotifierWatcher) bool {
        return self.connection.process();
    }

    pub fn drain(self: *StatusNotifierWatcher) void {
        self.connection.drain();
    }

    /// Get registered items.
    pub fn getItems(self: *const StatusNotifierWatcher) []const ?RegisteredItem {
        return &self.items;
    }

    /// Get number of registered items.
    pub fn getItemCount(self: *const StatusNotifierWatcher) usize {
        return self.item_count;
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *StatusNotifierWatcher, callback: StateChangeFn, context: ?*anyopaque) bool {
        return self.subscriptions.subscribe(callback, context);
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *StatusNotifierWatcher, callback: StateChangeFn, context: ?*anyopaque) void {
        self.subscriptions.unsubscribe(callback, context);
    }

    // --- Message dispatch (replaces C vtable) ---

    fn handleMessage(
        msg: ?*dbus.c.sd_bus_message,
        userdata: ?*anyopaque,
        _: [*c]dbus.c.sd_bus_error,
    ) callconv(.c) c_int {
        const self: *StatusNotifierWatcher = @ptrCast(@alignCast(userdata orelse return 0));
        var wrapped = dbus.Message.wrap(msg orelse return 0);
        const iface = wrapped.getInterface() orelse return 0;
        const member_name = wrapped.getMember() orelse return 0;

        if (mem.eql(u8, iface, watcher_interface)) {
            if (mem.eql(u8, member_name, "RegisterStatusNotifierItem"))
                return self.handleRegisterItem(msg.?, &wrapped);
            // RegisterStatusNotifierHost — accept but we are the host
            if (mem.eql(u8, member_name, "RegisterStatusNotifierHost"))
                return dbus.Connection.replyMethodReturn(msg.?);
        } else if (mem.eql(u8, iface, properties_interface)) {
            if (mem.eql(u8, member_name, "Get"))
                return self.handlePropertyGet(msg.?, &wrapped);
            if (mem.eql(u8, member_name, "GetAll"))
                return self.handlePropertyGetAll(msg.?, &wrapped);
        }

        return 0; // Not handled
    }

    fn handleRegisterItem(self: *StatusNotifierWatcher, raw: *dbus.c.sd_bus_message, msg: *dbus.Message) c_int {
        const arg = msg.readString() catch return -1;
        const sender = msg.getSender() orelse return -1;

        // Determine service and path from the argument
        var item = RegisteredItem{};

        if (arg.len > 0 and arg[0] == '/') {
            // Argument is an object path — service is the sender
            const s_len = @min(sender.len, max_id_len);
            @memcpy(item.service[0..s_len], sender[0..s_len]);
            item.service_len = s_len;
            const p_len = @min(arg.len, max_id_len);
            @memcpy(item.path[0..p_len], arg[0..p_len]);
            item.path_len = p_len;
        } else {
            // Argument is a bus name — path is /StatusNotifierItem
            const sni_path = "/StatusNotifierItem";
            const name = if (arg.len > 0) arg else sender;
            const s_len = @min(name.len, max_id_len);
            @memcpy(item.service[0..s_len], name[0..s_len]);
            item.service_len = s_len;
            @memcpy(item.path[0..sni_path.len], sni_path);
            item.path_len = sni_path.len;
        }

        // Build combined id: "service/path"
        const svc = item.getService();
        const pth = item.getPath();
        const total_len = @min(svc.len + 1 + pth.len, max_id_len * 2 + 1);
        @memcpy(item.id[0..svc.len], svc);
        if (svc.len < max_id_len * 2) {
            item.id[svc.len] = '/';
            const remaining = total_len -| (svc.len + 1);
            @memcpy(item.id[svc.len + 1 ..][0..remaining], pth[0..remaining]);
        }
        item.id_len = total_len;

        // Check for duplicate
        for (self.items) |maybe_item| {
            if (maybe_item) |existing| {
                if (mem.eql(u8, existing.getId(), item.getId())) {
                    // Already registered
                    return dbus.Connection.replyMethodReturn(raw);
                }
            }
        }

        // Find empty slot
        var added = false;
        for (&self.items) |*slot| {
            if (slot.* == null) {
                slot.* = item;
                self.item_count += 1;
                added = true;
                break;
            }
        }

        if (!added) {
            log.warn("Watcher full, cannot register item", .{});
            return dbus.Connection.replyMethodReturn(raw);
        }

        log.info("Registered item: {s}", .{item.getId()});

        // Emit StatusNotifierItemRegistered signal
        self.connection.emitSignalWithString(
            watcher_path,
            watcher_interface,
            "StatusNotifierItemRegistered",
            item.getIdZ(),
        ) catch {};

        self.notify();
        return dbus.Connection.replyMethodReturn(raw);
    }

    fn handlePropertyGet(self: *StatusNotifierWatcher, raw: *dbus.c.sd_bus_message, msg: *dbus.Message) c_int {
        const req_iface = msg.readString() catch return -1;
        const prop_name = msg.readString() catch return -1;
        if (!mem.eql(u8, req_iface, watcher_interface)) return 0;

        var reply = dbus.Connection.newMethodReturn(raw) catch return -1;
        defer reply.unref();

        if (mem.eql(u8, prop_name, "RegisteredStatusNotifierItems")) {
            reply.openContainer('v', "as") catch return -1;
            reply.openContainer('a', "s") catch return -1;
            for (&self.items) |*slot| {
                if (slot.*) |*item| {
                    reply.appendString(item.getIdZ()) catch return -1;
                }
            }
            reply.closeContainer() catch return -1;
            reply.closeContainer() catch return -1;
        } else if (mem.eql(u8, prop_name, "IsStatusNotifierHostRegistered")) {
            reply.openContainer('v', "b") catch return -1;
            reply.appendBool(true) catch return -1;
            reply.closeContainer() catch return -1;
        } else if (mem.eql(u8, prop_name, "ProtocolVersion")) {
            reply.openContainer('v', "i") catch return -1;
            reply.appendInt32(0) catch return -1;
            reply.closeContainer() catch return -1;
        } else {
            return 0;
        }

        self.connection.send(&reply) catch return -1;
        return 1;
    }

    fn handlePropertyGetAll(self: *StatusNotifierWatcher, raw: *dbus.c.sd_bus_message, msg: *dbus.Message) c_int {
        const req_iface = msg.readString() catch return -1;
        if (!mem.eql(u8, req_iface, watcher_interface)) return 0;

        var reply = dbus.Connection.newMethodReturn(raw) catch return -1;
        defer reply.unref();

        // Open a{sv}
        reply.openContainer('a', "{sv}") catch return -1;

        // RegisteredStatusNotifierItems
        reply.openContainer('e', "sv") catch return -1;
        reply.appendString("RegisteredStatusNotifierItems") catch return -1;
        reply.openContainer('v', "as") catch return -1;
        reply.openContainer('a', "s") catch return -1;
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                reply.appendString(item.getIdZ()) catch return -1;
            }
        }
        reply.closeContainer() catch return -1;
        reply.closeContainer() catch return -1;
        reply.closeContainer() catch return -1;

        // IsStatusNotifierHostRegistered
        reply.openContainer('e', "sv") catch return -1;
        reply.appendString("IsStatusNotifierHostRegistered") catch return -1;
        reply.openContainer('v', "b") catch return -1;
        reply.appendBool(true) catch return -1;
        reply.closeContainer() catch return -1;
        reply.closeContainer() catch return -1;

        // ProtocolVersion
        reply.openContainer('e', "sv") catch return -1;
        reply.appendString("ProtocolVersion") catch return -1;
        reply.openContainer('v', "i") catch return -1;
        reply.appendInt32(0) catch return -1;
        reply.closeContainer() catch return -1;
        reply.closeContainer() catch return -1;

        // Close a{sv}
        reply.closeContainer() catch return -1;

        self.connection.send(&reply) catch return -1;
        return 1;
    }

    fn handleNameOwnerChanged(msg_wrapped: dbus.Message, ctx: ?*anyopaque) void {
        const self: *StatusNotifierWatcher = @ptrCast(@alignCast(ctx orelse return));
        var msg = msg_wrapped;

        // NameOwnerChanged(s name, s old_owner, s new_owner)
        const name = msg.readString() catch return;
        _ = msg.readString() catch return; // old_owner
        const new_owner = msg.readString() catch return;

        // If new_owner is empty, the name disappeared — remove matching items
        if (new_owner.len == 0) {
            var removed = false;
            for (&self.items) |*slot| {
                if (slot.*) |*item| {
                    if (mem.eql(u8, item.getService(), name)) {
                        log.info("Item vanished: {s}", .{item.getId()});

                        // Only emit signals when we are the host
                        if (self.is_host) {
                            self.connection.emitSignalWithString(
                                watcher_path,
                                watcher_interface,
                                "StatusNotifierItemUnregistered",
                                item.getIdZ(),
                            ) catch {};
                        }

                        slot.* = null;
                        self.item_count -|= 1;
                        removed = true;
                    }
                }
            }
            if (removed) self.notify();
        }
    }

    /// Remove an item by service name.
    pub fn removeItem(self: *StatusNotifierWatcher, service_name: []const u8) bool {
        for (&self.items) |*slot| {
            if (slot.*) |*item| {
                if (mem.eql(u8, item.getService(), service_name)) {
                    // Only emit signals when we are the host
                    if (self.is_host) {
                        self.connection.emitSignalWithString(
                            watcher_path,
                            watcher_interface,
                            "StatusNotifierItemUnregistered",
                            item.getIdZ(),
                        ) catch {};
                    }

                    slot.* = null;
                    self.item_count -|= 1;
                    self.notify();
                    return true;
                }
            }
        }
        return false;
    }

    fn notify(self: *const StatusNotifierWatcher) void {
        self.subscriptions.notify();
    }
};

// Tests

test "StatusNotifierWatcher types compile" {
    _ = StatusNotifierWatcher;
    _ = RegisteredItem;
    _ = StateChangeFn;
    _ = Subscription;
}

test "RegisteredItem field operations" {
    const testing = std.testing;

    var item = RegisteredItem{};
    try testing.expectEqual(@as(usize, 0), item.service_len);
    try testing.expectEqual(@as(usize, 0), item.path_len);
    try testing.expectEqual(@as(usize, 0), item.id_len);

    // Set service
    const svc = ":1.42";
    @memcpy(item.service[0..svc.len], svc);
    item.service_len = svc.len;
    try testing.expectEqualStrings(":1.42", item.getService());

    // Set path
    const path = "/StatusNotifierItem";
    @memcpy(item.path[0..path.len], path);
    item.path_len = path.len;
    try testing.expectEqualStrings("/StatusNotifierItem", item.getPath());

    // Set id
    const id = ":1.42//StatusNotifierItem";
    @memcpy(item.id[0..id.len], id);
    item.id_len = id.len;
    try testing.expectEqualStrings(":1.42//StatusNotifierItem", item.getId());
}

test "StatusNotifierWatcher default state" {
    const testing = std.testing;

    // Verify default field values without opening a D-Bus connection
    const items: [max_items]?RegisteredItem = .{null} ** max_items;
    try testing.expectEqual(@as(usize, 0), countItems(&items));
}

fn countItems(items: []const ?RegisteredItem) usize {
    var count: usize = 0;
    for (items) |item| {
        if (item != null) count += 1;
    }
    return count;
}

test "addItemFromId parses service/path format" {
    const testing = std.testing;

    // Simulate what addItemFromId does for "service/path" format
    var item = RegisteredItem{};
    const item_id = ":1.42/StatusNotifierItem";

    if (mem.indexOfScalar(u8, item_id, '/')) |slash_pos| {
        const svc = item_id[0..slash_pos];
        const pth = item_id[slash_pos..];
        @memcpy(item.service[0..svc.len], svc);
        item.service_len = svc.len;
        @memcpy(item.path[0..pth.len], pth);
        item.path_len = pth.len;
    }

    try testing.expectEqualStrings(":1.42", item.getService());
    try testing.expectEqualStrings("/StatusNotifierItem", item.getPath());
}

test "addItemFromId parses plain bus name" {
    const testing = std.testing;

    // Simulate what addItemFromId does for a plain bus name (no slash)
    var item = RegisteredItem{};
    const item_id = ":1.99";
    const sni_path = "/StatusNotifierItem";

    if (mem.indexOfScalar(u8, item_id, '/') == null) {
        @memcpy(item.service[0..item_id.len], item_id);
        item.service_len = item_id.len;
        @memcpy(item.path[0..sni_path.len], sni_path);
        item.path_len = sni_path.len;
    }

    try testing.expectEqualStrings(":1.99", item.getService());
    try testing.expectEqualStrings("/StatusNotifierItem", item.getPath());
}

test "addItemFromId builds combined id" {
    const testing = std.testing;

    var item = RegisteredItem{};
    const svc = ":1.42";
    const pth = "/StatusNotifierItem";

    @memcpy(item.service[0..svc.len], svc);
    item.service_len = svc.len;
    @memcpy(item.path[0..pth.len], pth);
    item.path_len = pth.len;

    // Build combined id: "service/path"
    const total_len = @min(svc.len + 1 + pth.len, max_id_len * 2 + 1);
    @memcpy(item.id[0..svc.len], svc);
    item.id[svc.len] = '/';
    const remaining = total_len -| (svc.len + 1);
    @memcpy(item.id[svc.len + 1 ..][0..remaining], pth[0..remaining]);
    item.id_len = total_len;

    try testing.expectEqualStrings(":1.42//StatusNotifierItem", item.getId());
}
