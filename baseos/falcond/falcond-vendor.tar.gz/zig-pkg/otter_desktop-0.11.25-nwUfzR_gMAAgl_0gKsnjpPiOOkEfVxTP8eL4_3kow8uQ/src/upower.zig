//! UPower D-Bus Client
//!
//! Provides access to UPower daemon for battery status monitoring.
//! Uses D-Bus to communicate with the UPower service on the system bus.
//!
//! D-Bus Service: org.freedesktop.UPower
//! Device Interface: org.freedesktop.UPower.Device

const std = @import("std");
const Allocator = std.mem.Allocator;
const posix = std.posix;
const SubscriberList = @import("otter_utils").SubscriberList;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.upower);

/// D-Bus service constants
const service = "org.freedesktop.UPower";
const upower_path = "/org/freedesktop/UPower";
const upower_interface = "org.freedesktop.UPower";
const device_interface = "org.freedesktop.UPower.Device";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// Maximum number of battery devices tracked
const max_devices = 4;

/// Maximum length of device object paths
const max_path_len = 128;

/// UPower device type enumeration
pub const DeviceType = enum(u32) {
    unknown = 0,
    line_power = 1,
    battery = 2,
    ups = 3,
    monitor = 4,
    mouse = 5,
    keyboard = 6,
    pda = 7,
    phone = 8,
    media_player = 9,
    tablet = 10,
    computer = 11,
    gaming_input = 12,
    pen = 13,
    touchpad = 14,
    modem = 15,
    network = 16,
    headset = 17,
    speakers = 18,
    headphones = 19,
    video = 20,
    other_audio = 21,
    remote_control = 22,
    printer = 23,
    scanner = 24,
    camera = 25,
    wearable = 26,
    toy = 27,
    bluetooth_generic = 28,
    _,

    pub fn fromInt(val: u32) DeviceType {
        return @enumFromInt(val);
    }
};

/// UPower device state enumeration
pub const DeviceState = enum(u32) {
    unknown = 0,
    charging = 1,
    discharging = 2,
    empty = 3,
    fully_charged = 4,
    pending_charge = 5,
    pending_discharge = 6,
    _,

    pub fn fromInt(val: u32) DeviceState {
        return @enumFromInt(val);
    }

    pub fn toString(self: DeviceState) []const u8 {
        return switch (self) {
            .unknown => "Unknown",
            .charging => "Charging",
            .discharging => "Discharging",
            .empty => "Empty",
            .fully_charged => "Full",
            .pending_charge => "Pending Charge",
            .pending_discharge => "Pending Discharge",
            _ => "Unknown",
        };
    }
};

/// UPower warning level enumeration
pub const WarningLevel = enum(u32) {
    unknown = 0,
    none = 1,
    discharging = 2,
    low = 3,
    critical = 4,
    action = 5,
    _,

    pub fn fromInt(val: u32) WarningLevel {
        return @enumFromInt(val);
    }
};

/// Battery device information
pub const BatteryInfo = struct {
    /// Object path on D-Bus
    path: [max_path_len]u8 = undefined,
    path_len: usize = 0,

    /// Device type (should be .battery)
    device_type: DeviceType = .unknown,

    /// Current state (charging, discharging, etc.)
    state: DeviceState = .unknown,

    /// Charge percentage (0-100)
    percentage: f64 = 0,

    /// Energy currently available (Wh)
    energy: f64 = 0,

    /// Energy when fully charged (Wh)
    energy_full: f64 = 0,

    /// Design capacity when new (Wh)
    energy_full_design: f64 = 0,

    /// Charge/discharge rate (W)
    energy_rate: f64 = 0,

    /// Seconds until empty (0 if charging/unknown)
    time_to_empty: i64 = 0,

    /// Seconds until full (0 if discharging/unknown)
    time_to_full: i64 = 0,

    /// Current voltage
    voltage: f64 = 0,

    /// Temperature in Celsius
    temperature: f64 = 0,

    /// Battery health/capacity (percentage of design capacity)
    capacity: f64 = 100,

    /// Warning level from UPower
    warning_level: WarningLevel = .none,

    /// Whether the battery is present
    is_present: bool = true,

    /// Whether it's the power supply for the system
    is_power_supply: bool = true,

    /// Number of charge cycles (-1 if unknown)
    charge_cycles: i32 = -1,

    /// Vendor name
    vendor: [64]u8 = undefined,
    vendor_len: usize = 0,

    /// Model name
    model: [64]u8 = undefined,
    model_len: usize = 0,

    pub fn getPath(self: *const BatteryInfo) []const u8 {
        return self.path[0..self.path_len];
    }

    pub fn getVendor(self: *const BatteryInfo) []const u8 {
        return self.vendor[0..self.vendor_len];
    }

    pub fn getModel(self: *const BatteryInfo) []const u8 {
        return self.model[0..self.model_len];
    }

    /// Get percentage as integer (0-100)
    pub fn getPercentage(self: *const BatteryInfo) u8 {
        return @intFromFloat(@min(100, @max(0, self.percentage)));
    }

    /// Get formatted time remaining string
    pub fn formatTimeRemaining(self: *const BatteryInfo, buf: []u8) []const u8 {
        const seconds = if (self.state == .charging) self.time_to_full else self.time_to_empty;
        if (seconds <= 0) return "";

        const hours = @divTrunc(seconds, 3600);
        const minutes = @divTrunc(@mod(seconds, 3600), 60);

        if (hours > 0) {
            return std.fmt.bufPrint(buf, "{d}h {d}m", .{ hours, minutes }) catch "";
        } else {
            return std.fmt.bufPrint(buf, "{d}m", .{minutes}) catch "";
        }
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscriptions = SubscriberList(StateChangeFn, max_subscribers);
pub const Subscription = Subscriptions.Subscription;

pub const Error = dbus.types.Error || error{
    NoBattery,
    ParseError,
};

pub const UPower = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    subscriptions: Subscriptions = .{},

    /// Tracked battery devices
    batteries: [max_devices]?BatteryInfo = .{null} ** max_devices,
    battery_count: usize = 0,

    /// System-wide state
    on_battery: bool = false,
    lid_is_closed: bool = false,
    lid_is_present: bool = false,

    /// Initialize the UPower client.
    /// Connects to the system D-Bus.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location
    /// to enable D-Bus signal handling.
    pub fn init(allocator: Allocator) Error!UPower {
        var conn = try dbus.Connection.open(allocator, .system);
        errdefer conn.deinit();

        var self = UPower{
            .connection = conn,
            .allocator = allocator,
        };

        // Load initial state
        self.refresh() catch |err| {
            log.warn("Failed to load initial state: {s}", .{@errorName(err)});
        };

        return self;
    }

    /// Start monitoring for D-Bus property changes.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *UPower) void {
        self.subscribeToPropertyChanges() catch |err| {
            log.warn("Failed to subscribe to property changes: {s}", .{@errorName(err)});
        };

        self.subscribeToDeviceChanges() catch |err| {
            log.warn("Failed to subscribe to device changes: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *UPower) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const UPower) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if there are more messages to process.
    pub fn process(self: *UPower) bool {
        return self.connection.process();
    }

    pub fn drain(self: *UPower) void {
        self.connection.drain();
    }

    /// Get the primary battery (first battery found, usually BAT0).
    pub fn getPrimaryBattery(self: *const UPower) ?*const BatteryInfo {
        if (self.battery_count > 0) {
            if (self.batteries[0]) |*bat| {
                return bat;
            }
        }
        return null;
    }

    /// Get all tracked batteries.
    pub fn getBatteries(self: *const UPower) []const ?BatteryInfo {
        return self.batteries[0..self.battery_count];
    }

    /// Check if system is running on battery power.
    pub fn isOnBattery(self: *const UPower) bool {
        return self.on_battery;
    }

    /// Refresh all battery data from D-Bus.
    pub fn refresh(self: *UPower) Error!void {
        // Get system-wide properties
        self.refreshSystemProperties() catch |err| {
            log.debug("Failed to get system properties: {s}", .{@errorName(err)});
        };

        // Enumerate and refresh devices
        try self.enumerateDevices();
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *UPower, callback: StateChangeFn, context: ?*anyopaque) bool {
        return self.subscriptions.subscribe(callback, context);
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *UPower, callback: StateChangeFn, context: ?*anyopaque) void {
        self.subscriptions.unsubscribe(callback, context);
    }

    // Internal methods

    fn refreshSystemProperties(self: *UPower) Error!void {
        // Get OnBattery
        var msg = try self.connection.getProperty(service, upower_path, upower_interface, "OnBattery");
        defer msg.unref();
        self.on_battery = msg.readVariantBool() catch false;

        // Get LidIsClosed
        var lid_msg = self.connection.getProperty(service, upower_path, upower_interface, "LidIsClosed") catch return;
        defer lid_msg.unref();
        self.lid_is_closed = lid_msg.readVariantBool() catch false;

        // Get LidIsPresent
        var lid_present_msg = self.connection.getProperty(service, upower_path, upower_interface, "LidIsPresent") catch return;
        defer lid_present_msg.unref();
        self.lid_is_present = lid_present_msg.readVariantBool() catch false;
    }

    fn enumerateDevices(self: *UPower) Error!void {
        var msg = try self.connection.callMethod(service, upower_path, upower_interface, "EnumerateDevices");
        defer msg.unref();

        self.battery_count = 0;

        // Response is array of object paths
        if (try msg.enterArray("o")) {
            while (!msg.atEnd() and self.battery_count < max_devices) {
                const path = msg.readObjectPath() catch continue;

                // Get device type to filter batteries
                const device_type = self.getDeviceType(path) catch continue;

                if (device_type == .battery) {
                    var info = BatteryInfo{};
                    const len = @min(path.len, max_path_len);
                    @memcpy(info.path[0..len], path[0..len]);
                    info.path_len = len;
                    info.device_type = device_type;

                    self.refreshDeviceProperties(&info) catch |err| {
                        log.debug("Failed to get device properties for {s}: {s}", .{ path, @errorName(err) });
                        continue;
                    };

                    self.batteries[self.battery_count] = info;
                    self.battery_count += 1;

                    log.debug("Found battery: {s} ({d}%)", .{ path, info.getPercentage() });
                }
            }
            try msg.exitContainer();
        }

        if (self.battery_count == 0) {
            log.info("No battery devices found", .{});
        } else {
            log.info("Found {d} battery device(s)", .{self.battery_count});
        }
    }

    fn getDeviceType(self: *UPower, path: []const u8) Error!DeviceType {
        var path_buf: [max_path_len:0]u8 = undefined;
        const len = @min(path.len, max_path_len);
        @memcpy(path_buf[0..len], path[0..len]);
        path_buf[len] = 0;

        var msg = try self.connection.getProperty(service, path_buf[0..len :0], device_interface, "Type");
        defer msg.unref();

        return DeviceType.fromInt(msg.readVariantUint32() catch return .unknown);
    }

    fn refreshDeviceProperties(self: *UPower, info: *BatteryInfo) Error!void {
        const path = info.path[0..info.path_len :0];

        // Get all properties individually
        // Using inline helper to reduce boilerplate
        self.readPropertyU32(path, "State", &info.state);
        self.readPropertyDouble(path, "Percentage", &info.percentage);
        self.readPropertyDouble(path, "Energy", &info.energy);
        self.readPropertyDouble(path, "EnergyFull", &info.energy_full);
        self.readPropertyDouble(path, "EnergyFullDesign", &info.energy_full_design);
        self.readPropertyDouble(path, "EnergyRate", &info.energy_rate);
        self.readPropertyI64(path, "TimeToEmpty", &info.time_to_empty);
        self.readPropertyI64(path, "TimeToFull", &info.time_to_full);
        self.readPropertyDouble(path, "Voltage", &info.voltage);
        self.readPropertyDouble(path, "Temperature", &info.temperature);
        self.readPropertyDouble(path, "Capacity", &info.capacity);
        self.readPropertyU32(path, "WarningLevel", &info.warning_level);
        self.readPropertyBool(path, "IsPresent", &info.is_present);
        self.readPropertyBool(path, "PowerSupply", &info.is_power_supply);
        self.readPropertyI32(path, "ChargeCycles", &info.charge_cycles);
        self.readPropertyString(path, "Vendor", &info.vendor, &info.vendor_len);
        self.readPropertyString(path, "Model", &info.model, &info.model_len);
    }

    fn readPropertyU32(self: *UPower, path: [:0]const u8, prop: [:0]const u8, out: anytype) void {
        var msg = self.connection.getProperty(service, path, device_interface, prop) catch return;
        defer msg.unref();
        const val = msg.readVariantUint32() catch return;
        out.* = @enumFromInt(val);
    }

    fn readPropertyDouble(self: *UPower, path: [:0]const u8, prop: [:0]const u8, out: *f64) void {
        var msg = self.connection.getProperty(service, path, device_interface, prop) catch return;
        defer msg.unref();
        out.* = msg.readVariantDouble() catch return;
    }

    fn readPropertyI64(self: *UPower, path: [:0]const u8, prop: [:0]const u8, out: *i64) void {
        var msg = self.connection.getProperty(service, path, device_interface, prop) catch return;
        defer msg.unref();
        out.* = msg.readVariantInt64() catch return;
    }

    fn readPropertyI32(self: *UPower, path: [:0]const u8, prop: [:0]const u8, out: *i32) void {
        var msg = self.connection.getProperty(service, path, device_interface, prop) catch return;
        defer msg.unref();
        out.* = msg.readVariantInt32() catch return;
    }

    fn readPropertyBool(self: *UPower, path: [:0]const u8, prop: [:0]const u8, out: *bool) void {
        var msg = self.connection.getProperty(service, path, device_interface, prop) catch return;
        defer msg.unref();
        out.* = msg.readVariantBool() catch return;
    }

    fn readPropertyString(self: *UPower, path: [:0]const u8, prop: [:0]const u8, out: []u8, out_len: *usize) void {
        var msg = self.connection.getProperty(service, path, device_interface, prop) catch return;
        defer msg.unref();
        const str = msg.readVariantString() catch return;
        const len = @min(str.len, out.len);
        @memcpy(out[0..len], str[0..len]);
        out_len.* = len;
    }

    fn subscribeToPropertyChanges(self: *UPower) Error!void {
        // Subscribe to PropertiesChanged on all UPower device paths
        // We use a broad match and filter in the handler
        const match_rule =
            "type='signal'," ++
            "interface='org.freedesktop.DBus.Properties'," ++
            "member='PropertiesChanged'," ++
            "arg0='org.freedesktop.UPower.Device'";

        try self.connection.subscribeMatch(match_rule, handlePropertyChanged, self);

        // Also subscribe to UPower daemon properties
        const upower_match =
            "type='signal'," ++
            "interface='org.freedesktop.DBus.Properties'," ++
            "member='PropertiesChanged'," ++
            "path='/org/freedesktop/UPower'," ++
            "arg0='org.freedesktop.UPower'";

        try self.connection.subscribeMatch(upower_match, handleUPowerPropertyChanged, self);
    }

    fn subscribeToDeviceChanges(self: *UPower) Error!void {
        // Subscribe to DeviceAdded and DeviceRemoved signals
        const added_match =
            "type='signal'," ++
            "interface='org.freedesktop.UPower'," ++
            "member='DeviceAdded'";

        try self.connection.subscribeMatch(added_match, handleDeviceAdded, self);

        const removed_match =
            "type='signal'," ++
            "interface='org.freedesktop.UPower'," ++
            "member='DeviceRemoved'";

        try self.connection.subscribeMatch(removed_match, handleDeviceRemoved, self);
    }

    fn handlePropertyChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *UPower = @ptrCast(@alignCast(ctx orelse return));

        // Get the path of the device that changed
        const path = msg.getPath() orelse return;

        // Find the battery with this path and refresh it
        for (&self.batteries) |*slot| {
            if (slot.*) |*info| {
                if (std.mem.eql(u8, info.getPath(), path)) {
                    self.refreshDeviceProperties(info) catch {};
                    self.notify();
                    return;
                }
            }
        }
    }

    fn handleUPowerPropertyChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *UPower = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;

        // Refresh system properties
        self.refreshSystemProperties() catch {};
        self.notify();
    }

    fn handleDeviceAdded(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *UPower = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;

        // Re-enumerate devices
        self.enumerateDevices() catch {};
        self.notify();
    }

    fn handleDeviceRemoved(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *UPower = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;

        // Re-enumerate devices
        self.enumerateDevices() catch {};
        self.notify();
    }

    fn notify(self: *const UPower) void {
        self.subscriptions.notify();
    }
};

test "UPower types compile" {
    _ = UPower;
    _ = BatteryInfo;
    _ = DeviceState;
    _ = DeviceType;
    _ = WarningLevel;
    _ = StateChangeFn;
}
