//! Late D-Bus Connection method/property helpers.

const std = @import("std");
const types = @import("types.zig");
const Message = @import("message.zig").Message;
const c = types.c;
const log = std.log.scoped(.dbus);

/// Call a D-Bus method with two string arguments.
pub fn callMethodWithTwoStrings(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    member: [:0]const u8,
    arg1: [:0]const u8,
    arg2: [:0]const u8,
) types.Error!Message {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        interface.ptr,
        member.ptr,
        &err,
        &reply,
        "ss",
        arg1.ptr,
        arg2.ptr,
    );

    defer c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (err.name != null) {
            const name = std.mem.span(err.name);
            if (std.mem.eql(u8, name, "org.freedesktop.DBus.Error.ServiceUnknown")) {
                return types.Error.ServiceUnknown;
            } else if (std.mem.eql(u8, name, "org.freedesktop.DBus.Error.NameHasNoOwner")) {
                return types.Error.NameHasNoOwner;
            }
            log.warn("D-Bus error: {s}", .{name});
        }
        return types.Error.MethodCallFailed;
    }

    return Message.wrap(reply.?);
}

/// Call a D-Bus method with a u32 argument.
pub fn callMethodWithUint32(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    member: [:0]const u8,
    arg: u32,
) types.Error!Message {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        interface.ptr,
        member.ptr,
        &err,
        &reply,
        "u",
        arg,
    );

    defer c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (err.name != null) {
            log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
        }
        return types.Error.MethodCallFailed;
    }

    return Message.wrap(reply.?);
}

/// Call a D-Bus method with a string and u32 argument.
pub fn callMethodWithStringAndUint32(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    member: [:0]const u8,
    str_arg: [:0]const u8,
    uint_arg: u32,
) types.Error!Message {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        interface.ptr,
        member.ptr,
        &err,
        &reply,
        "su",
        str_arg.ptr,
        uint_arg,
    );

    defer c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (err.name != null) {
            log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
        }
        return types.Error.MethodCallFailed;
    }

    return Message.wrap(reply.?);
}

/// Call a D-Bus method with two i32 arguments.
pub fn callMethodWithTwoInt32(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    member: [:0]const u8,
    arg1: i32,
    arg2: i32,
) types.Error!Message {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        interface.ptr,
        member.ptr,
        &err,
        &reply,
        "ii",
        arg1,
        arg2,
    );

    defer c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (err.name != null) {
            log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
        }
        return types.Error.MethodCallFailed;
    }

    return Message.wrap(reply.?);
}

/// Call a D-Bus method with four string arguments (e.g. logind Inhibit).
pub fn callMethodWithFourStrings(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    member: [:0]const u8,
    arg1: [:0]const u8,
    arg2: [:0]const u8,
    arg3: [:0]const u8,
    arg4: [:0]const u8,
) types.Error!Message {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        interface.ptr,
        member.ptr,
        &err,
        &reply,
        "ssss",
        arg1.ptr,
        arg2.ptr,
        arg3.ptr,
        arg4.ptr,
    );

    defer c.sd_bus_error_free(&err);

    if (ret < 0) {
        if (err.name != null) {
            log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
        }
        return types.Error.MethodCallFailed;
    }

    return Message.wrap(reply.?);
}

/// Check if a D-Bus bus name is currently owned (service is running).
/// Queries the D-Bus daemon directly — does NOT trigger service activation,
/// returns immediately regardless of whether the service exists.
pub fn nameHasOwner(self: anytype, name: [:0]const u8) bool {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        "org.freedesktop.DBus",
        "/org/freedesktop/DBus",
        "org.freedesktop.DBus",
        "NameHasOwner",
        &err,
        &reply,
        "s",
        name.ptr,
    );

    defer c.sd_bus_error_free(&err);

    if (ret < 0) return false;
    const r = reply orelse return false;
    defer _ = c.sd_bus_message_unref(r);

    var result: c_int = 0;
    if (c.sd_bus_message_read_basic(r, 'b', @ptrCast(&result)) < 0) return false;
    return result != 0;
}

/// Set a D-Bus property value (string).
/// Uses org.freedesktop.DBus.Properties.Set interface.
pub fn setPropertyString(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    property: [:0]const u8,
    value: [:0]const u8,
) types.Error!void {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        "org.freedesktop.DBus.Properties",
        "Set",
        &err,
        &reply,
        "ssv",
        interface.ptr,
        property.ptr,
        "s",
        value.ptr,
    );

    defer c.sd_bus_error_free(&err);
    if (reply) |r| _ = c.sd_bus_message_unref(r);

    if (ret < 0) {
        if (err.name != null) {
            const name = std.mem.span(err.name);
            log.warn("D-Bus property set error: {s}", .{name});
        }
        return types.Error.MethodCallFailed;
    }
}

pub fn setPropertyBool(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    property: [:0]const u8,
    value: bool,
) types.Error!void {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const v: c_int = @intFromBool(value);
    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        "org.freedesktop.DBus.Properties",
        "Set",
        &err,
        &reply,
        "ssv",
        interface.ptr,
        property.ptr,
        "b",
        v,
    );

    defer c.sd_bus_error_free(&err);
    if (reply) |r| _ = c.sd_bus_message_unref(r);

    if (ret < 0) {
        if (err.name != null) {
            log.warn("D-Bus property set error: {s}", .{std.mem.span(err.name)});
        }
        return types.Error.MethodCallFailed;
    }
}

pub fn setPropertyUint32(
    self: anytype,
    destination: [:0]const u8,
    path: [:0]const u8,
    interface: [:0]const u8,
    property: [:0]const u8,
    value: u32,
) types.Error!void {
    var reply: ?*c.sd_bus_message = null;
    var err: c.sd_bus_error = .{
        .name = null,
        .message = null,
        ._need_free = 0,
    };

    const ret = c.sd_bus_call_method(
        self.bus,
        destination.ptr,
        path.ptr,
        "org.freedesktop.DBus.Properties",
        "Set",
        &err,
        &reply,
        "ssv",
        interface.ptr,
        property.ptr,
        "u",
        value,
    );

    defer c.sd_bus_error_free(&err);
    if (reply) |r| _ = c.sd_bus_message_unref(r);

    if (ret < 0) {
        if (err.name != null) {
            log.warn("D-Bus property set error: {s}", .{std.mem.span(err.name)});
        }
        return types.Error.MethodCallFailed;
    }
}
