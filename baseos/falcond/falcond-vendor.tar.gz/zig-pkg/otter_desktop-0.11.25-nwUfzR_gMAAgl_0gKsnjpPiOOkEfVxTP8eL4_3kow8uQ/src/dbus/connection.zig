//! D-Bus Connection management
//!
//! Wraps sd-bus connection with methods for calling, subscribing, and processing messages.

const std = @import("std");
const posix = std.posix;
const Allocator = std.mem.Allocator;

const types = @import("types.zig");
const Message = @import("message.zig").Message;
const c = types.c;

const log = std.log.scoped(.dbus);
const extra = @import("connection_extra.zig");

pub const Connection = struct {
    bus: *c.sd_bus,
    allocator: Allocator,
    slots: std.ArrayList(*c.sd_bus_slot) = .empty,
    handlers: std.ArrayList(*SignalHandler) = .empty,

    /// Open a D-Bus connection.
    pub fn open(allocator: Allocator, bus_type: types.BusType) types.Error!Connection {
        var bus: ?*c.sd_bus = null;

        const ret = switch (bus_type) {
            .session => c.sd_bus_open_user(&bus),
            .system => c.sd_bus_open_system(&bus),
        };

        if (ret < 0) {
            log.err("Failed to open D-Bus connection: {d}", .{ret});
            return types.Error.ConnectionFailed;
        }

        return .{
            .bus = bus.?,
            .allocator = allocator,
        };
    }

    /// Close the D-Bus connection.
    pub fn deinit(self: *Connection) void {
        // Free all signal subscription slots
        for (self.slots.items) |slot| {
            _ = c.sd_bus_slot_unref(slot);
        }
        self.slots.deinit(self.allocator);

        // Free all signal handlers
        for (self.handlers.items) |handler| {
            self.allocator.destroy(handler);
        }
        self.handlers.deinit(self.allocator);

        _ = c.sd_bus_flush_close_unref(self.bus);
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const Connection) posix.fd_t {
        return c.sd_bus_get_fd(self.bus);
    }

    /// Process pending D-Bus messages.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if there are more messages to process.
    pub fn process(self: *Connection) bool {
        const ret = c.sd_bus_process(self.bus, null);
        return ret > 0;
    }

    /// Process all currently pending D-Bus messages.
    /// Keeps `process()` as the one-message primitive for callers that step work.
    pub fn drain(self: *Connection) void {
        while (self.process()) {}
    }

    /// Flush outgoing messages.
    pub fn flush(self: *Connection) types.Error!void {
        const ret = c.sd_bus_flush(self.bus);
        if (ret < 0) return types.translateError(ret);
    }

    /// Call a D-Bus method synchronously.
    pub fn callMethod(
        self: *Connection,
        destination: [:0]const u8,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
    ) types.Error!Message {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };

        const ret = c.sd_bus_call_method(
            self.bus,
            destination.ptr,
            path.ptr,
            interface.ptr,
            member.ptr,
            &err,
            &reply,
            null, // no arguments
        );

        defer c.sd_bus_error_free(&err);

        if (ret < 0) {
            if (err.name != null) {
                const name = std.mem.span(err.name);
                if (std.mem.eql(u8, name, "org.freedesktop.DBus.Error.ServiceUnknown")) {
                    return types.Error.ServiceUnknown;
                } else if (std.mem.eql(u8, name, "org.freedesktop.DBus.Error.NameHasNoOwner")) {
                    return types.Error.NameHasNoOwner;
                }
                log.warn("D-Bus error: {s}", .{name});
            }
            return types.Error.MethodCallFailed;
        }

        return Message.wrap(reply.?);
    }

    /// Call a D-Bus method with string argument.
    pub fn callMethodWithString(
        self: *Connection,
        destination: [:0]const u8,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
        arg: [:0]const u8,
    ) types.Error!Message {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };

        const ret = c.sd_bus_call_method(
            self.bus,
            destination.ptr,
            path.ptr,
            interface.ptr,
            member.ptr,
            &err,
            &reply,
            "s",
            arg.ptr,
        );

        defer c.sd_bus_error_free(&err);

        if (ret < 0) {
            if (err.name != null) {
                log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
            }
            return types.Error.MethodCallFailed;
        }

        return Message.wrap(reply.?);
    }

    /// Call a D-Bus method with one object-path argument.
    pub fn callMethodWithObjectPath(
        self: *Connection,
        destination: [:0]const u8,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
        arg: [:0]const u8,
    ) types.Error!Message {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };

        const ret = c.sd_bus_call_method(
            self.bus,
            destination.ptr,
            path.ptr,
            interface.ptr,
            member.ptr,
            &err,
            &reply,
            "o",
            arg.ptr,
        );

        defer c.sd_bus_error_free(&err);

        if (ret < 0) {
            if (err.name != null) log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
            return types.Error.MethodCallFailed;
        }

        return Message.wrap(reply.?);
    }

    /// Call a D-Bus method with three object-path arguments.
    pub fn callMethodWithThreeObjectPaths(
        self: *Connection,
        destination: [:0]const u8,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
        arg1: [:0]const u8,
        arg2: [:0]const u8,
        arg3: [:0]const u8,
    ) types.Error!Message {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };

        const ret = c.sd_bus_call_method(
            self.bus,
            destination.ptr,
            path.ptr,
            interface.ptr,
            member.ptr,
            &err,
            &reply,
            "ooo",
            arg1.ptr,
            arg2.ptr,
            arg3.ptr,
        );

        defer c.sd_bus_error_free(&err);

        if (ret < 0) {
            if (err.name != null) log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
            return types.Error.MethodCallFailed;
        }

        return Message.wrap(reply.?);
    }

    /// Call a D-Bus method whose only argument is an empty `a{sv}` dict.
    pub fn callMethodWithEmptyVariantDict(
        self: *Connection,
        destination: [:0]const u8,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
    ) types.Error!Message {
        var msg: ?*c.sd_bus_message = null;
        const create_ret = c.sd_bus_message_new_method_call(
            self.bus,
            &msg,
            destination.ptr,
            path.ptr,
            interface.ptr,
            member.ptr,
        );
        if (create_ret < 0 or msg == null) return types.Error.MessageWriteError;
        defer _ = c.sd_bus_message_unref(msg.?);

        if (c.sd_bus_message_open_container(msg.?, 'a', "{sv}") < 0) return types.Error.MessageWriteError;
        if (c.sd_bus_message_close_container(msg.?) < 0) return types.Error.MessageWriteError;

        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };
        const ret = c.sd_bus_call(self.bus, msg.?, 0, &err, &reply);

        defer c.sd_bus_error_free(&err);
        if (ret < 0) {
            if (err.name != null) log.warn("D-Bus error: {s}", .{std.mem.span(err.name)});
            return types.Error.MethodCallFailed;
        }

        return Message.wrap(reply.?);
    }

    /// Callback function signature for signal handlers.
    pub const SignalCallback = *const fn (msg: Message, ctx: ?*anyopaque) void;

    /// Internal callback wrapper that converts C callback to Zig.
    fn signalCallbackWrapper(
        msg: ?*c.sd_bus_message,
        userdata: ?*anyopaque,
        _: [*c]c.sd_bus_error,
    ) callconv(.c) c_int {
        if (msg == null or userdata == null) return 0;

        const handler: *const SignalHandler = @ptrCast(@alignCast(userdata));
        const wrapped_msg = Message.wrap(msg.?);
        handler.callback(wrapped_msg, handler.context);

        return 0;
    }

    const SignalHandler = struct {
        callback: SignalCallback,
        context: ?*anyopaque,
    };

    /// Subscribe to a D-Bus signal.
    pub fn subscribeSignal(
        self: *Connection,
        interface: [:0]const u8,
        member: [:0]const u8,
        callback: SignalCallback,
        context: ?*anyopaque,
    ) types.Error!void {
        // Allocate handler struct to persist for callback lifetime
        const handler = self.allocator.create(SignalHandler) catch return types.Error.NoMemory;
        handler.* = .{
            .callback = callback,
            .context = context,
        };

        var slot: ?*c.sd_bus_slot = null;

        var match_buf: [512]u8 = undefined;
        const match_str = std.fmt.bufPrint(&match_buf, "type='signal',interface='{s}',member='{s}'", .{ interface, member }) catch {
            self.allocator.destroy(handler);
            return types.Error.NoMemory;
        };
        match_buf[match_str.len] = 0;
        const match_z: [:0]const u8 = match_buf[0..match_str.len :0];

        const ret = c.sd_bus_add_match(
            self.bus,
            &slot,
            match_z,
            signalCallbackWrapper,
            handler,
        );

        if (ret < 0) {
            self.allocator.destroy(handler);
            return types.translateError(ret);
        }

        self.slots.append(self.allocator, slot.?) catch {
            _ = c.sd_bus_slot_unref(slot.?);
            self.allocator.destroy(handler);
            return types.Error.NoMemory;
        };

        // Track handler for cleanup in deinit
        self.handlers.append(self.allocator, handler) catch {
            // Handler will still be freed via slot userdata, just not tracked
        };
    }

    /// Subscribe to a signal with a match rule string.
    pub fn subscribeMatch(
        self: *Connection,
        match_rule: [:0]const u8,
        callback: SignalCallback,
        context: ?*anyopaque,
    ) types.Error!void {
        const handler = self.allocator.create(SignalHandler) catch return types.Error.NoMemory;
        handler.* = .{
            .callback = callback,
            .context = context,
        };

        var slot: ?*c.sd_bus_slot = null;

        const ret = c.sd_bus_add_match(
            self.bus,
            &slot,
            match_rule.ptr,
            signalCallbackWrapper,
            handler,
        );

        if (ret < 0) {
            self.allocator.destroy(handler);
            return types.translateError(ret);
        }

        self.slots.append(self.allocator, slot.?) catch {
            _ = c.sd_bus_slot_unref(slot.?);
            self.allocator.destroy(handler);
            return types.Error.NoMemory;
        };

        // Track handler for cleanup in deinit
        self.handlers.append(self.allocator, handler) catch {
            // Handler will still be freed via slot userdata, just not tracked
        };
    }

    /// Get the unique name of this connection.
    pub fn getUniqueName(self: *const Connection) ?[]const u8 {
        var name: [*c]const u8 = null;
        const ret = c.sd_bus_get_unique_name(self.bus, &name);
        if (ret < 0 or name == null) return null;
        return std.mem.span(name);
    }

    /// Request a well-known name on the bus.
    pub fn requestName(self: *Connection, name: [:0]const u8) types.Error!void {
        const ret = c.sd_bus_request_name(self.bus, name.ptr, 0);
        if (ret < 0) return types.translateError(ret);
    }

    /// Request a well-known name on the bus with flags.
    /// Flags: SD_BUS_NAME_REPLACE_EXISTING (1), SD_BUS_NAME_ALLOW_REPLACEMENT (2), SD_BUS_NAME_QUEUE (4).
    pub fn requestNameFlags(self: *Connection, name: [:0]const u8, flags: u64) types.Error!void {
        const ret = c.sd_bus_request_name(self.bus, name.ptr, flags);
        if (ret < 0) return types.translateError(ret);
    }

    /// Release a previously requested name.
    pub fn releaseName(self: *Connection, name: [:0]const u8) types.Error!void {
        const ret = c.sd_bus_release_name(self.bus, name.ptr);
        if (ret < 0) return types.translateError(ret);
    }

    /// Get a D-Bus property value.
    /// Uses org.freedesktop.DBus.Properties.Get interface.
    pub fn getProperty(
        self: *Connection,
        destination: [:0]const u8,
        path: [:0]const u8,
        interface: [:0]const u8,
        property: [:0]const u8,
    ) types.Error!Message {
        var reply: ?*c.sd_bus_message = null;
        var err: c.sd_bus_error = .{
            .name = null,
            .message = null,
            ._need_free = 0,
        };

        const ret = c.sd_bus_call_method(
            self.bus,
            destination.ptr,
            path.ptr,
            "org.freedesktop.DBus.Properties",
            "Get",
            &err,
            &reply,
            "ss",
            interface.ptr,
            property.ptr,
        );

        defer c.sd_bus_error_free(&err);

        if (ret < 0) {
            if (err.name != null) {
                const name = std.mem.span(err.name);
                if (std.mem.eql(u8, name, "org.freedesktop.DBus.Error.ServiceUnknown")) {
                    return types.Error.ServiceUnknown;
                } else if (std.mem.eql(u8, name, "org.freedesktop.DBus.Error.NameHasNoOwner")) {
                    return types.Error.NameHasNoOwner;
                }
                log.debug("D-Bus property get error: {s}", .{name});
            }
            return types.Error.MethodCallFailed;
        }

        return Message.wrap(reply.?);
    }

    // --- Server-side methods ---

    /// C-compatible method handler callback type.
    pub const MethodHandler = *const fn (
        msg: ?*c.sd_bus_message,
        userdata: ?*anyopaque,
        ret_error: [*c]c.sd_bus_error,
    ) callconv(.c) c_int;

    /// Register a callback for all messages directed to an object path.
    pub fn addObject(
        self: *Connection,
        path: [:0]const u8,
        callback: MethodHandler,
        userdata: ?*anyopaque,
    ) types.Error!void {
        var slot: ?*c.sd_bus_slot = null;
        const ret = c.sd_bus_add_object(
            self.bus,
            &slot,
            path.ptr,
            callback,
            userdata,
        );
        if (ret < 0) return types.Error.VtableRegistrationFailed;

        self.slots.append(self.allocator, slot.?) catch {
            _ = c.sd_bus_slot_unref(slot.?);
            return types.Error.NoMemory;
        };
    }

    /// Emit a signal with no arguments.
    pub fn emitSignal(
        self: *Connection,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
    ) types.Error!void {
        const ret = c.sd_bus_emit_signal(
            self.bus,
            path.ptr,
            interface.ptr,
            member.ptr,
            null,
        );
        if (ret < 0) return types.Error.SignalEmitFailed;
    }

    /// Emit a signal with a single string argument.
    pub fn emitSignalWithString(
        self: *Connection,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
        arg: [*:0]const u8,
    ) types.Error!void {
        const ret = c.sd_bus_emit_signal(
            self.bus,
            path.ptr,
            interface.ptr,
            member.ptr,
            "s",
            arg,
        );
        if (ret < 0) return types.Error.SignalEmitFailed;
    }

    /// Create a new signal message for manual building.
    pub fn newSignal(
        self: *Connection,
        path: [:0]const u8,
        interface: [:0]const u8,
        member: [:0]const u8,
    ) types.Error!Message {
        var msg: ?*c.sd_bus_message = null;
        const ret = c.sd_bus_message_new_signal(
            self.bus,
            &msg,
            path.ptr,
            interface.ptr,
            member.ptr,
        );
        if (ret < 0) return types.Error.SignalEmitFailed;
        return Message.wrap(msg.?);
    }

    /// Send a message on the bus.
    pub fn send(self: *Connection, msg: *Message) types.Error!void {
        const ret = c.sd_bus_send(self.bus, msg.msg, null);
        if (ret < 0) return types.Error.MessageWriteError;
    }

    /// Create a method return message for building a reply.
    pub fn newMethodReturn(raw: *c.sd_bus_message) types.Error!Message {
        var reply: ?*c.sd_bus_message = null;
        const ret = c.sd_bus_message_new_method_return(raw, &reply);
        if (ret < 0) return types.translateError(ret);
        return Message.wrap(reply.?);
    }

    /// Reply to a method call with an empty return.
    pub fn replyMethodReturn(raw: *c.sd_bus_message) c_int {
        return c.sd_bus_reply_method_return(raw, null);
    }

    /// Reply to a method call with an error.
    pub fn replyMethodError(raw: *c.sd_bus_message, name: [*:0]const u8, errmsg: [*:0]const u8) c_int {
        var err: c.sd_bus_error = .{
            .name = name,
            .message = errmsg,
            ._need_free = 0,
        };
        return c.sd_bus_reply_method_error(raw, &err);
    }

    /// Call a D-Bus method with two string arguments.
    pub fn callMethodWithTwoStrings(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, member: [:0]const u8, arg1: [:0]const u8, arg2: [:0]const u8) types.Error!Message {
        return extra.callMethodWithTwoStrings(self, destination, path, interface, member, arg1, arg2);
    }

    /// Call a D-Bus method with a u32 argument.
    pub fn callMethodWithUint32(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, member: [:0]const u8, arg: u32) types.Error!Message {
        return extra.callMethodWithUint32(self, destination, path, interface, member, arg);
    }

    /// Call a D-Bus method with a string and u32 argument.
    pub fn callMethodWithStringAndUint32(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, member: [:0]const u8, str_arg: [:0]const u8, uint_arg: u32) types.Error!Message {
        return extra.callMethodWithStringAndUint32(self, destination, path, interface, member, str_arg, uint_arg);
    }

    /// Call a D-Bus method with two i32 arguments.
    pub fn callMethodWithTwoInt32(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, member: [:0]const u8, arg1: i32, arg2: i32) types.Error!Message {
        return extra.callMethodWithTwoInt32(self, destination, path, interface, member, arg1, arg2);
    }

    /// Call a D-Bus method with four string arguments (e.g. logind Inhibit).
    pub fn callMethodWithFourStrings(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, member: [:0]const u8, arg1: [:0]const u8, arg2: [:0]const u8, arg3: [:0]const u8, arg4: [:0]const u8) types.Error!Message {
        return extra.callMethodWithFourStrings(self, destination, path, interface, member, arg1, arg2, arg3, arg4);
    }

    /// Check if a D-Bus bus name is currently owned.
    pub fn nameHasOwner(self: *Connection, name: [:0]const u8) bool {
        return extra.nameHasOwner(self, name);
    }

    /// Set a D-Bus property value (string).
    pub fn setPropertyString(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, property: [:0]const u8, value: [:0]const u8) types.Error!void {
        return extra.setPropertyString(self, destination, path, interface, property, value);
    }

    pub fn setPropertyBool(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, property: [:0]const u8, value: bool) types.Error!void {
        return extra.setPropertyBool(self, destination, path, interface, property, value);
    }

    pub fn setPropertyUint32(self: *Connection, destination: [:0]const u8, path: [:0]const u8, interface: [:0]const u8, property: [:0]const u8, value: u32) types.Error!void {
        return extra.setPropertyUint32(self, destination, path, interface, property, value);
    }
};

test "Connection types compile" {
    // Just verify the types compile correctly
    _ = Connection;
    _ = types.BusType;
}
