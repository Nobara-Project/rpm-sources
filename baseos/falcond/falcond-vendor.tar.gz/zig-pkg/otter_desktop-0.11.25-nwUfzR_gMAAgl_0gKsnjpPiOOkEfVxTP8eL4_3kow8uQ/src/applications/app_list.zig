//! Application List Provider
//!
//! Manages a list of desktop applications with XDG directory scanning,
//! deduplication (user entries override system), and hot-reload support.

const std = @import("std");
const otter_utils_io = @import("otter_utils");
inline fn io_global() std.Io {
    return otter_utils_io.io.get();
}
const SubscriberList = otter_utils_io.SubscriberList;

const mem = std.mem;
const fs = std.fs;
const posix = std.posix;
const Allocator = std.mem.Allocator;

const desktop_entry = @import("desktop_entry.zig");
const DesktopEntry = desktop_entry.DesktopEntry;
const AppDirWatcher = @import("watcher.zig").AppDirWatcher;
const xdg_paths = @import("../xdg_paths.zig");

const log = std.log.scoped(.AppList);

/// Maximum number of state change subscribers
const max_subscribers = 8;

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscriptions = SubscriberList(StateChangeFn, max_subscribers);
pub const Subscription = Subscriptions.Subscription;

pub const AppList = struct {
    entries: std.StringHashMap(DesktopEntry),
    allocator: Allocator,
    subscriptions: Subscriptions = .{},
    watcher: ?AppDirWatcher,
    app_dirs: std.ArrayList([]const u8) = .empty,

    /// Initialize without hot-reload support.
    pub fn init(allocator: Allocator) AppList {
        return .{
            .entries = std.StringHashMap(DesktopEntry).init(allocator),
            .allocator = allocator,
            .watcher = null,
        };
    }

    /// Initialize with hot-reload support (watches directories for changes).
    pub fn initWithWatcher(allocator: Allocator) !AppList {
        const watcher = try AppDirWatcher.init(allocator);

        return .{
            .entries = std.StringHashMap(DesktopEntry).init(allocator),
            .allocator = allocator,
            .watcher = watcher,
        };
    }

    pub fn deinit(self: *AppList) void {
        // Free all entries
        var iter = self.entries.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
            entry.value_ptr.deinit();
        }
        self.entries.deinit();

        // Free app directory paths
        for (self.app_dirs.items) |dir| {
            self.allocator.free(dir);
        }
        self.app_dirs.deinit(self.allocator);

        if (self.watcher) |*w| {
            w.deinit();
        }

        self.* = undefined;
    }

    /// Scan all XDG application directories and populate the list.
    /// Deduplication: first entry wins (user dirs scanned before system).
    pub fn scan(self: *AppList) !void {
        // Clear existing entries
        self.clear();

        // Get XDG directories in priority order and scan them
        try self.scanAppDirectories();

        log.info("Loaded {d} applications", .{self.entries.count()});

        // Notify subscribers
        self.notify();
    }

    /// Clear all entries.
    pub fn clear(self: *AppList) void {
        var iter = self.entries.iterator();
        while (iter.next()) |entry| {
            self.allocator.free(entry.key_ptr.*);
            entry.value_ptr.deinit();
        }
        self.entries.clearRetainingCapacity();
    }

    /// Get an iterator over all entries.
    /// Use this instead of building a separate list.
    pub fn iterator(self: *const AppList) std.StringHashMap(DesktopEntry).Iterator {
        return self.entries.iterator();
    }

    /// Get application count.
    pub fn count(self: *const AppList) usize {
        return self.entries.count();
    }

    /// Find an application by its ID.
    pub fn findById(self: *const AppList, id: []const u8) ?*const DesktopEntry {
        return self.entries.getPtr(id);
    }

    /// Search applications by name and keywords.
    /// Writes matching entries to results (up to results.len entries).
    /// Returns the number of matches written.
    pub fn search(
        self: *const AppList,
        query: []const u8,
        results: []?*const DesktopEntry,
    ) usize {
        if (query.len == 0 or results.len == 0) return 0;

        var result_count: usize = 0;

        // Convert query to lowercase for case-insensitive matching
        var query_lower: [256]u8 = undefined;
        const query_len = @min(query.len, query_lower.len);
        for (query[0..query_len], 0..) |char, i| {
            query_lower[i] = std.ascii.toLower(char);
        }
        const search_query = query_lower[0..query_len];

        var iter = self.entries.iterator();
        while (iter.next()) |entry| {
            const app = entry.value_ptr;

            if (!app.isVisible()) continue;

            // Check name
            if (containsLower(app.name, search_query)) {
                results[result_count] = app;
                result_count += 1;
                if (result_count >= results.len) return result_count;
                continue;
            }

            // Check ID
            if (containsLower(app.id, search_query)) {
                results[result_count] = app;
                result_count += 1;
                if (result_count >= results.len) return result_count;
                continue;
            }

            // Check keywords
            for (app.keywords) |keyword| {
                if (containsLower(keyword, search_query)) {
                    results[result_count] = app;
                    result_count += 1;
                    if (result_count >= results.len) return result_count;
                    break;
                }
            }
        }

        return result_count;
    }

    /// Subscribe to application list changes.
    pub fn subscribe(self: *AppList, callback: StateChangeFn, context: ?*anyopaque) bool {
        return self.subscriptions.subscribe(callback, context);
    }

    /// Unsubscribe from application list changes.
    pub fn unsubscribe(self: *AppList, callback: StateChangeFn, context: ?*anyopaque) void {
        self.subscriptions.unsubscribe(callback, context);
    }

    /// Get watcher FD for poll integration (null if no watcher).
    pub fn getWatcherFd(self: *const AppList) ?posix.fd_t {
        if (self.watcher) |*w| {
            return w.getFd();
        }
        return null;
    }

    /// Process watcher events and update the application list.
    /// Call after poll indicates watcher FD is readable.
    pub fn processWatcherEvents(self: *AppList) !void {
        const watcher = &(self.watcher orelse return);

        var changed = false;

        while (watcher.nextEvent()) |event| {
            const filename = event.filename orelse continue;

            log.debug("File event: {s} in {s} ({s})", .{
                filename,
                event.dir_path,
                @tagName(event.kind),
            });

            switch (event.kind) {
                .created, .moved, .modified => {
                    // Parse and add/update entry
                    var path_buf: [fs.max_path_bytes]u8 = undefined;
                    const full_path = std.fmt.bufPrint(&path_buf, "{s}/{s}", .{ event.dir_path, filename }) catch continue;

                    if (self.parseAndAddEntry(full_path)) {
                        changed = true;
                    }
                },
                .deleted => {
                    // Remove entry by ID
                    const id = if (mem.endsWith(u8, filename, ".desktop"))
                        filename[0 .. filename.len - 8]
                    else
                        filename;

                    if (self.entries.fetchRemove(id)) |kv| {
                        self.allocator.free(kv.key);
                        var entry = kv.value;
                        entry.deinit();
                        changed = true;
                    }
                },
            }
        }

        if (changed) {
            self.notify();
        }
    }

    // Internal methods

    fn scanAppDirectories(self: *AppList) !void {
        var dirs = xdg_paths.PathList(16){};
        xdg_paths.collectApplicationDirs(&dirs, xdg_paths.Env.fromProcess());

        for (dirs.items()) |dir_path| {
            self.scanDirectory(dir_path) catch {};
            if (self.watcher) |*w| {
                w.watchDirectory(dir_path) catch {};
            }
        }
    }

    fn scanDirectory(self: *AppList, dir_path: []const u8) !void {
        var dir = std.Io.Dir.cwd().openDir(io_global(), dir_path, .{ .iterate = true }) catch return;
        defer dir.close(io_global());

        var iter = dir.iterate();
        while (try iter.next(io_global())) |entry| {
            if (entry.kind != .file and entry.kind != .sym_link) continue;
            if (!mem.endsWith(u8, entry.name, ".desktop")) continue;

            var path_buf: [fs.max_path_bytes]u8 = undefined;
            const full_path = std.fmt.bufPrint(&path_buf, "{s}/{s}", .{ dir_path, entry.name }) catch continue;

            _ = self.parseAndAddEntry(full_path);
        }
    }

    fn parseAndAddEntry(self: *AppList, path: []const u8) bool {
        const entry = desktop_entry.parse(self.allocator, path, .{}) catch |err| {
            switch (err) {
                desktop_entry.ParseError.NotAnApplication => {},
                else => log.debug("Failed to parse '{s}': {s}", .{ path, @errorName(err) }),
            }
            return false;
        };

        // Deduplication: first entry wins
        const gop = self.entries.getOrPut(entry.id) catch {
            var mutable_entry = entry;
            mutable_entry.deinit();
            return false;
        };

        if (gop.found_existing) {
            // Entry already exists, discard new one
            var mutable_entry = entry;
            mutable_entry.deinit();
            return false;
        }

        // Store with copied key
        gop.key_ptr.* = self.allocator.dupe(u8, entry.id) catch {
            var mutable_entry = entry;
            mutable_entry.deinit();
            return false;
        };
        gop.value_ptr.* = entry;

        return true;
    }

    fn notify(self: *const AppList) void {
        self.subscriptions.notify();
    }
};

/// Case-insensitive substring search.
/// Needle must already be lowercase.
fn containsLower(haystack: []const u8, needle: []const u8) bool {
    if (needle.len == 0) return true;
    if (needle.len > haystack.len) return false;

    const first_char = needle[0];
    const end = haystack.len - needle.len + 1;

    if (needle.len == 1) {
        for (haystack[0..end]) |c| {
            if (std.ascii.toLower(c) == first_char) return true;
        }
        return false;
    }

    var i: usize = 0;
    outer: while (i < end) : (i += 1) {
        if (std.ascii.toLower(haystack[i]) != first_char) continue;

        for (needle[1..], 1..) |c, j| {
            if (std.ascii.toLower(haystack[i + j]) != c) continue :outer;
        }
        return true;
    }
    return false;
}

test "init and deinit" {
    var list = AppList.init(std.testing.allocator);
    defer list.deinit();

    try std.testing.expectEqual(@as(usize, 0), list.count());
}

test "findById returns null for unknown" {
    var list = AppList.init(std.testing.allocator);
    defer list.deinit();

    try std.testing.expect(list.findById("nonexistent") == null);
}

test "subscriber notification" {
    var list = AppList.init(std.testing.allocator);
    defer list.deinit();

    var call_count: u32 = 0;
    const callback = struct {
        fn cb(ctx: ?*anyopaque) void {
            const count: *u32 = @ptrCast(@alignCast(ctx));
            count.* += 1;
        }
    }.cb;

    try std.testing.expect(list.subscribe(callback, &call_count));
    try std.testing.expectEqual(@as(usize, 1), list.subscriptions.count());

    list.notify();
    try std.testing.expectEqual(@as(u32, 1), call_count);

    list.unsubscribe(callback, &call_count);
    try std.testing.expectEqual(@as(usize, 0), list.subscriptions.count());

    list.notify();
    try std.testing.expectEqual(@as(u32, 1), call_count);
}

test "containsLower" {
    try std.testing.expect(containsLower("Firefox", "fire"));
    try std.testing.expect(containsLower("Firefox", "fox"));
    try std.testing.expect(containsLower("FIREFOX", "fire"));
    try std.testing.expect(!containsLower("Firefox", "chrome"));
    try std.testing.expect(containsLower("Firefox", "firefox"));
}
