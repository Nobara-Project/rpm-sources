//! D-Bus ScreenSaver inhibit service
//!
//! Implements org.freedesktop.ScreenSaver on the session bus to track
//! application inhibit requests. Other applications (e.g. video players)
//! call Inhibit/UnInhibit to temporarily suppress idle actions.

const std = @import("std");
const posix = std.posix;
const Allocator = std.mem.Allocator;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const c = dbus.types.c;
const BoundedArray = @import("otter_utils").BoundedArray;

const log = std.log.scoped(.screensaver_service);

const service_name = "org.freedesktop.ScreenSaver";
const object_path = "/org/freedesktop/ScreenSaver";
const interface_name = "org.freedesktop.ScreenSaver";

const MAX_INHIBITORS = 64;

pub const ScreenSaverService = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    cookies: BoundedArray(u32, MAX_INHIBITORS) = .{},
    next_cookie: u32 = 1,

    pub fn init(allocator: Allocator) Error!ScreenSaverService {
        var connection = try dbus.Connection.open(allocator, .session);
        errdefer connection.deinit();

        // Request the well-known name (allow replacement so we don't fight other implementations)
        try connection.requestNameFlags(service_name, 1 | 2);

        // Register object handler for method calls
        try connection.addObject(object_path, objectHandler, null);

        log.info("ScreenSaver inhibit service registered", .{});

        return .{
            .connection = connection,
            .allocator = allocator,
        };
    }

    pub fn deinit(self: *ScreenSaverService) void {
        self.connection.releaseName(service_name) catch {};
        self.connection.deinit();
        self.* = undefined;
    }

    pub fn getFd(self: *const ScreenSaverService) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages. Returns true if more messages to process.
    pub fn process(self: *ScreenSaverService) bool {
        return self.connection.process();
    }

    pub fn drain(self: *ScreenSaverService) void {
        self.connection.drain();
    }

    pub fn isInhibited(self: *const ScreenSaverService) bool {
        return self.cookies.len > 0;
    }

    pub fn inhibitCount(self: *const ScreenSaverService) usize {
        return self.cookies.len;
    }

    fn addInhibitor(self: *ScreenSaverService) ?u32 {
        const cookie = self.next_cookie;
        self.next_cookie +%= 1;
        if (self.next_cookie == 0) self.next_cookie = 1;

        self.cookies.append(cookie) catch {
            log.warn("Too many inhibitors (max {})", .{MAX_INHIBITORS});
            return null;
        };

        log.info("Inhibitor added (cookie={d}, active={d})", .{ cookie, self.cookies.len });
        return cookie;
    }

    fn removeInhibitor(self: *ScreenSaverService, cookie: u32) bool {
        for (self.cookies.slice(), 0..) |ck, i| {
            if (ck == cookie) {
                _ = self.cookies.orderedRemove(i);
                log.info("Inhibitor removed (cookie={d}, active={d})", .{ cookie, self.cookies.len });
                return true;
            }
        }
        return false;
    }
};

pub const Error = dbus.types.Error;

/// Global pointer for the object handler callback.
/// Must be set via `setGlobal` before the service processes any messages.
var global_service: ?*ScreenSaverService = null;

pub fn setGlobal(svc: *ScreenSaverService) void {
    global_service = svc;
}

fn objectHandler(
    msg: ?*c.sd_bus_message,
    _: ?*anyopaque,
    ret_error: [*c]c.sd_bus_error,
) callconv(.c) c_int {
    _ = ret_error;
    if (msg == null) return 0;

    const self = global_service orelse return 0;
    const wrapped = dbus.Message.wrap(msg.?);

    if (wrapped.isMethodCall(interface_name, "Inhibit")) {
        return handleInhibit(self, msg.?);
    }

    if (wrapped.isMethodCall(interface_name, "UnInhibit")) {
        return handleUnInhibit(self, msg.?);
    }

    if (wrapped.isMethodCall(interface_name, "GetActive")) {
        return handleGetActive(self, msg.?);
    }

    if (wrapped.isMethodCall("org.freedesktop.DBus.Introspectable", "Introspect")) {
        return handleIntrospect(msg.?);
    }

    return 0;
}

fn handleInhibit(self: *ScreenSaverService, raw: *c.sd_bus_message) c_int {
    var m = dbus.Message.wrap(raw);
    _ = m.readString() catch return dbus.Connection.replyMethodError(raw, "org.freedesktop.DBus.Error.InvalidArgs", "Missing app_name");
    _ = m.readString() catch return dbus.Connection.replyMethodError(raw, "org.freedesktop.DBus.Error.InvalidArgs", "Missing reason");

    const cookie = self.addInhibitor() orelse
        return dbus.Connection.replyMethodError(raw, "org.freedesktop.DBus.Error.LimitsExceeded", "Too many inhibitors");

    var reply = dbus.Connection.newMethodReturn(raw) catch return 0;
    reply.appendUint32(cookie) catch return 0;
    self.connection.send(&reply) catch return 0;
    reply.unref();
    return 1;
}

fn handleUnInhibit(self: *ScreenSaverService, raw: *c.sd_bus_message) c_int {
    var m = dbus.Message.wrap(raw);
    const cookie = m.readUint32() catch return dbus.Connection.replyMethodError(raw, "org.freedesktop.DBus.Error.InvalidArgs", "Missing cookie");

    if (!self.removeInhibitor(cookie)) {
        log.warn("UnInhibit called with unknown cookie {d}", .{cookie});
    }

    return dbus.Connection.replyMethodReturn(raw);
}

fn handleGetActive(self: *ScreenSaverService, raw: *c.sd_bus_message) c_int {
    var reply = dbus.Connection.newMethodReturn(raw) catch return 0;
    reply.appendBool(self.isInhibited()) catch return 0;
    self.connection.send(&reply) catch return 0;
    reply.unref();
    return 1;
}

fn handleIntrospect(raw: *c.sd_bus_message) c_int {
    const xml =
        \\<!DOCTYPE node PUBLIC "-//freedesktop//DTD D-BUS Object Introspection 1.0//EN"
        \\ "http://www.freedesktop.org/standards/dbus/1.0/introspect.dtd">
        \\<node>
        \\  <interface name="org.freedesktop.ScreenSaver">
        \\    <method name="Inhibit">
        \\      <arg name="application_name" type="s" direction="in"/>
        \\      <arg name="reason_for_inhibit" type="s" direction="in"/>
        \\      <arg name="cookie" type="u" direction="out"/>
        \\    </method>
        \\    <method name="UnInhibit">
        \\      <arg name="cookie" type="u" direction="in"/>
        \\    </method>
        \\    <method name="GetActive">
        \\      <arg name="active" type="b" direction="out"/>
        \\    </method>
        \\  </interface>
        \\  <interface name="org.freedesktop.DBus.Introspectable">
        \\    <method name="Introspect">
        \\      <arg name="xml_data" type="s" direction="out"/>
        \\    </method>
        \\  </interface>
        \\</node>
    ;

    var reply = dbus.Connection.newMethodReturn(raw) catch return 0;
    reply.appendString(xml) catch return 0;
    const ret = c.sd_bus_send(null, reply.msg, null);
    reply.unref();
    return if (ret >= 0) 1 else 0;
}

test "ScreenSaverService types compile" {
    _ = ScreenSaverService;
    _ = Error;
}

test "ScreenSaverService initial state" {
    const s = ScreenSaverService{
        .connection = undefined,
        .allocator = std.testing.allocator,
    };
    try std.testing.expect(!s.isInhibited());
    try std.testing.expectEqual(@as(usize, 0), s.inhibitCount());
}

test "cookie tracking" {
    var cookies: BoundedArray(u32, MAX_INHIBITORS) = .{};

    cookies.append(1) catch unreachable;
    cookies.append(2) catch unreachable;
    cookies.append(3) catch unreachable;
    try std.testing.expectEqual(@as(usize, 3), cookies.len);

    for (cookies.slice(), 0..) |ck, i| {
        if (ck == 2) {
            _ = cookies.orderedRemove(i);
            break;
        }
    }
    try std.testing.expectEqual(@as(usize, 2), cookies.len);
    try std.testing.expectEqual(@as(u32, 1), cookies.slice()[0]);
    try std.testing.expectEqual(@as(u32, 3), cookies.slice()[1]);
}
