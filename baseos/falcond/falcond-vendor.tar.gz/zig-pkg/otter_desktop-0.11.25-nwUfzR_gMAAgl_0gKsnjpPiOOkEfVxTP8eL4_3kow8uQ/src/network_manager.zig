//! NetworkManager D-Bus Client
//!
//! Provides access to NetworkManager daemon for network status monitoring and control.
//! Uses D-Bus to communicate with the NetworkManager service on the system bus.
//!
//! D-Bus Service: org.freedesktop.NetworkManager

const std = @import("std");
const Allocator = std.mem.Allocator;
const posix = std.posix;
const SubscriberList = @import("otter_utils").SubscriberList;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.network_manager);
const nm_read = @import("network_manager_read.zig");

/// D-Bus service constants
const nm_service = "org.freedesktop.NetworkManager";
const nm_path = "/org/freedesktop/NetworkManager";
const nm_interface = "org.freedesktop.NetworkManager";
const device_interface = "org.freedesktop.NetworkManager.Device";
const wireless_interface = "org.freedesktop.NetworkManager.Device.Wireless";
const ap_interface = "org.freedesktop.NetworkManager.AccessPoint";
const active_conn_interface = "org.freedesktop.NetworkManager.Connection.Active";
const ip4_interface = "org.freedesktop.NetworkManager.IP4Config";
const statistics_interface = "org.freedesktop.NetworkManager.Device.Statistics";
const settings_interface = "org.freedesktop.NetworkManager.Settings";
const settings_conn_interface = "org.freedesktop.NetworkManager.Settings.Connection";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// NM connectivity state
pub const NmState = enum(u32) {
    unknown = 0,
    asleep = 10,
    disconnected = 20,
    disconnecting = 30,
    connecting = 40,
    connected_local = 50,
    connected_site = 60,
    connected_global = 70,
    _,
};

/// Network device type
pub const DeviceType = enum(u32) {
    unknown = 0,
    ethernet = 1,
    wifi = 2,
    bluetooth = 5,
    wireguard = 14,
    _,
};

/// Network device state
pub const DeviceState = enum(u32) {
    unknown = 0,
    unmanaged = 10,
    unavailable = 20,
    disconnected = 30,
    prepare = 40,
    config_state = 50,
    need_auth = 60,
    ip_config = 70,
    ip_check = 80,
    secondaries = 90,
    activated = 100,
    deactivating = 110,
    failed = 120,
    _,
};

/// Active connection information (fixed-buffer, no heap)
pub const ConnectionInfo = struct {
    name: [64]u8 = undefined,
    name_len: usize = 0,
    iface_name: [64]u8 = undefined,
    iface_name_len: usize = 0,
    device_type: DeviceType = .unknown,
    device_state: DeviceState = .unknown,
    wifi_strength: u8 = 0,
    ssid: [32]u8 = undefined,
    ssid_len: usize = 0,
    wifi_freq: u32 = 0,
    is_vpn: bool = false,
    rx_bytes: u64 = 0,
    tx_bytes: u64 = 0,
    ip_address: [46]u8 = undefined,
    ip_address_len: usize = 0,
    device_path: [256]u8 = undefined,
    device_path_len: usize = 0,
    active_conn_path: [256]u8 = undefined,
    active_conn_path_len: usize = 0,

    pub fn getName(self: *const ConnectionInfo) []const u8 {
        return self.name[0..self.name_len];
    }

    pub fn getIfaceName(self: *const ConnectionInfo) []const u8 {
        return self.iface_name[0..self.iface_name_len];
    }

    pub fn getSsid(self: *const ConnectionInfo) []const u8 {
        return self.ssid[0..self.ssid_len];
    }

    pub fn getIpAddress(self: *const ConnectionInfo) []const u8 {
        return self.ip_address[0..self.ip_address_len];
    }

    pub fn getDevicePath(self: *const ConnectionInfo) []const u8 {
        return self.device_path[0..self.device_path_len];
    }

    pub fn getActiveConnPath(self: *const ConnectionInfo) []const u8 {
        return self.active_conn_path[0..self.active_conn_path_len];
    }

    /// Get WiFi signal level 0-4 using branchless thresholds (20/40/60/80)
    pub fn getSignalLevel(self: *const ConnectionInfo) u8 {
        const s = self.wifi_strength;
        return @as(u8, @intFromBool(s >= 20)) +
            @as(u8, @intFromBool(s >= 40)) +
            @as(u8, @intFromBool(s >= 60)) +
            @as(u8, @intFromBool(s >= 80));
    }
};

/// WiFi network scan result (fixed-buffer, no heap)
pub const WifiNetwork = struct {
    ssid: [32]u8 = undefined,
    ssid_len: usize = 0,
    strength: u8 = 0,
    frequency: u32 = 0,
    secured: bool = false,
    ap_path: [256]u8 = undefined,
    ap_path_len: usize = 0,

    pub fn getSsid(self: *const WifiNetwork) []const u8 {
        return self.ssid[0..self.ssid_len];
    }

    pub fn getApPath(self: *const WifiNetwork) []const u8 {
        return self.ap_path[0..self.ap_path_len];
    }
};

/// Saved/known connection (fixed-buffer, no heap)
pub const SavedConnection = struct {
    name: [64]u8 = undefined,
    name_len: usize = 0,
    conn_type: [32]u8 = undefined,
    conn_type_len: usize = 0,
    conn_path: [256]u8 = undefined,
    conn_path_len: usize = 0,
    is_vpn: bool = false,

    pub fn getName(self: *const SavedConnection) []const u8 {
        return self.name[0..self.name_len];
    }

    pub fn getConnType(self: *const SavedConnection) []const u8 {
        return self.conn_type[0..self.conn_type_len];
    }

    pub fn getConnPath(self: *const SavedConnection) []const u8 {
        return self.conn_path[0..self.conn_path_len];
    }
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscriptions = SubscriberList(StateChangeFn, max_subscribers);
pub const Subscription = Subscriptions.Subscription;

pub const Error = dbus.types.Error || error{
    ParseError,
};

pub const NetworkManager = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    subscriptions: Subscriptions = .{},

    connections: [8]?ConnectionInfo = .{null} ** 8,
    connection_count: usize = 0,

    wifi_networks: [32]?WifiNetwork = .{null} ** 32,
    wifi_network_count: usize = 0,

    saved_connections: [32]?SavedConnection = .{null} ** 32,
    saved_connection_count: usize = 0,

    state: NmState = .unknown,
    wireless_enabled: bool = false,
    available: bool = false,

    /// Aggregate byte counters across all active devices (from Device.Statistics)
    total_rx_bytes: u64 = 0,
    total_tx_bytes: u64 = 0,

    /// Cached WiFi device path (discovered via GetDevices, persists across disconnects)
    wifi_device_path: [256]u8 = undefined,
    wifi_device_path_len: usize = 0,

    /// Initialize the NetworkManager client.
    /// Connects to the system D-Bus.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location
    /// to enable D-Bus signal handling.
    pub fn init(allocator: Allocator) Error!NetworkManager {
        var conn = try dbus.Connection.open(allocator, .system);
        errdefer conn.deinit();

        var self = NetworkManager{
            .connection = conn,
            .allocator = allocator,
        };

        self.refresh() catch |err| {
            switch (err) {
                dbus.types.Error.ServiceUnknown, dbus.types.Error.NameHasNoOwner => {
                    log.info("NetworkManager service not available", .{});
                    self.available = false;
                    return self;
                },
                else => {
                    log.warn("Failed to load initial state: {s}", .{@errorName(err)});
                },
            }
        };

        return self;
    }

    /// Start monitoring for D-Bus property changes.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *NetworkManager) void {
        self.subscribeToSignals() catch |err| {
            log.warn("Failed to subscribe to signals: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *NetworkManager) void {
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const NetworkManager) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    /// Returns true if there are more messages to process.
    pub fn process(self: *NetworkManager) bool {
        return self.connection.process();
    }

    pub fn drain(self: *NetworkManager) void {
        self.connection.drain();
    }

    /// Subscribe to state changes.
    pub fn subscribe(self: *NetworkManager, callback: StateChangeFn, context: ?*anyopaque) bool {
        return self.subscriptions.subscribe(callback, context);
    }

    /// Unsubscribe from state changes.
    pub fn unsubscribe(self: *NetworkManager, callback: StateChangeFn, context: ?*anyopaque) void {
        self.subscriptions.unsubscribe(callback, context);
    }

    /// Check if NM reports global connectivity.
    pub fn isConnected(self: *const NetworkManager) bool {
        return self.state == .connected_global;
    }

    /// Get the device type of the first active (non-VPN) connection.
    pub fn getPrimaryType(self: *const NetworkManager) DeviceType {
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (!conn.is_vpn) return conn.device_type;
            }
        }
        return .unknown;
    }

    /// Get the WiFi device object path (for activateConnection calls).
    pub fn getWifiDevicePath(self: *NetworkManager) ?[:0]const u8 {
        return self.findWifiDevicePath();
    }

    /// Get saved connections slice.
    pub fn getSavedConnections(self: *const NetworkManager) []const ?SavedConnection {
        return self.saved_connections[0..self.saved_connection_count];
    }

    /// Get WiFi signal strength of the first active WiFi connection.
    pub fn getWifiStrength(self: *const NetworkManager) u8 {
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (conn.device_type == .wifi) return conn.wifi_strength;
            }
        }
        return 0;
    }

    /// Get active connections slice.
    pub fn getConnections(self: *const NetworkManager) []const ?ConnectionInfo {
        return self.connections[0..self.connection_count];
    }

    /// Get scanned WiFi networks slice.
    pub fn getWifiNetworks(self: *const NetworkManager) []const ?WifiNetwork {
        return self.wifi_networks[0..self.wifi_network_count];
    }

    /// Re-read byte counters from Device.Statistics for all active devices.
    /// Lightweight poll — does NOT re-enumerate connections.
    pub fn refreshStatistics(self: *NetworkManager) void {
        if (!self.available) return;

        var rx_total: u64 = 0;
        var tx_total: u64 = 0;

        for (self.connections[0..self.connection_count]) |*maybe_conn| {
            if (maybe_conn.*) |*conn| {
                if (conn.is_vpn) continue;
                if (conn.device_path_len <= 1) continue;

                var path_buf: [256:0]u8 = undefined;
                const path_z = toSentinel(&path_buf, conn.device_path[0..conn.device_path_len]) orelse continue;

                // RxBytes
                {
                    var msg = self.connection.getProperty(nm_service, path_z, statistics_interface, "RxBytes") catch continue;
                    defer msg.unref();
                    conn.rx_bytes = msg.readVariantUint64() catch conn.rx_bytes;
                }

                // TxBytes
                {
                    var msg = self.connection.getProperty(nm_service, path_z, statistics_interface, "TxBytes") catch continue;
                    defer msg.unref();
                    conn.tx_bytes = msg.readVariantUint64() catch conn.tx_bytes;
                }

                rx_total += conn.rx_bytes;
                tx_total += conn.tx_bytes;
            }
        }

        self.total_rx_bytes = rx_total;
        self.total_tx_bytes = tx_total;
    }

    // --- Actions ---

    /// Activate a connection. Use "/" for unspecified paths.
    pub fn activateConnection(
        self: *NetworkManager,
        conn_path_z: [:0]const u8,
        device_path_z: [:0]const u8,
        specific_object_z: [:0]const u8,
    ) void {
        var reply = self.connection.callMethodWithThreeObjectPaths(
            nm_service,
            nm_path,
            nm_interface,
            "ActivateConnection",
            conn_path_z,
            device_path_z,
            specific_object_z,
        ) catch |err| {
            log.warn("ActivateConnection failed: {s}", .{@errorName(err)});
            return;
        };
        defer reply.unref();
    }

    /// Deactivate an active connection by its active connection path.
    pub fn deactivateConnection(self: *NetworkManager, active_conn_path_z: [:0]const u8) void {
        var reply = self.connection.callMethodWithObjectPath(
            nm_service,
            nm_path,
            nm_interface,
            "DeactivateConnection",
            active_conn_path_z,
        ) catch |err| {
            log.warn("DeactivateConnection failed: {s}", .{@errorName(err)});
            return;
        };
        defer reply.unref();
    }

    /// Enable or disable wireless networking.
    pub fn setWirelessEnabled(self: *NetworkManager, enabled: bool) void {
        self.connection.setPropertyBool(
            nm_service,
            nm_path,
            nm_interface,
            "WirelessEnabled",
            enabled,
        ) catch |err| log.warn("SetWirelessEnabled failed: {s}", .{@errorName(err)});
    }

    /// Request a WiFi scan on the first wireless device found.
    pub fn requestWifiScan(self: *NetworkManager) void {
        // Find a WiFi device path from active connections
        const wifi_device = self.findWifiDevicePath() orelse {
            log.debug("No WiFi device found for scan", .{});
            return;
        };

        var reply = self.connection.callMethodWithEmptyVariantDict(
            nm_service,
            wifi_device,
            wireless_interface,
            "RequestScan",
        ) catch |err| {
            log.debug("RequestScan failed: {s}", .{@errorName(err)});
            return;
        };
        defer reply.unref();
    }

    /// Refresh the list of available WiFi networks from access points.
    pub fn refreshWifiNetworks(self: *NetworkManager) void {
        self.wifi_network_count = 0;

        const wifi_device = self.findWifiDevicePath() orelse return;

        // GetAccessPoints on the wireless device
        var reply_msg = self.connection.callMethod(
            nm_service,
            wifi_device,
            wireless_interface,
            "GetAccessPoints",
        ) catch return;
        defer reply_msg.unref();

        if (reply_msg.enterArray("o") catch false) {
            while (!reply_msg.atEnd() and self.wifi_network_count < 32) {
                const ap_path = reply_msg.readObjectPath() catch continue;
                var net = WifiNetwork{};
                self.readApProperties(ap_path, &net);
                if (net.ssid_len > 0) {
                    self.wifi_networks[self.wifi_network_count] = net;
                    self.wifi_network_count += 1;
                }
            }
            reply_msg.exitContainer() catch {};
        }
    }

    /// Refresh the list of saved/known connections.
    pub fn refreshSavedConnections(self: *NetworkManager) void {
        self.saved_connection_count = 0;

        var msg = self.connection.callMethod(
            nm_service,
            "/org/freedesktop/NetworkManager/Settings",
            settings_interface,
            "ListConnections",
        ) catch return;
        defer msg.unref();

        if (msg.enterArray("o") catch false) {
            while (!msg.atEnd() and self.saved_connection_count < 32) {
                const conn_path = msg.readObjectPath() catch continue;
                var saved = SavedConnection{};
                copyFixedBuf(&saved.conn_path, &saved.conn_path_len, conn_path);
                self.readSavedConnectionSettings(conn_path, &saved);
                self.saved_connections[self.saved_connection_count] = saved;
                self.saved_connection_count += 1;
            }
            msg.exitContainer() catch {};
        }
    }

    // --- Internal ---

    fn refresh(self: *NetworkManager) Error!void {
        self.refreshState() catch |err| {
            // Propagate service-not-found errors for init to handle
            switch (err) {
                dbus.types.Error.ServiceUnknown, dbus.types.Error.NameHasNoOwner => return err,
                else => {
                    log.debug("Failed to get NM state: {s}", .{@errorName(err)});
                },
            }
        };

        self.refreshWirelessEnabled() catch |err| {
            log.debug("Failed to get WirelessEnabled: {s}", .{@errorName(err)});
        };

        self.refreshActiveConnections() catch |err| {
            switch (err) {
                dbus.types.Error.ServiceUnknown, dbus.types.Error.NameHasNoOwner => return err,
                else => {
                    log.debug("Failed to get active connections: {s}", .{@errorName(err)});
                },
            }
        };

        self.available = true;
    }

    fn refreshState(self: *NetworkManager) Error!void {
        var msg = try self.connection.getProperty(nm_service, nm_path, nm_interface, "State");
        defer msg.unref();

        self.state = @enumFromInt(msg.readVariantUint32() catch return);
    }

    fn refreshWirelessEnabled(self: *NetworkManager) Error!void {
        var msg = try self.connection.getProperty(nm_service, nm_path, nm_interface, "WirelessEnabled");
        defer msg.unref();

        self.wireless_enabled = msg.readVariantBool() catch false;
    }

    fn refreshActiveConnections(self: *NetworkManager) Error!void {
        self.connection_count = 0;

        var msg = try self.connection.getProperty(nm_service, nm_path, nm_interface, "ActiveConnections");
        defer msg.unref();

        if (try msg.enterVariant("ao")) {
            if (try msg.enterArray("o")) {
                while (!msg.atEnd() and self.connection_count < 8) {
                    const conn_path = msg.readObjectPath() catch continue;

                    var info = ConnectionInfo{};
                    copyFixedBuf(&info.active_conn_path, &info.active_conn_path_len, conn_path);
                    self.readActiveConnectionProperties(conn_path, &info);
                    self.connections[self.connection_count] = info;
                    self.connection_count += 1;
                }
                try msg.exitContainer();
            }
            try msg.exitContainer();
        }

        // Aggregate byte counters across all active devices
        var rx_total: u64 = 0;
        var tx_total: u64 = 0;
        for (self.connections[0..self.connection_count]) |maybe_conn| {
            if (maybe_conn) |conn| {
                if (!conn.is_vpn) {
                    rx_total += conn.rx_bytes;
                    tx_total += conn.tx_bytes;
                }
            }
        }
        self.total_rx_bytes = rx_total;
        self.total_tx_bytes = tx_total;

        log.debug("Found {d} active connection(s), state={d}", .{
            self.connection_count,
            @intFromEnum(self.state),
        });
    }

    pub fn readActiveConnectionProperties(self: *NetworkManager, conn_path: []const u8, info: *ConnectionInfo) void {
        nm_read.readActiveConnectionProperties(self, conn_path, info);
    }

    pub fn readDeviceProperties(self: *NetworkManager, dev_path: []const u8, info: *ConnectionInfo) void {
        nm_read.readDeviceProperties(self, dev_path, info);
    }

    pub fn readDeviceStatistics(self: *NetworkManager, device_path_z: [:0]const u8, info: *ConnectionInfo) void {
        nm_read.readDeviceStatistics(self, device_path_z, info);
    }

    pub fn enableDeviceStatistics(self: *NetworkManager, device_path_z: [:0]const u8) void {
        nm_read.enableDeviceStatistics(self, device_path_z);
    }

    pub fn readWifiProperties(self: *NetworkManager, device_path_z: [:0]const u8, info: *ConnectionInfo) void {
        nm_read.readWifiProperties(self, device_path_z, info);
    }

    pub fn readIpAddress(self: *NetworkManager, device_path_z: [:0]const u8, info: *ConnectionInfo) void {
        nm_read.readIpAddress(self, device_path_z, info);
    }

    pub fn readApProperties(self: *NetworkManager, ap_path: []const u8, net: *WifiNetwork) void {
        nm_read.readApProperties(self, ap_path, net);
    }

    pub fn readSavedConnectionSettings(self: *NetworkManager, conn_path: []const u8, saved: *SavedConnection) void {
        nm_read.readSavedConnectionSettings(self, conn_path, saved);
    }

    pub fn readPropString(self: *NetworkManager, path: [:0]const u8, iface: [:0]const u8, prop: [:0]const u8, out: []u8, out_len: *usize) void {
        nm_read.readPropString(self, path, iface, prop, out, out_len);
    }

    pub fn readPropBool(self: *NetworkManager, path: [:0]const u8, iface: [:0]const u8, prop: [:0]const u8, out: *bool) void {
        nm_read.readPropBool(self, path, iface, prop, out);
    }

    pub fn findWifiDevicePath(self: *NetworkManager) ?[:0]const u8 {
        return nm_read.findWifiDevicePath(self);
    }

    pub fn discoverWifiDevice(self: *NetworkManager) void {
        nm_read.discoverWifiDevice(self);
    }

    fn subscribeToSignals(self: *NetworkManager) Error!void {
        // StateChanged signal on NM interface
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.NetworkManager'," ++
                "member='StateChanged'",
            handleStateChanged,
            self,
        );

        // PropertiesChanged on NM interface
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus.Properties'," ++
                "member='PropertiesChanged'," ++
                "path='/org/freedesktop/NetworkManager'," ++
                "arg0='org.freedesktop.NetworkManager'",
            handlePropertiesChanged,
            self,
        );

        // PropertiesChanged on AccessPoint interface (signal strength updates)
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus.Properties'," ++
                "member='PropertiesChanged'," ++
                "arg0='org.freedesktop.NetworkManager.AccessPoint'",
            handleApPropertiesChanged,
            self,
        );

        // PropertiesChanged on Device.Statistics interface (byte counter updates)
        try self.connection.subscribeMatch(
            "type='signal'," ++
                "interface='org.freedesktop.DBus.Properties'," ++
                "member='PropertiesChanged'," ++
                "arg0='org.freedesktop.NetworkManager.Device.Statistics'",
            handleStatisticsChanged,
            self,
        );
    }

    fn handleStateChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;
        self.refresh() catch {};
        self.notify();
    }

    fn handlePropertiesChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;
        self.refresh() catch {};
        self.notify();
    }

    fn handleApPropertiesChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));

        // Get AP path and update WiFi strength for matching connections
        const ap_path = msg.getPath() orelse return;

        // Read the updated strength from the AP
        var strength: u8 = 0;
        var ap_buf: [256:0]u8 = undefined;
        const ap_z = toSentinel(&ap_buf, ap_path) orelse return;

        {
            var prop_msg = self.connection.getProperty(nm_service, ap_z, ap_interface, "Strength") catch return;
            defer prop_msg.unref();
            if (prop_msg.enterVariant("y") catch false) {
                strength = prop_msg.readByte() catch return;
                prop_msg.exitContainer() catch {};
            }
        }

        // Update any connections using this AP
        var changed = false;
        for (&self.connections) |*slot| {
            if (slot.*) |*conn| {
                if (conn.device_type == .wifi) {
                    conn.wifi_strength = strength;
                    changed = true;
                }
            }
        }

        if (changed) self.notify();
    }

    fn handleStatisticsChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *NetworkManager = @ptrCast(@alignCast(ctx orelse return));
        _ = msg;
        // Lightweight refresh: just re-read byte counters, don't re-enumerate
        self.refreshStatistics();
        self.notify();
    }

    fn notify(self: *const NetworkManager) void {
        self.subscriptions.notify();
    }
};

// --- Utility functions ---

/// Copy a slice into a fixed-size buffer with length tracking.
fn copyFixedBuf(buf: []u8, len: *usize, src: []const u8) void {
    const n = @min(src.len, buf.len);
    @memcpy(buf[0..n], src[0..n]);
    len.* = n;
}

/// Create a sentinel-terminated slice from a runtime slice into a stack buffer.
fn toSentinel(buf: *[256:0]u8, src: []const u8) ?[:0]const u8 {
    if (src.len >= 256) return null;
    @memcpy(buf[0..src.len], src);
    buf[src.len] = 0;
    return buf[0..src.len :0];
}

test "NetworkManager types compile" {
    _ = NetworkManager;
    _ = ConnectionInfo;
    _ = WifiNetwork;
    _ = SavedConnection;
    _ = NmState;
    _ = DeviceType;
    _ = DeviceState;
    _ = StateChangeFn;
}

test "ConnectionInfo.getSignalLevel branchless" {
    var info = ConnectionInfo{};
    info.wifi_strength = 0;
    try std.testing.expectEqual(@as(u8, 0), info.getSignalLevel());
    info.wifi_strength = 25;
    try std.testing.expectEqual(@as(u8, 1), info.getSignalLevel());
    info.wifi_strength = 45;
    try std.testing.expectEqual(@as(u8, 2), info.getSignalLevel());
    info.wifi_strength = 65;
    try std.testing.expectEqual(@as(u8, 3), info.getSignalLevel());
    info.wifi_strength = 85;
    try std.testing.expectEqual(@as(u8, 4), info.getSignalLevel());
}
