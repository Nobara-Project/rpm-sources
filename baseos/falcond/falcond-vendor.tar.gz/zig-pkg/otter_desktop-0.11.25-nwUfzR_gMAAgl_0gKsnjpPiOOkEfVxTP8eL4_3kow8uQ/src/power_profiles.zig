//! Power Profiles Daemon D-Bus Client
//!
//! Provides access to power-profiles-daemon for getting/setting power profiles
//! and subscribing to profile change notifications.
//!
//! D-Bus Interface: org.freedesktop.UPower.PowerProfiles
//! Object Path: /org/freedesktop/UPower/PowerProfiles

const std = @import("std");
const Allocator = std.mem.Allocator;
const posix = std.posix;
const SubscriberList = @import("otter_utils").SubscriberList;

const dbus = struct {
    const Connection = @import("dbus/connection.zig").Connection;
    const Message = @import("dbus/message.zig").Message;
    const types = @import("dbus/types.zig");
};

const log = std.log.scoped(.power_profiles);

/// D-Bus service constants
const service = "org.freedesktop.UPower.PowerProfiles";
const object_path = "/org/freedesktop/UPower/PowerProfiles";
const interface = "org.freedesktop.UPower.PowerProfiles";

/// Maximum number of state change subscribers
const max_subscribers = 8;

/// Maximum number of profiles supported
const max_profiles = 8;

/// A power profile with its name and driver.
pub const Profile = struct {
    /// Profile name (e.g., "power-saver", "balanced", "performance")
    name: []const u8,
    /// Driver providing this profile
    driver: []const u8,
};

pub const StateChangeFn = *const fn (ctx: ?*anyopaque) void;

pub const Subscriptions = SubscriberList(StateChangeFn, max_subscribers);
pub const Subscription = Subscriptions.Subscription;

pub const Error = dbus.types.Error || error{
    ProfileNotFound,
    ParseError,
};

pub const PowerProfiles = struct {
    connection: dbus.Connection,
    allocator: Allocator,
    subscriptions: Subscriptions = .{},

    // Cached state
    active_profile: ?[]const u8 = null,
    profiles: [max_profiles]?Profile = .{null} ** max_profiles,
    profile_driver_owned: [max_profiles]bool = .{false} ** max_profiles,
    profile_count: usize = 0,

    /// Initialize the power profiles client.
    /// Connects to the system D-Bus.
    /// NOTE: Call `startMonitoring()` AFTER the struct is in its final memory location
    /// to enable D-Bus signal handling.
    pub fn init(allocator: Allocator) Error!PowerProfiles {
        var conn = try dbus.Connection.open(allocator, .system);
        errdefer conn.deinit();

        var self = PowerProfiles{
            .connection = conn,
            .allocator = allocator,
        };

        // Load initial state (but don't subscribe yet - pointer would be invalid)
        self.refresh() catch |err| {
            log.warn("Failed to load initial state: {s}", .{@errorName(err)});
        };

        return self;
    }

    /// Start monitoring for D-Bus property changes.
    /// MUST be called after the struct is in its final memory location.
    pub fn startMonitoring(self: *PowerProfiles) void {
        self.subscribeToPropertyChanges() catch |err| {
            log.warn("Failed to subscribe to property changes: {s}", .{@errorName(err)});
        };
    }

    pub fn deinit(self: *PowerProfiles) void {
        self.freeCache();
        self.connection.deinit();
        self.* = undefined;
    }

    /// Get the file descriptor for poll integration.
    pub fn getFd(self: *const PowerProfiles) posix.fd_t {
        return self.connection.getFd();
    }

    /// Process pending D-Bus messages.
    /// Call this after poll indicates the FD is readable.
    /// Returns true if there are more messages to process.
    pub fn process(self: *PowerProfiles) bool {
        return self.connection.process();
    }

    pub fn drain(self: *PowerProfiles) void {
        self.connection.drain();
    }

    /// Get the currently active profile name.
    pub fn getActiveProfile(self: *const PowerProfiles) ?[]const u8 {
        return self.active_profile;
    }

    /// Get the list of available profiles.
    pub fn getProfiles(self: *const PowerProfiles) []const ?Profile {
        return self.profiles[0..self.profile_count];
    }

    /// Set the active profile.
    pub fn setActiveProfile(self: *PowerProfiles, profile_name: [:0]const u8) Error!void {
        try self.connection.setPropertyString(
            service,
            object_path,
            interface,
            "ActiveProfile",
            profile_name,
        );

        // Update cache immediately
        self.updateActiveProfileCache(profile_name);
    }

    /// Refresh the cached state from D-Bus.
    pub fn refresh(self: *PowerProfiles) Error!void {
        self.freeCache();

        // Get active profile
        var msg = try self.connection.getProperty(
            service,
            object_path,
            interface,
            "ActiveProfile",
        );
        defer msg.unref();

        if (try msg.enterVariant("s")) {
            const profile = try msg.readString();
            self.active_profile = self.allocator.dupe(u8, profile) catch null;
            try msg.exitContainer();
        }

        // Get available profiles
        var profiles_msg = try self.connection.getProperty(
            service,
            object_path,
            interface,
            "Profiles",
        );
        defer profiles_msg.unref();

        self.parseProfiles(&profiles_msg) catch |err| {
            log.warn("Failed to parse profiles: {s}", .{@errorName(err)});
        };

        log.debug("Loaded {d} profiles, active: {s}", .{
            self.profile_count,
            self.active_profile orelse "unknown",
        });
    }

    /// Subscribe to profile changes.
    pub fn subscribe(self: *PowerProfiles, callback: StateChangeFn, context: ?*anyopaque) bool {
        return self.subscriptions.subscribe(callback, context);
    }

    /// Unsubscribe from profile changes.
    pub fn unsubscribe(self: *PowerProfiles, callback: StateChangeFn, context: ?*anyopaque) void {
        self.subscriptions.unsubscribe(callback, context);
    }

    // Internal methods

    fn subscribeToPropertyChanges(self: *PowerProfiles) Error!void {
        // Match rule for PropertiesChanged signal on our object
        const match_rule =
            "type='signal'," ++
            "interface='org.freedesktop.DBus.Properties'," ++
            "member='PropertiesChanged'," ++
            "path='/org/freedesktop/UPower/PowerProfiles'," ++
            "arg0='org.freedesktop.UPower.PowerProfiles'";

        try self.connection.subscribeMatch(
            match_rule,
            handlePropertyChanged,
            self,
        );
    }

    fn handlePropertyChanged(msg: dbus.Message, ctx: ?*anyopaque) void {
        const self: *PowerProfiles = @ptrCast(@alignCast(ctx orelse return));

        var mutable_msg = msg;

        // Signal signature: PropertiesChanged(s interface_name, a{sv} changed_properties, as invalidated)
        // Skip interface name (we already filtered by arg0)
        mutable_msg.skip("s") catch return;

        // Enter changed_properties dict
        if (mutable_msg.enterArray("{sv}") catch return) {
            while (!mutable_msg.atEnd()) {
                if (mutable_msg.enterDictEntry("sv") catch return) {
                    const prop_name = mutable_msg.readString() catch {
                        mutable_msg.exitContainer() catch {};
                        continue;
                    };

                    if (std.mem.eql(u8, prop_name, "ActiveProfile")) {
                        if (mutable_msg.enterVariant("s") catch false) {
                            if (mutable_msg.readString()) |new_profile| {
                                self.updateActiveProfileCache(new_profile);
                                self.notify();
                            } else |_| {}
                            mutable_msg.exitContainer() catch {};
                        }
                    } else {
                        // Skip other properties
                        mutable_msg.skip("v") catch {};
                    }

                    mutable_msg.exitContainer() catch {};
                }
            }
            mutable_msg.exitContainer() catch {};
        }
    }

    fn updateActiveProfileCache(self: *PowerProfiles, profile: []const u8) void {
        if (self.active_profile) |old| {
            self.allocator.free(old);
        }
        self.active_profile = self.allocator.dupe(u8, profile) catch null;
    }

    fn parseProfiles(self: *PowerProfiles, msg: *dbus.Message) Error!void {
        // Property value is wrapped in a variant
        if (!try msg.enterVariant("aa{sv}")) return;

        // Enter the outer array of profile dicts
        if (!try msg.enterArray("a{sv}")) {
            try msg.exitContainer();
            return;
        }

        self.profile_count = 0;

        while (!msg.atEnd() and self.profile_count < max_profiles) {
            // Enter each profile dict (array of dict entries)
            if (!try msg.enterArray("{sv}")) continue;

            var name: ?[]const u8 = null;
            var driver: ?[]const u8 = null;

            while (!msg.atEnd()) {
                if (!try msg.enterDictEntry("sv")) continue;

                const key = msg.readString() catch {
                    msg.exitContainer() catch {};
                    continue;
                };

                if (std.mem.eql(u8, key, "Profile")) {
                    if (try msg.enterVariant("s")) {
                        name = msg.readString() catch null;
                        try msg.exitContainer();
                    }
                } else if (std.mem.eql(u8, key, "Driver")) {
                    if (try msg.enterVariant("s")) {
                        driver = msg.readString() catch null;
                        try msg.exitContainer();
                    }
                } else {
                    msg.skip("v") catch {};
                }

                try msg.exitContainer(); // dict entry
            }

            try msg.exitContainer(); // profile dict

            if (name) |n| {
                self.appendProfile(n, driver) catch |err| {
                    log.warn("Failed to cache profile {s}: {s}", .{ n, @errorName(err) });
                };
            }
        }

        try msg.exitContainer(); // outer array
        try msg.exitContainer(); // variant
    }

    fn appendProfile(self: *PowerProfiles, name: []const u8, maybe_driver: ?[]const u8) Allocator.Error!void {
        const slot = self.profile_count;
        std.debug.assert(slot < max_profiles);

        const owned_name = try self.allocator.dupe(u8, name);
        errdefer self.allocator.free(owned_name);

        var profile = Profile{
            .name = owned_name,
            .driver = "",
        };
        var driver_owned = false;

        if (maybe_driver) |driver| {
            if (driver.len > 0) {
                profile.driver = try self.allocator.dupe(u8, driver);
                driver_owned = true;
            }
        }

        self.profiles[slot] = profile;
        self.profile_driver_owned[slot] = driver_owned;
        self.profile_count += 1;
    }

    fn freeCache(self: *PowerProfiles) void {
        if (self.active_profile) |profile| {
            self.allocator.free(profile);
            self.active_profile = null;
        }

        for (&self.profiles, &self.profile_driver_owned) |*slot, *driver_owned| {
            if (slot.*) |profile| {
                self.allocator.free(profile.name);
                if (driver_owned.*) {
                    self.allocator.free(profile.driver);
                }
                slot.* = null;
            }
            driver_owned.* = false;
        }
        self.profile_count = 0;
    }

    fn notify(self: *const PowerProfiles) void {
        self.subscriptions.notify();
    }
};

test "PowerProfiles types compile" {
    _ = PowerProfiles;
    _ = Profile;
    _ = StateChangeFn;
}

test "PowerProfiles cache tracks driver ownership explicitly" {
    var client = PowerProfiles{
        .connection = undefined,
        .allocator = std.testing.allocator,
    };

    try client.appendProfile("balanced", null);
    try client.appendProfile("performance", "platform_profile");

    try std.testing.expectEqual(@as(usize, 2), client.profile_count);
    try std.testing.expect(client.profiles[0] != null);
    try std.testing.expect(client.profiles[1] != null);
    try std.testing.expect(!client.profile_driver_owned[0]);
    try std.testing.expect(client.profile_driver_owned[1]);
    try std.testing.expectEqualStrings("", client.profiles[0].?.driver);
    try std.testing.expectEqualStrings("platform_profile", client.profiles[1].?.driver);

    client.freeCache();

    try std.testing.expectEqual(@as(usize, 0), client.profile_count);
    try std.testing.expect(client.profiles[0] == null);
    try std.testing.expect(client.profiles[1] == null);
    try std.testing.expect(!client.profile_driver_owned[0]);
    try std.testing.expect(!client.profile_driver_owned[1]);
}
