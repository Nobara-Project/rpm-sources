const std = @import("std");
const mem = std.mem;

const ns = @import("notification_service.zig");

const FixedString = ns.FixedString;
const Notification = ns.Notification;
const ImageData = ns.ImageData;
const Urgency = ns.Urgency;
const CloseReason = ns.CloseReason;
const Store = ns.Store;
const NotificationService = ns.NotificationService;
const NotifyCallback = ns.NotifyCallback;
const CloseCallback = ns.CloseCallback;
const introspection_xml = @import("notification_introspection.zig").xml;

// -- Notification type tests --

test "FixedString set and get" {
    var fs = FixedString(64){};
    try std.testing.expect(fs.isEmpty());

    fs.set("hello world");
    try std.testing.expectEqualStrings("hello world", fs.get());
    try std.testing.expect(!fs.isEmpty());
}

test "FixedString truncation" {
    var fs = FixedString(4){};
    fs.set("abcdefgh");
    try std.testing.expectEqualStrings("abcd", fs.get());
    try std.testing.expectEqual(@as(usize, 4), fs.len);
}

test "Notification defaults" {
    const n = Notification{};
    try std.testing.expectEqual(@as(u32, 0), n.id);
    try std.testing.expectEqual(Urgency.normal, n.urgency);
    try std.testing.expectEqual(@as(i32, -1), n.expire_timeout_ms);
    try std.testing.expectEqual(@as(u8, 0), n.action_count);
    try std.testing.expect(n.app_name.isEmpty());
    try std.testing.expect(n.summary.isEmpty());
    try std.testing.expect(n.image_path.isEmpty());
    try std.testing.expect(n.image_data == null);
    try std.testing.expect(!n.visible);
}

test "Notification addAction" {
    var n = Notification{};
    n.addAction("default", "Default Action");
    n.addAction("reply", "Reply");

    try std.testing.expectEqual(@as(u8, 2), n.action_count);
    try std.testing.expect(n.hasDefaultAction());

    try std.testing.expectEqualStrings("default", n.actions[0].?.key.get());
    try std.testing.expectEqualStrings("Default Action", n.actions[0].?.label.get());
    try std.testing.expectEqualStrings("reply", n.actions[1].?.key.get());
    try std.testing.expectEqualStrings("Reply", n.actions[1].?.label.get());
}

test "Notification isExpired" {
    var n = Notification{};
    n.expires_at_ms = 1000;
    try std.testing.expect(n.isExpired(1000));
    try std.testing.expect(n.isExpired(2000));

    try std.testing.expect(!n.isExpired(999));

    var n2 = Notification{};
    n2.expires_at_ms = 0;
    try std.testing.expect(!n2.isExpired(999999));
}

test "ImageData alloc and deinit" {
    const allocator = std.testing.allocator;
    const pixels = try allocator.alloc(u8, 16);
    @memset(pixels, 0xFF);

    const img_data = try allocator.create(ImageData);
    img_data.* = .{ .width = 2, .height = 2, .pixels = pixels, .allocator = allocator };

    try std.testing.expectEqual(@as(u32, 2), img_data.width);
    try std.testing.expectEqual(@as(u32, 2), img_data.height);
    try std.testing.expectEqual(@as(usize, 16), img_data.pixels.len);

    img_data.deinit();
    allocator.destroy(img_data);
}

test "Notification deinitImageData clears pointer" {
    const allocator = std.testing.allocator;
    var n = Notification{};

    n.deinitImageData();
    try std.testing.expect(n.image_data == null);

    const pixels = try allocator.alloc(u8, 4);
    @memset(pixels, 0xAB);

    const img_data = try allocator.create(ImageData);
    img_data.* = .{ .width = 1, .height = 1, .pixels = pixels, .allocator = allocator };
    n.image_data = img_data;

    try std.testing.expect(n.image_data != null);
    n.deinitImageData();
    try std.testing.expect(n.image_data == null);
}

test "Urgency enum values match freedesktop spec" {
    try std.testing.expectEqual(@as(u8, 0), @intFromEnum(Urgency.low));
    try std.testing.expectEqual(@as(u8, 1), @intFromEnum(Urgency.normal));
    try std.testing.expectEqual(@as(u8, 2), @intFromEnum(Urgency.critical));
}

test "CloseReason enum values match freedesktop spec" {
    try std.testing.expectEqual(@as(u32, 1), @intFromEnum(CloseReason.expired));
    try std.testing.expectEqual(@as(u32, 2), @intFromEnum(CloseReason.dismissed));
    try std.testing.expectEqual(@as(u32, 3), @intFromEnum(CloseReason.closed_by_call));
    try std.testing.expectEqual(@as(u32, 4), @intFromEnum(CloseReason.undefined));
}

// -- Store tests --

fn makeNotif(urgency: Urgency, expires_at: i64) Notification {
    var n = Notification{};
    n.urgency = urgency;
    n.expires_at_ms = expires_at;
    return n;
}

test "Store add and get" {
    var s = Store.init(5);
    const id = s.add(makeNotif(.normal, 0)).?;

    try std.testing.expectEqual(@as(u32, 1), id);
    try std.testing.expectEqual(@as(u32, 1), s.count);

    const n = s.get(id).?;
    try std.testing.expectEqual(@as(u32, 1), n.id);
    try std.testing.expectEqual(Urgency.normal, n.urgency);
}

test "Store auto-increments IDs" {
    var s = Store.init(5);
    const id1 = s.add(makeNotif(.normal, 0)).?;
    const id2 = s.add(makeNotif(.normal, 0)).?;

    try std.testing.expectEqual(@as(u32, 1), id1);
    try std.testing.expectEqual(@as(u32, 2), id2);
}

test "Store remove" {
    var s = Store.init(5);
    const id = s.add(makeNotif(.normal, 0)).?;
    const reason = s.remove(id);

    try std.testing.expectEqual(CloseReason.closed_by_call, reason.?);
    try std.testing.expectEqual(@as(u32, 0), s.count);
    try std.testing.expect(s.get(id) == null);
}

test "Store visibility limit" {
    var s = Store.init(2);
    _ = s.add(makeNotif(.normal, 0));
    _ = s.add(makeNotif(.normal, 0));
    _ = s.add(makeNotif(.normal, 0));

    try std.testing.expectEqual(@as(u32, 2), s.visibleCount());
    try std.testing.expectEqual(@as(u32, 3), s.count);
}

test "Store critical notifications always visible" {
    var s = Store.init(2);

    _ = s.add(makeNotif(.normal, 0));
    _ = s.add(makeNotif(.normal, 0));

    const crit_id = s.add(makeNotif(.critical, 0)).?;

    const crit = s.get(crit_id).?;
    try std.testing.expect(crit.visible);

    try std.testing.expectEqual(@as(u32, 2), s.visibleCount());

    const visible = s.getVisible();
    try std.testing.expectEqual(@as(u32, crit_id), visible[0].id);
}

test "Store replace preserves visibility" {
    var s = Store.init(5);
    const id = s.add(makeNotif(.normal, 0)).?;

    const before = s.get(id).?;
    try std.testing.expect(before.visible);

    var replacement = makeNotif(.low, 5000);
    replacement.summary.set("updated summary");
    _ = s.replace(id, replacement);

    const after = s.get(id).?;
    try std.testing.expect(after.visible);
    try std.testing.expectEqual(Urgency.low, after.urgency);
    try std.testing.expectEqualStrings("updated summary", after.summary.get());
    try std.testing.expectEqual(@as(i64, 5000), after.expires_at_ms);
}

test "Store removeExpired" {
    var s = Store.init(5);

    _ = s.add(makeNotif(.normal, 1000));
    _ = s.add(makeNotif(.normal, 3000));

    const removed = s.removeExpired(2000);
    try std.testing.expectEqual(@as(u32, 1), removed);
    try std.testing.expectEqual(@as(u32, 1), s.count);
}

test "Store nextExpiryMs" {
    var s = Store.init(5);

    _ = s.add(makeNotif(.normal, 5000));
    _ = s.add(makeNotif(.normal, 2000));

    const earliest = s.nextExpiryMs().?;
    try std.testing.expectEqual(@as(i64, 2000), earliest);
}

test "Store full returns null" {
    var s = Store.init(5);

    for (0..ns.max_capacity) |_| {
        const id = s.add(makeNotif(.normal, 0));
        try std.testing.expect(id != null);
    }

    const overflow = s.add(makeNotif(.normal, 0));
    try std.testing.expect(overflow == null);
    try std.testing.expectEqual(@as(u32, ns.max_capacity), s.count);
}

// -- D-Bus service tests --

test "getMonotonicMs returns positive value" {
    const ms = ns.getMonotonicMs();
    try std.testing.expect(ms > 0);
}

test "NotificationService types compile" {
    _ = NotificationService;
    _ = NotifyCallback;
    _ = CloseCallback;
}

test "introspection xml is well-formed" {
    const xml: []const u8 = mem.span(introspection_xml);
    try std.testing.expect(mem.startsWith(u8, xml, "<!DOCTYPE"));
    try std.testing.expect(mem.indexOf(u8, xml, "Notify") != null);
    try std.testing.expect(mem.indexOf(u8, xml, "CloseNotification") != null);
    try std.testing.expect(mem.indexOf(u8, xml, "GetCapabilities") != null);
    try std.testing.expect(mem.indexOf(u8, xml, "GetServerInformation") != null);
    try std.testing.expect(mem.indexOf(u8, xml, "NotificationClosed") != null);
    try std.testing.expect(mem.indexOf(u8, xml, "ActionInvoked") != null);
}

test "service constants" {
    try std.testing.expectEqualStrings("org.freedesktop.Notifications", ns.service_name);
    try std.testing.expectEqualStrings("/org/freedesktop/Notifications", ns.object_path);
    try std.testing.expectEqualStrings("org.freedesktop.Notifications", ns.notifications_interface);
}
